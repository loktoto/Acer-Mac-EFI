/*
 * Copyright (C) 2020  钟先耀
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
/*    $OpenBSD: if_iwx.c,v 1.45 2020/10/11 07:05:28 mpi Exp $    */

/*
 * Copyright (c) 2014, 2016 genua gmbh <info@genua.de>
 *   Author: Stefan Sperling <stsp@openbsd.org>
 * Copyright (c) 2014 Fixup Software Ltd.
 * Copyright (c) 2017, 2019, 2020 Stefan Sperling <stsp@openbsd.org>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*-
 * Based on BSD-licensed source modules in the Linux iwlwifi driver,
 * which were used as the reference documentation for this implementation.
 *
 ******************************************************************************
 *
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2017 Intel Deutschland GmbH
 * Copyright(c) 2018 - 2019 Intel Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * BSD LICENSE
 *
 * Copyright(c) 2017 Intel Deutschland GmbH
 * Copyright(c) 2018 - 2019 Intel Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  * Neither the name Intel Corporation nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 */

/*-
 * Copyright (c) 2007-2010 Damien Bergamini <damien.bergamini@free.fr>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifdef AIRPORT_WCL
#include "../../ForbiddenItlwm/WCL/WCL.hpp"
#endif
#include "ItlIwx.hpp"
#include <linux/types.h>
#include <linux/kernel.h>
#include <FwData.h>
#include <AWDLFrameParser.hpp>
#include <AWDLFrameBuilder.hpp>
#include <AWDLProbePolicy.hpp>
#include <AWDLObservation.hpp>
#include <AWDLPeerProbe.hpp>
#include <AWDLPeerSchedule.hpp>
#include <AWDLDataFrame.hpp>
#include <AWDLRegulatory.hpp>
#include <AWDLBlockAck.hpp>
#include <AWDLServiceMerge.hpp>
#include <AWDLSameChannelProbe.hpp>

// The firmware station for the AWDL peer, used by -itlawdlba.
constexpr uint8_t kAwdlBaStationId = 3;

// Channels whose NVM/LAR entry has IWX_NVM_CHANNEL_GO_CONCURRENT ("GO operation is allowed when connected to
// BSS"), filled by iwx_init_channel_map. The listener may treat such a passive channel as usable while the
// station is associated on the same channel or in the same 5 GHz UNII sub-band, as Linux does for
// IEEE80211_CHAN_IR_CONCURRENT (cfg80211_ir_permissive_check_wdev). -itlawdlnoirconcurrent turns it off.
static uint8_t awdlCoexIrConcurrent[howmany(IEEE80211_CHAN_MAX + 1, NBBY)];
static bool awdlCoexIrConcurrentOff;
static uint32_t awdlCoexIrConcurrentUsed; // Channel checks that passed only because of this rule.
// -itlawdlcoextx: the second context's own station (the monitor's number, unused in station mode)
// and queue, for AWDL frames sent beside Wi-Fi.
static bool awdlCoexTx;
static int awdlCoexQueue = -1;
static int awdlCoexBaTxQueue = -1, awdlCoexBaTxResetting = -1;
// -itlawdlcoexmulti: the listener gets the spare PHY context and its own binding on another channel (6
// for now), and the firmware, which manages time quotas itself (DYNAMIC_QUOTA), shares the radio between
// it and the station. Without it, or if that channel can't be used, the listener shares the station's.
constexpr int kAwdlCoexPhyId = 1;
static bool awdlCoexMulti, awdlCoexMultiActive;
static const char *awdlCoexMultiState = "off";
static uint32_t awdlCoexPhyResult, awdlCoexMultiBindResult;
// The listener's PHY context width. It applies only while that context's own command is being built:
// each PHY command records which context it builds before computing the width, so a station command
// built while ours waits can't pick it up.
static int awdlCoexPhyWidth = -1; // Only while our own PHY command is being built; -1 otherwise.
// Stage 2: the listener's own channel moves between 149 at 80 MHz and 6 at 20 MHz as the firmware's channel
// map allows. Its ACK and frame rates follow that channel's band, not the BSS's.
static struct ieee80211_channel *awdlCoexOwnChan;
static int awdlCoexOwnWidth = -1, awdlCoexWide80FailedGen = -1, awdlCoexCountryGen = -1;
static uint32_t awdlCoexMoves, awdlCoexMoveFailures, awdlCoexCountryNotices, awdlCoexCountryAnswers;
static uint32_t awdlCoexCountryLastStatus, awdlCoexCountryAnswerSeconds;
static uint16_t awdlCoexCountryNotice, awdlCoexCountryAnswered;
static uint8_t awdlCoexCountrySource, awdlCoexCountrySourceAnswered;
static bool awdlCoexCountryPending, awdlCoexCountryLearned;
// Bits 0-3: a beacon hint on 149, 153, 157, 161; bit 4: on 6; bits 8-11: on 36, 40, 44, 48
// (ITLAWDLCoexBeaconHints).
static uint32_t awdlCoexBeaconHints;
// Apple's AWDL 5 GHz channel, as the phone's own channel sequence (TLV 18) shows it: 149 where the country
// allows it, else 44 (Japan, for example). The listener follows it, as a Mac would. 0 until a peer is heard.
// It lapses after kAwdlCoexPeer5GLifeUS without a frame. It's kept across firmware restarts.
static uint8_t awdlCoexPeer5G;
static uint64_t awdlCoexPeer5GUS;
static uint32_t awdlCoexPeer5GFrames, awdlCoexPeer5GChanges;
constexpr uint64_t kAwdlCoexPeer5GLifeUS = 600000000ULL;
// The first channel of the 80 MHz block a listener channel belongs to: 149-161 or 36-48. 0 otherwise.
static inline unsigned awdlCoex80BlockFirst(unsigned ch)
{
    if (ch >= 149 && ch <= 161 && (ch - 149) % 4 == 0) return 149;
    if (ch >= 36 && ch <= 48 && ch % 4 == 0) return 36;
    return 0;
}
static uint64_t awdlCoexLastMoveUS;
// A move between two usable 5 GHz channels waits for a choice that held this long, and for this long
// without AWDL data (#68). ITLAWDLCoexMovesSettleDropped counts choices that changed before they settled.
static constexpr uint64_t kAwdlCoexMoveSettleUS = 60000000ULL, kAwdlCoexMoveQuietUS = 30000000ULL;
static int awdlCoexSettleWant, awdlCoexSettleGen = -1;
static uint8_t awdlCoexSettleWidth;
static uint64_t awdlCoexSettleSinceUS;
static uint32_t awdlCoexMovesSettleDropped;
// A move waits for the listener's ring to drain; nothing new is submitted meanwhile (iface129 review, 1).
static bool awdlCoexMovePending;
static bool awdlCoexData; // -itlawdlcoexdata
// -itlawdlcoexbatx: send Block Ack on the listener. Off by default from iface139: on iface138 the phone
// agreed twice but the firmware reported no Block Ack for the queue, and Mac to iPhone stalled.
static bool awdlCoexBaTxEnabled, awdlCoexBaPeerPauseEnabled;
static uint32_t awdlCoexAdvertise80Frames;
static uint64_t awdlCoexMovePendingUS, awdlCoexCountryRetryUS;
static uint32_t awdlCoexMoveDrainTimeouts, awdlCoexCountryFailures;
static int awdlPhyBuildingId = -1;
// A PHY command for the listener's context that failed without a readable answer leaves it uncertain;
// the own channel isn't used again until the firmware restarts.
static int awdlCoexPhyUncertainGen = -1;
// An add in progress (its generation), and a removal that arrived meanwhile: the add rolls back.
static int awdlCoexAddingGen = -1;
static uint32_t awdlCoexAddingOwner, awdlCoexAddingNext;
static bool awdlCoexRemoveRequested;
// -itlawdlsamples: raw frame samples in the registry. They can hold addresses and service records, and
// any local user can read the registry, so they are off unless asked for.
static bool awdlRawSamples;
// A queue whose teardown failed, kept so a reset or late completion still knows it is the listener's.
static int awdlCoexOrphanQueue = -1;
// Set by setup just before it asks for the queue: TVQM checks them after the firmware's answer, before it
// adopts a host ring, so a stale answer can't install one.
static uint32_t awdlReclaimRefused; // Completion boundaries refused by iwx_txq_reclaim_ok.
static uint32_t awdlCoexSetupToken;
static int awdlCoexSetupGen = -1;
// Covers station creation through queue allocation and any cancellation rollback.
static int awdlCoexTxSettingUpGen = -1;
static uint32_t awdlCoexTxSettingUpOwner, awdlCoexTxSettingUpNext;
// Station eligibility is published only after net80211 commits a successful RUN.
// A failed transition leaves it withdrawn until a later successful RUN/restart.
static int awdlCoexStationReadyGen = -1, awdlCoexStationTransitionGen = -1;
static uint32_t awdlCoexStationTransitionOwner, awdlCoexStationTransitionNext;
static bool awdlCoexSetupCurrent(int generation);
static bool awdlCoexBaQueueCurrent(int generation, uint32_t listener, uint32_t peer);
// Where its last queue allocation stopped, and the number the firmware gave.
static const char *awdlCoexQueueStage = "none";
static int awdlCoexQueueAssigned = -1;
static uint32_t awdlCoexQueueWritePointer = 0xffffffffU;
#include <AWDLTxBurst.hpp>
static void awdlLog(const char *, ...);
static void awdlTxLog(const char *, ...);
static void awdlStopTimers();
#include <crypto/sha1.h>

#include <IOKit/IOInterruptController.h>
#include <IOKit/IOCommandGate.h>
#include <IOKit/network/IONetworkMedium.h>
#include <net/ethernet.h>

#include <sys/_task.h>
#include <sys/pcireg.h>
#include <net80211/ieee80211_priv.h>
#include <pexpert/pexpert.h>

#define super ItlHalService
OSDefineMetaClassAndStructors(ItlIwx, ItlHalService)

#define DEVNAME(_s)    ((_s)->sc_dev.dv_xname)

#define IC2IFP(_ic_) (&(_ic_)->ic_if)

#define IWX_DEBUG

#ifdef IWX_DEBUG
#define DPRINTF(x)    do { if (iwx_debug > 0) XYLog x; } while (0)
#define DPRINTFN(n, x)    do { if (iwx_debug >= (n)) XYLog x; } while (0)
int iwx_debug = 1;
#else
#define DPRINTF(x)    do { ; } while (0)
#define DPRINTFN(n, x)    do { ; } while (0)
#endif

bool ItlIwx::attach(IOPCIDevice *device)
{
    com.qfullmsk.reset();
    pci.pa_tag = device;
    pci.workloop = getMainWorkLoop();
#ifdef AIRPORT_VTD
    if (!prepareDma(device, 36))
        return false;
    pci.pa_dmat = dmaArena;
#endif
    if (!iwx_attach(&com, &pci)) {
        detach(device);     // detach ends with releaseAll() (audit HL04: it ran twice)
        return false;
    }
    return true;
}

void ItlIwx::
detach(IOPCIDevice *device)
{
    // The AWDL timers and their tasks are global and take the softc: stop them before anything goes. The
    // flag and all three frees run as one gated action, so no gated task sees the flag clear and then a
    // freed timer (audit P-H02; each timer call was already gated and a freed timer can't be re-armed).
    //
    // Then quiesce, in every build, before any ring or DMA memory is freed: no interrupt, task or transmit
    // may touch them afterwards. This used to be VT-d only, so the Sonoma kext (built without AIRPORT_VTD)
    // freed the rings with the interrupt source and both task queues still live (audit HL01).
    //
    // The gate is looked up once. Without one (a start that failed before the HAL was given its
    // controller) both steps run directly: nothing else can be running on the device then (audit F02).
    auto stopTimers = [](OSObject *, void *, void *, void *, void *) -> IOReturn {
        awdlStopTimers();
        return kIOReturnSuccess;
    };
    auto quiesce = [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
        auto that = static_cast<ItlIwx *>(arg0);
        auto pci = static_cast<IOPCIDevice *>(arg1);
        that->dmaDetaching = true;
        that->dmaEpoch++;
        that->com.sc_ic.ic_ac.ac_if.if_flags &= ~(IFF_UP | IFF_RUNNING);
        that->com.sc_ic.ic_state = IEEE80211_S_INIT;
        timeout_del(&that->com.sc_ic.ic_bgscan_timeout);
        that->com.sc_flags |= IWX_FLAG_SHUTDOWN;
        that->com.sc_generation++;
        // Wake anything waiting on an in-flight listener add or TX setup (PR #12): with the generation
        // bumped it sees the shutdown and rolls back.
        if (IOCommandGate *g = that->getMainCommandGate())
            g->commandWakeup(&awdlCoexAddingGen);
        if (pci)
            pci->setBusMasterEnable(false);
        auto intr = that->com.ih;
        if (intr && intr->intr)
            intr->intr->disable();
        for (unsigned int i = 0; i < nitems(that->com.txq); i++)
            that->iwx_reset_tx_ring(&that->com, &that->com.txq[i]);
        return kIOReturnSuccess;
    };
    IOCommandGate *gate = getMainCommandGate();
    if (gate) {
        gate->runAction(stopTimers);
        gate->runAction(quiesce, this, device);
    } else {
        stopTimers(nullptr, nullptr, nullptr, nullptr, nullptr);
        quiesce(nullptr, this, device, nullptr, nullptr);
    }
    struct _ifnet *ifp = &com.sc_ic.ic_ac.ac_if;
    struct iwx_softc *sc = &com;
    // Interrupt source and task queues go before the rings, in every build (audit HL01).
    releaseAll();
    taskq_destroy(systq);
    taskq_destroy(com.sc_nswq);
    
    for (int txq_i = 0; txq_i < nitems(sc->txq); txq_i++)
        iwx_free_tx_ring(sc, &sc->txq[txq_i]);
    iwx_free_rx_ring(sc, &sc->rxq);
    iwx_dma_contig_free(&sc->ict_dma);
    iwx_dma_contig_free(&com.ctxt_info_dma);
#ifdef AIRPORT_VTD
    iwx_ctxt_info_free_fw_img(sc);
    iwx_ctxt_info_free_paging(sc);
    iwx_dma_contig_free(&sc->prph_info_dma);
    iwx_dma_contig_free(&sc->prph_scratch_dma);
    iwx_dma_contig_free(&sc->iml_dma);
    iwx_dma_contig_free(&sc->pnvm_dram);
    iwx_dma_contig_free(&sc->fw_mon);
    if (sc->sc_dmat)
        sc->sc_dmat->reclaim();
#endif
    ieee80211_ifdetach(ifp);
    releaseAll();
}

void ItlIwx::
releaseAll()
{
    pci_intr_handle *intrHandler = com.ih;
    
    if (intrHandler) {
        if (intrHandler->intr && intrHandler->workloop) {
//            intrHandler->intr->disable();
            intrHandler->workloop->removeEventSource(intrHandler->intr);
            intrHandler->intr->release();
        }
        intrHandler->intr = NULL;
        intrHandler->workloop = NULL;
        intrHandler->arg = NULL;
        intrHandler->dev = NULL;
        intrHandler->func = NULL;
        intrHandler->release();
        com.ih = NULL;
    }
    pci.pa_tag = NULL;
    pci.workloop = NULL;
}

void ItlIwx::free()
{
    XYLog("%s\n", __FUNCTION__);
    super::free();
}

ItlDriverInfo *ItlIwx::
getDriverInfo()
{
    return this;
}

ItlDriverController *ItlIwx::
getDriverController()
{
    return this;
}

IOReturn ItlIwx::enable(IONetworkInterface *netif)
{
    XYLog("%s\n", __PRETTY_FUNCTION__);
    struct _ifnet *ifp = &com.sc_ic.ic_ac.ac_if;
    if (ifp->if_flags & IFF_UP) {
        XYLog("%s already in activating state\n", __FUNCTION__);
        return kIOReturnSuccess;
    }
    ifp->if_flags |= IFF_UP;
    iwx_activate(&com, DVACT_RESUME);
    iwx_activate(&com, DVACT_WAKEUP);
    return kIOReturnSuccess;
}

IOReturn ItlIwx::disable(IONetworkInterface *netif)
{
    XYLog("%s\n", __FUNCTION__);
    struct _ifnet *ifp = &com.sc_ic.ic_ac.ac_if;
    if (!(ifp->if_flags & IFF_UP)) {
        XYLog("%s already in diactivating state\n", __FUNCTION__);
        return kIOReturnSuccess;
    }
    ifp->if_flags &= ~IFF_UP;
    iwx_activate(&com, DVACT_QUIESCE);
    return kIOReturnSuccess;
}

void ItlIwx::
clearScanningFlags()
{
    com.sc_flags &= ~(IWX_FLAG_SCANNING | IWX_FLAG_BGSCAN);
}

IOReturn ItlIwx::
setMulticastList(IOEthernetAddress *addr, int count)
{
    struct ieee80211com *ic = &com.sc_ic;
    struct iwx_mcast_filter_cmd *cmd;
    int len;
    uint8_t addr_count;
    int err;
    
    if (ic->ic_state != IEEE80211_S_RUN || ic->ic_bss == NULL)
        return kIOReturnError;
    addr_count = count;
    if (count > IWX_MAX_MCAST_FILTERING_ADDRESSES)
        addr_count = 0;
    if (addr == NULL)
        addr_count = 0;
    len = roundup(sizeof(struct iwx_mcast_filter_cmd) + addr_count * ETHER_ADDR_LEN, 4);
    XYLog("%s multicast count=%d bssid=%s\n", __FUNCTION__, count, ether_sprintf(ic->ic_bss->ni_bssid));
    cmd = (struct iwx_mcast_filter_cmd *)malloc(len, 0, 0);
    if (!cmd)
        return kIOReturnError;
    cmd->pass_all = addr_count == 0;
    cmd->count = addr_count;
    cmd->port_id = 0;
    IEEE80211_ADDR_COPY(cmd->bssid, ic->ic_bss->ni_bssid);
    if (addr_count > 0)
        memcpy(cmd->addr_list,
               addr->bytes, ETHER_ADDR_LEN * cmd->count);
    err = iwx_send_cmd_pdu(&com, IWX_MCAST_FILTER_CMD, IWX_CMD_ASYNC, len,
                     cmd);
    ::free(cmd);
    return err ? kIOReturnError : kIOReturnSuccess;
}

const char *ItlIwx::
getFirmwareVersion()
{
    return com.sc_fwver;
}

const char *ItlIwx::
getFirmwareName()
{
    return com.sc_fwname;
}

UInt32 ItlIwx::
supportedFeatures()
{
    return kIONetworkFeatureMultiPages;
}

const char *ItlIwx::
getFirmwareCountryCode()
{
    return com.sc_fw_mcc;
}

uint32_t ItlIwx::
getTxQueueSize()
{
    return com.sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? IWX_TFD_QUEUE_SIZE_MAX_GEN3 : IWX_DEFAULT_QUEUE_SIZE;
}

int16_t ItlIwx::
getBSSNoise()
{
    return com.sc_noise;
}

bool ItlIwx::
is5GBandSupport()
{
    return com.sc_nvm.sku_cap_band_52GHz_enable;
}

int ItlIwx::
getTxNSS()
{
    if (com.sc_ic.ic_bss && (com.sc_ic.ic_bss->ni_flags & IEEE80211_NODE_HE) &&
        com.sc_ic.ic_bss->ni_he_tx_nss)
        return com.sc_ic.ic_bss->ni_he_tx_nss;
    return iwx_mimo_enabled(&com) && 
    (com.sc_ic.ic_bss != NULL && com.sc_ic.ic_bss->ni_rx_nss > 1) ? 2 : 1;
}

struct ieee80211com *ItlIwx::
get80211Controller()
{
    return &com.sc_ic;
}

#define MUL_NO_OVERFLOW    (1UL << (sizeof(size_t) * 4))

#define    M_CANFAIL    0x0004
void *ItlIwx::
mallocarray(size_t nmemb, size_t size, int type, int flags)
{
    if ((nmemb >= MUL_NO_OVERFLOW || size >= MUL_NO_OVERFLOW) &&
        nmemb > 0 && SIZE_MAX / nmemb < size) {
        if (flags & M_CANFAIL)
            return (NULL);
        panic("mallocarray: overflow %zu * %zu", nmemb, size);
    }
    return (malloc(size * nmemb, type, flags));
}

const uint8_t iwx_nvm_channels_8000[] = {
    /* 2.4 GHz */
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
    /* 5 GHz */
    36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92,
    96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,
    149, 153, 157, 161, 165, 169, 173, 177, 181
};

static const uint8_t iwx_nvm_channels_uhb[] = {
   /* 2.4 GHz */
   1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
   /* 5 GHz */
   36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92,
   96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,
   149, 153, 157, 161, 165, 169, 173, 177, 181,
#ifdef notyet
   /* 6-7 GHz */
   1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69,
   73, 77, 81, 85, 89, 93, 97, 101, 105, 109, 113, 117, 121, 125, 129,
   133, 137, 141, 145, 149, 153, 157, 161, 165, 169, 173, 177, 181, 185,
   189, 193, 197, 201, 205, 209, 213, 217, 221, 225, 229, 233
#endif
};

#define IWX_NUM_2GHZ_CHANNELS    14
#define IWX_FIRST_2GHZ_HT_MINUS        5
#define IWX_LAST_2GHZ_HT_PLUS        9

const struct iwx_rate {
    uint16_t rate;
    uint8_t plcp;
    uint8_t ht_plcp;
} iwx_rates[] = {
    /* Legacy */        /* HT */
    {   2,    IWX_RATE_1M_PLCP,    IWX_RATE_HT_SISO_MCS_INV_PLCP  },
    {   4,    IWX_RATE_2M_PLCP,    IWX_RATE_HT_SISO_MCS_INV_PLCP },
    {  11,    IWX_RATE_5M_PLCP,    IWX_RATE_HT_SISO_MCS_INV_PLCP  },
    {  22,    IWX_RATE_11M_PLCP,    IWX_RATE_HT_SISO_MCS_INV_PLCP },
    {  12,    IWX_RATE_6M_PLCP,    IWX_RATE_HT_SISO_MCS_0_PLCP },
    {  18,    IWX_RATE_9M_PLCP,    IWX_RATE_HT_SISO_MCS_INV_PLCP  },
    {  24,    IWX_RATE_12M_PLCP,    IWX_RATE_HT_SISO_MCS_1_PLCP },
    {  26,    IWX_RATE_12M_PLCP,    IWX_RATE_HT_MIMO2_MCS_8_PLCP },
    {  36,    IWX_RATE_18M_PLCP,    IWX_RATE_HT_SISO_MCS_2_PLCP },
    {  48,    IWX_RATE_24M_PLCP,    IWX_RATE_HT_SISO_MCS_3_PLCP },
    {  52,    IWX_RATE_24M_PLCP,    IWX_RATE_HT_MIMO2_MCS_9_PLCP },
    {  72,    IWX_RATE_36M_PLCP,    IWX_RATE_HT_SISO_MCS_4_PLCP },
    {  78,    IWX_RATE_36M_PLCP,    IWX_RATE_HT_MIMO2_MCS_10_PLCP },
    {  96,    IWX_RATE_48M_PLCP,    IWX_RATE_HT_SISO_MCS_5_PLCP },
    { 104,    IWX_RATE_48M_PLCP,    IWX_RATE_HT_MIMO2_MCS_11_PLCP },
    { 108,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_SISO_MCS_6_PLCP },
    { 128,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_SISO_MCS_7_PLCP },
    { 156,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_MIMO2_MCS_12_PLCP },
    { 208,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_MIMO2_MCS_13_PLCP },
    { 234,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_MIMO2_MCS_14_PLCP },
    { 260,    IWX_RATE_54M_PLCP,    IWX_RATE_HT_MIMO2_MCS_15_PLCP },
};
#define IWX_RIDX_CCK    0
#define IWX_RIDX_OFDM    4
#define IWX_RIDX_MAX    (nitems(iwx_rates)-1)
#define IWX_RIDX_IS_CCK(_i_) ((_i_) < IWX_RIDX_OFDM)
#define IWX_RIDX_IS_OFDM(_i_) ((_i_) >= IWX_RIDX_OFDM)
#define IWX_RVAL_IS_OFDM(_i_) ((_i_) >= 12 && (_i_) != 22)

/* Convert an MCS index into an iwx_rates[] index. */
const int iwx_mcs2ridx[] = {
    IWX_RATE_MCS_0_INDEX,
    IWX_RATE_MCS_1_INDEX,
    IWX_RATE_MCS_2_INDEX,
    IWX_RATE_MCS_3_INDEX,
    IWX_RATE_MCS_4_INDEX,
    IWX_RATE_MCS_5_INDEX,
    IWX_RATE_MCS_6_INDEX,
    IWX_RATE_MCS_7_INDEX,
    IWX_RATE_MCS_8_INDEX,
    IWX_RATE_MCS_9_INDEX,
    IWX_RATE_MCS_10_INDEX,
    IWX_RATE_MCS_11_INDEX,
    IWX_RATE_MCS_12_INDEX,
    IWX_RATE_MCS_13_INDEX,
    IWX_RATE_MCS_14_INDEX,
    IWX_RATE_MCS_15_INDEX,
};
#define IWX_LAST_HE_RATE IWX_RATE_MCS_11_INDEX
#define IWL_RATE_COUNT IWX_LAST_HE_RATE
#define IWX_MAX_MCS_DISPLAY_SIZE    12

#define IWL_RATE_60M_PLCP 3

enum {
    IWX_RATE_INVM_INDEX = IWX_RATE_COUNT,
    IWX_RATE_INVALID = IWX_RATE_COUNT,
};

struct iwx_rate_mcs_info {
    char    mbps[IWX_MAX_MCS_DISPLAY_SIZE];
    char    mcs[IWX_MAX_MCS_DISPLAY_SIZE];
};

/* mbps, mcs */
static const struct iwx_rate_mcs_info iwx_rate_mcs[IWX_RATE_COUNT] = {
    {  "1", "BPSK DSSS"},
    {  "2", "QPSK DSSS"},
    {"5.5", "BPSK CCK"},
    { "11", "QPSK CCK"},
    {  "6", "BPSK 1/2"},
    {  "9", "BPSK 1/2"},
    { "12", "QPSK 1/2"},
    { "18", "QPSK 3/4"},
    { "24", "16QAM 1/2"},
    { "36", "16QAM 3/4"},
    { "48", "64QAM 2/3"},
    { "54", "64QAM 3/4"},
    { "60", "64QAM 5/6"},
};

#define IWX_MCS_INDEX_PER_STREAM    (8)

static const char *iwx_rs_pretty_ant(u8 ant)
{
    static const char * const ant_name[] = {
        [IWX_ANT_NONE] = "None",
        [IWX_ANT_A]    = "A",
        [IWX_ANT_B]    = "B",
        [IWX_ANT_AB]   = "AB",
    };

    if (ant > ARRAY_SIZE(ant_name))
        return "UNKNOWN";

    return ant_name[ant];
}

static const char *iwx_rs_pretty_bw(u8 bw)
{
    static const char * const pretty_bw[] = {
        "20Mhz",
        "40Mhz",
        "80Mhz",
        "160 Mhz",
        "320Mhz",
    };

    if (bw > ARRAY_SIZE(pretty_bw))
        return "UNKNOWN";

    return pretty_bw[bw];
}

static uint8_t iwx_rs_extract_rate(uint32_t rate_n_flags)
{
    /* also works for HT because bits 7:6 are zero there */
    return (uint8_t)(rate_n_flags & IWX_RATE_LEGACY_RATE_MSK_V1);
}

static int iwx_hwrate_to_plcp_idx(uint32_t rate_n_flags)
{
    int idx = 0;

    if (rate_n_flags & IWX_RATE_MCS_HT_MSK_V1) {
        idx = rate_n_flags & IWX_RATE_HT_MCS_RATE_CODE_MSK_V1;
        idx += IWX_RATE_MCS_0_INDEX;

        /* skip 9M not supported in HT*/
        if (idx >= IWX_RATE_9M_INDEX)
            idx += 1;
        if ((idx >= IWX_FIRST_HT_RATE) && (idx <= IWX_LAST_HT_RATE))
            return idx;
    } else if (rate_n_flags & IWX_RATE_MCS_VHT_MSK_V1 ||
           rate_n_flags & IWX_RATE_MCS_HE_MSK_V1) {
        idx = rate_n_flags & IWX_RATE_VHT_MCS_RATE_CODE_MSK;
        idx += IWX_RATE_MCS_0_INDEX;

        /* skip 9M not supported in VHT*/
        if (idx >= IWX_RATE_9M_INDEX)
            idx++;
        if ((idx >= IWX_FIRST_VHT_RATE) && (idx <= IWX_LAST_VHT_RATE))
            return idx;
        if ((rate_n_flags & IWX_RATE_MCS_HE_MSK_V1) &&
            (idx <= IWX_LAST_HE_RATE))
            return idx;
    } else {
        /* legacy rate format, search for match in table */

        uint8_t legacy_rate = iwx_rs_extract_rate(rate_n_flags);
        for (idx = 0; idx < ARRAY_SIZE(iwx_rates); idx++)
            if (iwx_rates[idx].plcp == legacy_rate)
                return idx;
    }

    return IWX_RATE_INVALID;
}

static int iwx_rs_pretty_print_rate_v1(char *buf, int bufsz, const u32 rate)
{
    char *type;
    uint8_t mcs = 0, nss = 0;
    uint8_t ant = (rate & IWX_RATE_MCS_ANT_AB_MSK) >> IWX_RATE_MCS_ANT_POS;
    uint32_t bw = (rate & IWX_RATE_MCS_CHAN_WIDTH_MSK_V1) >>
        IWX_RATE_MCS_CHAN_WIDTH_POS;

    if (!(rate & IWX_RATE_MCS_HT_MSK_V1) &&
        !(rate & IWX_RATE_MCS_VHT_MSK_V1) &&
        !(rate & IWX_RATE_MCS_HE_MSK_V1)) {
        int index = iwx_hwrate_to_plcp_idx(rate);

        return snprintf(buf, bufsz, "Legacy | ANT: %s Rate: %s Mbps",
                 iwx_rs_pretty_ant(ant),
                 index == IWX_RATE_INVALID ? "BAD" :
                 iwx_rate_mcs[index].mbps);
    }

    if (rate & IWX_RATE_MCS_VHT_MSK_V1) {
        type = "VHT";
        mcs = rate & IWX_RATE_VHT_MCS_RATE_CODE_MSK;
        nss = ((rate & IWX_RATE_VHT_MCS_NSS_MSK)
               >> IWX_RATE_VHT_MCS_NSS_POS) + 1;
    } else if (rate & IWX_RATE_MCS_HT_MSK_V1) {
        type = "HT";
        mcs = rate & IWX_RATE_HT_MCS_INDEX_MSK_V1;
        nss = ((rate & IWX_RATE_HT_MCS_NSS_MSK_V1)
               >> IWX_RATE_HT_MCS_NSS_POS_V1) + 1;
    } else if (rate & IWX_RATE_MCS_HE_MSK_V1) {
        type = "HE";
        mcs = rate & IWX_RATE_VHT_MCS_RATE_CODE_MSK;
        nss = ((rate & IWX_RATE_VHT_MCS_NSS_MSK)
               >> IWX_RATE_VHT_MCS_NSS_POS) + 1;
    } else {
        type = "Unknown"; /* shouldn't happen */
    }

    return snprintf(buf, bufsz,
             "0x%x: %s | ANT: %s BW: %s MCS: %d NSS: %d %s%s%s%s%s",
             rate, type, iwx_rs_pretty_ant(ant), iwx_rs_pretty_bw(bw), mcs, nss,
             (rate & IWX_RATE_MCS_SGI_MSK_V1) ? "SGI " : "NGI ",
             (rate & IWX_RATE_MCS_STBC_MSK) ? "STBC " : "",
             (rate & IWX_RATE_MCS_LDPC_MSK_V1) ? "LDPC " : "",
             (rate & IWX_RATE_HE_DUAL_CARRIER_MODE_MSK) ? "DCM " : "",
             (rate & IWX_RATE_MCS_BF_MSK) ? "BF " : "");
}

static bool iwx_he_is_sgi(u32 rate_n_flags)
{
    u32 type = rate_n_flags & IWX_RATE_MCS_HE_TYPE_MSK;
    u32 ltf_gi = rate_n_flags & IWX_RATE_MCS_HE_GI_LTF_MSK;

    if (type == IWX_RATE_MCS_HE_TYPE_SU ||
        type == IWX_RATE_MCS_HE_TYPE_EXT_SU)
        return ltf_gi == IWX_RATE_MCS_HE_SU_4_LTF_08_GI;
    return false;
}

static int iwx_rs_pretty_print_rate(char *buf, int bufsz, const uint32_t rate)
{
    char *type;
    u8 mcs = 0, nss = 0;
    u8 ant = (rate & IWX_RATE_MCS_ANT_AB_MSK) >> IWX_RATE_MCS_ANT_POS;
    u32 bw = (rate & IWX_RATE_MCS_CHAN_WIDTH_MSK) >>
        IWX_RATE_MCS_CHAN_WIDTH_POS;
    u32 format = rate & IWX_RATE_MCS_MOD_TYPE_MSK;
    bool sgi;

    if (format == IWX_RATE_MCS_CCK_MSK ||
        format == IWX_RATE_MCS_LEGACY_OFDM_MSK) {
        int legacy_rate = rate & IWX_RATE_LEGACY_RATE_MSK;
        int index = format == IWX_RATE_MCS_CCK_MSK ?
            legacy_rate :
            legacy_rate + IWX_FIRST_OFDM_RATE;

        return snprintf(buf, bufsz, "Legacy | ANT: %s Rate: %s Mbps",
                 iwx_rs_pretty_ant(ant),
                 index == IWX_RATE_INVALID ? "BAD" :
                 iwx_rate_mcs[index].mbps);
    }

    if (format ==  IWX_RATE_MCS_VHT_MSK)
        type = "VHT";
    else if (format == IWX_RATE_MCS_HT_MSK)
        type = "HT";
    else if (format == IWX_RATE_MCS_HE_MSK)
        type = "HE";
    else if (format == IWX_RATE_MCS_EHT_MSK)
        type = "EHT";
    else
        type = "Unknown"; /* shouldn't happen */

    mcs = format == IWX_RATE_MCS_HT_MSK ?
        IWX_RATE_HT_MCS_INDEX(rate) :
        rate & IWX_RATE_MCS_CODE_MSK;
    nss = ((rate & IWX_RATE_MCS_NSS_MSK)
           >> IWX_RATE_MCS_NSS_POS) + 1;
    sgi = format == IWX_RATE_MCS_HE_MSK ?
        iwx_he_is_sgi(rate) :
        rate & IWX_RATE_MCS_SGI_MSK;

    return snprintf(buf, bufsz,
             "0x%x: %s | ANT: %s BW: %s MCS: %d NSS: %d %s%s%s%s%s",
             rate, type, iwx_rs_pretty_ant(ant), iwx_rs_pretty_bw(bw), mcs, nss,
             (sgi) ? "SGI " : "NGI ",
             (rate & IWX_RATE_MCS_STBC_MSK) ? "STBC " : "",
             (rate & IWX_RATE_MCS_LDPC_MSK) ? "LDPC " : "",
             (rate & IWX_RATE_HE_DUAL_CARRIER_MODE_MSK) ? "DCM " : "",
             (rate & IWX_RATE_MCS_BF_MSK) ? "BF " : "");
}

#if NBPFILTER > 0
void    iwx_radiotap_attach(struct iwx_softc *);
#endif

uint8_t ItlIwx::
iwx_lookup_cmd_ver(struct iwx_softc *sc, uint8_t grp, uint8_t cmd)
{
    const struct iwx_fw_cmd_version *entry;
    int i;
    
    for (i = 0; i < sc->n_cmd_versions; i++) {
        entry = &sc->cmd_versions[i];
        if (entry->group == grp && entry->cmd == cmd)
            return entry->cmd_ver;
    }
    
    return IWX_FW_CMD_VER_UNKNOWN;
}

uint8_t ItlIwx::
iwx_lookup_notif_ver(struct iwx_softc *sc, uint8_t grp, uint8_t cmd)
{
    const struct iwx_fw_cmd_version *entry;
    int i;
    
    for (i = 0; i < sc->n_cmd_versions; i++) {
        entry = &sc->cmd_versions[i];
        if (entry->group == grp && entry->cmd == cmd)
            return entry->notif_ver;
    }
    
    return IWX_FW_CMD_VER_UNKNOWN;
}

uint32_t ItlIwx::
iwx_lmac_id(struct iwx_softc *sc, ieee80211_channel *chan)
{
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT) ||
        IEEE80211_IS_CHAN_2GHZ(chan))
        return IWX_LMAC_24G_INDEX;
    return IWX_LMAC_5G_INDEX;
}

int ItlIwx::
iwx_store_cscheme(struct iwx_softc *sc, uint8_t *data, size_t dlen)
{
    struct iwx_fw_cscheme_list *l = (struct iwx_fw_cscheme_list *)data;
    
    if (dlen < sizeof(*l) ||
        dlen < sizeof(l->size) + l->size * sizeof(*l->cs))
        return EINVAL;
    
    /* we don't actually store anything for now, always use s/w crypto */
    
    return 0;
}

int ItlIwx::
iwx_ctxt_info_alloc_dma(struct iwx_softc *sc,
                        const struct iwx_fw_onesect *sec, struct iwx_dma_info *dram)
{
    int err = iwx_dma_contig_alloc(sc->sc_dmat, dram, sec->fws_len, 0);
    if (err) {
        XYLog("%s: could not allocate context info DMA memory\n",
              DEVNAME(sc));
        return err;
    }
    
    memcpy(dram->vaddr, sec->fws_data, sec->fws_len);
    
    return 0;
}

void ItlIwx::
iwx_ctxt_info_free_paging(struct iwx_softc *sc)
{
    struct iwx_self_init_dram *dram = &sc->init_dram;
    int i;
    
    if (!dram->paging)
        return;
    
    /* free paging*/
    for (i = 0; i < dram->paging_cnt; i++)
        iwx_dma_contig_free(&dram->paging[i]);
    
    IOFree(dram->paging, dram->paging_cnt * sizeof(*dram->paging));
    dram->paging_cnt = 0;
    dram->paging = NULL;
}

int ItlIwx::
iwx_get_num_sections(const struct iwx_fw_sects *fws, int start)
{
    int i = 0;
    
    while (start < fws->fw_count &&
           fws->fw_sect[start].fws_devoff != IWX_CPU1_CPU2_SEPARATOR_SECTION &&
           fws->fw_sect[start].fws_devoff != IWX_PAGING_SEPARATOR_SECTION) {
        start++;
        i++;
    }
    
    return i;
}

int ItlIwx::
iwx_init_fw_sec(struct iwx_softc *sc, const struct iwx_fw_sects *fws,
                struct iwx_context_info_dram *ctxt_dram)
{
    struct iwx_self_init_dram *dram = &sc->init_dram;
    int i, ret, fw_cnt = 0;
    
    KASSERT(dram->paging == NULL, "dram->paging == NULL");
    
    dram->lmac_cnt = iwx_get_num_sections(fws, 0);
    /* add 1 due to separator */
    dram->umac_cnt = iwx_get_num_sections(fws, dram->lmac_cnt + 1);
    /* add 2 due to separators */
    dram->paging_cnt = iwx_get_num_sections(fws,
    dram->lmac_cnt + dram->umac_cnt + 2);
    
    dram->fw = (struct iwx_dma_info *)kcalloc(dram->umac_cnt + dram->lmac_cnt, sizeof(*dram->fw));
    if (!dram->fw) {
        XYLog("%s: could not allocate memory for firmware sections\n",
        DEVNAME(sc));
        return ENOMEM;
    }
    dram->paging = (struct iwx_dma_info *)kcalloc(dram->paging_cnt, sizeof(*dram->paging));
    if (!dram->paging) {
        XYLog("%s: could not allocate memory for firmware paging\n",
        DEVNAME(sc));
        return ENOMEM;
    }
    
    /* initialize lmac sections */
    for (i = 0; i < dram->lmac_cnt; i++) {
        ret = iwx_ctxt_info_alloc_dma(sc, &fws->fw_sect[i],
                           &dram->fw[fw_cnt]);
        if (ret)
            return ret;
        ctxt_dram->lmac_img[i] =
            htole64(dram->fw[fw_cnt].paddr);
        DPRINTFN(3, ("%s: firmware LMAC section %d at 0x%llx size %lld\n", __func__, i,
            (unsigned long long)dram->fw[fw_cnt].paddr,
            (unsigned long long)dram->fw[fw_cnt].size));
        fw_cnt++;
    }

    /* initialize umac sections */
    for (i = 0; i < dram->umac_cnt; i++) {
        /* access FW with +1 to make up for lmac separator */
        ret = iwx_ctxt_info_alloc_dma(sc,
            &fws->fw_sect[fw_cnt + 1], &dram->fw[fw_cnt]);
        if (ret)
            return ret;
        ctxt_dram->umac_img[i] =
            htole64(dram->fw[fw_cnt].paddr);
        DPRINTFN(3, ("%s: firmware UMAC section %d at 0x%llx size %lld\n", __func__, i,
            (unsigned long long)dram->fw[fw_cnt].paddr,
            (unsigned long long)dram->fw[fw_cnt].size));
        fw_cnt++;
    }

    /*
     * Initialize paging.
     * Paging memory isn't stored in dram->fw as the umac and lmac - it is
     * stored separately.
     * This is since the timing of its release is different -
     * while fw memory can be released on alive, the paging memory can be
     * freed only when the device goes down.
     * Given that, the logic here in accessing the fw image is a bit
     * different - fw_cnt isn't changing so loop counter is added to it.
     */
    for (i = 0; i < dram->paging_cnt; i++) {
        /* access FW with +2 to make up for lmac & umac separators */
        int fw_idx = fw_cnt + i + 2;

        ret = iwx_ctxt_info_alloc_dma(sc,
            &fws->fw_sect[fw_idx], &dram->paging[i]);
        if (ret)
            return ret;

        ctxt_dram->virtual_img[i] = htole64(dram->paging[i].paddr);
        DPRINTFN(3, ("%s: firmware paging section %d at 0x%llx size %lld\n", __func__, i,
            (unsigned long long)dram->paging[i].paddr,
            (unsigned long long)dram->paging[i].size));
    }

    return 0;
}

void ItlIwx::
iwx_fw_version_str(char *buf, size_t bufsize,
                   uint32_t major, uint32_t minor, uint32_t api)
{
    /*
     * Starting with major version 35 the Linux driver prints the minor
     * version in hexadecimal.
     */
    if (major >= 35)
        snprintf(buf, bufsize, "%u.%08x.%u", major, minor, api);
    else
        snprintf(buf, bufsize, "%u.%u.%u", major, minor, api);
}

int ItlIwx::
iwx_alloc_fw_monitor_block(struct iwx_softc *sc, uint8_t max_power,
                           uint8_t min_power)
{
    struct iwx_dma_info *fw_mon = &sc->fw_mon;
    uint32_t size = 0;
    uint8_t power;
    int err = 0;
    
    if (fw_mon->size)
        return 0;
    
    for (power = max_power; power >= min_power; power--) {
        size = (1 << power);
        
        err = iwx_dma_contig_alloc(sc->sc_dmat, fw_mon, size, 0);
        if (err)
            continue;
        
        DPRINTF(("%s: allocated 0x%08x bytes for firmware monitor.\n",
                 DEVNAME(sc), size));
        break;
    }
    
    if (err) {
        fw_mon->size = 0;
        return err;
    }
    
    if (power != max_power)
        DPRINTF(("%s: Sorry - debug buffer is only %luK while you requested %luK\n",
                 DEVNAME(sc), (unsigned long)(1 << (power - 10)),
                 (unsigned long)(1 << (max_power - 10))));
    
    return 0;
}

int ItlIwx::
iwx_alloc_fw_monitor(struct iwx_softc *sc, uint8_t max_power)
{
    if (!max_power) {
        /* default max_power is maximum */
        max_power = 26;
    } else {
        max_power += 11;
    }
    
    if (max_power > 26) {
        DPRINTF(("%s: External buffer size for monitor is too big %d, "
                 "check the FW TLV\n", DEVNAME(sc), max_power));
        return 0;
    }
    
    if (sc->fw_mon.size)
        return 0;
    
    return iwx_alloc_fw_monitor_block(sc, max_power, 11);
}

int ItlIwx::
iwx_apply_debug_destination(struct iwx_softc *sc)
{
    struct iwx_fw_dbg_dest_tlv_v1 *dest_v1;
    int i, err;
    uint8_t mon_mode, size_power, base_shift, end_shift;
    uint32_t base_reg, end_reg;
    
    dest_v1 = sc->sc_fw.dbg_dest_tlv_v1;
    mon_mode = dest_v1->monitor_mode;
    size_power = dest_v1->size_power;
    base_reg = le32toh(dest_v1->base_reg);
    end_reg = le32toh(dest_v1->end_reg);
    base_shift = dest_v1->base_shift;
    end_shift = dest_v1->end_shift;
    
    DPRINTF(("%s: applying debug destination %d\n", DEVNAME(sc), mon_mode));
    
    if (mon_mode == EXTERNAL_MODE) {
        err = iwx_alloc_fw_monitor(sc, size_power);
        if (err)
            return err;
    }
    
    if (!iwx_nic_lock(sc))
        return EBUSY;
    
    for (i = 0; i < sc->sc_fw.n_dest_reg; i++) {
        uint32_t addr, val;
        uint8_t op;
        
        addr = le32toh(dest_v1->reg_ops[i].addr);
        val = le32toh(dest_v1->reg_ops[i].val);
        op = dest_v1->reg_ops[i].op;
        
        DPRINTF(("%s: op=%u addr=%u val=%u\n", __func__, op, addr, val));
        switch (op) {
            case CSR_ASSIGN:
                IWX_WRITE(sc, addr, val);
                break;
            case CSR_SETBIT:
                IWX_SETBITS(sc, addr, (1 << val));
                break;
            case CSR_CLEARBIT:
                IWX_CLRBITS(sc, addr, (1 << val));
                break;
            case PRPH_ASSIGN:
                iwx_write_prph(sc, addr, val);
                break;
            case PRPH_SETBIT:
                iwx_set_bits_prph(sc, addr, (1 << val));
                break;
            case PRPH_CLEARBIT:
                iwx_clear_bits_prph(sc, addr, (1 << val));
                break;
            case PRPH_BLOCKBIT:
                if (iwx_read_prph(sc, addr) & (1 << val))
                    goto monitor;
                break;
            default:
                DPRINTF(("%s: FW debug - unknown OP %d\n",
                         DEVNAME(sc), op));
                break;
        }
    }
    
monitor:
    if (mon_mode == EXTERNAL_MODE && sc->fw_mon.size) {
        iwx_write_prph(sc, le32toh(base_reg),
                       sc->fw_mon.paddr >> base_shift);
        iwx_write_prph(sc, end_reg,
                       (sc->fw_mon.paddr + sc->fw_mon.size - 256)
                       >> end_shift);
    }
    
    iwx_nic_unlock(sc);
    return 0;
}

void ItlIwx::
iwx_set_ltr(struct iwx_softc *sc)
{
    uint32_t ltr_val = IWX_CSR_LTR_LONG_VAL_AD_NO_SNOOP_REQ |
                    u32_encode_bits(IWX_CSR_LTR_LONG_VAL_AD_SCALE_USEC,
                    IWX_CSR_LTR_LONG_VAL_AD_NO_SNOOP_SCALE) |
                    u32_encode_bits(250,
                    IWX_CSR_LTR_LONG_VAL_AD_NO_SNOOP_VAL) |
                    IWX_CSR_LTR_LONG_VAL_AD_SNOOP_REQ |
                    u32_encode_bits(IWX_CSR_LTR_LONG_VAL_AD_SCALE_USEC,
                    IWX_CSR_LTR_LONG_VAL_AD_SNOOP_SCALE) |
                    u32_encode_bits(250, IWX_CSR_LTR_LONG_VAL_AD_SNOOP_VAL);
    
    /*
     * To workaround hardware latency issues during the boot process,
     * initialize the LTR to ~250 usec (see ltr_val above).
     * The firmware initializes this again later (to a smaller value).
     */
    if ((sc->sc_device_family == IWX_DEVICE_FAMILY_AX210 ||
         sc->sc_device_family == IWX_DEVICE_FAMILY_22000) &&
        !sc->sc_integrated) {
        IWX_WRITE(sc, IWX_CSR_LTR_LONG_VAL_AD, ltr_val);
    } else if (sc->sc_integrated &&
           sc->sc_device_family == IWX_DEVICE_FAMILY_22000) {
        if (iwx_nic_lock(sc)) {
            iwx_write_prph(sc, IWX_HPM_MAC_LTR_CSR, IWX_HPM_MAC_LRT_ENABLE_ALL);
            iwx_write_prph(sc, IWX_HPM_UMAC_LTR, ltr_val);
            iwx_nic_unlock(sc);
        }
    }
}

int ItlIwx::
iwx_ctxt_info_init(struct iwx_softc *sc, const struct iwx_fw_sects *fws)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_context_info *ctxt_info;
    struct iwx_context_info_rbd_cfg *rx_cfg;
    uint32_t control_flags = 0, rb_size;
    int err;
    
    ctxt_info = (struct iwx_context_info *)sc->ctxt_info_dma.vaddr;
    
    ctxt_info->version.version = 0;
    ctxt_info->version.mac_id =
    htole16((uint16_t)IWX_READ(sc, IWX_CSR_HW_REV));
    /* size is in DWs */
    ctxt_info->version.size = htole16(sizeof(*ctxt_info) / 4);
    
    rb_size = IWX_CTXT_INFO_RB_SIZE_4K;
    
    KASSERT(IWX_RX_QUEUE_CB_SIZE(IWX_MQ_RX_TABLE_SIZE) < 0xF, "IWX_RX_QUEUE_CB_SIZE(IWX_MQ_RX_TABLE_SIZE) < 0xF");
    control_flags = IWX_CTXT_INFO_TFD_FORMAT_LONG |
    (IWX_RX_QUEUE_CB_SIZE(IWX_MQ_RX_TABLE_SIZE) <<
     IWX_CTXT_INFO_RB_CB_SIZE_POS) |
    (rb_size << IWX_CTXT_INFO_RB_SIZE_POS);
    ctxt_info->control.control_flags = htole32(control_flags);
    
    /* initialize RX default queue */
    rx_cfg = &ctxt_info->rbd_cfg;
    rx_cfg->free_rbd_addr = htole64(sc->rxq.free_desc_dma.paddr);
    rx_cfg->used_rbd_addr = htole64(sc->rxq.used_desc_dma.paddr);
    rx_cfg->status_wr_ptr = htole64(sc->rxq.stat_dma.paddr);
    
    /* initialize TX command queue */
    ctxt_info->hcmd_cfg.cmd_queue_addr =
    htole64(sc->txq[IWX_DQA_CMD_QUEUE].desc_dma.paddr);
    ctxt_info->hcmd_cfg.cmd_queue_size =
    IWX_TFD_QUEUE_CB_SIZE(IWX_CMD_QUEUE_SIZE);
    
    /* allocate ucode sections in dram and set addresses */
    err = iwx_init_fw_sec(sc, fws, &ctxt_info->dram);
    if (err) {
        iwx_ctxt_info_free_fw_img(sc);
        return err;
    }
    
    //zxystd: I don't know if it is necessary, but it is also works without the debug info, comment it to avoid DMA memory leak
#if 0
    /* Configure debug, if exists */
    if (sc->sc_fw.dbg_dest_tlv_v1) {
        err = iwx_apply_debug_destination(sc);
        if (err) {
            iwx_ctxt_info_free_fw_img(sc);
            return err;
        }
    }
#endif
    
    iwx_enable_fwload_interrupt(sc);
    
    IWX_WRITE64(sc, IWX_CSR_CTXT_INFO_BA, sc->ctxt_info_dma.paddr);
    
    iwx_set_ltr(sc);
    
    /* kick FW self load */
    if (!iwx_nic_lock(sc)) {
        iwx_ctxt_info_free_fw_img(sc);
        return EBUSY;
    }
    iwx_write_prph(sc, IWX_UREG_CPU_INIT_RUN, 1);
    iwx_nic_unlock(sc);
    
    /* Context info will be released upon alive or failure to get one */
    
    return 0;
}

int ItlIwx::
iwx_ctxt_info_gen3_init(struct iwx_softc *sc, const struct iwx_fw_sects *fws)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_context_info_gen3 *ctxt_info_gen3;
    struct iwx_prph_scratch *prph_scratch;
    struct iwx_prph_scratch_ctrl_cfg *prph_sc_ctrl;
    uint32_t control_flags = 0;
    int err;
    
    /* Allocate prph scratch. */
    err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->prph_scratch_dma,
                               sizeof(struct iwx_prph_scratch), 0);
    if (err) {
        XYLog("%s: could not allocate prph scratch\n", DEVNAME(sc));
        return false;
    }
    
    prph_scratch = (struct iwx_prph_scratch *)sc->prph_scratch_dma.vaddr;
    
    prph_sc_ctrl = &prph_scratch->ctrl_cfg;
    prph_sc_ctrl->version.version = 0;
    prph_sc_ctrl->version.mac_id =
        htole16((uint16_t)IWX_READ(sc, IWX_CSR_HW_REV));
    prph_sc_ctrl->version.size = htole16(sizeof(*prph_scratch) / 4);
    
    control_flags = IWX_PRPH_SCRATCH_RB_SIZE_4K;
    control_flags |= IWX_PRPH_SCRATCH_MTR_MODE;
    control_flags |= IWX_PRPH_MTR_FORMAT_256B & IWX_PRPH_SCRATCH_MTR_FORMAT;
    
    /* initialize RX default queue */
    prph_sc_ctrl->rbd_cfg.free_rbd_addr =
        htole64(sc->rxq.free_desc_dma.paddr);
    
    prph_sc_ctrl->control.control_flags = htole32(control_flags);
    
    /* allocate ucode sections in dram and set addresses */
    err = iwx_init_fw_sec(sc, fws, &prph_scratch->dram);
    if (err) {
        iwx_ctxt_info_free_fw_img(sc);
        return err;
    }
    
    /* Allocate prph information. */
    err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->prph_info_dma,
                               PAGE_SIZE, 0);
    if (err) {
        XYLog("%s: could not allocate prph information\n", DEVNAME(sc));
        goto fail0;
    }
    
    ctxt_info_gen3 = (struct iwx_context_info_gen3 *)sc->ctxt_info_dma.vaddr;
    
    ctxt_info_gen3->prph_info_base_addr =
        htole64(sc->prph_info_dma.paddr);
    ctxt_info_gen3->prph_scratch_base_addr =
        htole64(sc->prph_scratch_dma.paddr);
    ctxt_info_gen3->prph_scratch_size =
        htole32(sizeof(*prph_scratch));
    ctxt_info_gen3->cr_head_idx_arr_base_addr =
        htole64(sc->rxq.stat_dma.paddr);
    ctxt_info_gen3->tr_tail_idx_arr_base_addr =
        htole64((uint8_t *)sc->prph_info_dma.paddr + PAGE_SIZE / 2);
    ctxt_info_gen3->cr_tail_idx_arr_base_addr =
        htole64((uint8_t *)sc->prph_info_dma.paddr + 3 * PAGE_SIZE / 4);
    ctxt_info_gen3->mtr_base_addr =
        htole64(sc->txq[IWX_DQA_CMD_QUEUE].desc_dma.paddr);
    ctxt_info_gen3->mcr_base_addr =
        htole64(sc->rxq.used_desc_dma.paddr);
    ctxt_info_gen3->mtr_size =
        htole16(IWX_TFD_QUEUE_CB_SIZE(IWX_CMD_QUEUE_SIZE_GEN3));
    ctxt_info_gen3->mcr_size =
        htole16(IWX_RX_QUEUE_CB_SIZE(IWX_RX_MQ_RING_COUNT));
    
    /* Allocate IML. */
    err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->iml_dma,
                               IWX_IML_MAX_LEN, 0);
    if (err) {
        XYLog("%s: could not allocate IML\n", DEVNAME(sc));
        goto fail1;
    }
    
    memcpy(sc->iml_dma.vaddr, sc->sc_iml, sc->sc_iml_len);
    
    iwx_enable_fwload_interrupt(sc);
    
    /* kick FW self load */
    IWX_WRITE64(sc, IWX_CSR_CTXT_INFO_ADDR,
            sc->ctxt_info_dma.paddr);
    IWX_WRITE64(sc, IWX_CSR_IML_DATA_ADDR,
            sc->iml_dma.paddr);
    IWX_WRITE(sc, IWX_CSR_IML_SIZE_ADDR, sc->sc_iml_len);

    IWX_SETBITS(sc, IWX_CSR_CTXT_INFO_BOOT_CTRL,
            IWX_CSR_AUTO_FUNC_BOOT_ENA);
    
    iwx_set_ltr(sc);
    
    if (!iwx_nic_lock(sc))
        return EBUSY;
    iwx_write_umac_prph(sc, IWX_UREG_CPU_INIT_RUN, 1);
    iwx_nic_unlock(sc);
    
    return 0;
    
fail1:
    iwx_dma_contig_free(&sc->iml_dma);
fail0:
    iwx_dma_contig_free(&sc->prph_info_dma);
    iwx_dma_contig_free(&sc->prph_scratch_dma);
    return ENOMEM;
}

void ItlIwx::
iwx_force_power_gating(struct iwx_softc *sc)
{
   iwx_set_bits_prph(sc, IWX_HPM_HIPM_GEN_CFG,
       IWX_HPM_HIPM_GEN_CFG_CR_FORCE_ACTIVE);
   DELAY(20);
   iwx_set_bits_prph(sc, IWX_HPM_HIPM_GEN_CFG,
       IWX_HPM_HIPM_GEN_CFG_CR_PG_EN |
       IWX_HPM_HIPM_GEN_CFG_CR_SLP_EN);
   DELAY(20);
   iwx_clear_bits_prph(sc, IWX_HPM_HIPM_GEN_CFG,
       IWX_HPM_HIPM_GEN_CFG_CR_FORCE_ACTIVE);
}

void ItlIwx::
iwx_clear_persistence_bit(struct iwx_softc *sc)
{
    uint32_t hpm, wprot;
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        return;
    
    wprot = IWX_PREG_PRPH_WPROT_22000;
    hpm = iwx_read_prph_unlocked(sc, IWX_HPM_DEBUG);
    if (hpm != 0xa5a5a5a0 && (hpm & IWX_PERSISTENCE_BIT)) {
        uint32_t wprot_val = iwx_read_prph_unlocked(sc, wprot);
        
        if (wprot_val & IWX_PREG_WFPM_ACCESS) {
            XYLog("Error, can not clear persistence bit\n");
            return;
        }
        iwx_write_prph_unlocked(sc, IWX_HPM_DEBUG,
                                hpm & ~IWX_PERSISTENCE_BIT);
    }
}

void ItlIwx::
iwx_ctxt_info_free_fw_img(struct iwx_softc *sc)
{
    struct iwx_self_init_dram *dram = &sc->init_dram;
    int i;
    
    if (!dram->fw)
        return;

    for (i = 0; i < dram->lmac_cnt + dram->umac_cnt; i++)
        iwx_dma_contig_free(&dram->fw[i]);

    IOFree(dram->fw,
        (dram->lmac_cnt + dram->umac_cnt) * sizeof(*dram->fw));
    dram->lmac_cnt = 0;
    dram->umac_cnt = 0;
    dram->fw = NULL;
}

int ItlIwx::
iwx_firmware_store_section(struct iwx_softc *sc, enum iwx_ucode_type type,
                           uint8_t *data, size_t dlen)
{
    struct iwx_fw_sects *fws;
    struct iwx_fw_onesect *fwone;
    
    if (type >= IWX_UCODE_TYPE_MAX)
        return EINVAL;
    if (dlen < sizeof(uint32_t))
        return EINVAL;
    
    fws = &sc->sc_fw.fw_sects[type];
    DPRINTFN(3, ("%s: ucode type %d section %d\n", DEVNAME(sc), type, fws->fw_count));
    if (fws->fw_count >= IWX_UCODE_SECT_MAX)
        return EINVAL;
    
    fwone = &fws->fw_sect[fws->fw_count];
    
    /* first 32bit are device load offset */
    memcpy(&fwone->fws_devoff, data, sizeof(uint32_t));
    
    /* rest is data */
    fwone->fws_data = data + sizeof(uint32_t);
    fwone->fws_len = dlen - sizeof(uint32_t);
    
    fws->fw_count++;
    fws->fw_totlen += fwone->fws_len;
    
    return 0;
}

#define IWX_DEFAULT_SCAN_CHANNELS    40
/* Newer firmware might support more channels. Raise this value if needed. */
#define IWX_MAX_SCAN_CHANNELS        256 /* as of 8265-34 firmware image */
#define IWX_STATION_COUNT_MAX        16

struct iwx_tlv_calib_data {
    uint32_t ucode_type;
    struct iwx_tlv_calib_ctrl calib;
} __packed;

int ItlIwx::
iwx_set_default_calib(struct iwx_softc *sc, const void *data)
{
    const struct iwx_tlv_calib_data *def_calib = (const struct iwx_tlv_calib_data *)data;
    uint32_t ucode_type = le32toh(def_calib->ucode_type);
    
    if (ucode_type >= IWX_UCODE_TYPE_MAX)
        return EINVAL;
    
    sc->sc_default_calib[ucode_type].flow_trigger =
    def_calib->calib.flow_trigger;
    sc->sc_default_calib[ucode_type].event_trigger =
    def_calib->calib.event_trigger;
    
    return 0;
}

void ItlIwx::
iwx_fw_info_free(struct iwx_fw_info *fw)
{
    ::free(fw->fw_rawdata);
    fw->fw_rawdata = NULL;
    fw->fw_rawsize = 0;
    /* don't touch fw->fw_status */
    memset(fw->fw_sects, 0, sizeof(fw->fw_sects));
}

void ItlIwx::
iwx_pnvm_free(struct iwx_fw_info *fw)
{
    if (fw->pnvm_rawdata) {
        ::free(fw->pnvm_rawdata);
        fw->pnvm_rawdata = NULL;
        fw->pnvm_rawsize = 0;
    }
}

#define IWX_FW_ADDR_CACHE_CONTROL 0xC0000000

//void ItlIwx::
//onLoadFW(OSKextRequestTag requestTag, OSReturn result, const void *resourceData, uint32_t resourceDataLength, void *context)
//{
//    XYLog("onLoadFW callback ret=0x%08x length=%d", result, resourceDataLength);
//    ResourceCallbackContext *resourceContxt = (ResourceCallbackContext*)context;
//    IOLockLock(resourceContxt->context->_fwLoadLock);
//    if (resourceDataLength > 0) {
//        XYLog("onLoadFW return success");
//        resourceContxt->resource = OSData::withBytes(resourceData, resourceDataLength);
//    }
//    IOLockUnlock(resourceContxt->context->_fwLoadLock);
//    IOLockWakeup(resourceContxt->context->_fwLoadLock, resourceContxt->context, false);
//    XYLog("onLoadFW wakeupOn");
//}

int ItlIwx::
iwx_read_firmware(struct iwx_softc *sc)
{
    struct iwx_fw_info *fw = &sc->sc_fw;
    struct iwx_tlv_ucode_header *uhdr;
    struct iwx_ucode_tlv tlv;
    uint32_t tlv_type = 0;
    uint8_t *data;
    int err = 0;
    size_t len;
    OSData *fwData = NULL;
    
    if (fw->fw_status == IWX_FW_STATUS_DONE)
        return 0;
    
    if (fw->fw_status == IWX_FW_STATUS_INPROGRESS)
        return EBUSY;
    fw->fw_status = IWX_FW_STATUS_INPROGRESS;
    
    if (fw->fw_rawdata != NULL)
        iwx_fw_info_free(fw);
    
//    IOLockLock(_fwLoadLock);
//    ResourceCallbackContext context =
//    {
//        .context = this,
//        .resource = NULL
//    };
//
//    //here leaks
//    IOReturn ret = OSKextRequestResource(OSKextGetCurrentIdentifier(), sc->sc_fwname, onLoadFW, &context, NULL);
//    IOLockSleep(_fwLoadLock, this, 0);
//    IOLockUnlock(_fwLoadLock);
//    if (context.resource == NULL) {
//        XYLog("%s resource load fail.\n", sc->sc_fwname);
//        goto out;
//    }
//    fw->fw_rawdata = malloc(context.resource->getLength(), 1, 1);
//    memcpy(fw->fw_rawdata, context.resource->getBytesNoCopy(), context.resource->getLength());
//    fw->fw_rawsize = context.resource->getLength();
    fwData = getFWDescByName(sc->sc_fwname);
    if (fwData == NULL) {
        err = EINVAL;
        XYLog("%s resource load fail.\n", sc->sc_fwname);
        goto out;
    }
    fw->fw_rawsize = fwData->getLength() * 4;
    fw->fw_rawdata = malloc(fw->fw_rawsize, 1, 1);
    uncompressFirmware((u_char *)fw->fw_rawdata, (uint *)&fw->fw_rawsize, (u_char *)fwData->getBytesNoCopy(), fwData->getLength());
    XYLog("load firmware %s done\n", sc->sc_fwname);
    
    sc->sc_capaflags = 0;
    sc->sc_capa_n_scan_channels = IWX_DEFAULT_SCAN_CHANNELS;
    memset(sc->sc_enabled_capa, 0, sizeof(sc->sc_enabled_capa));
    memset(sc->sc_ucode_api, 0, sizeof(sc->sc_ucode_api));
    sc->n_cmd_versions = 0;
    memcpy(sc->sc_fw_mcc, "ZZ", sizeof(sc->sc_fw_mcc));
    sc->sc_fw_mcc_int = 0x3030;
    
    uhdr = (struct iwx_tlv_ucode_header *)fw->fw_rawdata;
    if (*(uint32_t *)fw->fw_rawdata != 0
        || le32toh(uhdr->magic) != IWX_TLV_UCODE_MAGIC) {
        XYLog("%s: invalid firmware %s\n",
              DEVNAME(sc), sc->sc_fwname);
        err = EINVAL;
        goto out;
    }
    
    iwx_fw_version_str(sc->sc_fwver, sizeof(sc->sc_fwver),
             IWX_UCODE_MAJOR(le32toh(uhdr->ver)),
             IWX_UCODE_MINOR(le32toh(uhdr->ver)),
             IWX_UCODE_API(le32toh(uhdr->ver)));
    data = uhdr->data;
    len = fw->fw_rawsize - sizeof(*uhdr);
    
    XYLog("parsing firmware %s\n", sc->sc_fwname);
    while (len >= sizeof(tlv)) {
        size_t tlv_len;
        void *tlv_data;
        
        memcpy(&tlv, data, sizeof(tlv));
        tlv_len = le32toh(tlv.length);
        tlv_type = le32toh(tlv.type);
        
        len -= sizeof(tlv);
        data += sizeof(tlv);
        tlv_data = data;
        
        if (len < tlv_len) {
            XYLog("%s: firmware too short: %zu bytes\n",
                  DEVNAME(sc), len);
            err = EINVAL;
            goto parse_out;
        }
        
        switch (tlv_type) {
            case IWX_UCODE_TLV_PROBE_MAX_LEN:
                if (tlv_len < sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_capa_max_probe_len
                = le32toh(*(uint32_t *)tlv_data);
                if (sc->sc_capa_max_probe_len >
                    IWX_SCAN_OFFLOAD_PROBE_REQ_SIZE) {
                    err = EINVAL;
                    goto parse_out;
                }
                break;
            case IWX_UCODE_TLV_PAN:
                if (tlv_len) {
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_capaflags |= IWX_UCODE_TLV_FLAGS_PAN;
                break;
            case IWX_UCODE_TLV_FLAGS:
                if (tlv_len < sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                /*
                 * Apparently there can be many flags, but Linux driver
                 * parses only the first one, and so do we.
                 *
                 * XXX: why does this override IWX_UCODE_TLV_PAN?
                 * Intentional or a bug?  Observations from
                 * current firmware file:
                 *  1) TLV_PAN is parsed first
                 *  2) TLV_FLAGS contains TLV_FLAGS_PAN
                 * ==> this resets TLV_PAN to itself... hnnnk
                 */
                sc->sc_capaflags = le32toh(*(uint32_t *)tlv_data);
                break;
            case IWX_UCODE_TLV_CSCHEME:
                err = iwx_store_cscheme(sc, (uint8_t *)tlv_data, tlv_len);
                if (err)
                    goto parse_out;
                break;
            case IWX_UCODE_TLV_NUM_OF_CPU: {
                uint32_t num_cpu;
                if (tlv_len != sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                num_cpu = le32toh(*(uint32_t *)tlv_data);
                if (num_cpu < 1 || num_cpu > 2) {
                    err = EINVAL;
                    goto parse_out;
                }
                break;
            }
            case IWX_UCODE_TLV_SEC_RT:
                err = iwx_firmware_store_section(sc,
                                                 IWX_UCODE_TYPE_REGULAR, (uint8_t *)tlv_data, tlv_len);
                if (err)
                    goto parse_out;
                break;
            case IWX_UCODE_TLV_SEC_INIT:
                err = iwx_firmware_store_section(sc,
                                                 IWX_UCODE_TYPE_INIT, (uint8_t *)tlv_data, tlv_len);
                if (err)
                    goto parse_out;
                break;
            case IWX_UCODE_TLV_SEC_WOWLAN:
                err = iwx_firmware_store_section(sc,
                                                 IWX_UCODE_TYPE_WOW, (uint8_t *)tlv_data, tlv_len);
                if (err)
                    goto parse_out;
                break;
            case IWX_UCODE_TLV_DEF_CALIB:
                if (tlv_len != sizeof(struct iwx_tlv_calib_data)) {
                    err = EINVAL;
                    goto parse_out;
                }
                err = iwx_set_default_calib(sc, tlv_data);
                if (err)
                    goto parse_out;
                break;
            case IWX_UCODE_TLV_PHY_SKU:
                if (tlv_len != sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_fw_phy_config = le32toh(*(uint32_t *)tlv_data);
                break;
                
            case IWX_UCODE_TLV_API_CHANGES_SET: {
                struct iwx_ucode_api *api;
                int idx, i;
                if (tlv_len != sizeof(*api)) {
                    err = EINVAL;
                    goto parse_out;
                }
                api = (struct iwx_ucode_api *)tlv_data;
                idx = le32toh(api->api_index);
                if (idx >= howmany(IWX_NUM_UCODE_TLV_API, 32)) {
                    err = EINVAL;
                    goto parse_out;
                }
                for (i = 0; i < 32; i++) {
                    if ((le32toh(api->api_flags) & (1 << i)) == 0)
                        continue;
                    setbit(sc->sc_ucode_api, i + (32 * idx));
                }
                break;
            }
                
            case IWX_UCODE_TLV_ENABLED_CAPABILITIES: {
                struct iwx_ucode_capa *capa;
                int idx, i;
                if (tlv_len != sizeof(*capa)) {
                    err = EINVAL;
                    goto parse_out;
                }
                capa = (struct iwx_ucode_capa *)tlv_data;
                idx = le32toh(capa->api_index);
                if (idx >= howmany(IWX_NUM_UCODE_TLV_CAPA, 32)) {
                    goto parse_out;
                }
                for (i = 0; i < 32; i++) {
                    if ((le32toh(capa->api_capa) & (1 << i)) == 0)
                        continue;
                    setbit(sc->sc_enabled_capa, i + (32 * idx));
                }
                break;
            }
                
            case IWX_UCODE_TLV_SDIO_ADMA_ADDR:
            case IWX_UCODE_TLV_FW_GSCAN_CAPA:
                /* ignore, not used by current driver */
                break;
                
            case IWX_UCODE_TLV_SEC_RT_USNIFFER:
                err = iwx_firmware_store_section(sc,
                                                 IWX_UCODE_TYPE_REGULAR_USNIFFER, (uint8_t *)tlv_data,
                                                 tlv_len);
                if (err)
                    goto parse_out;
                break;
                
            case IWX_UCODE_TLV_PAGING:
                if (tlv_len != sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                break;
                
            case IWX_UCODE_TLV_N_SCAN_CHANNELS:
                if (tlv_len != sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_capa_n_scan_channels =
                le32toh(*(uint32_t *)tlv_data);
                if (sc->sc_capa_n_scan_channels > IWX_MAX_SCAN_CHANNELS) {
                    err = ERANGE;
                    goto parse_out;
                }
                break;
                
            case IWX_UCODE_TLV_FW_VERSION:
                if (tlv_len != sizeof(uint32_t) * 3) {
                    err = EINVAL;
                    goto parse_out;
                }
                iwx_fw_version_str(sc->sc_fwver, sizeof(sc->sc_fwver),
                         le32toh(((uint32_t *)tlv_data)[0]),
                         le32toh(((uint32_t *)tlv_data)[1]),
                         le32toh(((uint32_t *)tlv_data)[2]));
                break;
                
            case IWX_UCODE_TLV_FW_DBG_DEST: {
                struct iwx_fw_dbg_dest_tlv_v1 *dest_v1 = NULL;
                
                fw->dbg_dest_ver = (uint8_t *)tlv_data;
                if (*fw->dbg_dest_ver != 0) {
                    err = EINVAL;
                    goto parse_out;
                }
                
                if (fw->dbg_dest_tlv_init)
                    break;
                fw->dbg_dest_tlv_init = true;
                
                dest_v1 = (struct iwx_fw_dbg_dest_tlv_v1 *)tlv_data;
                fw->dbg_dest_tlv_v1 = dest_v1;
                fw->n_dest_reg = tlv_len -
                offsetof(struct iwx_fw_dbg_dest_tlv_v1, reg_ops);
                fw->n_dest_reg /= sizeof(dest_v1->reg_ops[0]);
                DPRINTF(("%s: found debug dest; n_dest_reg=%d\n", __func__, fw->n_dest_reg));
                break;
            }
                
            case IWX_UCODE_TLV_FW_DBG_CONF: {
                struct iwx_fw_dbg_conf_tlv *conf = (struct iwx_fw_dbg_conf_tlv *)tlv_data;
                
                if (!fw->dbg_dest_tlv_init ||
                    conf->id >= nitems(fw->dbg_conf_tlv) ||
                    fw->dbg_conf_tlv[conf->id] != NULL)
                    break;
                
                DPRINTF(("Found debug configuration: %d\n", conf->id));
                fw->dbg_conf_tlv[conf->id] = conf;
                fw->dbg_conf_tlv_len[conf->id] = tlv_len;
                break;
            }
                
            case IWX_UCODE_TLV_UMAC_DEBUG_ADDRS: {
                struct iwx_umac_debug_addrs *dbg_ptrs =
                (struct iwx_umac_debug_addrs *)tlv_data;
                
                if (tlv_len != sizeof(*dbg_ptrs)) {
                    err = EINVAL;
                    goto parse_out;
                }
                if (sc->sc_device_family < IWX_DEVICE_FAMILY_22000)
                    break;
                sc->sc_uc.uc_umac_error_event_table =
                le32toh(dbg_ptrs->error_info_addr) &
                ~IWX_FW_ADDR_CACHE_CONTROL;
                sc->sc_uc.error_event_table_tlv_status |=
                IWX_ERROR_EVENT_TABLE_UMAC;
                break;
            }
                
            case IWX_UCODE_TLV_LMAC_DEBUG_ADDRS: {
                struct iwx_lmac_debug_addrs *dbg_ptrs =
                (struct iwx_lmac_debug_addrs *)tlv_data;
                
                if (tlv_len != sizeof(*dbg_ptrs)) {
                    err = EINVAL;
                    goto parse_out;
                }
                if (sc->sc_device_family < IWX_DEVICE_FAMILY_22000)
                    break;
                sc->sc_uc.uc_lmac_error_event_table[0] =
                le32toh(dbg_ptrs->error_event_table_ptr) &
                ~IWX_FW_ADDR_CACHE_CONTROL;
                sc->sc_uc.error_event_table_tlv_status |=
                IWX_ERROR_EVENT_TABLE_LMAC1;
                break;
            }
                
            case IWX_UCODE_TLV_FW_MEM_SEG:
                break;
                
            case IWX_UCODE_TLV_IML:
                if (sizeof(sc->sc_iml) < tlv_len) {
                    XYLog("IML max len mismatch. len1: %zu len2: %zu\n", sizeof(sc->sc_iml), tlv_len);
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_iml_len = (uint32_t)tlv_len;
                memcpy(sc->sc_iml, tlv_data, sc->sc_iml_len);
                break;
                
            case IWX_UCODE_TLV_CMD_VERSIONS:
                if (tlv_len % sizeof(struct iwx_fw_cmd_version)) {
                    tlv_len /= sizeof(struct iwx_fw_cmd_version);
                    tlv_len *= sizeof(struct iwx_fw_cmd_version);
                }
                if (sc->n_cmd_versions != 0) {
                    err = EINVAL;
                    goto parse_out;
                }
                if (tlv_len > sizeof(sc->cmd_versions)) {
                    err = EINVAL;
                    goto parse_out;
                }
                memcpy(&sc->cmd_versions[0], tlv_data, tlv_len);
                sc->n_cmd_versions = tlv_len / sizeof(struct iwx_fw_cmd_version);
                break;
                
            case IWX_UCODE_TLV_FW_RECOVERY_INFO:
                break;
                
            case IWX_UCODE_TLV_FW_FSEQ_VERSION: {
                struct sfseq_ver {
                    uint8_t version[32];
                    uint8_t sha1[20];
                };
                sfseq_ver *seq_ver = (sfseq_ver *)tlv_data;
                if (tlv_len != sizeof(struct sfseq_ver)) {
                    err = EINVAL;
                    goto parse_out;
                }
                XYLog("TLV_FW_FSEQ_VERSION: %s\n", seq_ver->version);
            }
                break;
                
            case IWX_UCODE_PHY_INTEGRATION_VERSION:
                break;
            case IWX_UCODE_TLV_FW_NUM_STATIONS:
                if (tlv_len != sizeof(uint32_t)) {
                    err = EINVAL;
                    goto parse_out;
                }
                sc->sc_capa_num_stations = le32toh(*(uint32_t *)tlv_data);
                if (sc->sc_capa_num_stations > IWX_STATION_COUNT_MAX) {
                    XYLog("%d is an invalid number of station\n",
                          sc->sc_capa_num_stations);
                    err = EINVAL;
                    goto parse_out;
                }
                break;
                
                /* undocumented TLVs found in iwx-cc-a0-48 image */
            case 58:
            case 0x1000003:
            case 0x1000004:
                break;
                
                /* undocumented TLVs found in iwx-cc-a0-48 image */
            case 0x1000000:
            case 0x1000002:
            case IWX_UCODE_TLV_TYPE_DEBUG_INFO:
            case IWX_UCODE_TLV_TYPE_BUFFER_ALLOCATION:
            case IWX_UCODE_TLV_TYPE_HCMD:
            case IWX_UCODE_TLV_TYPE_REGIONS:
            case IWX_UCODE_TLV_TYPE_TRIGGERS:
            case IWX_UCODE_TLV_TYPE_CONF_SET:
                break;

                /* undocumented TLV found in iwx-cc-a0-67 image */
            case 0x100000b:
                break;
                
            default:
                //            err = EINVAL;
                //            goto parse_out;
                XYLog("%s unhandle section type= %d\n", __FUNCTION__, tlv_type);
                break;
        }
        
        /*
         * Check for size_t overflow and ignore missing padding at
         * end of firmware file.
         */
        if (roundup(tlv_len, 4) > len)
            break;
        
        len -= roundup(tlv_len, 4);
        data += roundup(tlv_len, 4);
    }
    
    KASSERT(err == 0, "err == 0");
    
    XYLog("firmware parse done\n");
    
parse_out:
    if (err) {
        XYLog("%s: firmware parse error %d, "
              "section type %d\n", DEVNAME(sc), err, tlv_type);
    }
    
out:
    if (err) {
        fw->fw_status = IWX_FW_STATUS_NONE;
        if (fw->fw_rawdata != NULL)
            iwx_fw_info_free(fw);
    } else
        fw->fw_status = IWX_FW_STATUS_DONE;
    wakeupOn(&sc->sc_fw);

    OSSafeReleaseNULL(fwData);
    
    return err;
}

struct iwx_pnvm_section {
    uint32_t offset;
    const uint8_t data[];
} __packed;

int ItlIwx::
iwx_pnvm_handle_section(struct iwx_softc *sc, const uint8_t *data, size_t len)
{
    struct iwx_ucode_tlv *tlv;
    uint32_t sha1 = 0;
    uint16_t mac_type = 0, rf_id = 0;
    uint8_t *pnvm_data = NULL, *tmp;
    bool hw_match = false;
    uint32_t size = 0;
    int err = 0;
    struct iwx_prph_scratch_ctrl_cfg *prph_sc_ctrl;
    
    XYLog("Handling PNVM section\n");
    
    while (len >= sizeof(*tlv)) {
        uint32_t tlv_len, tlv_type;
        
        len -= sizeof(*tlv);
        tlv = (struct iwx_ucode_tlv *)data;
        
        tlv_len = le32toh(tlv->length);
        tlv_type = le32toh(tlv->type);
        
        if (len < tlv_len) {
            XYLog("invalid TLV len: %zd/%u\n",
                  len, tlv_len);
            err = -EINVAL;
            goto out;
        }
        
        data += sizeof(*tlv);
        
        switch (tlv_type) {
            case IWX_UCODE_TLV_PNVM_VERSION:
                if (tlv_len < sizeof(__le32)) {
                    XYLog("Invalid size for IWL_UCODE_TLV_PNVM_VERSION (expected %zd, got %d)\n",
                          sizeof(__le32), tlv_len);
                    break;
                }
                
                sha1 = le32_to_cpup((__le32 *)data);
                
                XYLog("Got IWL_UCODE_TLV_PNVM_VERSION %0x\n",
                      sha1);
                break;
            case IWX_UCODE_TLV_HW_TYPE:
                if (tlv_len < 2 * sizeof(__le16)) {
                    XYLog("Invalid size for IWL_UCODE_TLV_HW_TYPE (expected %zd, got %d)\n",
                          2 * sizeof(__le16), tlv_len);
                    break;
                }
                
                if (hw_match)
                    break;

                mac_type = le16_to_cpup((__le16 *)data);
                rf_id = le16_to_cpup((__le16 *)(data + sizeof(__le16)));
                
                XYLog("Got IWL_UCODE_TLV_HW_TYPE mac_type 0x%0x rf_id 0x%0x\n",
                      mac_type, rf_id);
                
                if (mac_type == CSR_HW_REV_TYPE(sc->sc_hw_rev) &&
                    rf_id == CSR_HW_RFID_TYPE(sc->sc_hw_rf_id))
                    hw_match = true;
                break;
            case IWX_UCODE_TLV_SEC_RT: {
                struct iwx_pnvm_section *section = (struct iwx_pnvm_section *)data;
                u32 data_len = tlv_len - sizeof(*section);
                
                XYLog("Got IWL_UCODE_TLV_SEC_RT len %d\n",
                      tlv_len);
                
                /* TODO: remove, this is a deprecated separator */
                if (le32_to_cpup((__le32 *)data) == 0xddddeeee) {
                    XYLog("Ignoring separator.\n");
                    break;
                }
                
                XYLog("Adding data (size %d)\n",
                      data_len);
                
                tmp = (uint8_t *)malloc(size + data_len, 0, 0);
                if (!tmp) {
                    XYLog("Couldn't allocate (more) pnvm_data\n");
                    
                    err = -ENOMEM;
                    goto out;
                }
                if (pnvm_data && size > 0) {
                    memcpy(tmp, pnvm_data, size);
                    ::free(pnvm_data);
                }
                
                pnvm_data = tmp;
                
                memcpy(pnvm_data + size, section->data, data_len);
                
                size += data_len;
                
                break;
            }
            case IWX_UCODE_TLV_PNVM_SKU:
                XYLog("New PNVM section started, stop parsing.\n");
                goto done;
            default:
                XYLog("Found TLV 0x%0x, len %d\n",
                      tlv_type, tlv_len);
                break;
        }
        
        if (roundup(tlv_len, 4) > len)
            break;
        
        len -= roundup(tlv_len, 4);
        data += roundup(tlv_len, 4);
    }
    
done:
    if (!hw_match) {
        XYLog("HW mismatch, skipping PNVM section (need mac_type 0x%x rf_id 0x%x)\n",
                 CSR_HW_REV_TYPE(sc->sc_hw_rev),
                 CSR_HW_RFID_TYPE(sc->sc_hw_rf_id));
        err = -ENOENT;
        goto out;
    }

    if (!size) {
        XYLog("Empty PNVM, skipping.\n");
        err = -ENOENT;
        goto out;
    }
    
    XYLog("loaded PNVM version %08x\n", sha1);
    
    prph_sc_ctrl = &((struct iwx_prph_scratch *)sc->prph_scratch_dma.vaddr)->ctrl_cfg;
    
    iwx_dma_contig_free(&sc->pnvm_dram);
    err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->pnvm_dram, size, 0);
    if (err) {
        XYLog("%s: could not allocate context info DMA memory\n",
              DEVNAME(sc));
        goto out;
    }
    
    memcpy(sc->pnvm_dram.vaddr, pnvm_data, size);
    
    prph_sc_ctrl->pnvm_cfg.pnvm_base_addr =
        htole64(sc->pnvm_dram.paddr);
    prph_sc_ctrl->pnvm_cfg.pnvm_size =
        htole32(sc->pnvm_dram.size);
    
out:
    ::free(pnvm_data);
    
    return err;
}

int ItlIwx::
iwx_read_pnvm(struct iwx_softc *sc)
{
    int err = 0;
    OSData *fwData = NULL;
    struct iwx_fw_info *fw = &sc->sc_fw;
    char fwname_copy[64];
    char pnvm_name[64];
    struct iwx_ucode_tlv *tlv;
    uint8_t *data;
    size_t len;
    const char *find;
    
    if (fw->pnvm_rawdata != NULL)
        iwx_pnvm_free(fw);
    /*
     * The prefix unfortunately includes a hyphen at the end, so
     * don't add the dot here...
     */
    memcpy(fwname_copy, sc->sc_fwname, sizeof(fwname_copy));
    find = strrchr(sc->sc_fwname, '-');
    if (!find)
        goto out;
    if (find - sc->sc_fwname - 1 <= 0)
        goto out;
    fwname_copy[find - sc->sc_fwname - 1] = '\0';
    
    snprintf(pnvm_name, sizeof(pnvm_name), "%s.pnvm",
         fwname_copy);
    
    fwData = getFWDescByName(pnvm_name);

    if (fwData == NULL) {
        err = EINVAL;
        XYLog("%s resource load fail.\n", pnvm_name);
        goto out;
    }
    fw->pnvm_rawsize = fwData->getLength() * 20;
    fw->pnvm_rawdata = malloc(fw->pnvm_rawsize, 1, 1);
    uncompressFirmware((u_char *)fw->pnvm_rawdata, (uint *)&fw->pnvm_rawsize, (u_char *)fwData->getBytesNoCopy(), fwData->getLength());
    XYLog("load firmware %s done %zu\n", pnvm_name, fw->pnvm_rawsize);
    
    XYLog("Parsing PNVM file\n");
    
    data = (uint8_t *)fw->pnvm_rawdata;
    len = fw->pnvm_rawsize;
    
    while (len >= sizeof(*tlv)) {
        uint32_t tlv_len, tlv_type;

        len -= sizeof(*tlv);
        tlv = (struct iwx_ucode_tlv *)data;

        tlv_len = le32toh(tlv->length);
        tlv_type = le32toh(tlv->type);

        if (len < tlv_len || roundup(tlv_len, 4) > len) {
            XYLog("invalid TLV len: %zd/%u\n",
                len, tlv_len);
            err = -EINVAL;
            goto out;
        }

        if (tlv_type == IWX_UCODE_TLV_PNVM_SKU) {
            struct iwx_sku_id *sku_id =
                (struct iwx_sku_id *)(data + sizeof(*tlv));

            XYLog("Got IWL_UCODE_TLV_PNVM_SKU len %d\n",
                     tlv_len);
            XYLog("sku_id 0x%0x 0x%0x 0x%0x\n",
                     le32toh(sku_id->data[0]),
                     le32toh(sku_id->data[1]),
                     le32toh(sku_id->data[2]));

            data += sizeof(*tlv) + roundup(tlv_len, 4);
            len -= roundup(tlv_len, 4);

            if (sc->sku_id[0] == le32toh(sku_id->data[0]) &&
                sc->sku_id[1] == le32toh(sku_id->data[1]) &&
                sc->sku_id[2] == le32toh(sku_id->data[2])) {

                err = iwx_pnvm_handle_section(sc, data, len);
                if (!err)
                    goto out;
            } else {
                XYLog("SKU ID didn't match!\n");
            }
        } else {
            data += sizeof(*tlv) + roundup(tlv_len, 4);
            len -= roundup(tlv_len, 4);
        }
    }
    
    XYLog("PNVM parse done\n");
    
out:
    OSSafeReleaseNULL(fwData);
    
    return err;
}

int ItlIwx::
iwx_load_pnvm(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    int err;
    
    /* if the SKU_ID is empty, there's nothing to do */
    if (!sc->sku_id[0] && !sc->sku_id[1] && !sc->sku_id[2])
        return 0;
    
    if (!iwx_read_pnvm(sc)) {
        goto out;
    };
    
out:
    sc->sc_init_complete &= ~IWX_PNVM_COMPLETE;
    /* kick the doorbell */
    if (iwx_nic_lock(sc)) {
        iwx_write_umac_prph(sc, IWX_UREG_DOORBELL_TO_ISR6,
        IWX_UREG_DOORBELL_TO_ISR6_PNVM);
        iwx_nic_unlock(sc);
    }
    
    err = iwx_wait_notification(sc, &sc->sc_init_complete, IWX_PNVM_COMPLETE, 2000);
    if (err == ENXIO)
        return err;
    
    iwx_pnvm_free(&sc->sc_fw);
    
    return err;
}

static uint32_t iwx_prph_msk(struct iwx_softc *sc)
{
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        return 0x00FFFFFF;
    else
        return 0x000FFFFF;
}

uint32_t ItlIwx::
iwx_read_prph_unlocked(struct iwx_softc *sc, uint32_t addr)
{
    IWX_WRITE(sc,
              IWX_HBUS_TARG_PRPH_RADDR, ((addr & iwx_prph_msk(sc)) | (3 << 24)));
    IWX_BARRIER_READ_WRITE(sc);
    return IWX_READ(sc, IWX_HBUS_TARG_PRPH_RDAT);
}

uint32_t ItlIwx::
iwx_read_prph(struct iwx_softc *sc, uint32_t addr)
{
    iwx_nic_assert_locked(sc);
    return iwx_read_prph_unlocked(sc, addr);
}

uint32_t ItlIwx::
iwx_read_umac_prph(struct iwx_softc *sc, uint32_t addr)
{
    int off = 0;
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        off = GEN3_UMAC_PRPH_OFFSET;
    return iwx_read_prph(sc, off + addr);
}

void ItlIwx::
iwx_write_prph_unlocked(struct iwx_softc *sc, uint32_t addr, uint32_t val)
{
    IWX_WRITE(sc,
              IWX_HBUS_TARG_PRPH_WADDR, ((addr & iwx_prph_msk(sc)) | (3 << 24)));
    IWX_BARRIER_WRITE(sc);
    IWX_WRITE(sc, IWX_HBUS_TARG_PRPH_WDAT, val);
}

void ItlIwx::
iwx_write_umac_prph(struct iwx_softc *sc, uint32_t addr, uint32_t val)
{
    int off = 0;
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        off = GEN3_UMAC_PRPH_OFFSET;
    iwx_write_prph(sc, off + addr, val);
}

void ItlIwx::
iwx_write_prph(struct iwx_softc *sc, uint32_t addr, uint32_t val)
{
    iwx_nic_assert_locked(sc);
    iwx_write_prph_unlocked(sc, addr, val);
}

void ItlIwx::
iwx_write_prph64(struct iwx_softc *sc, uint64_t addr, uint64_t val)
{
    iwx_write_prph(sc, (uint32_t)addr, val & 0xffffffff);
    iwx_write_prph(sc, (uint32_t)addr + 4, val >> 32);
}

int ItlIwx::
iwx_read_mem(struct iwx_softc *sc, uint32_t addr, void *buf, int dwords)
{
    int offs, err = 0;
    uint32_t *vals = (uint32_t *)buf;
    
    if (iwx_nic_lock(sc)) {
        IWX_WRITE(sc, IWX_HBUS_TARG_MEM_RADDR, addr);
        for (offs = 0; offs < dwords; offs++)
            vals[offs] = le32toh(IWX_READ(sc, IWX_HBUS_TARG_MEM_RDAT));
        iwx_nic_unlock(sc);
    } else {
        err = EBUSY;
    }
    return err;
}

int ItlIwx::
iwx_write_mem(struct iwx_softc *sc, uint32_t addr, const void *buf, int dwords)
{
    int offs;
    const uint32_t *vals = (const uint32_t *)buf;
    
    if (iwx_nic_lock(sc)) {
        IWX_WRITE(sc, IWX_HBUS_TARG_MEM_WADDR, addr);
        /* WADDR auto-increments */
        for (offs = 0; offs < dwords; offs++) {
            uint32_t val = vals ? vals[offs] : 0;
            IWX_WRITE(sc, IWX_HBUS_TARG_MEM_WDAT, val);
        }
        iwx_nic_unlock(sc);
    } else {
        return EBUSY;
    }
    return 0;
}

int ItlIwx::
iwx_write_mem32(struct iwx_softc *sc, uint32_t addr, uint32_t val)
{
    return iwx_write_mem(sc, addr, &val, 1);
}

/*
 * A register that reads as all ones means the device is not answering on
 * the bus. That can happen briefly while the PCIe link comes back after
 * resume, so an all-ones read never counts as success but polling goes on
 * until the caller's timeout.
 */
int ItlIwx::
iwx_poll_bit(struct iwx_softc *sc, int reg, uint32_t bits, uint32_t mask,
             int timo)
{
    uint32_t val;
    
    for (;;) {
        val = IWX_READ(sc, reg);
        if (val != 0xffffffff && (val & mask) == (bits & mask))
            return 1;
        if (timo < 10) {
            if (val == 0xffffffff)
                XYLog("%s: device not responding (reg 0x%x reads 0xffffffff)\n",
                      DEVNAME(sc), reg);
            return 0;
        }
        timo -= 10;
        DELAY(10);
    }
}

int ItlIwx::
iwx_nic_lock(struct iwx_softc *sc)
{
    if (sc->sc_nic_locks > 0) {
        iwx_nic_assert_locked(sc);
        sc->sc_nic_locks++;
        return 1; /* already locked */
    }
    
    IWX_SETBITS(sc, IWX_CSR_GP_CNTRL,
                IWX_CSR_GP_CNTRL_REG_FLAG_MAC_ACCESS_REQ);
    
    DELAY(2);
    
    if (iwx_poll_bit(sc, IWX_CSR_GP_CNTRL,
                     IWX_CSR_GP_CNTRL_REG_VAL_MAC_ACCESS_EN,
                     IWX_CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY
                     | IWX_CSR_GP_CNTRL_REG_FLAG_GOING_TO_SLEEP, 150000)) {
        sc->sc_nic_locks++;
        return 1;
    }
    
    XYLog("%s: acquiring device failed\n", DEVNAME(sc));
    return 0;
}

void ItlIwx::
iwx_nic_assert_locked(struct iwx_softc *sc)
{
    if (sc->sc_nic_locks <= 0)
        panic("%s: nic locks counter %d", DEVNAME(sc), sc->sc_nic_locks);
}

void ItlIwx::
iwx_nic_unlock(struct iwx_softc *sc)
{
    if (sc->sc_nic_locks > 0) {
        if (--sc->sc_nic_locks == 0)
            IWX_CLRBITS(sc, IWX_CSR_GP_CNTRL,
                        IWX_CSR_GP_CNTRL_REG_FLAG_MAC_ACCESS_REQ);
    } else
        XYLog("%s: NIC already unlocked\n", DEVNAME(sc));
}

void ItlIwx::
iwx_set_bits_mask_prph(struct iwx_softc *sc, uint32_t reg, uint32_t bits,
                       uint32_t mask)
{
    uint32_t val;
    
    /* XXX: no error path? */
    if (iwx_nic_lock(sc)) {
        val = iwx_read_prph(sc, reg) & mask;
        val |= bits;
        iwx_write_prph(sc, reg, val);
        iwx_nic_unlock(sc);
    }
}

void ItlIwx::
iwx_set_bits_prph(struct iwx_softc *sc, uint32_t reg, uint32_t bits)
{
    iwx_set_bits_mask_prph(sc, reg, bits, ~0);
}

void ItlIwx::
iwx_clear_bits_prph(struct iwx_softc *sc, uint32_t reg, uint32_t bits)
{
    iwx_set_bits_mask_prph(sc, reg, 0, ~bits);
}

bool allocDmaMemory2(bus_dma_tag_t tag, struct iwx_dma_info *dma, size_t size, int alignment)
{
#ifdef AIRPORT_VTD
    if (!tag || !dma || size > UINT32_MAX || alignment < 0 ||
        !tag->allocate(static_cast<uint32_t>(size), alignment, dma->mapping))
        return false;
    dma->vaddr = dma->mapping.vaddr;
    dma->paddr = dma->mapping.address;
    dma->size = static_cast<bus_size_t>(size);
    return true;
#else
    IOBufferMemoryDescriptor *bmd;
    IODMACommand::Segment64 seg;
    UInt64 ofs = 0;
    UInt32 numSegs = 1;
    
    bmd = IOBufferMemoryDescriptor::inTaskWithPhysicalMask(kernel_task, kIODirectionInOut | kIOMemoryPhysicallyContiguous | kIOMapInhibitCache, size, DMA_BIT_MASK(64));
    
    if (bmd == NULL) {
        XYLog("%s alloc DMA memory failed.\n", __FUNCTION__);
        return false;
    }
    
    if (bmd->prepare() != kIOReturnSuccess) {
        XYLog("%s prepare DMA memory failed.\n", __FUNCTION__);
        bmd->release();
        bmd = NULL;
        return false;
    }
    IODMACommand *cmd = IODMACommand::withSpecification(kIODMACommandOutputHost64, 64, 0, IODMACommand::kMapped, 0, alignment);
    
    if (cmd == NULL) {
        XYLog("%s alloc IODMACommand memory failed.\n", __FUNCTION__);
        bmd->complete();
        bmd->release();
        return false;
    }

    if (cmd->setMemoryDescriptor(bmd) != kIOReturnSuccess
        || cmd->gen64IOVMSegments(&ofs, &seg, &numSegs) != kIOReturnSuccess) {
        cmd->release();
        cmd = NULL;
        bmd->complete();
        bmd->release();
        bmd = NULL;
        return false;
    }
    dma->paddr = seg.fIOVMAddr;
    dma->vaddr = bmd->getBytesNoCopy();
    dma->size = size;
    dma->buffer = bmd;
    dma->cmd = cmd;
    memset(dma->vaddr, 0, dma->size);
    return true;
#endif
}

int ItlIwx::
iwx_dma_contig_alloc(bus_dma_tag_t tag, struct iwx_dma_info *dma,
                     bus_size_t size, bus_size_t alignment)
{
    if (!allocDmaMemory2(tag, dma, size, alignment)) {
        return 1;
    }
    
    return 0;
}

void ItlIwx::
iwx_dma_contig_free(struct iwx_dma_info *dma)
{
#ifdef AIRPORT_VTD
    if (!dma)
        return;
    if (dma->mapping.arena)
        dma->mapping.arena->deallocate(dma->mapping);
    dma->vaddr = nullptr;
    dma->paddr = 0;
    dma->size = 0;
    return;
#endif
    if (dma == NULL || dma->cmd == NULL)
        return;
    if (dma->vaddr == NULL)
        return;
    dma->cmd->clearMemoryDescriptor();
    dma->cmd->release();
    dma->cmd = NULL;
    dma->buffer->complete();
    dma->buffer->release();
    dma->buffer = NULL;
    dma->vaddr = NULL;
}

/**
 * struct iwl_rx_transfer_desc - transfer descriptor
 * @addr: ptr to free buffer start address
 * @rbid: unique tag of the buffer
 * @reserved: reserved
 */
struct iwx_rx_transfer_desc {
    uint16_t rbid;
    uint16_t reserved[3];
    uint64_t addr;
} __packed;

int ItlIwx::
iwx_alloc_rx_ring(struct iwx_softc *sc, struct iwx_rx_ring *ring)
{
    bus_size_t size;
    int i, err;
    int rb_stts_size = sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? sizeof(uint16_t) : sizeof(iwx_rb_status);
    int rb_stts_align = sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? 0 : 16;
    
    ring->cur = 0;
    
    /* Allocate RX descriptors (256-byte aligned). */
    size = IWX_RX_MQ_RING_COUNT * (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? sizeof(struct iwx_rx_transfer_desc) : sizeof(uint64_t));
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->free_desc_dma, size, 256);
    if (err) {
        XYLog("%s: could not allocate RX ring DMA memory\n",
              DEVNAME(sc));
        goto fail;
    }
    ring->desc = ring->free_desc_dma.vaddr;
    
    /* Allocate RX status area (16-byte aligned). */
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->stat_dma,
                               rb_stts_size, rb_stts_align);
    if (err) {
        XYLog("%s: could not allocate RX status DMA memory\n",
              DEVNAME(sc));
        goto fail;
    }
    ring->stat = ring->stat_dma.vaddr;
    
    size = IWX_RX_MQ_RING_COUNT * (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? sizeof(struct iwx_rx_completion_desc) : sizeof(uint32_t));
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->used_desc_dma,
                               size, 256);
    if (err) {
        XYLog("%s: could not allocate RX ring DMA memory\n",
              DEVNAME(sc));
        goto fail;
    }
    
    for (i = 0; i < IWX_RX_MQ_RING_COUNT; i++) {
        struct iwx_rx_data *data = &ring->data[i];
        
        memset(data, 0, sizeof(*data));
        err = bus_dmamap_create(sc->sc_dmat, IWX_RBUF_SIZE, 1,
                                IWX_RBUF_SIZE, 0, BUS_DMA_NOWAIT,
                                &data->map);
        if (err) {
            XYLog("%s: could not create RX buf DMA map\n",
                  DEVNAME(sc));
            goto fail;
        }
        
        err = iwx_rx_addbuf(sc, IWX_RBUF_SIZE, i);
        if (err)
            goto fail;
    }
    return 0;
    
fail:    iwx_free_rx_ring(sc, ring);
    return err;
}

void ItlIwx::
iwx_disable_rx_dma(struct iwx_softc *sc)
{
    int ntries;
    
    if (iwx_nic_lock(sc)) {
        if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
            iwx_write_umac_prph(sc, IWX_RFH_RXF_DMA_CFG_GEN3, 0);
            for (ntries = 0; ntries < 1000; ntries++) {
                uint32_t val = iwx_read_umac_prph(sc, IWX_RFH_GEN_STATUS_GEN3);
                if (val == 0xFFFFFFFF || (val & IWX_RXF_DMA_IDLE))
                    break;
                DELAY(10);
            }
        } else {
            iwx_write_prph(sc, IWX_RFH_RXF_DMA_CFG, 0);
            for (ntries = 0; ntries < 1000; ntries++) {
                uint32_t val = iwx_read_prph(sc, IWX_RFH_GEN_STATUS);
                if (val == 0xFFFFFFFF || (val & IWX_RXF_DMA_IDLE))
                    break;
                DELAY(10);
            }
        }
        iwx_nic_unlock(sc);
    }
}

void ItlIwx::
iwx_reset_rx_ring(struct iwx_softc *sc, struct iwx_rx_ring *ring)
{
    ring->cur = 0;
    //    bus_dmamap_sync(sc->sc_dmat, ring->stat_dma.map, 0,
    //        ring->stat_dma.size, BUS_DMASYNC_PREWRITE);
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        memset(ring->stat, 0, sizeof(uint16_t));
    else
        memset(ring->stat, 0, sizeof(struct iwx_rb_status));
    //    bus_dmamap_sync(sc->sc_dmat, ring->stat_dma.map, 0,
    //        ring->stat_dma.size, BUS_DMASYNC_POSTWRITE);
    
}

void ItlIwx::
iwx_free_rx_ring(struct iwx_softc *sc, struct iwx_rx_ring *ring)
{
    int i;
    
    iwx_dma_contig_free(&ring->free_desc_dma);
    iwx_dma_contig_free(&ring->stat_dma);
    iwx_dma_contig_free(&ring->used_desc_dma);
    
    for (i = 0; i < IWX_RX_MQ_RING_COUNT; i++) {
        struct iwx_rx_data *data = &ring->data[i];
        
        if (data->m != NULL) {
            //            bus_dmamap_sync(sc->sc_dmat, data->map, 0,
            //                data->map->dm_mapsize, BUS_DMASYNC_POSTREAD);
            //            bus_dmamap_unload(sc->sc_dmat, data->map);
            mbuf_freem(data->m);
            data->m = NULL;
        }
        if (data->map != NULL) {
            bus_dmamap_destroy(sc->sc_dmat, data->map);
            data->map = NULL;
        }
    }
}

void ItlIwx::
iwx_tx_ring_init(struct iwx_softc *sc, struct iwx_tx_ring *ring, int size)
{
    int low_mark, high_mark;

    ring->ring_count = size;
    low_mark = ring->ring_count / 4;
    if (low_mark < 4)
        low_mark = 4;
    ring->low_mark = ring->ring_count - low_mark;

    high_mark = ring->ring_count / 8;
    if (high_mark < 2)
        high_mark = 2;
    ring->hi_mark = ring->ring_count - high_mark;
    ring->queued = 0;
    ring->cur = 0;
    ring->tail = 0;
}

int ItlIwx::
iwx_alloc_tx_ring(struct iwx_softc *sc, struct iwx_tx_ring *ring, int qid)
{
    bus_addr_t paddr;
    bus_size_t size;
    int i, err;

    /* 0:CMD 2:MGMT */
    if (qid > IWX_QID_MGMT) {
        ring->qid = IWX_INVALID_QUEUE;
        return 0;
    }
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        if (qid == IWX_DQA_CMD_QUEUE)
            size = IWX_CMD_QUEUE_SIZE_GEN3;
        else
            size = IWX_MIN_256_BA_QUEUE_SIZE_GEN3;
    }
    else {
        if (qid == IWX_DQA_CMD_QUEUE)
            size = IWX_CMD_QUEUE_SIZE;
        else
            size = IWX_DEFAULT_QUEUE_SIZE;
    }
    iwx_tx_ring_init(sc, ring, size);
    ring->qid = qid;
    /* Allocate TX descriptors (256-byte aligned). */
    size = ring->ring_count * sizeof (struct iwx_tfh_tfd);
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->desc_dma, size, 256);
    if (err) {
        XYLog("%s: could not allocate TX ring DMA memory\n",
              DEVNAME(sc));
        goto fail;
    }
    ring->desc = (struct iwx_tfh_tfd*)ring->desc_dma.vaddr;

    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->bc_tbl,
                                   sizeof(struct iwx_gen3_bc_tbl), 0);
    else
        err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->bc_tbl,
                                   sizeof(struct iwx_agn_scd_bc_tbl), 0);
    if (err) {
        XYLog("%s: could not allocate byte count table DMA memory\n",
              DEVNAME(sc));
        goto fail;
    }
    
    size = ring->ring_count * sizeof(struct iwx_device_cmd);
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->cmd_dma, size,
                               IWX_FIRST_TB_SIZE_ALIGN);
    if (err) {
        XYLog("%s: could not allocate cmd DMA memory\n", DEVNAME(sc));
        goto fail;
    }
    ring->cmd = (struct iwx_device_cmd*)ring->cmd_dma.vaddr;
    
    paddr = ring->cmd_dma.paddr;
    for (i = 0; i < ring->ring_count; i++) {
        struct iwx_tx_data *data = &ring->data[i];
        size_t mapsize;
        
        data->cmd_paddr = paddr;
        paddr += sizeof(struct iwx_device_cmd);
        
        /* FW commands may require more mapped space than packets. */
        if (qid == IWX_DQA_CMD_QUEUE)
            mapsize = (sizeof(struct iwx_cmd_header) +
                       IWX_MAX_CMD_PAYLOAD_SIZE);
        else
            mapsize = MCLBYTES;
        err = bus_dmamap_create(sc->sc_dmat, mapsize,
                                IWX_TFH_NUM_TBS - 2, mapsize, 0, BUS_DMA_NOWAIT,
                                &data->map);
        if (err) {
            XYLog("%s: could not create TX buf DMA map\n",
                  DEVNAME(sc));
            goto fail;
        }
    }
    KASSERT(paddr == ring->cmd_dma.paddr + size, "paddr == ring->cmd_dma.paddr + size");
    return 0;
    
fail:    iwx_free_tx_ring(sc, ring);
    return err;
}

void ItlIwx::
iwx_reset_tx_ring(struct iwx_softc *sc, struct iwx_tx_ring *ring)
{
    int i;
    
    for (i = 0; i < ring->ring_count; i++) {
        struct iwx_tx_data *data = &ring->data[i];
        if (ring->qid == IWX_DQA_CMD_QUEUE) {
            data->flags = 0;
            ::free(sc->sc_cmd_resp_pkt[i]);
            sc->sc_cmd_resp_pkt[i] = NULL;
            sc->sc_cmd_resp_len[i] = 0;
            if (ring->desc)
                getMainCommandGate()->commandWakeup(&ring->desc[i]);
        }
        
        if (data == awdlMonitorPending) {
            // Match normal completion order: release packet storage before the
            // retained node; the generic reset below then sees a null packet.
            if (data->m) {
                mbuf_freem(data->m);
                data->m = nullptr;
            }
            if (data->in) {
                ieee80211_release_node(&sc->sc_ic, &data->in->in_ni);
                data->in = nullptr;
            }
            awdlMonitorPending = nullptr;
            awdlTxLog("single-frame pending ownership returned during ring reset\n");
        }
        // The listener's frames hold a node reference, released on completion; a reset has to release it too.
        if (data->m != NULL && data->in &&
            ((awdlCoexQueue >= 0 && ring->qid == awdlCoexQueue) || (awdlCoexOrphanQueue >= 0 && ring->qid == awdlCoexOrphanQueue) ||
             (awdlCoexBaTxQueue >= 0 && ring->qid == awdlCoexBaTxQueue) ||
             (awdlCoexBaTxResetting >= 0 && ring->qid == awdlCoexBaTxResetting))) {
            ieee80211_release_node(&sc->sc_ic, &data->in->in_ni);
            data->in = nullptr;
        }
        if (data->m != NULL) {
            //            bus_dmamap_sync(sc->sc_dmat, data->map, 0,
            //                data->map->dm_mapsize, BUS_DMASYNC_POSTWRITE);
            //            bus_dmamap_unload(sc->sc_dmat, data->map);
            mbuf_freem(data->m);
            data->m = NULL;
        }
    }

    if (awdlCoexOrphanQueue >= 0 && ring->qid == awdlCoexOrphanQueue)
        awdlCoexOrphanQueue = -1;
    if (ring->qid == IWX_INVALID_QUEUE || !ring->desc) {
        return;
    }
    
    /* Clear byte count table. */
    memset(ring->bc_tbl.vaddr, 0, ring->bc_tbl.size);
    
    /* Clear TX descriptors. */
    memset(ring->desc, 0, ring->desc_dma.size);
    //    bus_dmamap_sync(sc->sc_dmat, ring->desc_dma.map, 0,
    //        ring->desc_dma.size, BUS_DMASYNC_PREWRITE);
    sc->qfullmsk.clear(ring->qid);
    ring->queued = 0;
    ring->cur = 0;
    ring->tail = 0;
}

void ItlIwx::
iwx_free_tx_ring(struct iwx_softc *sc, struct iwx_tx_ring *ring)
{
    int i;
    
    iwx_dma_contig_free(&ring->desc_dma);
    iwx_dma_contig_free(&ring->cmd_dma);
    iwx_dma_contig_free(&ring->bc_tbl);
    
    for (i = 0; i < ring->ring_count; i++) {
        struct iwx_tx_data *data = &ring->data[i];
        
        if (data->m != NULL) {
            //            bus_dmamap_sync(sc->sc_dmat, data->map, 0,
            //                data->map->dm_mapsize, BUS_DMASYNC_POSTWRITE);
            //            bus_dmamap_unload(sc->sc_dmat, data->map);
            mbuf_freem(data->m);
            data->m = NULL;
        }
        if (data->map != NULL) {
            bus_dmamap_destroy(sc->sc_dmat, data->map);
            data->map = NULL;
        }
    }
    ring->qid = IWX_INVALID_QUEUE;
    ring->hi_mark = 0;
    ring->low_mark = 0;
    ring->ring_count = 0;
}

void ItlIwx::
iwx_enable_rfkill_int(struct iwx_softc *sc)
{
    if (!sc->sc_msix) {
        sc->sc_intmask = IWX_CSR_INT_BIT_RF_KILL;
        IWX_WRITE(sc, IWX_CSR_INT_MASK, sc->sc_intmask);
    } else {
        IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                  sc->sc_fh_init_mask);
        IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_MASK_AD,
                  ~IWX_MSIX_HW_INT_CAUSES_REG_RF_KILL);
        sc->sc_hw_mask = IWX_MSIX_HW_INT_CAUSES_REG_RF_KILL;
    }
    
    IWX_SETBITS(sc, IWX_CSR_GP_CNTRL,
                IWX_CSR_GP_CNTRL_REG_FLAG_RFKILL_WAKE_L1A_EN);
}

int ItlIwx::
iwx_check_rfkill(struct iwx_softc *sc)
{
    uint32_t v;
    int s;
    int rv;
    
    s = splnet();
    
    /*
     * "documentation" is not really helpful here:
     *  27:    HW_RF_KILL_SW
     *    Indicates state of (platform's) hardware RF-Kill switch
     *
     * But apparently when it's off, it's on ...
     */
    v = IWX_READ(sc, IWX_CSR_GP_CNTRL);
    rv = (v & IWX_CSR_GP_CNTRL_REG_FLAG_HW_RF_KILL_SW) == 0;
    if (rv) {
        sc->sc_flags |= IWX_FLAG_RFKILL;
    } else {
        sc->sc_flags &= ~IWX_FLAG_RFKILL;
    }
    
    XYLog("%s RF_KILL hw: %d\n", __FUNCTION__, rv);

    splx(s);
    return rv;
}

void ItlIwx::
iwx_enable_interrupts(struct iwx_softc *sc)
{
    if (!sc->sc_msix) {
        sc->sc_intmask = IWX_CSR_INI_SET_MASK;
        IWX_WRITE(sc, IWX_CSR_INT_MASK, sc->sc_intmask);
    } else {
        /*
         * fh/hw_mask keeps all the unmasked causes.
         * Unlike msi, in msix cause is enabled when it is unset.
         */
        sc->sc_hw_mask = sc->sc_hw_init_mask;
        sc->sc_fh_mask = sc->sc_fh_init_mask;
        IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                  ~sc->sc_fh_mask);
        IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_MASK_AD,
                  ~sc->sc_hw_mask);
    }
}

void ItlIwx::
iwx_enable_fwload_interrupt(struct iwx_softc *sc)
{
    
    XYLog("%s\n", __FUNCTION__);
    if (!sc->sc_msix) {
        sc->sc_intmask = IWX_CSR_INT_BIT_ALIVE | IWX_CSR_INT_BIT_FH_RX;
        IWX_WRITE(sc, IWX_CSR_INT_MASK, sc->sc_intmask);
    } else {
        IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_MASK_AD,
                  ~IWX_MSIX_HW_INT_CAUSES_REG_ALIVE);
        sc->sc_hw_mask = IWX_MSIX_HW_INT_CAUSES_REG_ALIVE;
        /*
         * Leave all the FH causes enabled to get the ALIVE
         * notification.
         */
        IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                  ~sc->sc_fh_init_mask);
        sc->sc_fh_mask = sc->sc_fh_init_mask;
    }
}

void ItlIwx::
iwx_restore_interrupts(struct iwx_softc *sc)
{
    IWX_WRITE(sc, IWX_CSR_INT_MASK, sc->sc_intmask);
}

void ItlIwx::
iwx_disable_interrupts(struct iwx_softc *sc)
{
    int s = splnet();
    
    if (!sc->sc_msix) {
        IWX_WRITE(sc, IWX_CSR_INT_MASK, 0);
        
        /* acknowledge all interrupts */
        IWX_WRITE(sc, IWX_CSR_INT, ~0);
        IWX_WRITE(sc, IWX_CSR_FH_INT_STATUS, ~0);
    } else {
        IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                  sc->sc_fh_init_mask);
        IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_MASK_AD,
                  sc->sc_hw_init_mask);
    }
    
    splx(s);
}

void ItlIwx::
iwx_ict_reset(struct iwx_softc *sc)
{
    iwx_disable_interrupts(sc);
    
    memset(sc->ict_dma.vaddr, 0, IWX_ICT_SIZE);
    sc->ict_cur = 0;
    
    /* Set physical address of ICT (4KB aligned). */
    IWX_WRITE(sc, IWX_CSR_DRAM_INT_TBL_REG,
              IWX_CSR_DRAM_INT_TBL_ENABLE
              | IWX_CSR_DRAM_INIT_TBL_WRAP_CHECK
              | IWX_CSR_DRAM_INIT_TBL_WRITE_POINTER
              | sc->ict_dma.paddr >> IWX_ICT_PADDR_SHIFT);
    
    /* Switch to ICT interrupt mode in driver. */
    sc->sc_flags |= IWX_FLAG_USE_ICT;
    
    IWX_WRITE(sc, IWX_CSR_INT, sc->sc_intmask);
    iwx_enable_interrupts(sc);
}

#define IWX_HW_READY_TIMEOUT 50
int ItlIwx::
iwx_set_hw_ready(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    int ready;
    
    IWX_SETBITS(sc, IWX_CSR_HW_IF_CONFIG_REG,
                IWX_CSR_HW_IF_CONFIG_REG_BIT_NIC_READY);
    
    ready = iwx_poll_bit(sc, IWX_CSR_HW_IF_CONFIG_REG,
                         IWX_CSR_HW_IF_CONFIG_REG_BIT_NIC_READY,
                         IWX_CSR_HW_IF_CONFIG_REG_BIT_NIC_READY,
                         IWX_HW_READY_TIMEOUT);
    if (ready)
        IWX_SETBITS(sc, IWX_CSR_MBOX_SET_REG,
                    IWX_CSR_MBOX_SET_REG_OS_ALIVE);
    
    return ready;
}
#undef IWX_HW_READY_TIMEOUT

int ItlIwx::
iwx_prepare_card_hw(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    int t = 0;
    int ntries;
    
    if (iwx_set_hw_ready(sc))
        return 0;
    
    IWX_SETBITS(sc, IWX_CSR_DBG_LINK_PWR_MGMT_REG,
                IWX_CSR_RESET_LINK_PWR_MGMT_DISABLED);
    DELAY(1000);
    
    
    for (ntries = 0; ntries < 10; ntries++) {
        /* If HW is not ready, prepare the conditions to check again */
        IWX_SETBITS(sc, IWX_CSR_HW_IF_CONFIG_REG,
                    IWX_CSR_HW_IF_CONFIG_REG_PREPARE);
        
        t = 0;
        do {
            uint32_t val = IWX_READ(sc, IWX_CSR_HW_IF_CONFIG_REG);
            if (val == 0xFFFFFFFF)
                return ENXIO;
            if (iwx_set_hw_ready(sc))
                return 0;
            DELAY(200);
            t += 200;
        } while (t < 150000);
        DELAY(25000);
    }
    
    return ETIMEDOUT;
}

void ItlIwx::
iwx_apm_config(struct iwx_softc *sc)
{
    pcireg_t lctl, cap;
    
    /*
     * L0S states have been found to be unstable with our devices
     * and in newer hardware they are not officially supported at
     * all, so we must always set the L0S_DISABLED bit.
     */
    IWX_SETBITS(sc, IWX_CSR_GIO_REG, IWX_CSR_GIO_REG_VAL_L0S_DISABLED);
    lctl = pci_conf_read(sc->sc_pct, sc->sc_pcitag,
                         sc->sc_cap_off + PCI_PCIE_LCSR);
    /*
     * Disable L0s and L1s in PCIE register because we don't support ASPM now.
     */
    lctl &= ~(PCI_PCIE_LCSR_ASPM_L0S | PCI_PCIE_LCSR_ASPM_L1);
    pci_conf_write(sc->sc_pct, sc->sc_pcitag, sc->sc_cap_off + PCI_PCIE_LCSR, lctl);
    lctl = pci_conf_read(sc->sc_pct, sc->sc_pcitag, sc->sc_cap_off + PCI_PCIE_LCSR);
    
    cap = pci_conf_read(sc->sc_pct, sc->sc_pcitag,
                        sc->sc_cap_off + PCI_PCIE_DCSR2);
    sc->sc_ltr_enabled = (cap & PCI_PCIE_DCSR2_LTREN) ? 1 : 0;
    DPRINTF(("%s: L1 %sabled - LTR %sabled\n",
             DEVNAME(sc),
             (lctl & PCI_PCIE_LCSR_ASPM_L1) ? "En" : "Dis",
             sc->sc_ltr_enabled ? "En" : "Dis"));
}

/*
 * Start up NIC's basic functionality after it has been reset
 * e.g. after platform boot or shutdown.
 * NOTE:  This does not load uCode nor start the embedded processor
 */
int ItlIwx::
iwx_apm_init(struct iwx_softc *sc)
{
    int err = 0;
    
    /*
     * Disable L0s without affecting L1;
     *  don't wait for ICH L0s (ICH bug W/A)
     */
    IWX_SETBITS(sc, IWX_CSR_GIO_CHICKEN_BITS,
                IWX_CSR_GIO_CHICKEN_BITS_REG_BIT_L1A_NO_L0S_RX);
    
    /* Set FH wait threshold to maximum (HW error during stress W/A) */
    IWX_SETBITS(sc, IWX_CSR_DBG_HPET_MEM_REG, IWX_CSR_DBG_HPET_MEM_REG_VAL);
    
    /*
     * Enable HAP INTA (interrupt from management bus) to
     * wake device's PCI Express link L1a -> L0s
     */
    IWX_SETBITS(sc, IWX_CSR_HW_IF_CONFIG_REG,
                IWX_CSR_HW_IF_CONFIG_REG_BIT_HAP_WAKE_L1A);
    
    iwx_apm_config(sc);
    
    /*
     * Set "initialization complete" bit to move adapter from
     * D0U* --> D0A* (powered-up active) state.
     */
    IWX_SETBITS(sc, IWX_CSR_GP_CNTRL, IWX_CSR_GP_CNTRL_REG_FLAG_INIT_DONE);
    
    /*
     * Wait for clock stabilization; once stabilized, access to
     * device-internal resources is supported, e.g. iwx_write_prph()
     * and accesses to uCode SRAM.
     */
    if (!iwx_poll_bit(sc, IWX_CSR_GP_CNTRL,
                      IWX_CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY,
                      IWX_CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY, 25000)) {
        XYLog("%s: timeout waiting for clock stabilization\n",
              DEVNAME(sc));
        err = ETIMEDOUT;
        goto out;
    }
out:
    if (err)
        XYLog("%s: apm init error %d\n", DEVNAME(sc), err);
    return err;
}

void ItlIwx::
iwx_apm_stop(struct iwx_softc *sc)
{
    IWX_SETBITS(sc, IWX_CSR_DBG_LINK_PWR_MGMT_REG,
                IWX_CSR_RESET_LINK_PWR_MGMT_DISABLED);
    IWX_SETBITS(sc, IWX_CSR_HW_IF_CONFIG_REG,
                IWX_CSR_HW_IF_CONFIG_REG_PREPARE |
                IWX_CSR_HW_IF_CONFIG_REG_ENABLE_PME);
    DELAY(1000);
    IWX_CLRBITS(sc, IWX_CSR_DBG_LINK_PWR_MGMT_REG,
                IWX_CSR_RESET_LINK_PWR_MGMT_DISABLED);
    DELAY(5000);
    
    /* stop device's busmaster DMA activity */
    IWX_SETBITS(sc, IWX_CSR_RESET, IWX_CSR_RESET_REG_FLAG_STOP_MASTER);
    
    if (!iwx_poll_bit(sc, IWX_CSR_RESET,
                      IWX_CSR_RESET_REG_FLAG_MASTER_DISABLED,
                      IWX_CSR_RESET_REG_FLAG_MASTER_DISABLED, 100))
        XYLog("%s: timeout waiting for master\n", DEVNAME(sc));
    
    /*
     * Clear "initialization complete" bit to move adapter from
     * D0A* (powered-up Active) --> D0U* (Uninitialized) state.
     */
    IWX_CLRBITS(sc, IWX_CSR_GP_CNTRL,
                IWX_CSR_GP_CNTRL_REG_FLAG_INIT_DONE);
}

void ItlIwx::
iwx_init_msix_hw(struct iwx_softc *sc)
{
    iwx_conf_msix_hw(sc, 0);
    
    if (!sc->sc_msix)
        return;
    
    sc->sc_fh_init_mask = ~IWX_READ(sc, IWX_CSR_MSIX_FH_INT_MASK_AD);
    sc->sc_fh_mask = sc->sc_fh_init_mask;
    sc->sc_hw_init_mask = ~IWX_READ(sc, IWX_CSR_MSIX_HW_INT_MASK_AD);
    sc->sc_hw_mask = sc->sc_hw_init_mask;
}

void ItlIwx::
iwx_conf_msix_hw(struct iwx_softc *sc, int stopped)
{
    int vector = 0;
    
    if (!sc->sc_msix) {
        /* Newer chips default to MSIX. */
        if (!stopped && iwx_nic_lock(sc)) {
            iwx_write_umac_prph(sc, IWX_UREG_CHICK,
                           IWX_UREG_CHICK_MSI_ENABLE);
            iwx_nic_unlock(sc);
        }
        return;
    }
    
    if (!stopped && iwx_nic_lock(sc)) {
        iwx_write_umac_prph(sc, IWX_UREG_CHICK, IWX_UREG_CHICK_MSIX_ENABLE);
        iwx_nic_unlock(sc);
    }
    
    /* Disable all interrupts */
    IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_MASK_AD, ~0);
    IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_MASK_AD, ~0);
    
    /* Map fallback-queue (command/mgmt) to a single vector */
    IWX_WRITE_1(sc, IWX_CSR_MSIX_RX_IVAR(0),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    /* Map RSS queue (data) to the same vector */
    IWX_WRITE_1(sc, IWX_CSR_MSIX_RX_IVAR(1),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    
    /* Enable the RX queues cause interrupts */
    IWX_CLRBITS(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                IWX_MSIX_FH_INT_CAUSES_Q0 | IWX_MSIX_FH_INT_CAUSES_Q1);
    
    /* Map non-RX causes to the same vector */
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_D2S_CH0_NUM),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_D2S_CH1_NUM),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_S2D),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_FH_ERR),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_ALIVE),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_WAKEUP),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_IML),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_CT_KILL),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_RF_KILL),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_PERIODIC),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_SW_ERR),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_SCD),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_FH_TX),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_HW_ERR),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    IWX_WRITE_1(sc, IWX_CSR_MSIX_IVAR(IWX_MSIX_IVAR_CAUSE_REG_HAP),
                vector | IWX_MSIX_NON_AUTO_CLEAR_CAUSE);
    
    /* Enable non-RX causes interrupts */
    IWX_CLRBITS(sc, IWX_CSR_MSIX_FH_INT_MASK_AD,
                IWX_MSIX_FH_INT_CAUSES_D2S_CH0_NUM |
                IWX_MSIX_FH_INT_CAUSES_D2S_CH1_NUM |
                IWX_MSIX_FH_INT_CAUSES_S2D |
                IWX_MSIX_FH_INT_CAUSES_FH_ERR);
    IWX_CLRBITS(sc, IWX_CSR_MSIX_HW_INT_MASK_AD,
                IWX_MSIX_HW_INT_CAUSES_REG_ALIVE |
                IWX_MSIX_HW_INT_CAUSES_REG_WAKEUP |
                IWX_MSIX_HW_INT_CAUSES_REG_IML |
                IWX_MSIX_HW_INT_CAUSES_REG_CT_KILL |
                IWX_MSIX_HW_INT_CAUSES_REG_RF_KILL |
                IWX_MSIX_HW_INT_CAUSES_REG_PERIODIC |
                IWX_MSIX_HW_INT_CAUSES_REG_SW_ERR |
                IWX_MSIX_HW_INT_CAUSES_REG_SCD |
                IWX_MSIX_HW_INT_CAUSES_REG_FH_TX |
                IWX_MSIX_HW_INT_CAUSES_REG_HW_ERR |
                IWX_MSIX_HW_INT_CAUSES_REG_HAP);
}

int ItlIwx::
iwx_start_hw(struct iwx_softc *sc)
{
#ifdef AIRPORT_VTD
    if (dmaDetaching)
        return ENXIO;
    sc->sc_pcitag->setBusMasterEnable(true);
#endif
    XYLog("%s\n", __FUNCTION__);
    int err;
    
    err = iwx_prepare_card_hw(sc);
    if (err)
        return err;
    
    iwx_clear_persistence_bit(sc);
    
    /* Reset the entire device */
    IWX_SETBITS(sc, IWX_CSR_RESET, IWX_CSR_RESET_REG_FLAG_SW_RESET);
    DELAY(5000);
    
    if (sc->sc_device_family == IWX_DEVICE_FAMILY_22000 && sc->sc_integrated) {
        IWX_SETBITS(sc, IWX_CSR_GP_CNTRL,
                    IWX_CSR_GP_CNTRL_REG_FLAG_INIT_DONE);
        DELAY(20);
        if (!iwx_poll_bit(sc, IWX_CSR_GP_CNTRL,
                          IWX_CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY,
                          IWX_CSR_GP_CNTRL_REG_FLAG_MAC_CLOCK_READY, 25000)) {
            XYLog("%s: timeout waiting for clock stabilization\n",
                  DEVNAME(sc));
            return ETIMEDOUT;
        }
        
        iwx_force_power_gating(sc);
        
        /* Reset the entire device */
        IWX_SETBITS(sc, IWX_CSR_RESET, IWX_CSR_RESET_REG_FLAG_SW_RESET);
        DELAY(5000);
    }
    
    err = iwx_apm_init(sc);
    if (err)
        return err;
    
    iwx_init_msix_hw(sc);
    
    iwx_enable_rfkill_int(sc);
    iwx_check_rfkill(sc);
    
    return 0;
}


void ItlIwx::
iwx_stop_device(struct iwx_softc *sc)
{
    if (!getMainWorkLoop()->inGate()) {
        getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
                ItlIwx *that = (ItlIwx *)arg0;
                that->iwx_stop_device((struct iwx_softc *)arg1);
                return kIOReturnSuccess;
            }, this, sc);
        return;
    }

#ifdef AIRPORT_VTD
    dmaEpoch++;
#endif
    XYLog("%s\n", __FUNCTION__);
    int qid;
    
    iwx_disable_interrupts(sc);
    sc->sc_flags &= ~IWX_FLAG_USE_ICT;
    
    iwx_disable_rx_dma(sc);
#ifndef AIRPORT_VTD
    iwx_reset_rx_ring(sc, &sc->rxq);
    for (qid = 0; qid < nitems(sc->txq); qid++)
        iwx_reset_tx_ring(sc, &sc->txq[qid]);
#endif
    
    /* Make sure (redundant) we've released our request to stay awake */
    IWX_CLRBITS(sc, IWX_CSR_GP_CNTRL,
                IWX_CSR_GP_CNTRL_REG_FLAG_MAC_ACCESS_REQ);
    if (sc->sc_nic_locks > 0)
        XYLog("%s: %d active NIC locks forcefully cleared\n",
              DEVNAME(sc), sc->sc_nic_locks);
    sc->sc_nic_locks = 0;
    
    /* Stop the device, and put it in low power state */
    iwx_apm_stop(sc);
    
    /* Reset the on-board processor. */
    IWX_SETBITS(sc, IWX_CSR_RESET, IWX_CSR_RESET_REG_FLAG_SW_RESET);
    DELAY(5000);
#ifdef AIRPORT_VTD
    sc->sc_pcitag->setBusMasterEnable(false);
    iwx_reset_rx_ring(sc, &sc->rxq);
    for (qid = 0; qid < nitems(sc->txq); qid++)
        iwx_reset_tx_ring(sc, &sc->txq[qid]);
#endif
    
    /*
     * Upon stop, the IVAR table gets erased, so msi-x won't
     * work. This causes a bug in RF-KILL flows, since the interrupt
     * that enables radio won't fire on the correct irq, and the
     * driver won't be able to handle the interrupt.
     * Configure the IVAR table again after reset.
     */
    iwx_conf_msix_hw(sc, 1);
    
    /*
     * Upon stop, the APM issues an interrupt if HW RF kill is set.
     * Clear the interrupt again.
     */
    iwx_disable_interrupts(sc);
    
    /* Even though we stop the HW we still want the RF kill interrupt. */
    iwx_enable_rfkill_int(sc);
    iwx_check_rfkill(sc);
    
    iwx_prepare_card_hw(sc);
    
    iwx_ctxt_info_free_paging(sc);
    /* free gen3 devices related firmware DMA resource */
    iwx_dma_contig_free(&sc->prph_info_dma);
    iwx_dma_contig_free(&sc->prph_scratch_dma);
    iwx_dma_contig_free(&sc->iml_dma);
    iwx_dma_contig_free(&sc->pnvm_dram);
#ifdef AIRPORT_VTD
    sc->sc_dmat->reclaim();
#endif
}

void ItlIwx::
iwx_nic_config(struct iwx_softc *sc)
{
    uint8_t radio_cfg_type, radio_cfg_step, radio_cfg_dash;
    uint32_t mask, val, reg_val = 0;
    
    radio_cfg_type = (sc->sc_fw_phy_config & IWX_FW_PHY_CFG_RADIO_TYPE) >>
    IWX_FW_PHY_CFG_RADIO_TYPE_POS;
    radio_cfg_step = (sc->sc_fw_phy_config & IWX_FW_PHY_CFG_RADIO_STEP) >>
    IWX_FW_PHY_CFG_RADIO_STEP_POS;
    radio_cfg_dash = (sc->sc_fw_phy_config & IWX_FW_PHY_CFG_RADIO_DASH) >>
    IWX_FW_PHY_CFG_RADIO_DASH_POS;
    
    reg_val |= IWX_CSR_HW_REV_STEP(sc->sc_hw_rev) <<
    IWX_CSR_HW_IF_CONFIG_REG_POS_MAC_STEP;
    reg_val |= IWX_CSR_HW_REV_DASH(sc->sc_hw_rev) <<
    IWX_CSR_HW_IF_CONFIG_REG_POS_MAC_DASH;
    
    /* radio configuration */
    reg_val |= radio_cfg_type << IWX_CSR_HW_IF_CONFIG_REG_POS_PHY_TYPE;
    reg_val |= radio_cfg_step << IWX_CSR_HW_IF_CONFIG_REG_POS_PHY_STEP;
    reg_val |= radio_cfg_dash << IWX_CSR_HW_IF_CONFIG_REG_POS_PHY_DASH;
    
    mask = IWX_CSR_HW_IF_CONFIG_REG_MSK_MAC_DASH |
    IWX_CSR_HW_IF_CONFIG_REG_MSK_MAC_STEP |
    IWX_CSR_HW_IF_CONFIG_REG_MSK_PHY_STEP |
    IWX_CSR_HW_IF_CONFIG_REG_MSK_PHY_DASH |
    IWX_CSR_HW_IF_CONFIG_REG_MSK_PHY_TYPE |
    IWX_CSR_HW_IF_CONFIG_REG_BIT_RADIO_SI |
    IWX_CSR_HW_IF_CONFIG_REG_BIT_MAC_SI;
    
    val = IWX_READ(sc, IWX_CSR_HW_IF_CONFIG_REG);
    val &= ~mask;
    val |= reg_val;
    IWX_WRITE(sc, IWX_CSR_HW_IF_CONFIG_REG, val);
    
    XYLog("%s Radio type=0x%x-0x%x-0x%x\n", __FUNCTION__, radio_cfg_type,
          radio_cfg_step, radio_cfg_dash);
}

// itlawdlintcoal=N: hold interrupts for at most N times 32 us instead of 0x40 (about 2 ms). With
// only a few frames in flight, a late completion leaves the firmware with nothing to send.
static uint8_t awdlIntCoalescing = IWX_HOST_INT_TIMEOUT_DEF;

int ItlIwx::
iwx_nic_rx_init(struct iwx_softc *sc)
{
    IWX_WRITE_1(sc, IWX_CSR_INT_COALESCING, awdlIntCoalescing);
    
    /*
     * We don't configure the RFH; the firmware will do that.
     * Rx descriptors are set when firmware sends an ALIVE interrupt.
     */
    return 0;
}

int ItlIwx::
iwx_nic_init(struct iwx_softc *sc)
{
    int err;
    
    iwx_apm_init(sc);
    iwx_nic_config(sc);
    
    err = iwx_nic_rx_init(sc);
    if (err)
        return err;
    
    IWX_SETBITS(sc, IWX_CSR_MAC_SHADOW_REG_CTRL, 0x800fffff);
    
    return 0;
}

/* Map ieee80211_edca_ac categories to firmware Tx FIFO. */
const uint8_t iwx_ac_to_tx_fifo[] = {
    IWX_GEN2_EDCA_TX_FIFO_BE,
    IWX_GEN2_EDCA_TX_FIFO_BK,
    IWX_GEN2_EDCA_TX_FIFO_VI,
    IWX_GEN2_EDCA_TX_FIFO_VO,
};

int ItlIwx::
iwx_enable_txq(struct iwx_softc *sc, int sta_id, int qid, int tid,
               int num_slots)
{
    
    XYLog("%s\n", __FUNCTION__);
    struct iwx_tx_queue_cfg_cmd cmd;
    struct iwx_rx_packet *pkt;
    struct iwx_tx_queue_cfg_rsp *resp;
    struct iwx_host_cmd hcmd = {
        .id = IWX_SCD_QUEUE_CFG,
        .flags = IWX_CMD_WANT_RESP,
        .resp_pkt_len = sizeof(*pkt) + sizeof(*resp),
    };
    struct iwx_tx_ring *ring = &sc->txq[qid];
    int err, fwqid;
    uint32_t wr_idx;
    size_t resp_len;
    
    iwx_reset_tx_ring(sc, ring);
    
    memset(&cmd, 0, sizeof(cmd));
    cmd.sta_id = sta_id;
    cmd.tid = tid;
    cmd.flags = htole16(IWX_TX_QUEUE_CFG_ENABLE_QUEUE);
    cmd.cb_size = htole32(IWX_TFD_QUEUE_CB_SIZE(num_slots));
    cmd.byte_cnt_addr = htole64(ring->bc_tbl.paddr);
    cmd.tfdq_addr = htole64(ring->desc_dma.paddr);
    
    hcmd.data[0] = &cmd;
    hcmd.len[0] = sizeof(cmd);
    
    err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    
    pkt = hcmd.resp_pkt;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        DPRINTF(("SCD_QUEUE_CFG command failed\n"));
        err = EIO;
        goto out;
    }
    
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (resp_len != sizeof(*resp)) {
        DPRINTF(("SCD_QUEUE_CFG returned %zu bytes, expected %zu bytes\n", resp_len, sizeof(*resp)));
        err = EIO;
        goto out;
    }
    
    resp = (struct iwx_tx_queue_cfg_rsp *)pkt->data;
    fwqid = le16toh(resp->queue_number);
    wr_idx = le16toh(resp->write_pointer);
    
    /* Unlike iwlwifi, we do not support dynamic queue ID assignment. */
    if (fwqid != qid) {
        DPRINTF(("requested qid %d but %d was assigned\n", qid, fwqid));
        err = EIO;
        goto out;
    }
    
    if (wr_idx != ring->cur) {
        DPRINTF(("fw write index is %d but ring is %d\n", wr_idx, ring->cur));
        err = EIO;
        goto out;
    }
out:
    iwx_free_resp(sc, &hcmd);
    return err;
}

int ItlIwx::
iwx_tvqm_alloc_txq(struct iwx_softc *sc, int tid, int ssn)
{
    int queue, generation = sc->sc_generation;
    //TODO: Here is a bug, for gen3 devices which support 256 frame aggregate into 1 A-MPDU like ax210, if the TfDs count larger than 256 than it would trigger system freeze on macOS, don't know why but Linux can do this. Still need to dig deep into the code or optimize the DMA memory allocation, here I just limit the size to 256 as the temporary solution.
#ifdef notyet
    int size = sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210 ? IWX_MIN_256_BA_QUEUE_SIZE_GEN3 : IWX_DEFAULT_QUEUE_SIZE;
#else
    int size = IWX_DEFAULT_QUEUE_SIZE;
#endif
    
    do {
        queue = iwx_tvqm_enable_txq(sc, tid, ssn, size);
        if (generation != sc->sc_generation)
            return -ENXIO;
#ifdef AIRPORT_VTD
        if (queue < 0 && queue != -ENOMEM)
            return queue;
#endif
        if (queue < 0)
            XYLog("Failed allocating TXQ of size %d for sta %d tid %d, ret: %d\n",
                  size, IWX_STATION_ID, tid, queue);
        size /= 2;
    } while (queue < 0 && size >= 16);
    
    if (queue < 0)
        return queue;
    sc->sc_tid_data[tid].qid = queue;
    return queue;
}

int ItlIwx::
iwx_tvqm_enable_txq(struct iwx_softc *sc, int tid, int ssn, uint32_t size, int stationId,
                    const CoexBaQueueOwner *owner)
{
#ifdef AIRPORT_VTD
    if (!getMainWorkLoop()->inGate()) {
        struct Request {
            iwx_softc *sc; int tid; int ssn; uint32_t size; int stationId;
            const CoexBaQueueOwner *owner;
        } request = {sc, tid, ssn, size, stationId, owner};
        return getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
                auto request = static_cast<Request *>(arg1);
                return static_cast<ItlIwx *>(arg0)->iwx_tvqm_enable_txq(
                    request->sc, request->tid, request->ssn, request->size, request->stationId, request->owner);
            }, this, &request);
    }
    if (dmaDetaching || !size || size > IWX_MIN_256_BA_QUEUE_SIZE_GEN3 || (size & (size - 1)))
        return -EINVAL;
    uint64_t epoch = dmaEpoch;
#endif
    if (stationId != IWX_STATION_ID && stationId != IWX_MONITOR_STA_ID && stationId != kAwdlBaStationId)
        return -EINVAL;
    const auto ownerCurrent = [&]() {
        return !owner || (owner->generation == sc->sc_generation &&
            awdlCoexBaQueueCurrent(owner->generation, owner->listener, owner->peer));
    };
    if (!ownerCurrent())
        return -ECANCELED;
    const char *failureStage = "allocation";
    int err = -1;
#ifdef AIRPORT_VTD
    bool submitted = false;
#endif
    int i = 0;
    bus_addr_t paddr;
    uint8_t auxCommandVersion = IWX_FW_CMD_VER_UNKNOWN;
    bool spareMonitorAuxSlot = false;
    bool spareBaSlot = false;
    int fwqid;
    uint32_t wr_idx;
    size_t resp_len;
    struct iwx_tx_queue_cfg_cmd cmd = {
        .flags = htole16(IWX_TX_QUEUE_CFG_ENABLE_QUEUE),
        .sta_id = static_cast<uint8_t>(stationId),
        .tid = (uint8_t)tid,
    };
    struct iwx_rx_packet *pkt;
    struct iwx_tx_queue_cfg_rsp *resp;
    struct iwx_host_cmd hcmd = {
        .id = IWX_SCD_QUEUE_CFG,
        .flags = IWX_CMD_WANT_RESP,
        .resp_pkt_len = sizeof(*pkt) + sizeof(*resp),
    };
#ifdef AIRPORT_VTD
    auto ring = new iwx_tx_ring();
    if (!ring)
        return -ENOMEM;
#else
    struct iwx_tx_ring *ring = &sc->sc_tvqm_ring;
#endif
    
    memset(ring, 0, sizeof(*ring));
    ring->qid = IWX_INVALID_QUEUE;
    iwx_tx_ring_init(sc, ring, size);
    /* Allocate TX descriptors (256-byte aligned). */
    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->desc_dma, ring->ring_count * sizeof (struct iwx_tfh_tfd), 256);
    if (err) {
        XYLog("%s: could not allocate TX ring DMA memory\n",
              DEVNAME(sc));
        err = -ENOMEM;
        goto fail;
    }
    ring->desc = (struct iwx_tfh_tfd*)ring->desc_dma.vaddr;
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->bc_tbl,
                                   sizeof(struct iwx_gen3_bc_tbl), 0);
    else
        err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->bc_tbl,
                                   sizeof(struct iwx_agn_scd_bc_tbl), 0);
    if (err) {
        XYLog("%s: could not allocate byte count table DMA memory\n",
              DEVNAME(sc));
        err = -ENOMEM;
        goto fail;
    }

    err = iwx_dma_contig_alloc(sc->sc_dmat, &ring->cmd_dma, ring->ring_count * sizeof(struct iwx_device_cmd), IWX_FIRST_TB_SIZE_ALIGN);
    if (err) {
        XYLog("%s: could not allocate cmd DMA memory\n", DEVNAME(sc));
        err = -ENOMEM;
        goto fail;
    }
    ring->cmd = (struct iwx_device_cmd*)ring->cmd_dma.vaddr;

    paddr = ring->cmd_dma.paddr;
    for (i = 0; i < ring->ring_count; i++) {
        struct iwx_tx_data *data = &ring->data[i];

        data->cmd_paddr = paddr;
        paddr += sizeof(struct iwx_device_cmd);
        failureStage = "packet-map";
        err = bus_dmamap_create(sc->sc_dmat, MCLBYTES,
                                IWX_TFH_NUM_TBS - 2, MCLBYTES, 0, BUS_DMA_NOWAIT,
                                &data->map);
        if (err) {
            XYLog("%s: could not create TX buf DMA map\n",
                  DEVNAME(sc));
            err = -EIO;
            goto fail;
        }
    }
    cmd.cb_size = htole32(IWX_TFD_QUEUE_CB_SIZE(ring->ring_count));
    cmd.byte_cnt_addr = htole64(ring->bc_tbl.paddr);
    cmd.tfdq_addr = htole64(ring->desc_dma.paddr);

    hcmd.data[0] = &cmd;
    hcmd.len[0] = sizeof(cmd);

#ifdef AIRPORT_VTD
    submitted = true;
#endif
    failureStage = "firmware-command";
    err = iwx_send_cmd(sc, &hcmd);
#ifdef AIRPORT_VTD
    if (epoch != dmaEpoch)
        err = ENXIO;
#endif
    if (err) {
        err = -err;
        goto fail;
    }

    failureStage = "response-status";
    pkt = hcmd.resp_pkt;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        XYLog("SCD_QUEUE_CFG command failed\n");
        err = -EIO;
        goto fail;
    }

    failureStage = "response-length";
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (stationId == IWX_MONITOR_STA_ID)
        awdlLog("queue response bytes %u expected %u\n", (unsigned)resp_len, (unsigned)sizeof(*resp));
    if (resp_len != sizeof(*resp)) {
        XYLog("SCD_QUEUE_CFG returned %zu bytes, expected %zu bytes\n", resp_len, sizeof(*resp));
        err = -EIO;
        goto fail;
    }

    resp = (struct iwx_tx_queue_cfg_rsp *)pkt->data;
    fwqid = le16toh(resp->queue_number);
    wr_idx = le16toh(resp->write_pointer);
    // The firmware's own answer, before the host decides anything about it.
    if (awdlCoexTx && stationId == IWX_MONITOR_STA_ID) {
        awdlCoexQueueAssigned = fwqid;
        awdlCoexQueueWritePointer = wr_idx;
    }
    failureStage = "queue-index";
    if (stationId == IWX_MONITOR_STA_ID)
        awdlLog("queue assigned %d write %u host limit %u reserved-through %u\n",
                fwqid, wr_idx, (unsigned)ARRAY_SIZE(sc->txq), (unsigned)IWX_QID_MGMT);
    if (fwqid >= ARRAY_SIZE(sc->txq)) {
        XYLog("queue index %d unsupported", fwqid);
        err = -EIO;
        goto fail;
    }
#ifdef AIRPORT_VTD
    failureStage = "queue-ownership-or-write-pointer";
    if (stationId == IWX_MONITOR_STA_ID)
        awdlLog("queue occupancy %u write-limit %u allocated-slots %u\n",
                (unsigned)sc->txq[fwqid].queued, (unsigned)getTxQueueSize(), (unsigned)ring->ring_count);
    // iwx_add_aux_sta creates no auxiliary host queue for known command
    // versions >=12: firmware uses its internal auxiliary station instead.
    // Only the single-attempt monitor owner may adopt that unused slot. Keep
    // queue 0, normal STA allocations, legacy/unknown aux and busy rings blocked.
    auxCommandVersion = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_ADD_STA);
    spareMonitorAuxSlot = stationId == IWX_MONITOR_STA_ID &&
        sc->sc_ic.ic_opmode == IEEE80211_M_MONITOR &&
        fwqid == IWX_DQA_AUX_QUEUE && fwqid != IWX_DQA_CMD_QUEUE &&
        auxCommandVersion != IWX_FW_CMD_VER_UNKNOWN && auxCommandVersion >= 12;
    if (stationId == IWX_MONITOR_STA_ID)
        awdlLog("queue auxiliary command version %u spare-monitor-slot %u\n",
                auxCommandVersion, spareMonitorAuxSlot ? 1U : 0U);
    // Normal Wi-Fi doesn't run in this mode, so its low numbers are free for the peer's queue too,
    // apart from the command queue and the one the monitor already has.
    spareBaSlot = stationId == kAwdlBaStationId && sc->sc_ic.ic_opmode == IEEE80211_M_MONITOR &&
        fwqid > 0 && fwqid != IWX_DQA_CMD_QUEUE && fwqid != awdlMonitorQueue;
    if (stationId == kAwdlBaStationId)
        awdlLog("peer queue assigned %d write %u slot allowed %u busy %u\n", fwqid, wr_idx,
                spareBaSlot ? 1U : 0U, (unsigned)sc->txq[fwqid].queued);
    // In station mode the station's management queue is the auxiliary slot (1) with this firmware, so the
    // listener's queue gets the next low number. Whatever number it gets, it must be one no host queue
    // uses: not the command queue, not the station's management queue, and no TID's.
    if (awdlCoexTx && stationId == IWX_MONITOR_STA_ID && sc->sc_ic.ic_opmode == IEEE80211_M_STA) {
        if (!awdlCoexSetupCurrent(sc->sc_generation)) {
            failureStage = "stale";
            err = -ECANCELED;
            goto fail;
        }
        bool used = fwqid <= 0 || fwqid == IWX_DQA_CMD_QUEUE || fwqid == sc->first_data_qid ||
            fwqid == awdlCoexOrphanQueue;
        for (int t = 0; t < int(nitems(sc->sc_tid_data)); ++t)
            used |= sc->sc_tid_data[t].qid == fwqid;
        if (used) {
            failureStage = "queue-owned";
            err = -EIO;
            goto fail;
        }
        spareBaSlot = true;
        if (sc->txq[fwqid].queued)
            failureStage = "queue-busy";
        else if (wr_idx >= getTxQueueSize())
            failureStage = "write-pointer";
    }
    if (awdlCoexData && stationId == kAwdlBaStationId && sc->sc_ic.ic_opmode == IEEE80211_M_STA) {
        // The listener peer's queue: a number no host queue uses, like the listener's own.
        bool used = fwqid <= 0 || fwqid == IWX_DQA_CMD_QUEUE || fwqid == sc->first_data_qid ||
            fwqid == awdlCoexOrphanQueue || fwqid == awdlCoexQueue;
        for (int t = 0; t < int(nitems(sc->sc_tid_data)); ++t)
            used |= sc->sc_tid_data[t].qid == fwqid;
        spareBaSlot = !used;
        if (used) {
            err = -EIO;
            goto fail;
        }
    }
    if ((fwqid <= sc->first_data_qid && !spareMonitorAuxSlot && !spareBaSlot) ||
        sc->txq[fwqid].queued || wr_idx >= getTxQueueSize()) {
        err = -EIO;
        goto fail;
    }
#endif
    if (!ownerCurrent()) {
        failureStage = "stale-peer";
        err = -ECANCELED;
        goto fail;
    }
    ring->cur = wr_idx;
    ring->tail = IWX_AGG_SSN_TO_TXQ_IDX(wr_idx, ring->ring_count);
    ring->qid = fwqid;
    iwx_reset_tx_ring(sc, &sc->txq[fwqid]);
    iwx_free_tx_ring(sc, &sc->txq[fwqid]);
    memcpy(&sc->txq[fwqid], ring, sizeof(*ring));
#ifdef AIRPORT_VTD
    delete ring;
#endif
    iwx_free_resp(sc, &hcmd);
    if (awdlCoexTx && stationId == IWX_MONITOR_STA_ID)
        awdlCoexQueueStage = "ok";
    return fwqid;
fail:
    if (awdlCoexTx && stationId == IWX_MONITOR_STA_ID)
        awdlCoexQueueStage = failureStage;
    if (stationId == IWX_MONITOR_STA_ID)
        awdlLog("queue allocation failure stage %s error %d\n", failureStage, err);
#ifdef AIRPORT_VTD
    if (submitted)
        sc->sc_dmat->deferRecycling();
#endif
    iwx_free_resp(sc, &hcmd);
#ifndef AIRPORT_VTD
    iwx_reset_tx_ring(sc, ring);
#endif
    iwx_free_tx_ring(sc, ring);
#ifdef AIRPORT_VTD
    delete ring;
#endif
    return err;
}

void ItlIwx::
iwx_post_alive(struct iwx_softc *sc)
{
    
    XYLog("%s\n", __FUNCTION__);
    iwx_ict_reset(sc);
    
    /*
     * Re-enable all the interrupts, including the RF-Kill one, now that
     * the firmware is alive.
     */
    iwx_enable_interrupts(sc);
}

/*
 * For the high priority TE use a time event type that has similar priority to
 * the FW's action scan priority.
 */
#define IWX_ROC_TE_TYPE_NORMAL IWX_TE_P2P_DEVICE_DISCOVERABLE
#define IWX_ROC_TE_TYPE_MGMT_TX IWX_TE_P2P_CLIENT_ASSOC

int ItlIwx::
iwx_send_time_event_cmd(struct iwx_softc *sc,
                        const struct iwx_time_event_cmd *cmd)
{
    struct iwx_rx_packet *pkt;
    struct iwx_time_event_resp *resp;
    struct iwx_host_cmd hcmd = {
        .id = IWX_TIME_EVENT_CMD,
        .flags = IWX_CMD_WANT_RESP,
        .resp_pkt_len = sizeof(*pkt) + sizeof(*resp),
    };
    uint32_t resp_len;
    int err;
    
    hcmd.data[0] = cmd;
    hcmd.len[0] = sizeof(*cmd);
    err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    
    pkt = hcmd.resp_pkt;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        err = EIO;
        goto out;
    }
    
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (resp_len != sizeof(*resp)) {
        err = EIO;
        goto out;
    }
    
    resp = (struct iwx_time_event_resp *)pkt->data;
    if (le32toh(resp->status) == 0)
        sc->sc_time_event_uid = le32toh(resp->unique_id);
    else
        err = EIO;
out:
    iwx_free_resp(sc, &hcmd);
    return err;
}

void ItlIwx::
iwx_protect_session(struct iwx_softc *sc, struct iwx_node *in,
                    uint32_t duration, uint32_t max_delay)
{
    struct iwx_time_event_cmd time_cmd;
    
    /* Do nothing if a time event is already scheduled. */
    if (sc->sc_flags & IWX_FLAG_TE_ACTIVE)
        return;
    
    memset(&time_cmd, 0, sizeof(time_cmd));
    
    time_cmd.action = htole32(IWX_FW_CTXT_ACTION_ADD);
    time_cmd.id_and_color =
    htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
    time_cmd.id = htole32(IWX_TE_BSS_STA_AGGRESSIVE_ASSOC);
    
    time_cmd.apply_time = htole32(0);
    
    time_cmd.max_frags = IWX_TE_V2_FRAG_NONE;
    time_cmd.max_delay = htole32(max_delay);
    /* TODO: why do we need to interval = bi if it is not periodic? */
    time_cmd.interval = htole32(1);
    time_cmd.duration = htole32(duration);
    time_cmd.repeat = 1;
    time_cmd.policy
    = htole16(IWX_TE_V2_NOTIF_HOST_EVENT_START |
              IWX_TE_V2_NOTIF_HOST_EVENT_END |
              IWX_T2_V2_START_IMMEDIATELY);
    
    if (iwx_send_time_event_cmd(sc, &time_cmd) == 0)
        sc->sc_flags |= IWX_FLAG_TE_ACTIVE;
    
    DELAY(100);
}

int ItlIwx::
iwx_schedule_protect_session(struct iwx_softc *sc, struct iwx_node *in,
                    uint32_t duration)
{
    struct iwx_session_prot_cmd cmd = {
        .id_and_color =
            htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color)),
        .action = htole32(IWX_FW_CTXT_ACTION_ADD),
        .duration_tu = htole32(duration * IEEE80211_DUR_TU),
    };
    int err;
    
    cmd.conf_id = IWX_SESSION_PROTECT_CONF_ASSOC;
    
    DPRINTFN(1, ("Add new session protection, duration %d TU\n",
             htole32(cmd.duration_tu)));
    
    err = iwx_send_cmd_pdu(sc, iwx_cmd_id(IWX_SESSION_PROTECTION_CMD, IWX_MAC_CONF_GROUP, 0), 0, sizeof(cmd), &cmd);
    if (err)
        XYLog("Couldn't send the SESSION_PROTECTION_CMD %d\n", err);
    return err;
}

int ItlIwx::
iwx_cancel_session_protection(struct iwx_softc *sc, struct iwx_node *in)
{
    struct iwx_session_prot_cmd cmd = {
        .id_and_color =
            htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color)),
        .action = htole32(IWX_FW_CTXT_ACTION_REMOVE),
        .conf_id = IWX_SESSION_PROTECT_CONF_ASSOC,
    };
    int err;
    
    DPRINTFN(1, ("Remove session protection\n"));
    
    err = iwx_send_cmd_pdu(sc, iwx_cmd_id(IWX_SESSION_PROTECTION_CMD, IWX_MAC_CONF_GROUP, 0), 0, sizeof(cmd), &cmd);
    if (err)
        XYLog("Couldn't send the Cancel SESSION_PROTECTION_CMD %d\n", err);
    return err;
}

void ItlIwx::
iwx_unprotect_session(struct iwx_softc *sc, struct iwx_node *in)
{
    struct iwx_time_event_cmd time_cmd;
    
    /* Do nothing if the time event has already ended. */
    if ((sc->sc_flags & IWX_FLAG_TE_ACTIVE) == 0)
        return;
    
    memset(&time_cmd, 0, sizeof(time_cmd));
    
    time_cmd.action = htole32(IWX_FW_CTXT_ACTION_REMOVE);
    time_cmd.id_and_color =
    htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
    time_cmd.id = htole32(sc->sc_time_event_uid);
    
    if (iwx_send_time_event_cmd(sc, &time_cmd) == 0)
        sc->sc_flags &= ~IWX_FLAG_TE_ACTIVE;
    
    DELAY(100);
}

/*
 * NVM read access and content parsing.  We do not support
 * external NVM or writing NVM.
 */

uint8_t ItlIwx::
iwx_fw_valid_tx_ant(struct iwx_softc *sc)
{
    uint8_t tx_ant;
    
    tx_ant = ((sc->sc_fw_phy_config & IWX_FW_PHY_CFG_TX_CHAIN)
              >> IWX_FW_PHY_CFG_TX_CHAIN_POS);
    
    if (sc->sc_nvm.valid_tx_ant)
        tx_ant &= sc->sc_nvm.valid_tx_ant;
    
    return tx_ant;
}

uint8_t ItlIwx::
iwx_fw_valid_rx_ant(struct iwx_softc *sc)
{
    uint8_t rx_ant;
    
    rx_ant = ((sc->sc_fw_phy_config & IWX_FW_PHY_CFG_RX_CHAIN)
              >> IWX_FW_PHY_CFG_RX_CHAIN_POS);
    
    if (sc->sc_nvm.valid_rx_ant)
        rx_ant &= sc->sc_nvm.valid_rx_ant;
    
    return rx_ant;
}

void ItlIwx::
iwx_init_channel_map(struct iwx_softc *sc, uint16_t *channel_profile_v3,
uint32_t *channel_profile_v4, int nchan_profile)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_nvm_data *data = &sc->sc_nvm;
    int ch_idx;
    struct ieee80211_channel *channel;
    uint32_t ch_flags;
    int is_5ghz;
    int flags, hw_value;
    int nchan;
    const uint8_t *nvm_channels;

    if (sc->sc_uhb_supported) {
        nchan = nitems(iwx_nvm_channels_uhb);
        nvm_channels = iwx_nvm_channels_uhb;
    } else {
        nchan = nitems(iwx_nvm_channels_8000);
        nvm_channels = iwx_nvm_channels_8000;
    }

    for (ch_idx = 0; ch_idx < nchan && ch_idx < nchan_profile; ch_idx++) {
        if (channel_profile_v4)
            ch_flags = le32_to_cpup(channel_profile_v4 + ch_idx);
        else
            ch_flags = le16_to_cpup(channel_profile_v3 + ch_idx);

        is_5ghz = ch_idx >= IWX_NUM_2GHZ_CHANNELS;
        if (is_5ghz && !data->sku_cap_band_52GHz_enable)
            ch_flags &= ~IWX_NVM_CHANNEL_VALID;
        
        if (ch_flags & IWX_NVM_CHANNEL_160MHZ)
            data->vht160_supported = true;

        hw_value = nvm_channels[ch_idx];
        channel = &ic->ic_channels[hw_value];
        if ((ch_flags & IWX_NVM_CHANNEL_VALID) && (ch_flags & IWX_NVM_CHANNEL_GO_CONCURRENT))
            setbit(awdlCoexIrConcurrent, hw_value);
        else
            clrbit(awdlCoexIrConcurrent, hw_value);

        if (!(ch_flags & IWX_NVM_CHANNEL_VALID)) {
            channel->ic_freq = 0;
            channel->ic_flags = 0;
            continue;
        }

        if (!is_5ghz) {
            flags = IEEE80211_CHAN_2GHZ;
            channel->ic_flags
                = IEEE80211_CHAN_CCK
                | IEEE80211_CHAN_OFDM
                | IEEE80211_CHAN_DYN
                | IEEE80211_CHAN_2GHZ;
        } else {
            flags = IEEE80211_CHAN_5GHZ;
            channel->ic_flags =
                IEEE80211_CHAN_A;
        }

        if (!(ch_flags & IWX_NVM_CHANNEL_ACTIVE))
            channel->ic_flags |= IEEE80211_CHAN_PASSIVE;

        if (data->sku_cap_11n_enable)
            channel->ic_flags |= IEEE80211_CHAN_HT20;

        if (!is_5ghz && (ch_flags & IWX_NVM_CHANNEL_40MHZ)) {
            if (hw_value <= IWX_LAST_2GHZ_HT_PLUS) {
                channel->ic_flags |= IEEE80211_CHAN_HT40U;
            }
            if (hw_value >= IWX_FIRST_2GHZ_HT_MINUS) {
                channel->ic_flags |= IEEE80211_CHAN_HT40D;
            }
        } else if (ch_flags & IWX_NVM_CHANNEL_40MHZ) {
            if ((ch_idx - IWX_NUM_2GHZ_CHANNELS) % 2 == 0) {
                channel->ic_flags |= IEEE80211_CHAN_HT40U;
            } else {
                channel->ic_flags |= IEEE80211_CHAN_HT40D;
            }
        }

        if (data->sku_cap_11ac_enable) {
            if (ch_flags & IWX_NVM_CHANNEL_80MHZ) {
                channel->ic_flags |= IEEE80211_CHAN_VHT80;
            }
            if (ch_flags & IWX_NVM_CHANNEL_160MHZ) {
                channel->ic_flags |= IEEE80211_CHAN_VHT160;
            }
        }

        if (ch_flags & IWX_NVM_CHANNEL_DFS) {
            channel->ic_flags |= IEEE80211_CHAN_DFS;
        }

        channel->ic_freq = ieee80211_ieee2mhz(hw_value, flags);
        
        DPRINTFN(3, ("Ch. %d Flags %x [%sGHz] - No traffic\n",
              hw_value,
              channel->ic_flags,
              (!IEEE80211_IS_CHAN_2GHZ(channel)) ? "5.2" : "2.4"));
    }
    // Which of the listener's candidate channels allow IR-concurrent use (diagnostic, set on every map).
    char irc[32];
    snprintf(irc, sizeof(irc), "6=%d 44=%d 149=%d", isset(awdlCoexIrConcurrent, 6) ? 1 : 0,
             isset(awdlCoexIrConcurrent, 44) ? 1 : 0, isset(awdlCoexIrConcurrent, 149) ? 1 : 0);
    IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLCoexIrConcurrent", irc);
}

int ItlIwx::
iwx_mimo_enabled(struct iwx_softc *sc)
{
   struct ieee80211com *ic = &sc->sc_ic;

   return !sc->sc_nvm.sku_cap_mimo_disable &&
       (ic->ic_userflags & IEEE80211_F_NOMIMO) == 0;
}

void ItlIwx::
iwx_setup_ht_rates(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    uint8_t rx_ant;
    
    /* TX is supported with the same MCS as RX. */
    ic->ic_tx_mcs_set = IEEE80211_TX_MCS_SET_DEFINED;
    
    memset(ic->ic_sup_mcs, 0, sizeof(ic->ic_sup_mcs));
    ic->ic_sup_mcs[0] = 0xff;        /* MCS 0-7 */
    
    if (!iwx_mimo_enabled(sc))
        return;
    
    rx_ant = iwx_fw_valid_rx_ant(sc);
    if ((rx_ant & IWX_ANT_AB) == IWX_ANT_AB ||
        (rx_ant & IWX_ANT_BC) == IWX_ANT_BC)
        ic->ic_sup_mcs[1] = 0xff;    /* MCS 8-15 */
}

void ItlIwx::
iwx_init_reorder_buffer(struct iwx_reorder_buffer *reorder_buf,
                        uint16_t ssn, uint16_t buf_size)
{
    reorder_buf->head_sn = ssn;
    reorder_buf->num_stored = 0;
    reorder_buf->buf_size = buf_size;
    reorder_buf->last_amsdu = 0;
    reorder_buf->last_sub_index = 0;
    reorder_buf->removed = 0;
    reorder_buf->valid = 0;
    reorder_buf->consec_oldsn_drops = 0;
    reorder_buf->consec_oldsn_ampdu_gp2 = 0;
    reorder_buf->consec_oldsn_prev_drop = 0;
}

void ItlIwx::
iwx_clear_reorder_buffer(struct iwx_softc *sc, struct iwx_rxba_data *rxba)
{
    int i;
    struct iwx_reorder_buffer *reorder_buf = &rxba->reorder_buf;
    struct iwx_reorder_buf_entry *entry;
    
    for (i = 0; i < reorder_buf->buf_size; i++) {
        entry = &rxba->entries[i];
        ml_purge(&entry->frames);
        timerclear(&entry->reorder_time);
    }
    
    reorder_buf->removed = 1;
    timeout_del(&reorder_buf->reorder_timer);
    timeout_free(&reorder_buf->reorder_timer);
    timerclear(&rxba->last_rx);
    timeout_del(&rxba->session_timer);
    timeout_free(&rxba->session_timer);
    rxba->baid = IWX_RX_REORDER_DATA_INVALID_BAID;
}

#define RX_REORDER_BUF_TIMEOUT_MQ_USEC (100000ULL)

void ItlIwx::
iwx_rx_ba_session_expired(void *arg)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_rxba_data *rxba = (struct iwx_rxba_data *)arg;
    struct iwx_softc *sc = rxba->sc;
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    struct timeval now, timeout, expiry;
    int s;
    
    s = splnet();
    if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0 &&
        ic->ic_state == IEEE80211_S_RUN &&
        rxba->baid != IWX_RX_REORDER_DATA_INVALID_BAID) {
        getmicrouptime(&now);
        USEC_TO_TIMEVAL(RX_REORDER_BUF_TIMEOUT_MQ_USEC, &timeout);
        timeradd(&rxba->last_rx, &timeout, &expiry);
        if (timercmp(&now, &expiry, <)) {
            timeout_add_usec(&rxba->session_timer, rxba->timeout);
        } else {
            ic->ic_stats.is_ht_rx_ba_timeout++;
            ieee80211_delba_request(ic, ni,
                                    IEEE80211_REASON_TIMEOUT, 0, rxba->tid);
        }
    }
    splx(s);
}

void ItlIwx::
iwx_reorder_timer_expired(void *arg)
{
    XYLog("%s\n", __FUNCTION__);
    struct mbuf_list ml = MBUF_LIST_INITIALIZER();
    struct iwx_reorder_buffer *buf = (struct iwx_reorder_buffer *)arg;
    struct iwx_rxba_data *rxba = iwx_rxba_data_from_reorder_buf(buf);
    struct iwx_reorder_buf_entry *entries = &rxba->entries[0];
    struct iwx_softc *sc = rxba->sc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    int i, s;
    uint16_t sn = 0, index = 0;
    int expired = 0;
    int cont = 0;
    struct timeval now, timeout, expiry;
    
    if (!buf->num_stored || buf->removed)
        return;
    
    s = splnet();
    getmicrouptime(&now);
    USEC_TO_TIMEVAL(RX_REORDER_BUF_TIMEOUT_MQ_USEC, &timeout);
    
    for (i = 0; i < buf->buf_size ; i++) {
        index = (buf->head_sn + i) % buf->buf_size;
        
        if (ml_empty(&entries[index].frames)) {
            /*
             * If there is a hole and the next frame didn't expire
             * we want to break and not advance SN.
             */
            cont = 0;
            continue;
        }
        timeradd(&entries[index].reorder_time, &timeout, &expiry);
        if (!cont && timercmp(&now, &expiry, <))
            break;
        
        expired = 1;
        /* continue until next hole after this expired frame */
        cont = 1;
        sn = (buf->head_sn + (i + 1)) & 0xfff;
    }
    
    if (expired) {
        /* SN is set to the last expired frame + 1 */
        that->iwx_release_frames(sc, ni, rxba, buf, sn, &ml);
        if_input(&sc->sc_ic.ic_if, &ml);
        ic->ic_stats.is_ht_rx_ba_window_gap_timeout++;
    } else {
        /*
         * If no frame expired and there are stored frames, index is now
         * pointing to the first unexpired frame - modify reorder timeout
         * accordingly.
         */
        timeout_add_usec(&buf->reorder_timer,
                         RX_REORDER_BUF_TIMEOUT_MQ_USEC);
    }
    
    splx(s);
}

static inline uint8_t iwx_num_of_ant(uint8_t mask)
{
    return  !!((mask) & IWX_ANT_A) +
        !!((mask) & IWX_ANT_B) +
        !!((mask) & IWX_ANT_C);
}

void ItlIwx::
iwx_setup_vht_rates(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    uint8_t rx_ant, tx_ant;
    unsigned int max_ampdu_exponent = IEEE80211_VHTCAP_MAX_AMPDU_1024K;
    
    if (ic->ic_userflags & IEEE80211_F_NOVHT)
        return;
    
    /* enable 11ac support */
    ic->ic_flags |= IEEE80211_F_VHTON;
    
    rx_ant = iwx_num_of_ant(iwx_fw_valid_rx_ant(sc));
    tx_ant = iwx_num_of_ant(iwx_fw_valid_tx_ant(sc));
    
    ic->ic_vhtcaps = IEEE80211_VHTCAP_SHORT_GI_80 |
    IEEE80211_VHTCAP_RXSTBC_1 |
    IEEE80211_VHTCAP_SU_BEAMFORMEE_CAPABLE | 
    3 << IEEE80211_VHTCAP_BEAMFORMEE_STS_SHIFT |
    max_ampdu_exponent << IEEE80211_VHTCAP_MAX_A_MPDU_LENGTH_EXPONENT_SHIFT |
    IEEE80211_VHTCAP_MU_BEAMFORMEE_CAPABLE;
    
    if (sc->sc_nvm.vht160_supported)
        ic->ic_vhtcaps |= IEEE80211_VHTCAP_SUPP_CHAN_WIDTH_160MHZ |
                IEEE80211_VHTCAP_SHORT_GI_160;
    
    if (!iwx_mimo_enabled(sc)) {
        rx_ant = 1;
        tx_ant = 1;
    }
    
    ic->ic_vhtcaps |= IEEE80211_VHTCAP_RXLDPC;
    if (tx_ant > 1)
        ic->ic_vhtcaps |= IEEE80211_VHTCAP_TXSTBC;
    else
        ic->ic_vhtcaps |= IEEE80211_VHTCAP_TX_ANTENNA_PATTERN;
    
    ic->ic_vht_rx_mcs_map =
        htole16(IEEE80211_VHT_MCS_SUPPORT_0_9 << 0 |
                IEEE80211_VHT_MCS_SUPPORT_0_9 << 2 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 4 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 6 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 8 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 10 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 12 |
                IEEE80211_VHT_MCS_NOT_SUPPORTED << 14);
    if (rx_ant == 1) {
        ic->ic_vhtcaps |= IEEE80211_VHTCAP_RX_ANTENNA_PATTERN;
        /* this works because NOT_SUPPORTED == 3 */
        ic->ic_vht_rx_mcs_map |=
            htole16(IEEE80211_VHT_MCS_NOT_SUPPORTED << 2);
    }
    ic->ic_vht_tx_mcs_map = ic->ic_vht_rx_mcs_map;

    ic->ic_vht_tx_highest |=
        htole16(IEEE80211_VHT_EXT_NSS_BW_CAPABLE);
    ic->ic_vht_rx_highest = 0;
    
    memset(ic->ic_vht_sup_mcs, 0, sizeof(ic->ic_vht_sup_mcs));
    ic->ic_vht_sup_mcs[0] = 0x03FF;        /* MCS 0-9 */
    
    if (!iwx_mimo_enabled(sc))
        return;
    
    ic->ic_vht_sup_mcs[1] = 0x03FF;         /* MCS 0-9 */
}

void ItlIwx::
iwx_setup_he_rates(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    ic->ic_flags &= ~IEEE80211_F_HEON;
    memset(&ic->ic_he_cap_elem, 0, sizeof(ic->ic_he_cap_elem));
    memset(&ic->ic_he_mcs_nss_supp, 0xff, sizeof(ic->ic_he_mcs_nss_supp));
    memset(ic->ic_ppe_thres, 0, sizeof(ic->ic_ppe_thres));
    uint8_t version = iwx_lookup_cmd_ver(sc, IWX_DATA_PATH_GROUP, IWX_STA_HE_CTXT_CMD);
    /* Preinit builds modecaps before media_init enables HT. Requiring HTON
     * here would omit 11ax from the initial capability table permanently.
     * Negotiation still requires HT and QoS on the associated node. */
    if (!sc->sc_nvm.sku_cap_11ax_enable ||
        !(ic->ic_userflags & IEEE80211_F_HEON) ||
        (ic->ic_userflags & IEEE80211_F_NOVHT) ||
        (version != 1 && version != 2))
        return;
    unsigned rx = iwx_num_of_ant(iwx_fw_valid_rx_ant(sc));
    unsigned tx = iwx_num_of_ant(iwx_fw_valid_tx_ant(sc));
    if (!rx || !tx)
        return;
    if (!iwx_mimo_enabled(sc))
        rx = tx = 1;
    /* Conservative station profile: no TWT, OMI, multi-TID or fragmentation. */
    ic->ic_he_cap_elem.mac_cap_info[0] = IEEE80211_HE_MAC_CAP0_HTC_HE;
    ic->ic_he_cap_elem.mac_cap_info[1] = IEEE80211_HE_MAC_CAP1_TF_MAC_PAD_DUR_16US;
    ic->ic_he_cap_elem.mac_cap_info[2] = IEEE80211_HE_MAC_CAP2_32BIT_BA_BITMAP;
    ic->ic_he_cap_elem.mac_cap_info[4] = IEEE80211_HE_MAC_CAP4_AMDSU_IN_AMPDU;
    if (ic->ic_htcaps & IEEE80211_HTCAP_CBW20_40)
        ic->ic_he_cap_elem.phy_cap_info[0] |= IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_40MHZ_IN_2G;
    if (sc->sc_nvm.sku_cap_band_52GHz_enable)
        ic->ic_he_cap_elem.phy_cap_info[0] |= IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_40MHZ_80MHZ_IN_5G;
    ic->ic_he_cap_elem.phy_cap_info[1] = IEEE80211_HE_PHY_CAP1_DEVICE_CLASS_A |
        IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD;
    ic->ic_he_cap_elem.phy_cap_info[2] = IEEE80211_HE_PHY_CAP2_NDP_4x_LTF_AND_3_2US;
    ic->ic_he_cap_elem.phy_cap_info[7] = IEEE80211_HE_PHY_CAP7_HE_SU_MU_PPDU_4XLTF_AND_08_US_GI;
    /* Require 16us padding without advertising an optional PPE field. */
    ic->ic_he_cap_elem.phy_cap_info[9] = IEEE80211_HE_PHY_CAP9_NOMIMAL_PKT_PADDING_16US |
        IEEE80211_HE_PHY_CAP9_RX_FULL_BW_SU_USING_MU_WITH_COMP_SIGB |
        IEEE80211_HE_PHY_CAP9_RX_FULL_BW_SU_USING_MU_WITH_NON_COMP_SIGB;
    ic->ic_he_mcs_nss_supp.rx_mcs_80 = htole16(rx > 1 ? 0xfffa : 0xfffe);
    ic->ic_he_mcs_nss_supp.tx_mcs_80 = htole16(tx > 1 ? 0xfffa : 0xfffe);
    if (sc->sc_nvm.vht160_supported) {
        ic->ic_he_cap_elem.phy_cap_info[0] |= IEEE80211_HE_PHY_CAP0_CHANNEL_WIDTH_SET_160MHZ_IN_5G;
        ic->ic_he_mcs_nss_supp.rx_mcs_160 = ic->ic_he_mcs_nss_supp.rx_mcs_80;
        ic->ic_he_mcs_nss_supp.tx_mcs_160 = ic->ic_he_mcs_nss_supp.tx_mcs_80;
    }
    ic->ic_flags |= IEEE80211_F_HEON;
    XYLog("Experimental HE enabled: context-v%u rx80=%04x tx80=%04x width-bits=%02x\n",
        version, le16toh(ic->ic_he_mcs_nss_supp.rx_mcs_80),
        le16toh(ic->ic_he_mcs_nss_supp.tx_mcs_80), ic->ic_he_cap_elem.phy_cap_info[0]);
}

#define IWX_MAX_RX_BA_SESSIONS 16

int ItlIwx::
iwx_sta_rx_agg(struct iwx_softc *sc, struct ieee80211_node *ni, uint8_t tid,
               uint16_t ssn, uint16_t winsize, int timeout_val, int start)
{
    XYLog("%s start=%d tid=%d ssn=%d winsize=%d\n", __FUNCTION__, start, tid, ssn, winsize);
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_add_sta_cmd cmd;
    struct iwx_node *in = (struct iwx_node *)ni;
    int err, s, generation = sc->sc_generation;
    uint32_t status;
    struct iwx_rxba_data *rxba = NULL;
    uint8_t baid = 0;
    
    s = splnet();
    
    if (start && sc->sc_rx_ba_sessions >= IWX_MAX_RX_BA_SESSIONS) {
        ieee80211_addba_req_refuse(ic, ni, tid);
        splx(s);
        return ENOSPC;
    }
    
    memset(&cmd, 0, sizeof(cmd));
    
    cmd.sta_id = IWX_STATION_ID;
    cmd.mac_id_n_color
    = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
    cmd.add_modify = IWX_STA_MODE_MODIFY;
    
    if (start) {
        cmd.add_immediate_ba_tid = (uint8_t)tid;
        cmd.add_immediate_ba_ssn = htole16(ssn);
        cmd.rx_ba_window = htole16(winsize);
    } else {
        cmd.remove_immediate_ba_tid = (uint8_t)tid;
    }
    cmd.modify_mask = start ? IWX_STA_MODIFY_ADD_BA_TID :
    IWX_STA_MODIFY_REMOVE_BA_TID;
    
    status = IWX_ADD_STA_SUCCESS;
    err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd,
                                  &status);
    
    if (generation != sc->sc_generation) {
        splx(s);
        return ENXIO;
    }
    if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
        if (start)
            ieee80211_addba_req_refuse(ic, ni, tid);
        splx(s);
        return err ? err : EIO;
    }
    
    /* Deaggregation is done in hardware. */
    if (start) {
        if (!(status & IWX_ADD_STA_BAID_VALID_MASK)) {
            ieee80211_addba_req_refuse(ic, ni, tid);
            splx(s);
            return EIO;
        }
        baid = (status & IWX_ADD_STA_BAID_MASK) >>
        IWX_ADD_STA_BAID_SHIFT;
        if (baid == IWX_RX_REORDER_DATA_INVALID_BAID ||
            baid >= nitems(sc->sc_rxba_data)) {
            ieee80211_addba_req_refuse(ic, ni, tid);
            splx(s);
            return EIO;
        }
        rxba = &sc->sc_rxba_data[baid];
        if (rxba->baid != IWX_RX_REORDER_DATA_INVALID_BAID) {
            ieee80211_addba_req_refuse(ic, ni, tid);
            splx(s);
            return EIO;
        }
        rxba->sta_id = IWX_STATION_ID;
        rxba->tid = tid;
        rxba->baid = baid;
        rxba->timeout = timeout_val;
        getmicrouptime(&rxba->last_rx);
        iwx_init_reorder_buffer(&rxba->reorder_buf, ssn,
                                winsize);
        if (timeout_val != 0) {
            struct ieee80211_rx_ba *ba;
            timeout_add_usec(&rxba->session_timer,
                             timeout_val);
            /* XXX disable net80211's BA timeout handler */
            ba = &ni->ni_rx_ba[tid];
            ba->ba_timeout_val = 0;
        }
    } else {
        int i;
        for (i = 0; i < nitems(sc->sc_rxba_data); i++) {
            rxba = &sc->sc_rxba_data[i];
            if (rxba->baid ==
                IWX_RX_REORDER_DATA_INVALID_BAID)
                continue;
            if (rxba->tid != tid)
                continue;
            iwx_clear_reorder_buffer(sc, rxba);
            break;
        }
    }
    
    if (start) {
        sc->sc_rx_ba_sessions++;
        ieee80211_addba_req_accept(ic, ni, tid);
    } else if (sc->sc_rx_ba_sessions > 0)
        sc->sc_rx_ba_sessions--;

    splx(s);
    return 0;
}

void ItlIwx::
iwx_mac_ctxt_task(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                iwx_mac_ctxt_task(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    struct ieee80211com *ic = &sc->sc_ic;

    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int err, s = splnet();
    
    if (sc->sc_flags & IWX_FLAG_SHUTDOWN ||
        ic->ic_state != IEEE80211_S_RUN ||
        in->in_phyctxt == NULL) {
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }
    
    err = that->iwx_config_he_sta(sc, &in->in_ni);
    if (err) {
        XYLog("HE context update failed: %d\n", err);
        splx(s);
        return;
    }
    err = that->iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_MODIFY, 1);
    if (err) {
        printf("%s: failed to update MAC\n", DEVNAME(sc));
        splx(s);
        return;
    }
    
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_SESSION_PROT_CMD))
        that->iwx_unprotect_session(sc, in);
    
    //    refcnt_rele_wake(&sc->task_refs);
    splx(s);
}

void ItlIwx::
iwx_chan_ctxt_task(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                iwx_chan_ctxt_task(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    struct ieee80211com *ic = &sc->sc_ic;

    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int chains = that->iwx_mimo_enabled(sc) ? 2 : 1;
    int err, s = splnet();
    
    if (sc->sc_flags & IWX_FLAG_SHUTDOWN ||
        ic->ic_state != IEEE80211_S_RUN ||
        in->in_phyctxt == NULL) {
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }
    
    err = that->iwx_phy_ctxt_update(sc, in->in_phyctxt,
                                    in->in_phyctxt->channel, chains, chains, 0);
    if (err) {
        XYLog("%s: failed to update PHY (error %d)\n",
              __FUNCTION__, err);
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }
    err = that->iwx_rs_init(sc, in, true);
    if (err) {
        XYLog("%s: could not update rate scaling (error %d)\n",
              __FUNCTION__, err);
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }
    
    //    refcnt_rele_wake(&sc->task_refs);
    splx(s);
}

void ItlIwx::
iwx_update_chw(struct ieee80211com *ic)
{
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (ic->ic_state == IEEE80211_S_RUN && (sc->sc_flags & IWX_FLAG_STA_ACTIVE))
        that->iwx_add_task(sc, systq, &sc->chan_ctxt_task);
}

void ItlIwx::
iwx_updateprot(struct ieee80211com *ic)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (ic->ic_state == IEEE80211_S_RUN && (sc->sc_flags & IWX_FLAG_STA_ACTIVE))
        that->iwx_add_task(sc, systq, &sc->mac_ctxt_task);
}

void ItlIwx::
iwx_updateslot(struct ieee80211com *ic)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (ic->ic_state == IEEE80211_S_RUN && (sc->sc_flags & IWX_FLAG_STA_ACTIVE))
        that->iwx_add_task(sc, systq, &sc->mac_ctxt_task);
}

void ItlIwx::
iwx_updateedca(struct ieee80211com *ic)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (ic->ic_state == IEEE80211_S_RUN && (sc->sc_flags & IWX_FLAG_STA_ACTIVE))
        that->iwx_add_task(sc, systq, &sc->mac_ctxt_task);
}

void ItlIwx::
iwx_updatedtim(struct ieee80211com *ic)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (ic->ic_state == IEEE80211_S_RUN && (sc->sc_flags & IWX_FLAG_STA_ACTIVE))
        that->iwx_add_task(sc, systq, &sc->mac_ctxt_task);
}

void ItlIwx::
iwx_ba_task(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                iwx_ba_task(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    struct ieee80211com *ic = &sc->sc_ic;

    struct ieee80211_node *ni = ic->ic_bss;
    struct ieee80211_tx_ba *ba;
    struct iwx_tx_ring *ring;
    int s = splnet();
    int generation = sc->sc_generation;
    int err = 0;
    int qid = 0;
    int tid;
    
    if (sc->sc_flags & IWX_FLAG_SHUTDOWN || ic->ic_state != IEEE80211_S_RUN ||
        sc->ns_nstate != IEEE80211_S_RUN) {
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }

    for (tid = 0; tid < IWX_MAX_TID_COUNT; tid++) {
        if (sc->sc_flags & IWX_FLAG_SHUTDOWN || ic->ic_state != IEEE80211_S_RUN ||
            sc->ns_nstate != IEEE80211_S_RUN)
            break;
        if (sc->ba_rx.start_tidmask & (1 << tid)) {
            struct ieee80211_rx_ba *ba = &ni->ni_rx_ba[tid];
            XYLog("%s ba_rx_start tid=%d, ssn=%d\n", __FUNCTION__, tid, ba->ba_winstart);
            that->iwx_sta_rx_agg(sc, ni, tid, ba->ba_winstart,
                                 ba->ba_winsize, ba->ba_timeout_val, 1);
            if (generation != sc->sc_generation) {
                splx(s);
                return;
            }
            sc->ba_rx.start_tidmask &= ~(1 << tid);
        } else if (sc->ba_rx.stop_tidmask & (1 << tid)) {
            that->iwx_sta_rx_agg(sc, ni, tid, 0, 0, 0, 0);
            if (generation != sc->sc_generation) {
                splx(s);
                return;
            }
            sc->ba_rx.stop_tidmask &= ~(1 << tid);
        }
    }
    
    for (tid = 0; tid < IWX_MAX_TID_COUNT; tid++) {
        if (sc->sc_flags & IWX_FLAG_SHUTDOWN || ic->ic_state != IEEE80211_S_RUN ||
            sc->ns_nstate != IEEE80211_S_RUN)
            break;
        if (sc->ba_tx.start_tidmask & (1 << tid)) {
            ba = &ni->ni_tx_ba[tid];
            XYLog("%s ba_tx_start tid=%d, ssn=%d\n", __FUNCTION__, tid, ba->ba_winstart);
            if (!that->iwx_nic_lock(sc)) {
                err = -1;
                goto out;
            }
            if ((qid = that->iwx_tvqm_alloc_txq(sc, tid, ba->ba_winstart)) < 0) {
                err = -1;
                goto out;
            }
            ring = &sc->txq[qid];
            ba->ba_winstart = IWX_AGG_SSN_TO_TXQ_IDX(ring->cur, ring->ring_count);
            ba->ba_winend = (ba->ba_winstart + ba->ba_winsize - 1) & 0xfff;
            ba->ba_timeout_val = 0;
            ieee80211_addba_resp_accept(ic, ni, tid);
            XYLog("%s tx queue alloc succeed qid=%d ssn=%d\n", __FUNCTION__, qid, ba->ba_winstart);
        out:
            if (generation != sc->sc_generation) {
                splx(s);
                return;
            }
            that->iwx_nic_unlock(sc);
            if (err)
                ieee80211_addba_resp_refuse(ic, ni, tid,
                                            IEEE80211_STATUS_UNSPECIFIED);
            sc->ba_tx.start_tidmask &= ~(1 << tid);
        }
    }
    
    //    refcnt_rele_wake(&sc->task_refs);
    splx(s);
}

/*
 * This function is called by upper layer when an ADDBA request is received
 * from another STA and before the ADDBA response is sent.
 */
int ItlIwx::
iwx_ampdu_rx_start(struct ieee80211com *ic, struct ieee80211_node *ni,
                   uint8_t tid)
{
    struct iwx_softc *sc = (struct iwx_softc *)IC2IFP(ic)->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (sc->sc_rx_ba_sessions >= IWX_MAX_RX_BA_SESSIONS ||
        tid >= IWX_MAX_TID_COUNT)
        return ENOSPC;
    
    if (ic->ic_state != IEEE80211_S_RUN)
        return ENOSPC;
    
    if (sc->ba_rx.start_tidmask & (1 << tid))
        return EBUSY;

    sc->ba_rx.start_tidmask |= (1 << tid);
    that->iwx_add_task(sc, systq, &sc->ba_task);
    
    return EBUSY;
}

/*
 * This function is called by upper layer on teardown of an HT-immediate
 * Block Ack agreement (eg. upon receipt of a DELBA frame).
 */
void ItlIwx::
iwx_ampdu_rx_stop(struct ieee80211com *ic, struct ieee80211_node *ni,
                  uint8_t tid)
{
    struct iwx_softc *sc = (struct iwx_softc *)IC2IFP(ic)->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (tid >= IWX_MAX_TID_COUNT || sc->ba_rx.stop_tidmask & (1 << tid))
        return;
    
    if (ic->ic_state != IEEE80211_S_RUN)
        return;

    sc->ba_rx.stop_tidmask |= (1 << tid);
    that->iwx_add_task(sc, systq, &sc->ba_task);
}

int ItlIwx::
iwx_ampdu_tx_start(struct ieee80211com *ic, struct ieee80211_node *ni, uint8_t tid)
{
    struct ieee80211_tx_ba *ba = &ni->ni_tx_ba[tid];
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);

    XYLog("%s tid=%d ssn=%d\n", __FUNCTION__, tid, ba->ba_winstart);

    if (tid < 0 || tid >= IWX_MAX_TID_COUNT) {
        XYLog("%s tx agg refused. tid=%d\n", __FUNCTION__, tid);
        return ENOSPC;
    }
    
    if (sc->ba_tx.start_tidmask & (1 << tid)) {
        XYLog("%s tid %d is pending to agg\n", __FUNCTION__, tid);
        return EBUSY;
    }
    
    sc->ba_tx.start_tidmask |= (1 << tid);
    that->iwx_add_task(sc, systq, &sc->ba_task);
    return EBUSY;
}

void ItlIwx::
iwx_ampdu_tx_stop(struct ieee80211com *ic, struct ieee80211_node *ni, uint8_t tid)
{
    struct ieee80211_tx_ba *ba = &ni->ni_tx_ba[tid];
    struct iwx_softc *sc = (struct iwx_softc *)IC2IFP(ic)->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);

    XYLog("%s tid=%d\n", __FUNCTION__, tid);

    if (ba->ba_state != IEEE80211_BA_AGREED) {
        return;
    }

    sc->sc_tid_data[tid].qid = IWX_INVALID_QUEUE;
    ic->ic_stats.is_ht_tx_ba_agreements--;
}

static void iwx_flip_hw_address(uint32_t mac_addr0, uint32_t mac_addr1, uint8_t *dest)
{
    const u8 *hw_addr;

    hw_addr = (const u8 *)&mac_addr0;
    dest[0] = hw_addr[3];
    dest[1] = hw_addr[2];
    dest[2] = hw_addr[1];
    dest[3] = hw_addr[0];

    hw_addr = (const u8 *)&mac_addr1;
    dest[4] = hw_addr[1];
    dest[5] = hw_addr[0];
}

int ItlIwx::
iwx_set_mac_addr_from_csr(struct iwx_softc *sc, struct iwx_nvm_data *data)
{
    uint32_t mac_addr0, mac_addr1;
    
    if (!iwx_nic_lock(sc))
        return EBUSY;
    
    mac_addr0 = htole32(IWX_READ(sc, IWX_CSR_MAC_ADDR0_STRAP));
    mac_addr1 = htole32(IWX_READ(sc, IWX_CSR_MAC_ADDR1_STRAP));
    
    iwx_flip_hw_address(mac_addr0, mac_addr1, data->hw_addr);
    
    /*
     * If the OEM fused a valid address, use it instead of the one in the
     * OTP
     */
    if (iwx_is_valid_mac_addr(data->hw_addr))
        goto done;
    
    mac_addr0 = htole32(IWX_READ(sc, IWX_CSR_MAC_ADDR0_OTP));
    mac_addr1 = htole32(IWX_READ(sc, IWX_CSR_MAC_ADDR1_OTP));
    
    iwx_flip_hw_address(mac_addr0, mac_addr1, data->hw_addr);
    
done:
    
    iwx_nic_unlock(sc);
    return 0;
}

int ItlIwx::
iwx_is_valid_mac_addr(const uint8_t *addr)
{
    return (memcmp(etherbroadcastaddr, addr, sizeof(etherbroadcastaddr)) != 0 &&
            memcmp(etheranyaddr, addr, sizeof(etheranyaddr)) != 0 &&
            !ETHER_IS_MULTICAST(addr));
}

int ItlIwx::
iwx_nvm_get(struct iwx_softc *sc)
{
    struct iwx_nvm_get_info cmd = {};
    struct iwx_nvm_data *nvm = &sc->sc_nvm;
    struct iwx_host_cmd hcmd = {
        .flags = IWX_CMD_WANT_RESP | IWX_CMD_SEND_IN_RFKILL,
        .data = { &cmd, },
        .len = { sizeof(cmd) },
        .id = IWX_WIDE_ID(IWX_REGULATORY_AND_NVM_GROUP,
                          IWX_NVM_GET_INFO)
    };
    int err;
    uint32_t mac_flags;
    /*
     * All the values in iwx_nvm_get_info_rsp v4 are the same as
     * in v3, except for the channel profile part of the
     * regulatory.  So we can just access the new struct, with the
     * exception of the latter.
     */
    struct iwx_nvm_get_info_rsp *rsp;
    struct iwx_nvm_get_info_rsp_v3 *rsp_v3;
    int v4 = isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_REGULATORY_NVM_INFO);
    size_t resp_len = v4 ? sizeof(*rsp) : sizeof(*rsp_v3);
    
    hcmd.resp_pkt_len = sizeof(struct iwx_rx_packet) + resp_len;
    err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    
    if (iwx_rx_packet_payload_len(hcmd.resp_pkt) != resp_len) {
        err = EIO;
        goto out;
    }
    
    memset(nvm, 0, sizeof(*nvm));
    
    iwx_set_mac_addr_from_csr(sc, nvm);
    if (!iwx_is_valid_mac_addr(nvm->hw_addr)) {
        XYLog("%s: no valid mac address was found\n", DEVNAME(sc));
        err = EINVAL;
        goto out;
    }
    
    rsp = (struct iwx_nvm_get_info_rsp *)hcmd.resp_pkt->data;
    
    /* Initialize general data */
    nvm->nvm_version = le16toh(rsp->general.nvm_version);
    nvm->n_hw_addrs = rsp->general.n_hw_addrs;
    
    /* Initialize MAC sku data */
    mac_flags = le32toh(rsp->mac_sku.mac_sku_flags);
    nvm->sku_cap_11ac_enable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_802_11AC_ENABLED);
    nvm->sku_cap_11n_enable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_802_11N_ENABLED);
    nvm->sku_cap_11ax_enable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_802_11AX_ENABLED);
    nvm->sku_cap_band_24GHz_enable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_BAND_2_4_ENABLED);
    nvm->sku_cap_band_52GHz_enable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_BAND_5_2_ENABLED);
    nvm->sku_cap_mimo_disable =
    !!(mac_flags & IWX_NVM_MAC_SKU_FLAGS_MIMO_DISABLED);
    
    /* Initialize PHY sku data */
    nvm->valid_tx_ant = (uint8_t)le32toh(rsp->phy_sku.tx_chains);
    nvm->valid_rx_ant = (uint8_t)le32toh(rsp->phy_sku.rx_chains);
    
    if (le32toh(rsp->regulatory.lar_enabled) &&
        isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_LAR_SUPPORT)) {
        nvm->lar_enabled = 1;
    }
    
    if (v4) {
        iwx_init_channel_map(sc, NULL,
                             rsp->regulatory.channel_profile, IWX_NUM_CHANNELS);
    } else {
        rsp_v3 = (struct iwx_nvm_get_info_rsp_v3 *)rsp;
        iwx_init_channel_map(sc, rsp_v3->regulatory.channel_profile,
                             NULL, IWX_NUM_CHANNELS_V1);
    }
out:
    iwx_free_resp(sc, &hcmd);
    return err;
}

int ItlIwx::
iwx_wait_notification(struct iwx_softc *sc, int *value, int bits, uint32_t milliseconds)
{
    int generation = sc->sc_generation;
    AbsoluteTime deadline;
    clock_interval_to_deadline(milliseconds, kMillisecondScale,
        reinterpret_cast<uint64_t *>(&deadline));
    while (generation == sc->sc_generation && (*value & bits) != bits) {
        int result = getMainCommandGate()->commandSleep(value, deadline, THREAD_UNINT);
        if (generation != sc->sc_generation)
            return ENXIO;
        if (result != THREAD_AWAKENED && (*value & bits) != bits)
            return (result == THREAD_TIMED_OUT) ? EWOULDBLOCK : EINTR;
    }
    return generation == sc->sc_generation ? 0 : ENXIO;
}

int ItlIwx::
iwx_load_firmware(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_fw_sects *fws;
    int err;

    sc->sc_uc.uc_intr = 0;
    sc->sc_uc.uc_ok = 0;
    
    fws = &sc->sc_fw.fw_sects[IWX_UCODE_TYPE_REGULAR];
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        err = iwx_ctxt_info_gen3_init(sc, fws);
    else
        err = iwx_ctxt_info_init(sc, fws);
    if (err) {
        XYLog("%s: could not init context info\n", DEVNAME(sc));
        return err;
    }
    
    err = iwx_wait_notification(sc, &sc->sc_uc.uc_intr, 1, 1000);
    if (err == ENXIO)
        return err;
    if (!err && !sc->sc_uc.uc_ok)
        err = EIO;
    if (err || !sc->sc_uc.uc_ok) {
#ifdef AIRPORT_VTD
        sc->sc_dmat->deferRecycling();
#endif
        if (iwx_nic_lock(sc)) {
            XYLog("SecBoot CPU1 Status: 0x%x, CPU2 Status: 0x%x\n",
                  iwx_read_umac_prph(sc, IWX_UMAG_SB_CPU_1_STATUS),
                  iwx_read_umac_prph(sc, IWX_UMAG_SB_CPU_2_STATUS));
            XYLog("UMAC PC: 0x%x\n",
                  iwx_read_umac_prph(sc,
                                     IWX_UREG_UMAC_CURRENT_PC));
            XYLog("LMAC PC: 0x%x\n",
                  iwx_read_umac_prph(sc,
                                     IWX_UREG_LMAC1_CURRENT_PC));
            iwx_nic_unlock(sc);
        }
        iwx_ctxt_info_free_paging(sc);
        XYLog("%s: could not load firmware\n", DEVNAME(sc));
    }
    
    iwx_ctxt_info_free_fw_img(sc);
    
    iwx_dma_contig_free(&sc->iml_dma);
    
    if (err)
        return err;
    
    XYLog("%s: load firmware ok\n", DEVNAME(sc));
    
    return err;
}

int ItlIwx::
iwx_start_fw(struct iwx_softc *sc)
{
    
    XYLog("%s\n", __FUNCTION__);
    int err;
    
    err = iwx_prepare_card_hw(sc);
    if (err) {
        XYLog("%s: could not initialize hardware\n", DEVNAME(sc));
        return err;
    }
    
    iwx_enable_rfkill_int(sc);
    
    IWX_WRITE(sc, IWX_CSR_INT, 0xFFFFFFFF);
    
    iwx_disable_interrupts(sc);
    
    /* make sure rfkill handshake bits are cleared */
    IWX_WRITE(sc, IWX_CSR_UCODE_DRV_GP1_CLR, IWX_CSR_UCODE_SW_BIT_RFKILL);
    IWX_WRITE(sc, IWX_CSR_UCODE_DRV_GP1_CLR,
              IWX_CSR_UCODE_DRV_GP1_BIT_CMD_BLOCKED);
    
    /* clear (again), then enable firwmare load interrupt */
    IWX_WRITE(sc, IWX_CSR_INT, ~0);
    
    err = iwx_nic_init(sc);
    if (err) {
        XYLog("%s: unable to init nic\n", DEVNAME(sc));
        return err;
    }
    
    return iwx_load_firmware(sc);
}

int ItlIwx::
iwx_send_tx_ant_cfg(struct iwx_softc *sc, uint8_t valid_tx_ant)
{
    struct iwx_tx_ant_cfg_cmd tx_ant_cmd = {
        .valid = htole32(valid_tx_ant),
    };
    
    XYLog("%s select valid tx ant: %u\n", __FUNCTION__, valid_tx_ant);
    return iwx_send_cmd_pdu(sc, IWX_TX_ANT_CONFIGURATION_CMD,
                            0, sizeof(tx_ant_cmd), &tx_ant_cmd);
}

int ItlIwx::
iwx_send_phy_cfg_cmd(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_phy_cfg_cmd_v3 phy_cfg_cmd;
    uint8_t cmdver;
    
    phy_cfg_cmd.phy_cfg = htole32(sc->sc_fw_phy_config);
    phy_cfg_cmd.calib_control.event_trigger =
    sc->sc_default_calib[IWX_UCODE_TYPE_REGULAR].event_trigger;
    phy_cfg_cmd.calib_control.flow_trigger =
    sc->sc_default_calib[IWX_UCODE_TYPE_REGULAR].flow_trigger;
    
    cmdver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_PHY_CONFIGURATION_CMD);
    
    return iwx_send_cmd_pdu(sc, IWX_PHY_CONFIGURATION_CMD, 0,
                            (cmdver == 3) ? sizeof(struct iwx_phy_cfg_cmd_v3) :
                            sizeof(struct iwx_phy_cfg_cmd_v1), &phy_cfg_cmd);
}

int ItlIwx::
iwx_send_dqa_cmd(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_dqa_enable_cmd dqa_cmd = {
        .cmd_queue = htole32(IWX_DQA_CMD_QUEUE),
    };
    uint32_t cmd_id;
    
    cmd_id = iwx_cmd_id(IWX_DQA_ENABLE_CMD, IWX_DATA_PATH_GROUP, 0);
    return iwx_send_cmd_pdu(sc, cmd_id, 0, sizeof(dqa_cmd), &dqa_cmd);
}

int ItlIwx::
iwx_load_ucode_wait_alive(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    int err;
    
    err = iwx_read_firmware(sc);
    if (err)
        return err;
    
    err = iwx_start_fw(sc);
    if (err)
        return err;
    
    err = iwx_load_pnvm(sc);
    if (err)
        return err;
    
    iwx_post_alive(sc);
    
    return 0;
}

int ItlIwx::
iwx_run_init_mvm_ucode(struct iwx_softc *sc, int readnvm)
{
    XYLog("%s\n", __FUNCTION__);
    const int wait_flags = IWX_INIT_COMPLETE;
    struct iwx_nvm_access_complete_cmd nvm_complete = {};
    struct iwx_init_extended_cfg_cmd init_cfg = {
        .init_flags = htole32(IWX_INIT_NVM),
    };
    int err;

    if ((sc->sc_flags & IWX_FLAG_RFKILL) && !readnvm) {
        XYLog("%s: radio is disabled by hardware switch\n",
            DEVNAME(sc));
        return EPERM;
    }

    sc->sc_init_complete = 0;
    err = iwx_load_ucode_wait_alive(sc);
    if (err) {
        XYLog("%s: failed to load init firmware\n", DEVNAME(sc));
        return err;
    }
    
    if (sc->sc_tx_with_siso_diversity)
        init_cfg.init_flags |= htole32(IWX_INIT_PHY);

    /*
     * Send init config command to mark that we are sending NVM
     * access commands
     */
    err = iwx_send_cmd_pdu(sc, IWX_WIDE_ID(IWX_SYSTEM_GROUP,
                                           IWX_INIT_EXTENDED_CFG_CMD), IWX_CMD_SEND_IN_RFKILL, sizeof(init_cfg), &init_cfg);
    if (err)
        return err;

    err = iwx_send_cmd_pdu(sc, IWX_WIDE_ID(IWX_REGULATORY_AND_NVM_GROUP,
                                           IWX_NVM_ACCESS_COMPLETE), IWX_CMD_SEND_IN_RFKILL, sizeof(nvm_complete), &nvm_complete);
    if (err)
        return err;

    /* INIT_COMPLETE can arrive before NVM_ACCESS_COMPLETE is acknowledged. */
    err = iwx_wait_notification(sc, &sc->sc_init_complete, wait_flags, 2000);
    if (err)
        return err;

    if (readnvm) {
        err = iwx_nvm_get(sc);
        if (err) {
            XYLog("%s: failed to read nvm\n", DEVNAME(sc));
            return err;
        }
        if (IEEE80211_ADDR_EQ(etheranyaddr, sc->sc_ic.ic_myaddr))
            IEEE80211_ADDR_COPY(sc->sc_ic.ic_myaddr,
                sc->sc_nvm.hw_addr);
        
    }
    return 0;
}

int ItlIwx::
iwx_config_ltr(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_ltr_config_cmd cmd = {
        .flags = htole32(IWX_LTR_CFG_FLAG_FEATURE_ENABLE),
    };
    
    if (!sc->sc_ltr_enabled)
        return 0;
    
    return iwx_send_cmd_pdu(sc, IWX_LTR_CONFIG, 0, sizeof(cmd), &cmd);
}

void ItlIwx::
iwx_update_rx_desc(struct iwx_softc *sc, struct iwx_rx_ring *ring, int idx)
{
    struct iwx_rx_data *data = &ring->data[idx];
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        struct iwx_rx_transfer_desc *bd = (struct iwx_rx_transfer_desc *)ring->desc;
        
        bd[idx].addr = htole64(data->map->dm_segs[0].location);
        bd[idx].rbid = htole16(idx & 0x0fff);
    } else
        ((uint64_t *)ring->desc)[idx] =
        htole64(data->map->dm_segs[0].location | (idx & 0x0fff));
    //    bus_dmamap_sync(sc->sc_dmat, ring->free_desc_dma.map,
    //        idx * sizeof(uint64_t), sizeof(uint64_t),
    //        BUS_DMASYNC_PREWRITE);
}

int ItlIwx::
iwx_rx_addbuf(struct iwx_softc *sc, int size, int idx)
{
    struct iwx_rx_ring *ring = &sc->rxq;
    struct iwx_rx_data *data = &ring->data[idx];
    mbuf_t m;
    int err;
    int fatal = 0;
    
    m = getController()->allocatePacket(size);
    
    //    m = m_gethdr(M_DONTWAIT, MT_DATA);
    //    if (m == NULL)
    //        return ENOBUFS;
    //
    //    if (size <= MCLBYTES) {
    //        MCLGET(m, M_DONTWAIT);
    //    } else {
    //        MCLGETI(m, M_DONTWAIT, NULL, IWX_RBUF_SIZE);
    //    }
    //    if ((m->m_flags & M_EXT) == 0) {
    //        m_freem(m);
    //        return ENOBUFS;
    //    }
    //
    //    if (data->m != NULL) {
    //        bus_dmamap_unload(sc->sc_dmat, data->map);
    //        fatal = 1;
    //    }
    //
    //    m->m_len = m->m_pkthdr.len = m->m_ext.ext_size;
    //    err = bus_dmamap_load_mbuf(sc->sc_dmat, data->map, m,
    //        BUS_DMA_READ|BUS_DMA_NOWAIT);
    if (m == NULL) {
        XYLog("could not allocate RX mbuf\n");
        return ENOMEM;
    }
    data->map->dm_nsegs = bus_dmamap_packet(data->map, m, &data->map->dm_segs[0], 1, true);
    if (data->map->dm_nsegs == 0) {
        /* XXX */
        if (fatal)
            panic("%s: could not load RX mbuf", DEVNAME(sc));
        mbuf_freem(m);
        return ENOMEM;
    }
    data->m = m;
    //    bus_dmamap_sync(sc->sc_dmat, data->map, 0, size, BUS_DMASYNC_PREREAD);
    
    /* Update RX descriptor. */
    iwx_update_rx_desc(sc, ring, idx);
    
    return 0;
}

int ItlIwx::
iwx_rxmq_get_signal_strength(struct iwx_softc *sc,
                             struct iwx_rx_mpdu_desc *desc)
{
    int energy_a, energy_b;
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        energy_a = desc->v3.energy_a;
        energy_b = desc->v3.energy_b;
    } else {
        energy_a = desc->v1.energy_a;
        energy_b = desc->v1.energy_b;
    }
    energy_a = energy_a ? -energy_a : -256;
    energy_b = energy_b ? -energy_b : -256;
    return MAX(energy_a, energy_b);
}

void ItlIwx::
iwx_rx_rx_phy_cmd(struct iwx_softc *sc, struct iwx_rx_packet *pkt,
                  struct iwx_rx_data *data)
{
    struct iwx_rx_phy_info *phy_info = (struct iwx_rx_phy_info *)pkt->data;
    
    //    bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*pkt),
    //        sizeof(*phy_info), BUS_DMASYNC_POSTREAD);
    
    memcpy(&sc->sc_last_phy_info, phy_info, sizeof(sc->sc_last_phy_info));
}

/*
 * Retrieve the average noise (in dBm) among receivers.
 */
int ItlIwx::
iwx_get_noise(const uint8_t *beacon_silence_rssi)
{
    int i, total, nbant, noise;
    
    total = nbant = noise = 0;
    for (i = 0; i < 3; i++) {
        noise = letoh32(beacon_silence_rssi[i]) & 0xff;
        if (noise) {
            total += noise;
            nbant++;
        }
    }
    
    /* There should be at least one antenna but check anyway. */
    return (nbant == 0) ? -127 : (total / nbant) - 107;
}

int ItlIwx::
iwx_ccmp_decap(struct iwx_softc *sc, mbuf_t m, struct ieee80211_node *ni,
    struct ieee80211_rxinfo *rxi)
{
   struct ieee80211com *ic = &sc->sc_ic;
   struct ieee80211_key *k;
   struct ieee80211_frame *wh;
   uint64_t pn, *prsc;
   uint8_t *ivp;
   uint8_t tid;
   int hdrlen, hasqos;

   wh = mtod(m, struct ieee80211_frame *);
   hdrlen = ieee80211_get_hdrlen(wh);
   ivp = (uint8_t *)wh + hdrlen;
    
   /* find key for decryption */
   k = ieee80211_get_rxkey(ic, m, ni);
   if (k == NULL || k->k_cipher != IEEE80211_CIPHER_CCMP)
       return 1;

   /* Check that ExtIV bit is be set. */
   if (!(ivp[3] & IEEE80211_WEP_EXTIV))
       return 1;

   hasqos = ieee80211_has_qos(wh);
   tid = hasqos ? ieee80211_get_qos(wh) & IEEE80211_QOS_TID : 0;
   prsc = &k->k_rsc[tid];

   /* Extract the 48-bit PN from the CCMP header. */
   pn = (uint64_t)ivp[0]       |
        (uint64_t)ivp[1] <<  8 |
        (uint64_t)ivp[4] << 16 |
        (uint64_t)ivp[5] << 24 |
        (uint64_t)ivp[6] << 32 |
        (uint64_t)ivp[7] << 40;
    if (rxi->rxi_flags & IEEE80211_RXI_HWDEC_SAME_PN) {
        if (pn < *prsc) {
            ic->ic_stats.is_ccmp_replays++;
            return 1;
        }
    } else if (pn <= *prsc) {
       ic->ic_stats.is_ccmp_replays++;
       return 1;
   }
   /* Last seen packet number is updated in ieee80211_inputm(). */

   /*
    * Some firmware versions strip the MIC, and some don't. It is not
    * clear which of the capability flags could tell us what to expect.
    * For now, keep things simple and just leave the MIC in place if
    * it is present.
    *
    * The IV will be stripped by ieee80211_inputm().
    */
   return 0;
}

int ItlIwx::
iwx_rx_hwdecrypt(struct iwx_softc *sc, mbuf_t m, uint32_t rx_pkt_status,
                 struct ieee80211_rxinfo *rxi)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = IC2IFP(ic);
    struct ieee80211_frame *wh;
    struct ieee80211_node *ni;
    int ret = 0;
    uint8_t type, subtype;
    
    wh = mtod(m, struct ieee80211_frame *);
    
    type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
    if (type == IEEE80211_FC0_TYPE_CTL)
        return 0;
    
    subtype = wh->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK;
    if (ieee80211_has_qos(wh) && (subtype & IEEE80211_FC0_SUBTYPE_NODATA))
        return 0;
    
    ni = ieee80211_find_rxnode(ic, wh);
    /* Handle hardware decryption. */
    if (((wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK) != IEEE80211_FC0_TYPE_CTL)
        && (wh->i_fc[1] & IEEE80211_FC1_PROTECTED) &&
        (ni->ni_flags & IEEE80211_NODE_RXPROT) &&
        ((!IEEE80211_IS_MULTICAST(wh->i_addr1) &&
          ni->ni_rsncipher == IEEE80211_CIPHER_CCMP) ||
         (IEEE80211_IS_MULTICAST(wh->i_addr1) &&
          ni->ni_rsngroupcipher == IEEE80211_CIPHER_CCMP))) {
        if ((rx_pkt_status & IWX_RX_MPDU_RES_STATUS_SEC_ENC_MSK) !=
            IWX_RX_MPDU_RES_STATUS_SEC_CCM_ENC) {
            ic->ic_stats.is_ccmp_dec_errs++;
            ret = 1;
            goto out;
        }
        /* Check whether decryption was successful or not. */
        if ((rx_pkt_status &
             (IWX_RX_MPDU_RES_STATUS_DEC_DONE |
              IWX_RX_MPDU_RES_STATUS_MIC_OK)) !=
            (IWX_RX_MPDU_RES_STATUS_DEC_DONE |
             IWX_RX_MPDU_RES_STATUS_MIC_OK)) {
            ic->ic_stats.is_ccmp_dec_errs++;
            ret = 1;
            goto out;
        }
        rxi->rxi_flags |= IEEE80211_RXI_HWDEC;
    }
out:
    if (ret)
        ifp->netStat->inputErrors++;
    ieee80211_release_node(ic, ni);
    return ret;
}

// -itlawdlrx: AWDL receive test. Runs the card in monitor mode on AWDL's 5 GHz
// social channels instead of joining a network, and logs what it hears from
// nearby Apple devices. Also times a burst of channel switches, because AWDL's
// availability windows last about 16 ms. An AWDL sync frame is a vendor action
// frame with BSSID 00:25:00:ff:94:73: category 0x7f, OUI 00:17:f2, type 8,
// version, subtype (0 PSF, 3 MIF), reserved, then phy_tx_time and
// target_tx_time, little endian, in microseconds of the sender's clock.
#if defined(ITL_AWDL_NATIVE)
extern bool itlAWDLBuildAllowed();
extern IOReturn itlAWDLReceiveAction(IOEthernetController*, mbuf_t, size_t, uint32_t, int32_t);
extern void itlAWDLObserveData(IOEthernetController*, const uint8_t*, size_t);
extern IOReturn itlAWDLBuildSyncProbe(IOEthernetController*, mbuf_t*, uint64_t);
extern IOReturn itlAWDLBuildTransmit(IOEthernetController*, mbuf_t*);
extern IOReturn itlAWDLBuildTransmit(IOEthernetController*, mbuf_t*, const uint8_t*);
extern IOReturn itlAWDLBuildTransmit(IOEthernetController*, mbuf_t*, const uint8_t*, bool);
extern unsigned itlAWDLTransmitHeldShort(IOEthernetController*);
extern bool itlAWDLServiceTransmit(IOEthernetController*);
extern unsigned itlAWDLTransmitQueued(IOEthernetController*);
#else
// No AirDrop interface on this macOS target: nothing is ever queued for it.
static inline unsigned itlAWDLTransmitQueued(IOEthernetController*) { return 0; }
#endif
extern bool itlAWDLBuildAllowed();
static bool awdlRx;
static bool awdlQueueProbe;
static bool awdlQueueProbeAttempted;
bool itlLogOn;
// Away cap for full scans while associated, from itlwm_scanout (0 = default 120 TU).
uint32_t itlScanMaxOutTU;
bool itlLogStartup;
// Fixed slots, so writers on any thread only need an atomic index. IOLog from
// this kext does not reach the unified log, and XYLog is kprintf only.
static char itlLogLines[512][160];
static volatile uint32_t itlLogNext;
void itlLogRing(const char *fmt, ...)
{
    const uint32_t n = __sync_fetch_and_add(&itlLogNext, 1);
    char *line = itlLogLines[n % 512];
    uint64_t t;
    uint64_t ms;
    clock_get_uptime(&t);
    absolutetime_to_nanoseconds(t, &ms);
    ms /= 1000000;
    int off = snprintf(line, 160, "%u.%03u ", (unsigned)(ms / 1000), (unsigned)(ms % 1000));
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line + off, 160 - off, fmt, ap);
    va_end(ap);
}
uint32_t itlLogMark(void)
{
    return itlLogNext;
}

OSArray *itlLogCopySince(uint32_t mark)
{
    const uint32_t end = itlLogNext;
    uint32_t count = end - mark;
    if (count > 512)
        count = 512;
    OSArray *lines = OSArray::withCapacity(count ? count : 1);
    if (!lines)
        return nullptr;
    for (uint32_t n = end - count; n != end; ++n) {
        char copy[160];
        strlcpy(copy, itlLogLines[n % 512], sizeof(copy));
        if (OSString *line = OSString::withCString(copy)) {
            lines->setObject(line);
            line->release();
        }
    }
    return lines;
}
// The test's own results, so the driver's messages cannot push them out.
static char awdlEventLines[512][160];
static volatile uint32_t awdlEventNext;
static void awdlLog(const char *fmt, ...) __printflike(1, 2);
static void awdlLog(const char *fmt, ...)
{
    const uint32_t n = __sync_fetch_and_add(&awdlEventNext, 1);
    char *line = awdlEventLines[n % 512];
    uint64_t t;
    uint64_t ms;
    clock_get_uptime(&t);
    absolutetime_to_nanoseconds(t, &ms);
    ms /= 1000000;
    int off = snprintf(line, 160, "%u.%03u ", (unsigned)(ms / 1000), (unsigned)(ms % 1000));
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line + off, 160 - off, fmt, ap);
    va_end(ap);
}
static bool itlLogSerialize(void *target, void *, OSSerialize *serializer)
{
    static char text[512 * 160];
    size_t used = 0;
    const bool events = target != nullptr;
    const uint32_t end = events ? awdlEventNext : itlLogNext;
    for (uint32_t i = end > 512 ? end - 512 : 0; i < end && used < sizeof(text) - 2; i++) {
        const char *line = events ? awdlEventLines[i % 512] : itlLogLines[i % 512];
        size_t len = strnlen(line, 159);
        memcpy(text + used, line, len);
        used += len;
        if (!len || line[len - 1] != '\n')
            text[used++] = '\n';
    }
    OSData *data = OSData::withBytes(text, (unsigned)used);
    if (!data)
        return false;
    const bool ok = data->serialize(serializer);
    data->release();
    return ok;
}
// Only bounded probe lifecycle messages enter this ring. Busy RX traffic must
// not erase the one-shot result before userspace can inspect it after boot.
static char awdlTxLines[128][160];
static volatile uint32_t awdlTxNext;
static void awdlTxLog(const char *fmt, ...) __printflike(1, 2);
static void awdlTxLog(const char *fmt, ...)
{
    const uint32_t n = __sync_fetch_and_add(&awdlTxNext, 1);
    char *line = awdlTxLines[n % 128];
    uint64_t t, ns;
    clock_get_uptime(&t);
    absolutetime_to_nanoseconds(t, &ns);
    const uint64_t ms = ns / 1000000;
    const int off = snprintf(line, 160, "%u.%03u ", unsigned(ms / 1000), unsigned(ms % 1000));
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line + off, 160 - off, fmt, ap);
    va_end(ap);
}
// Session events only: Block Ack sessions, the filter, the peer's service sets, gaps in hearing it.
// Rare enough that one ring covers a whole test session (ITLAWDLSessionEvents).
static char awdlSessLines[256][140];
static volatile uint32_t awdlSessNext;
static void awdlSessLog(const char *fmt, ...) __printflike(1, 2);
static void awdlSessLog(const char *fmt, ...)
{
    const uint32_t n = __sync_fetch_and_add(&awdlSessNext, 1);
    char *line = awdlSessLines[n % 256];
    uint64_t t, ns;
    clock_get_uptime(&t);
    absolutetime_to_nanoseconds(t, &ns);
    const uint64_t ms = ns / 1000000;
    const int off = snprintf(line, 140, "%u.%03u ", unsigned(ms / 1000), unsigned(ms % 1000));
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line + off, 140 - off, fmt, ap);
    va_end(ap);
}
static bool awdlSessLogSerialize(void *, void *, OSSerialize *serializer)
{
    static char text[256 * 140];
    size_t used = 0;
    const uint32_t end = awdlSessNext;
    for (uint32_t i = end > 256 ? end - 256 : 0; i < end && used < sizeof(text) - 2; i++) {
        const char *line = awdlSessLines[i % 256];
        size_t len = strnlen(line, 139);
        memcpy(text + used, line, len);
        used += len;
        if (!len || line[len - 1] != '\n')
            text[used++] = '\n';
    }
    OSData *data = OSData::withBytes(text, (unsigned)used);
    if (!data)
        return false;
    const bool ok = data->serialize(serializer);
    data->release();
    return ok;
}
static bool awdlTxLogSerialize(void *, void *, OSSerialize *serializer)
{
    static char text[128 * 160];
    size_t used = 0;
    const uint32_t end = awdlTxNext;
    for (uint32_t i = end > 128 ? end - 128 : 0; i < end && used < sizeof(text) - 2; ++i) {
        const char *line = awdlTxLines[i % 128];
        const size_t length = strnlen(line, 159);
        memcpy(text + used, line, length);
        used += length;
        if (!length || line[length - 1] != '\n') text[used++] = '\n';
    }
    OSData *data = OSData::withBytes(text, unsigned(used));
    if (!data) return false;
    const bool ok = data->serialize(serializer);
    data->release();
    return ok;
}
static struct task awdlRxTaskEntry;
static CTimeout *awdlRxTimer;
static const uint8_t awdlRxChannels[] = {149, 44};
static bool awdlRxChannel6;
// The fixed AWDL channel. Channel 149 needs -itlawdlch149 and the firmware's regulatory
// answer to allow transmit there, normally through a real country in itlawdlcc=.
static bool awdlWant149;
static unsigned awdlFixedChannel = 6;
static char awdlCountry[3] = "ZZ";
static int awdlBtCoexRequest = -1;
unsigned itlAWDLFixedChannel() { return awdlFixedChannel; }
static bool awdlSyncProbe;
static bool awdlSyncTrain;
static bool awdlFastProbe;
static bool awdlPeerTrain;
static bool awdlAckProbe;
static ItlAWDL::AckProbe awdlAckPending = ItlAWDL::AckProbe::None;
static ItlAWDL::AckCounts awdlAcks;
static uint8_t awdlLastPeer[6];
static int awdlLastPeerRssi;
static uint8_t awdlAckTarget[6];
static int awdlAckTargetRssi;
static ItlAWDL::PeerProbe awdlPeerProbes[8];
static unsigned awdlPeerProbeCount;
static ItlAWDL::AirCounts awdlAir;
static uint32_t awdlPeerTLVs[256];
static uint64_t awdlUptimeUS();
// When TLV 2, services, changes in our frames and in the peer's, to time a lookup.
static ItlAWDL::ServiceSnapshotLog awdlServiceLog;
// -itlawdlmcastuc: each group data frame also goes to the last peer heard, as unicast, so it gets an
// ACK and retries. The phone answers few of our multicast mDNS queries, though it accepts unicast.
static bool awdlMcastUnicast, awdlNoPeerPsf, awdlServiceMerge;
// -itlawdlwide80: listen on channel 149 at 80 MHz (149 to 161, centre 155), only if the firmware
// marks 149 as 80 MHz capable and all four channels as usable for sending. If the firmware refuses,
// the driver goes back to 20 MHz for the rest of the boot.
static bool awdlWide80, awdlWide80Refused;
static uint32_t awdlWide80State, awdlWide80Error;
// -itlawdladv80: while the firmware is listening at 80 MHz on 149, our channel sequence TLV says
// so, class 128, as the phone's does. Otherwise it stays class 124, 20 MHz.
static bool awdlAdvertise80, awdlWide80Live;
static uint32_t awdlAdvertise80Frames;
static bool awdlTx80;
static uint8_t awdlTx80Peer[6];
static uint64_t awdlTx80PeerUS;
static int awdlTx80PeerGeneration;
static ItlAWDL::BaTxBulkState awdlTx80Bulk;
static uint32_t awdlTx80Requested, awdlTx80Completed, awdlTx80Reported, awdlTx80Acked;
static unsigned awdlTx80ConsecutiveMisses;
unsigned itlAWDLChannelClass()
{
    // The listener beside Wi-Fi: 80 MHz is advertised only while its own context really is at 80 MHz on 149
    // and no move is pending.
    if (awdlCoexMultiActive && awdlCoexOwnWidth == 80 && !awdlCoexMovePending &&
        awdlCoex80BlockFirst(awdlFixedChannel)) {
        ++awdlCoexAdvertise80Frames;
        return 128;
    }
    if (!awdlAdvertise80 || !awdlWide80Live || awdlWide80Refused || awdlFixedChannel != 149)
        return 0;
    ++awdlAdvertise80Frames;
    return 128;
}
static bool awdlWide80Applies(struct ieee80211com *ic, struct ieee80211_channel *c)
{
    if (!awdlWide80 || awdlWide80Refused || !ic || !c || ic->ic_opmode != IEEE80211_M_MONITOR ||
        ieee80211_chan2ieee(ic, c) != 149 || !(c->ic_flags & IEEE80211_CHAN_VHT80))
        return false;
    for (unsigned ch = 149; ch <= 161; ch += 4) {
        const auto &sub = ic->ic_channels[ch];
        if (!sub.ic_freq || (sub.ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC)))
            return false;
    }
    return true;
}
static ItlAWDL::PeerServiceCache awdlServiceCache;
static uint32_t awdlCoexServiceCacheToken;
static uint32_t awdlServiceMergedFrames, awdlServiceMergedRecords, awdlServiceMergeRefused, awdlServiceMergeLastError;
static uint32_t awdlPeerPsfKept;
static uint32_t awdlMcastUnicastCopies, awdlMcastUnicastSkipped;
constexpr uint64_t kAwdlMcastPeerRecentUS = 10000000;
static void awdlNoteServices(const uint8_t *frame, size_t length, bool fromPeer)
{
    awdlServiceLog.note(uint32_t(awdlUptimeUS() / 1000), fromPeer, frame, length);
}
static size_t awdlLargestPeer[2];
static bool awdlMacProbe;
static bool awdlElicit;
static bool awdlForeignControl;
static bool awdlDataTx;
// What the frame in flight is: 0 not data, 1 multicast, 2 unicast. Unicast status
// shows whether the peer's radio ACKed it.
static unsigned awdlDataInFlight;
static ItlAWDL::DataRateState awdlDataRate;
static unsigned awdlDataStepInFlight;
// Per rate step: sent, acknowledged, failed, total retries.
static uint32_t awdlRateResults[ItlAWDL::kDataRateSteps][4];
static uint32_t awdlTxKicks;
static ItlAWDL::ResendState awdlResend;
static uint8_t awdlResendFrame[1600];
static size_t awdlResendLength;
static uint32_t awdlResendSent, awdlResendRecovered, awdlResendGaveUp;
static bool awdlKickTransmit;
static bool awdlDataEverActive;
static uint64_t awdlLastDataUS;
static ItlAWDL::RxRateEntry awdlRxRates[16];
static uint32_t awdlRxRatesOverflow;
static uint64_t awdlLastSyncUS;
static uint32_t awdlDataSent[2], awdlDataOK[2], awdlDataFailed[2], awdlDataLastFailure;
// macOS needs the path to stay open as long as it's up. 16384 closed it after about
// 19 minutes. Sync frames are still gated on a peer being audible.
static unsigned awdlTrainLimit()
{
    return awdlDataTx ? 0x40000000U : ItlAWDL::probeLimit(awdlFastProbe, awdlPeerTrain);
}
static uint8_t awdlLearnedPeer[6];
static uint8_t awdlLearnedPeerIP[16];
static uint16_t awdlRequestSequence;
static bool awdlMacTried;
static uint8_t awdlMacOverride[6];
// -itlawdlcoexprobe, on a normal Wi-Fi boot: once associated, add a second MAC context (a LISTENER,
// ID 1, TSF B) to the station's binding, to learn whether this firmware keeps Wi-Fi working with
// an AWDL-style listener beside it. Counting only; nothing is sent from it.
constexpr uint32_t kAwdlCoexMacId = 1;
static bool awdlCoexProbe, awdlCoexAdded;
// itlawdlcoexfilter=N: the listener's receive filter. 0 promiscuous with a broadcast BSSID (iface108,
// which stopped the station's unicast traffic); 1, the default, AWDL's BSSID with group frames and no
// promiscuous mode; 2 a broadcast BSSID with group frames and no promiscuous mode.
static uint32_t awdlCoexFilter = 1;
// itlawdlcoexcycle=N: with the probe, the listener goes off and on every N seconds while associated,
// so Wi-Fi throughput can be compared with and without it on one boot. 0, the default, keeps it on.
static uint32_t awdlCoexCycleSecs, awdlCoexCycleFlips;
// -itlawdlcoexrx: with the probe and -itlawdliface, AWDL action frames the listener hears go to
// macOS's awdl0, as in monitor mode, so peers can be discovered while Wi-Fi stays up. Receive only.
static bool awdlCoexRx;
static uint32_t awdlCoexForwarded, awdlCoexForwardRefused, awdlCoexForwardMalformed;
static uint32_t awdlCoexZeroPadTrimmed;   // listener frames whose trailing zero padding was cut (issue #6)
// -itlawdlcoextx: macOS's sync frames go out from that context every 110 TU, one at a time, on the
// station's channel, unless the firmware marks it passive, DFS or no-ad-hoc. No data frames yet.
constexpr uint32_t kAwdlCoexTxPeriodMS = 113;
constexpr uint64_t kAwdlCoexTxStuckUS = 1000000;
constexpr uint32_t kAwdlCoexTxSetupTries = 3;
static bool awdlCoexTxStaAdded, awdlCoexInFlight, awdlCoexSending, awdlCoexAddrKnown;
static uint8_t awdlCoexAddr[6];
static uint64_t awdlCoexInFlightUS;
// Stage 3 (-itlawdlcoexdata): AWDL data through the listener. Received data frames go to awdl0, and
// macOS's awdl0 packets go out the listener's queue at a fixed OFDM rate.
static bool awdlCoexSendingData;
static uint32_t awdlCoexDataRx, awdlCoexDataRxDelivered, awdlCoexDataRxMalformed, awdlCoexDataTx,
    awdlCoexDataTxErrors, awdlCoexDataOK, awdlCoexDataFailed, awdlCoexDataPumps;
static uint64_t awdlCoexLastDataUS, awdlCoexLastSyncUS;
static uint8_t awdlCoexDataBuf[2304 + 4];
static CTimeout *awdlCoexTxTimer;
static struct task awdlCoexTxTaskEntry;
static uint32_t awdlCoexTxSetupTried, awdlCoexStaResult, awdlCoexQueueResult;
static uint32_t awdlCoexTxBuilt, awdlCoexTxNotReady, awdlCoexTxSubmitted, awdlCoexTxSubmitErrors;
// Builds the bridge refused for a reason other than "not ready yet", and its last return code.
static uint32_t awdlCoexTxBuildRejected, awdlCoexLastBuildResult;
// Why the channel is refused right now, as bits: 1 not in the fixed-schedule list, 2 passive (net80211's
// flag for a channel the firmware's profile doesn't mark active), 4 DFS, 8 no ad hoc, 16 not active,
// 32 not the channel our frames name. 0 while it is eligible. The last refusal is kept as one line too.
static uint32_t awdlCoexRefusedReason, awdlCoexRefusedChannelFlags;
static char awdlCoexRefusalSnapshot[128];
// AWDL action frames heard on the listener's own channel and on any other, and the timer's tick count,
// which drives routine publication.
static uint32_t awdlCoexActionOnChannel, awdlCoexActionOffChannel;
static uint64_t awdlCoexLastRoutinePublishUS;
static uint32_t awdlCoexTxOK, awdlCoexTxFailed, awdlCoexTxStuck, awdlCoexTxRefusedChannel;
static uint32_t awdlCoexAddrChanges, awdlCoexAddrFailures;
// The address the firmware context really has, separately from the one wanted: TX waits until they match.
static bool awdlCoexAddrApplied;
static uint8_t awdlCoexAddrInFirmware[6];
// The one frame in flight, by ring slot, so a completion that comes after the watchdog gave up can't retire
// a newer one. A completion's sequence number is the slot after the last one it frees, so the frame is
// matched by whether that range covers its slot.
static int awdlCoexPendingSlot = -1;
// After a frame never completes, nothing more is sent until the queue is set up again.
static bool awdlCoexTxHalted;
static uint32_t awdlCoexSetupAttempts;
// Changes on every listener add or remove and every firmware restart. Work that waited on the firmware
// checks it (with the generation and the stop flag) before touching anything again.
static uint32_t awdlCoexToken;
// The firmware generation a removal is running in: new TX and setup are already off, and a second add
// for the same generation waits for it to finish. A restarted firmware isn't held back.
static int awdlCoexRemovingGen = -1;
// The last completion fault or halt, as one line.
static char awdlCoexFaultSnapshot[160];
static uint32_t awdlCoexLastSsn = 0xffffffffU;

static uint32_t awdlCoexSetupAborts, awdlCoexBadCompletions;
static int awdlCoexLastSlot = -1, awdlCoexLastBoundary = -1;
static int awdlCoexPendingGeneration = -1;
static uint32_t awdlCoexLateCompletions;
// A failed teardown command leaves the firmware's state unknown, so nothing is re-added until the firmware
// restarts (the generation changes).
static int awdlCoexBrokenGeneration = -1;
static uint32_t awdlCoexTeardownErrors;
// Set at detach: AWDL timers and tasks stop re-arming.
static bool awdlStopping;
static bool awdlCoexSetupCurrent(int generation)
{
    return awdlCoexSetupToken == awdlCoexToken && awdlCoexAdded && !awdlStopping && awdlCoexSetupGen == generation;
}
static bool awdlCoexWant = true;
static CTimeout *awdlCoexTimer;
static struct task awdlCoexTaskEntry;
static int awdlCoexGeneration = -1;
static uint32_t awdlCoexAdds, awdlCoexRemoves, awdlCoexMacResult, awdlCoexBindResult, awdlCoexBindStatus;
// Why the listener was added again (#16): after a normal removal (the station left RUN and came back), or
// after a firmware restart dropped it without a removal. A rising restart count means the firmware is
// restarting under the listener, not that the driver re-adds it on purpose.
static uint32_t awdlCoexAddsAfterRemove, awdlCoexAddsAfterRestart;
static bool awdlCoexLostToRestart;
// -itlawdlsameband (#16, test): while the station is on 2.4 GHz, keep the listener on channel 6, in the same
// band, instead of time-sharing the radio across bands. Off by default until testers confirm it helps.
static bool awdlCoexSameBand;
// For the listener's 5 GHz channel (149 or 44): the station's own 80 MHz block (149-161 or 36-48) with another
// primary (1), or a 160 MHz station channel over it (2). The listener takes that channel at 20 MHz, or skips it
// (ITLAWDLCoexOverlap, for the channel picked last). -itlawdloverlap80 keeps the old choice, for comparison.
static uint8_t awdlCoexOverlapState;
static bool awdlCoexOverlap80;
// Test (-itlawdlsta44, #68): while the station itself is on 44, the listener shares it instead of following
// the peer's 149 slots. A peer on the same router names 44 in its Wi-Fi slots and 149 in some AWDL slots, and
// the min rule then moved the listener between 44 and 149 every few seconds.
static bool awdlCoexStation44;
// Block Ack on the shared context (#16, #24): when the listener shares the station's binding (without
// -itlawdlcoexmulti, or in its fallback), receive and send Block Ack run there as well. Until 0.5.3 they
// ran only with the listener on its own context, so a shared listener answered no ADDBA request and sent
// every frame singly (#16: 84 requests, 0 answers, about 1 MB/s). -itlawdlnosharedba restores that, for an A/B.
static bool awdlCoexNoSharedBa;
// The width the last peer station was added with (80 or 20; 0 before the first).
static uint32_t awdlCoexBaPeerWidth;
// The usable country the beacon hints were gathered under (#21, and seen on the project machine): the
// firmware's answer can drop to its world code and come back to the same country, and clearing the hints
// each time sent the listener back to channel 6. Hints are now cleared only for a different usable country.
static uint16_t awdlCoexHintCountry;
static uint32_t awdlCoexCountryUnusableAnswers, awdlCoexHintClears;
// How many beacon hints the last country change kept (#21).
static uint32_t awdlCoexHintsKept;
// The phone's latest 16-slot channel sequence (TLV 18) (#24, #21): which channels it spends its slots on. The
// listener's channel picker follows the 5 GHz AWDL channel it names (awdlCoexPeerNames).
static uint8_t awdlCoexPeerSeq[16];
static uint32_t awdlCoexPeerSeqFrames, awdlCoexPeerSeqChanges;
// Whether the phone's sequence names ch as an AWDL channel. Slots 6, 7, 14 and 15 are the ones Apple gives to the
// phone's own Wi-Fi network (#24: an iPhone on a router on 36 showed 36 exactly there). An idle phone also spends
// other slots there (#35: 48 in slots 0, 1, 9 and 11 as well), so a channel that appears in those four slots is
// the phone's Wi-Fi and doesn't count, unless wifiToo: then it counts if it also appears in another slot.
// Based on PR #21's min rule (zheznanohana).
// Whether the phone's sequence puts it on ch in any of its 16 slots, Wi-Fi slots included: it can be met there.
static bool awdlCoexPeerVisits(const uint8_t seq[16], unsigned ch)
{
    for (unsigned n = 0; n < 16; ++n)
        if (seq[n] == ch)
            return true;
    return false;
}
static bool awdlCoexPeerNames(const uint8_t seq[16], unsigned ch, bool wifiToo = false)
{
    if (!wifiToo && (seq[6] == ch || seq[7] == ch || seq[14] == ch || seq[15] == ch))
        return false;
    for (unsigned n = 0; n < 16; ++n)
        if ((n & 7) < 6 && seq[n] == ch)
            return true;
    return false;
}
// The 5 GHz AWDL channel the phone uses: 44 or 149, 0 if neither. 44 wins (the min rule). A phone whose Wi-Fi is
// on 44 counts as using 44 only when its sequence doesn't name 149: in Japan, with the router on 44, AWDL is on
// 44 too, while a phone elsewhere on a router on 44 still names 149 for AWDL.
static unsigned awdlCoexPeerChannel(const uint8_t seq[16])
{
    const bool names149 = awdlCoexPeerNames(seq, 149);
    if (awdlCoexPeerNames(seq, 44, !names149))
        return 44;
    return names149 ? 149 : 0;
}
static bool awdlCoexPeerSequence(const uint8_t *frame, size_t length, uint8_t out[16])
{
    if (!frame || length < 40) return false;
    for (size_t i = 40; i + 3 <= length;) {
        const size_t value = size_t(frame[i + 1]) | size_t(frame[i + 2]) << 8;
        if (i + 3 + value > length) return false;
        if (frame[i] == 18) {
            if (value < 6 + 32) return false;
            for (unsigned n = 0; n < 16; ++n) out[n] = frame[i + 3 + 6 + 2 * n];
            return true;
        }
        i += 3 + value;
    }
    return false;
}
static uint32_t awdlCoexAwdlAction, awdlCoexAwdlData, awdlCoexOther, awdlCoexChannel, awdlCoexPublished;
// Data is handed to awdl0 only from a source heard sending valid AWDL action frames in the last 60 s
// (iface129 review, 5). Addresses stay in memory only and are never published.
struct AwdlCoexPeer { uint8_t addr[6]; uint64_t heardUS; unsigned channel; uint32_t token; };
static AwdlCoexPeer awdlCoexPeers[8];
static uint32_t awdlCoexDataRxUnknownPeer, awdlCoexDataRxOffChannel;
// Why a data source was refused, by count only: 0 never heard, 1 heard over 60 s ago, 2 heard on another
// channel, 3 heard by an earlier listener (token).
static uint32_t awdlCoexRejectReasons[4];
// Stage 4: receive Block Ack on the listener. The phone's ADDBA request gets a peer station (bound to the
// listener's MAC context) and a firmware session, then an answer from the listener's queue. While a lot
// of data arrives, promiscuous receive goes off (dedicated mode found that the firmware doesn't
// acknowledge a session's frames with it on). By default it stays off for as long as the peer's firmware
// station exists, and comes back when that station goes (see awdlCoexBaHandle).
static bool awdlCoexBaPeerAdded, awdlCoexBaFilterOff;
static ItlAWDL::PendingAddbaRequests awdlCoexBaRequestsPending;
static uint8_t awdlCoexBaPeer[6], awdlCoexBaTidToken[8];
static uint8_t awdlCoexBaTids;
static int awdlCoexBaFailedGen = -1, awdlCoexBaGen = -1;
static uint32_t awdlCoexBaRequests, awdlCoexBaSessions, awdlCoexBaAnswers, awdlCoexBaAnswerErrors,
    awdlCoexBaOtherPeer, awdlCoexBaDelbas, awdlCoexBaStatus, awdlCoexBaFilterChanges;
static uint8_t awdlCoexBaAnswer[ItlAWDL::kAddbaResponseLength];
static size_t awdlCoexBaAnswerLength;
static uint8_t awdlCoexBaAnswerTid;
static uint64_t awdlCoexBaAnswerRetryUS;
static uint16_t awdlCoexBaSequence;
static ItlAWDL::BaFilterState awdlCoexBaFilter;
// What the phone's data looks like: retries, and modulation (index = rate_n_flags mod type), 80 MHz count.
static uint32_t awdlCoexDataRxRetry, awdlCoexRxModulation[8], awdlCoexRxWide80;
// Unicast data rate for our frames: 0 legacy 24 Mbit/s, then HT MCS 4, 5, 7 (20 MHz, one stream). Steps
// down after a window with over 20% failures, up after one with under 5%.
static unsigned awdlCoexRateStep;
static uint32_t awdlCoexRateWindowOK, awdlCoexRateWindowFailed, awdlCoexRateUps, awdlCoexRateDowns;
// Steps 4 and 5 are VHT 80 MHz, two streams, MCS 4 and 7, only while the listener is at 80 MHz.
static const uint8_t kAwdlCoexRateMcs[6] = {0, 4, 5, 7, 4, 7};
// Our management frames (ADDBA answers and requests) are tagged so they never count toward the data rate.
enum { kCoexSlotBaAnswer = 3, kCoexSlotBaAsk, kCoexSlotDelba };
static uint8_t awdlCoexSendingMgmt, awdlCoexSendingMgmtToken;
static bool awdlCoexBaPeerAccepted;
static bool awdlCoexBaQueueAllocPending;
static uint32_t awdlCoexBaPeerEpoch;
static bool awdlCoexBaQueueCurrent(int generation, uint32_t listener, uint32_t peer)
{
    return awdlCoexAdded && awdlCoexBaPeerAdded &&
        awdlCoexGeneration == generation && awdlCoexToken == listener && awdlCoexBaPeerEpoch == peer;
}
static uint32_t awdlCoexBaAskOK, awdlCoexBaAskFailed, awdlCoexBaAsksSkippedAway;
static uint32_t awdlCoexMgmtOK, awdlCoexMgmtFailed;
// DELBA from the phone for its own session: those TIDs are removed from the firmware on the next pass.
static uint8_t awdlCoexBaTidTeardown;
static uint64_t awdlCoexBaPeerLastUS;
// Stage 4 part 2: send Block Ack. A bulk stream of unicast data to one peer gets that peer's station (the
// same one receive BA uses), a firmware aggregation queue on TID 0 with firmware rate control, and our own
// ADDBA request. Once the phone agrees, bulk frames to it go out aggregated; short exchanges stay on the
// listener's single-frame queue, as dedicated mode found works best.
enum { kCoexBaTxOff, kCoexBaTxAsking, kCoexBaTxAgreed, kCoexBaTxFailed, kCoexBaTxEnabling };
static int awdlCoexBaTxState = kCoexBaTxOff;
static uint16_t awdlCoexBaTxSeq;
static uint8_t awdlCoexBaTxToken = 0x5a;
static uint32_t awdlCoexBaTxAsks, awdlCoexBaTxAskRounds, awdlCoexBaTxAgreements, awdlCoexBaTxRefusals,
    awdlCoexBaTxFrames, awdlCoexBaTxSubmitErrors, awdlCoexBaTxNotifs, awdlCoexBaTxAcked, awdlCoexBaTxSentAir,
    awdlCoexBaTxQueueResult, awdlCoexBaTxDelbas, awdlCoexBaTxPeerAdds;
static uint64_t awdlCoexBaTxLastAskUS, awdlCoexBaTxRestUntilUS;
// Asking stops once nothing has gone to or come from the peer for this long and no bulk send runs: after a
// transfer the rounds went on for minutes (#24). Data to or from it starts a fresh round.
constexpr uint64_t kAwdlCoexBaIdleAskUS = 30000000;
static uint32_t awdlCoexBaTxIdleHolds;
static ItlAWDL::BaTxBulkState awdlCoexBaTxBulk;
static bool awdlCoexBaSendingAgg;
// iwlmvm enables aggregation for a TID by clearing its bit in tid_disable_tx (STA_MODIFY_TID_DISABLE_TX);
// the peer station was added with all bits set. Done once per agreement, from the task.
static uint32_t awdlCoexBaTxAggEnableStatus;
// The unicast destination of our data and how many frames went to it, for picking the TX peer.
static uint8_t awdlCoexTxDest[6];
static uint32_t awdlCoexTxDestFrames;
constexpr uint32_t kAwdlCoexBaTxQueuedMax = 128;
// Block Ack action frames to our AWDL address, by action code (0 request, 1 answer, 2 teardown, 3 other)
// and by whether they carry AWDL's BSSID (iface135: none of 165 asks got an answer we saw).
static uint32_t awdlCoexBaActionSeen[4], awdlCoexBaActionAwdlBssid, awdlCoexBaActionOtherBssid;
static uint32_t awdlCoexRxWhileFilterOff;
// The listener's queue carries data too now, so a sync frame can wait behind retried data while the radio
// is on the station's channel (iface136: one wait over 1 s halted TX for good). A stall counts only if no
// completion at all came for a second, or the sync frame waited 5 s; it pauses sending for 0.5 s, and
// only three stalls in a row with no completion between them halt TX.
static uint64_t awdlCoexLastCompletionUS, awdlCoexTxPauseUntilUS;
static uint32_t awdlCoexStuckStreak, awdlCoexTxPauses, awdlCoexWedgedRebuilds;
static uint32_t awdlCoexBaTxResponses, awdlCoexBaTxResponseFrames, awdlCoexBaTxAggResponses, awdlCoexVhtFrames;
static uint32_t awdlCoexBaTxPeakQueued, awdlCoexBaTxSinglesWithBacklog;
static uint32_t awdlCoexBaTxPausedFullDeferrals;
static bool awdlCoexBaTraceEnabled, awdlCoexBaRefillEnabled;
static uint32_t awdlCoexBaRefillKicks, awdlCoexBaRefillFrames;
// When a Block Ack leaves the aggregate queue empty: did awdl0 have frames waiting (the driver fed too
// slowly) or none (macOS had nothing to send)? After a refill kick, was it still empty with frames waiting?
static uint32_t awdlCoexBaEmptyWithReady, awdlCoexBaEmptyNoReady, awdlCoexBaRefillStillEmptyReady;
// -itlawdlcoexbafilterhyst: the old receive-filter policy (promiscuous back on after quiet seconds) for an
// A/B test. By default promiscuous receive stays off while the peer's firmware station exists (not only while
// a receive BA session is open): the firmware doesn't acknowledge a station's frames with it on, and iPhone
// sysdiagnoses showed a minute-long stall where the phone's frames went unacknowledged after it came back on.
// A receive session is torn down after 60 s idle, but the station lives up to ten minutes, and a send we start
// in that gap gets no replies until the phone opens a session itself: two minutes in the 2026-11-15 tests.
static bool awdlCoexBaFilterHysteresis;
static bool awdlCoexBaFilterBySession; // -itlawdlfilterbysession: the pre-#57 rule (off only during a receive session).
// -itlawdlcoexawhold: outside an aggregated bulk send (which has its own station pause), awdl0 output waits
// in macOS's queue while the active peer's fresh, calibrated schedule says it is away from our channel,
// for at most the current away run (pauseLimitUS, 450 ms ceiling) per hold. iPhone sysdiagnoses showed an
// idle phone on 149 for only 2 or 5 of 16 entries, so group frames (never retried) and unicast frames
// (retried only for milliseconds) sent outside those entries are lost and delay connection setup.
static bool awdlCoexAwHold;
// Block Ack event log for the listener (iface151, diagnostic): why does the phone sometimes never answer our
// ADDBA? Each entry: uptime ms, type, three small values. Published as text, newest last. Types:
// A ask sent (token, SSN, flags: 1 filter off, 2 schedule usable, 4 RX session open; away deferrals before it)
// a ask completion (token, acked)        R answer received (token, status, accepted by the real predicate)
// B any BA action frame to us (action, from the BA peer, AWDL BSSID, gate: 1 channel valid + 2 peer known)
// Q phone ADDBA request (token, tid)     q our answer completion (token, acked)
// d our DELBA completion (tid, acked)    D phone DELBA (tid, 1 if it was the sender)
// S send-BA state change (old, new)
// Fields: a, b and d are 16-bit, c is 8-bit. The first 64 events of the boot are also
// kept apart, so the first negotiation survives the ring wrapping.
struct AwdlCoexBaEvent { uint32_t ms; char type; uint16_t a, b; uint8_t c; uint16_t d, id; };
static AwdlCoexBaEvent awdlCoexBaEvents[256], awdlCoexBaEventsFirst[64];
static uint32_t awdlCoexBaEventCount;
static int awdlCoexBaEventLastState = -1;
static void awdlCoexBaEvent(char type, unsigned a, unsigned b, unsigned c, unsigned d = 0, unsigned id = 0)
{
    uint64_t up = 0, ns = 0;
    clock_get_uptime(&up);
    absolutetime_to_nanoseconds(up, &ns);
    const AwdlCoexBaEvent e{uint32_t(ns / 1000000ULL), type, uint16_t(a), uint16_t(b), uint8_t(c), uint16_t(d),
                            uint16_t(id)};
    if (awdlCoexBaEventCount < nitems(awdlCoexBaEventsFirst))
        awdlCoexBaEventsFirst[awdlCoexBaEventCount] = e;
    awdlCoexBaEvents[awdlCoexBaEventCount++ % nitems(awdlCoexBaEvents)] = e;
}
// Away deferrals since the last ask actually sent.
static uint32_t awdlCoexAskSkipsSinceLast;
// Per-enqueue identity for listener management frames: each one gets the next id, kept with its slot, so an
// ask, answer or DELBA pairs with its own completion even when 40 asks share a dialog token.
static uint16_t awdlCoexMgmtEnqueueId, awdlCoexLastMgmtEnqueueId;
// TX response attribution (iface153). The response's status is for the descriptor its header index names;
// the SSN only says how far to reclaim. Slots reclaimed without their own status are counted, not credited.
static uint32_t awdlCoexStatusIdxHits, awdlCoexStatusIdxMisses, awdlCoexMultiReclaims, awdlCoexReclaimUnknown,
    awdlCoexSyncReclaimedUnknown;
// iface149. The phone's station (with the Mac's send BA agreement) is kept between sends: removed after 60 s
// without hearing the peer, or 10 minutes without data, not after 60 s without data. Payload frames to an
// agreed peer take the aggregate path (with the away pause) without waiting for the bulk detector, which
// a slowly starting QUIC stream may never reach. A pause resume is confirmed by the firmware and retried.
static uint64_t awdlCoexBaTxLastAggUS;
static uint64_t awdlCoexBaProbeUntilUS, awdlCoexBaLastRxPayloadUS;
static bool awdlCoexBaProbeTried;
static uint32_t awdlCoexPauseResumeFailures, awdlCoexBaEarlyAggFrames;
static uint64_t awdlCoexResumeRetryUS;
static bool awdlCoexResumePending;
static uint32_t awdlCoexResumeFailStreak, awdlCoexResumeRetirements, awdlCoexBaRxIdleTeardowns, awdlCoexBaDelbasSent;
static uint8_t awdlCoexBaRxIdleTids;
// Idle receive teardown (iface153): the session is removed only after the phone acknowledges our DELBA, or
// after three failed tries or a 3 s deadline. Keyed by firmware generation, peer epoch and TID.
static uint32_t awdlCoexDelbaTries, awdlCoexDelbaForced, awdlCoexDelbaConfirmed, awdlCoexDelbaFailedTx;
static int awdlCoexDelbaWaitTid = -1, awdlCoexDelbaWaitGen = -1;
static uint32_t awdlCoexDelbaWaitEpoch;
static uint16_t awdlCoexDelbaAttemptId;
static uint8_t awdlCoexDelbaResult; // 0 none or pending, 1 acknowledged, 2 failed.
static uint64_t awdlCoexDelbaDeadlineUS, awdlCoexDelbaNextTryUS;
// Last QoS data from the BA peer per TID: a receive session is idle only when its own TID is.
static uint64_t awdlCoexBaRxTidLastUS[8];
// The send agreement's window from the phone's answer (0 until agreed), and answers not usable.
static uint16_t awdlCoexBaTxWindow;
static uint32_t awdlCoexBaTxSmallWindows, awdlCoexBaTxPolicyRefusals, awdlCoexBaNonAwdlBssidAccepted,
    awdlCoexBaNonAwdlBssidApplied, awdlCoexDelbaRxTidRemoved;
// A phone that answers with a window under 64 gets at most that many frames outstanding on the aggregation
// queue. Host-side only: whether this firmware learns the answer's window is unverified.
static uint32_t awdlCoexBaTxQueuedCap()
{
    return awdlCoexBaTxWindow && awdlCoexBaTxWindow < 64 ? awdlCoexBaTxWindow : kAwdlCoexBaTxQueuedMax;
}
// iface160: one path, in order, for everything to the Block Ack peer while its aggregate queue is paused,
// full or still holds frames. On iface157 to iface159 frames under 1,200 bytes skipped the hold and went out
// on the listener's single-frame queue, which is never paused, so they overtook the held packets of the
// same QUIC connection. QUIC declares a packet lost once three later ones are acknowledged ahead of it, and
// cuts its congestion window. Dedicated mode (iface99 on) held everything. -itlawdlcoexnoorder restores the
// size rule for an A/B.
static bool awdlCoexOrder = true;
static uint32_t awdlCoexOrderViaAgg, awdlCoexOrderHeld, awdlCoexOrderSingleBehindAgg, awdlCoexOrderStalled;
// When the aggregate queue last reported a Block Ack. A full queue holds short frames only while it is
// still draining; a queue that has reported nothing for a second falls back to the old size rule, so a
// stuck queue can't keep short frames from the peer.
static uint64_t awdlCoexBaTxLastNotifUS;
// Single-frame transmit responses on the aggregate queue, by result. On an aggregation queue such a
// response is a frame sent on its own or one the firmware gave up on; before iface160 the status was unread.
static uint32_t awdlCoexBaTxRespOK, awdlCoexBaTxRespFailed, awdlCoexBaTxRespLastFailStatus;
// -itlawdlcoexawsync0: idle sync frames are timed to the peer's AWs from its first valid sequence, taking
// offset 0, instead of waiting for 300 data frames to calibrate it.
static bool awdlCoexAwSyncAssume;
// -itlawdlcoexlowlat: LOW_LATENCY_CMD (MAC config group, 3) for the listener's MAC context, the way iwlmvm
// asks dynamic-quota firmware to favour a context. iwlmvm sends it on the DYNAMIC_QUOTA capability alone and
// never consults the command-version table, which doesn't list it on this firmware; iface149 to iface159
// required the table entry, so the command was never sent.
static bool awdlCoexLowLatency;
static uint32_t awdlCoexLowLatencyResult;
constexpr uint8_t kIwxLowLatencyCmd = 0x3;
struct iwx_mac_low_latency_cmd {
    uint32_t mac_id;
    uint8_t low_latency_rx;
    uint8_t low_latency_tx;
    uint16_t reserved;
} __packed;
static uint64_t awdlCoexHoldSinceUS, awdlCoexHoldLimitUS;
static uint32_t awdlCoexHolds, awdlCoexHoldTicks, awdlCoexHoldForced;
// iface161 send gate (on unless -itlawdlcoexnogate). Outside an aggregated bulk send, frames for the phone
// leave the host only while its schedule has it on our channel, and while it is idle only in the first
// kAwdlGateAwWindowUS of an AW. The iface160 boot showed why: the station pause covered bulk only, so
// QUIC probes went out at any moment; probe timeouts backed off to 11 s silences, rate control sat at 20 MHz, and
// the aggregate queue's single frames failed 1,379 of 7,137 times at the retry limit. With the gate, the
// station pause also covers frames already in the aggregate queue, not only a bulk send.
static bool awdlCoexGate = true;
static uint64_t awdlCoexGateSinceUS, awdlCoexGateLimitUS;
static uint8_t awdlCoexGateKind;
static uint32_t awdlCoexGateHolds, awdlCoexGateAwayTicks, awdlCoexGateDozeTicks, awdlCoexGateForced;
static uint32_t awdlCoexGateQueuedPauses;
// Last data frame from the schedule peer: a peer that sent data in the last 100 ms is awake.
static uint64_t awdlCoexSchedPeerRxUS;
constexpr uint64_t kAwdlGateAwWindowUS = 4000, kAwdlGateAwakeUS = 100000;
// iface161 (on unless -itlawdlcoexcalwait): the coex schedule assumes offset 0 until refuted
// (PeerSchedule::assumeZero), so pauses and the gate work from the first sync frame after each anchor.
static bool awdlCoexAssumeZero = true;
static ItlAWDL::BaTrace awdlCoexBaTrace;
static uint32_t awdlCoexBaTracePublished;
// Sample from the coex timer so silence between Block Acks is represented too.
// The most recent completion snapshot is valid only for the same queue owner.
struct CoexBaRefillSample {
    uint64_t uptimeUS;
    uint32_t generation, listener, peer;
    int queue;
    uint16_t host, reclaimed, refilled;
};
static CoexBaRefillSample awdlCoexBaLastRefillSample;
struct CoexBaTimelineEntry {
    uint64_t uptimeUS, lastBaUS;
    uint32_t generation, listener, peer, notifications, acked, refillFrames, emptyReady, emptyNoReady;
    uint16_t hostQueued, aggregateQueued, hostAtReclaim, aggregateAfterReclaim, aggregateAfterRefill;
    uint8_t flags, channel;
    uint32_t refillKicks;
};
static_assert(sizeof(CoexBaTimelineEntry) == 64, "coex timeline entry layout");
struct CoexBaTimeline {
    static constexpr unsigned capacity = 4096;
    uint32_t version = 1, count = 0;
    CoexBaTimelineEntry entries[capacity];
};
static CoexBaTimeline awdlCoexBaTimeline;
static uint64_t awdlCoexBaTimelineLastUS, awdlCoexBaTimelinePublishedUS;
// The peer whose schedule is tracked, and how sync frames were paced.
static ItlAWDL::PeerSchedule awdlCoexPeerSchedule;
static ItlAWDL::PeerPauseState awdlCoexPeerPause;
static ItlAWDL::PeerBulkState awdlCoexPeerBulk;
static uint32_t awdlCoexBaTxVht80TwoStreamNotifs, awdlCoexBaTxPeakReportedFrames, awdlCoexRxVht80TwoStream;
static uint32_t awdlCoexBaTxLastRate;
static uint8_t awdlCoexSchedPeer[6];
static uint32_t awdlCoexSchedToken;

static bool awdlCoexScheduleCurrent()
{
    return awdlCoexAdded && awdlCoexSchedToken == awdlCoexToken &&
        awdlCoexPeerSchedule.ourChannel == awdlCoexChannel &&
        (!awdlCoexBaPeerAdded || ItlAWDL::sameAddress(awdlCoexSchedPeer, awdlCoexBaPeer));
}
static uint32_t awdlCoexPeerSyncFrames, awdlCoexAwSyncFrames, awdlCoexIdleSyncFrames;
static uint32_t awdlCoexPeerSequenceRejected;
static bool awdlCoexScheduleCalibrated;
// Per ring slot: 1 for a group data frame, 2 for unicast, so completions say whether the peer acknowledged us.
static uint8_t awdlCoexSlotKind[IWX_MIN_256_BA_QUEUE_SIZE_GEN3];
static uint32_t awdlCoexSlotBaPeerEpoch[nitems(awdlCoexSlotKind)];
static uint8_t awdlCoexSlotToken[nitems(awdlCoexSlotKind)]; // Dialog token (ADDBA) or TID (DELBA) per slot.
static uint16_t awdlCoexSlotEnqueueId[nitems(awdlCoexSlotKind)];
static uint32_t awdlCoexUcastOK, awdlCoexUcastFailed, awdlCoexGroupOK, awdlCoexGroupFailed;
static uint32_t awdlCoexDataRxUcast, awdlCoexDataRxGroup, awdlCoexPromiscDropped;
static bool awdlCoexPromiscLive;      // Applied: the firmware accepted a MAC command that set it.
static bool awdlCoexPromiscUncertain; // A MAC command failed: the firmware may hold either filter.
static uint32_t awdlCoexPromiscAmbiguous, awdlCoexMacMaskSeen[4];
static ItlAWDL::SameChannelProbe awdlCoexSameChannelProbe;
static bool awdlCoexSameChannelProbeWanted(struct iwx_softc *sc, uint64_t now)
{
    if (awdlCoexFilter != 3 || !awdlCoexBaTxEnabled) return false;
    auto *node = reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss);
    const auto *station = node && node->in_phyctxt ? node->in_phyctxt->channel : nullptr;
    const unsigned ownNumber = awdlCoexOwnChan ? ieee80211_chan2ieee(&sc->sc_ic, awdlCoexOwnChan) : 0;
    const unsigned stationNumber = station ? ieee80211_chan2ieee(&sc->sc_ic, station) : 0;
    return awdlCoexSameChannelProbe.wants(ownNumber, stationNumber,
        awdlCoexBaPeerAdded && awdlCoexBaTids, awdlCoexBaTxState == kCoexBaTxAsking,
        awdlCoexBaFilterOff, awdlCoexBaProbeUntilUS, now);
}

// The RX descriptor's MAC context mask, valid only for the frame being handed to iwx_rx_frame directly
// (not frames released later from a reorder buffer).
static bool awdlRxMacMaskValid;
static uint8_t awdlRxMacMask;
static void awdlCoexPeerHeard(const uint8_t *addr, uint64_t nowUS)
{
    AwdlCoexPeer *slot = &awdlCoexPeers[0];
    for (auto &p : awdlCoexPeers) {
        if (!memcmp(p.addr, addr, 6)) { slot = &p; break; }
        if (p.heardUS < slot->heardUS) slot = &p;
    }
    memcpy(slot->addr, addr, 6);
    slot->heardUS = nowUS;
    slot->channel = awdlCoexChannel;
    slot->token = awdlCoexToken;
}
static void awdlCoexNoteRejectReason(const uint8_t *addr, uint64_t nowUS)
{
    unsigned reason = 0;
    for (const auto &p : awdlCoexPeers) {
        if (!p.heardUS || memcmp(p.addr, addr, 6))
            continue;
        reason = nowUS - p.heardUS >= 60000000ULL ? 1 : p.channel != awdlCoexChannel ? 2 : 3;
        break;
    }
    ++awdlCoexRejectReasons[reason];
}
static bool awdlCoexPeerKnown(const uint8_t *addr, uint64_t nowUS, bool refresh = false)
{
    for (auto &p : awdlCoexPeers) {
        // Previously discovered on this channel by this listener. Valid directed
        // traffic from the established BA peer can renew an existing entry.
        if (p.heardUS && !memcmp(p.addr, addr, 6) && nowUS - p.heardUS < 60000000ULL &&
            p.channel == awdlCoexChannel && p.token == awdlCoexToken) {
            if (refresh)
                p.heardUS = nowUS;
            return true;
        }
    }
    return false;
}
static void awdlCoexPublish()
{
    auto *root = IORegistryEntry::getRegistryRoot();
    root->setProperty("ITLAWDLCoexAdded", awdlCoexAdded);
    root->setProperty("ITLAWDLCoexSameChannelProbeEnabled", awdlCoexSameChannelProbe.enabled);
    root->setProperty("ITLAWDLCoexSameChannelProbeLive", awdlCoexSameChannelProbe.applied);
    root->setProperty("ITLAWDLCoexSameChannelProbeOpens", awdlCoexSameChannelProbe.opens, 32);
    root->setProperty("ITLAWDLCoexSameChannelProbeCloses", awdlCoexSameChannelProbe.closes, 32);
    root->setProperty("ITLAWDLCoexSameChannelProbeRestoreFailures", awdlCoexSameChannelProbe.restoreFailures, 32);
    root->setProperty("ITLAWDLCoexSameChannelProbeLastUS", awdlCoexSameChannelProbe.lastUS, 64);
    root->setProperty("ITLAWDLCoexSameChannelProbeMaxUS", awdlCoexSameChannelProbe.maxUS, 64);

    root->setProperty("ITLAWDLCoexAdds", awdlCoexAdds, 32);
    root->setProperty("ITLAWDLCoexRemoves", awdlCoexRemoves, 32);
    root->setProperty("ITLAWDLCoexAddsAfterRemove", awdlCoexAddsAfterRemove, 32);
    root->setProperty("ITLAWDLCoexAddsAfterRestart", awdlCoexAddsAfterRestart, 32);
    root->setProperty("ITLAWDLCoexFirmwareGeneration", uint32_t(awdlCoexGeneration), 32);
    root->setProperty("ITLAWDLCoexCountryUnusableAnswers", awdlCoexCountryUnusableAnswers, 32);
    root->setProperty("ITLAWDLCoexHintClears", awdlCoexHintClears, 32);
    root->setProperty("ITLAWDLCoexHintsKept", awdlCoexHintsKept, 32);
    root->setProperty("ITLAWDLCoexIrConcurrentUsed", awdlCoexIrConcurrentUsed, 32);
    root->setProperty("ITLAWDLCoexBaSharedOff", awdlCoexNoSharedBa);
    root->setProperty("ITLAWDLCoexBaPeerWidth", awdlCoexBaPeerWidth, 32);
    if (auto *seq = OSData::withBytes(awdlCoexPeerSeq, sizeof(awdlCoexPeerSeq))) {
        root->setProperty("ITLAWDLCoexPeerSequence", seq);
        seq->release();
    }
    root->setProperty("ITLAWDLCoexPeerSequenceFrames", awdlCoexPeerSeqFrames, 32);
    root->setProperty("ITLAWDLCoexPeerSequenceUpdates", awdlCoexPeerSeqChanges, 32);
    root->setProperty("ITLAWDLCoexMacResult", awdlCoexMacResult, 32);
    root->setProperty("ITLAWDLCoexBindResult", awdlCoexBindResult, 32);
    root->setProperty("ITLAWDLCoexBindStatus", awdlCoexBindStatus, 32);
    root->setProperty("ITLAWDLCoexChannel", awdlCoexChannel, 32);
    root->setProperty("ITLAWDLCoexAwdlAction", awdlCoexAwdlAction, 32);
    root->setProperty("ITLAWDLCoexAwdlData", awdlCoexAwdlData, 32);
    root->setProperty("ITLAWDLCoexOther", awdlCoexOther, 32);
    root->setProperty("ITLAWDLCoexFilter", awdlCoexFilter, 32);
    if (awdlCoexTx) {
        root->setProperty("ITLAWDLCoexStaResult", awdlCoexStaResult, 32);
        root->setProperty("ITLAWDLCoexQueueResult", awdlCoexQueueResult, 32);
        root->setProperty("ITLAWDLCoexQueueStage", awdlCoexQueueStage);
        root->setProperty("ITLAWDLCoexQueueAssigned", uint32_t(awdlCoexQueueAssigned), 32);
        root->setProperty("ITLAWDLCoexQueueWritePointer", awdlCoexQueueWritePointer, 32);
        root->setProperty("ITLAWDLCoexSetupAttempts", awdlCoexSetupAttempts, 32);
        root->setProperty("ITLAWDLCoexTxHalted", awdlCoexTxHalted);
        root->setProperty("ITLAWDLCoexSetupAborts", awdlCoexSetupAborts, 32);
        root->setProperty("ITLAWDLCoexBadCompletions", awdlCoexBadCompletions, 32);
        root->setProperty("ITLAWDLCoexLastSlot", uint32_t(awdlCoexLastSlot), 32);
        root->setProperty("ITLAWDLCoexLastBoundary", uint32_t(awdlCoexLastBoundary), 32);
        root->setProperty("ITLAWDLCoexLastSsn", awdlCoexLastSsn, 32);
        if (awdlCoexFaultSnapshot[0])
            root->setProperty("ITLAWDLCoexFault", awdlCoexFaultSnapshot);
        root->setProperty("ITLAWDLCoexOrphanQueue", uint32_t(awdlCoexOrphanQueue), 32);
        root->setProperty("ITLAWDLCoexTxBuilt", awdlCoexTxBuilt, 32);
        root->setProperty("ITLAWDLCoexTxNotReady", awdlCoexTxNotReady, 32);
        root->setProperty("ITLAWDLCoexTxBuildRejected", awdlCoexTxBuildRejected, 32);
        root->setProperty("ITLAWDLCoexRefusedReason", awdlCoexRefusedReason, 32);
        root->setProperty("ITLAWDLCoexRefusedChannelFlags", awdlCoexRefusedChannelFlags, 32);
        if (awdlCoexRefusalSnapshot[0])
            root->setProperty("ITLAWDLCoexLastRefusal", awdlCoexRefusalSnapshot);
        root->setProperty("ITLAWDLCoexActionOnChannel", awdlCoexActionOnChannel, 32);
        root->setProperty("ITLAWDLCoexActionOffChannel", awdlCoexActionOffChannel, 32);
        root->setProperty("ITLAWDLCoexLastBuildResult", awdlCoexLastBuildResult, 32);
        root->setProperty("ITLAWDLCoexTxSubmitted", awdlCoexTxSubmitted, 32);
        root->setProperty("ITLAWDLCoexTxSubmitErrors", awdlCoexTxSubmitErrors, 32);
        root->setProperty("ITLAWDLCoexTxOK", awdlCoexTxOK, 32);
        root->setProperty("ITLAWDLCoexTxFailed", awdlCoexTxFailed, 32);
        root->setProperty("ITLAWDLCoexTxStuck", awdlCoexTxStuck, 32);
        root->setProperty("ITLAWDLCoexTxRefusedChannel", awdlCoexTxRefusedChannel, 32);
        root->setProperty("ITLAWDLCoexAddrChanges", awdlCoexAddrChanges, 32);
        root->setProperty("ITLAWDLCoexAddrFailures", awdlCoexAddrFailures, 32);
        root->setProperty("ITLAWDLCoexAddrApplied", awdlCoexAddrApplied);
        root->setProperty("ITLAWDLCoexLateCompletions", awdlCoexLateCompletions, 32);
        root->setProperty("ITLAWDLCoexTeardownErrors", awdlCoexTeardownErrors, 32);
        if (awdlCoexData) {
            root->setProperty("ITLAWDLCoexDataRx", awdlCoexDataRx, 32);
            root->setProperty("ITLAWDLCoexDataRxHandedOff", awdlCoexDataRxDelivered, 32);
            root->setProperty("ITLAWDLCoexDataRxMalformed", awdlCoexDataRxMalformed, 32);
            root->setProperty("ITLAWDLCoexDataRxUnknownPeer", awdlCoexDataRxUnknownPeer, 32);
            root->setProperty("ITLAWDLCoexDataRxOffChannel", awdlCoexDataRxOffChannel, 32);
            root->setProperty("ITLAWDLCoexDataRxRetry", awdlCoexDataRxRetry, 32);
            root->setProperty("ITLAWDLCoexRxWide80", awdlCoexRxWide80, 32);
            if (auto *mods = OSData::withBytes(awdlCoexRxModulation, sizeof(awdlCoexRxModulation))) {
                root->setProperty("ITLAWDLCoexRxModulation", mods);
                mods->release();
            }
            root->setProperty("ITLAWDLCoexBaRequests", awdlCoexBaRequests, 32);
            root->setProperty("ITLAWDLCoexBaSessions", awdlCoexBaSessions, 32);
            root->setProperty("ITLAWDLCoexBaAnswers", awdlCoexBaAnswers, 32);
            root->setProperty("ITLAWDLCoexBaAnswerErrors", awdlCoexBaAnswerErrors, 32);
            root->setProperty("ITLAWDLCoexBaOtherPeer", awdlCoexBaOtherPeer, 32);
            root->setProperty("ITLAWDLCoexBaDelbas", awdlCoexBaDelbas, 32);
            root->setProperty("ITLAWDLCoexBaStatus", awdlCoexBaStatus, 32);
            root->setProperty("ITLAWDLCoexBaPeerAdded", awdlCoexBaPeerAdded);
            root->setProperty("ITLAWDLCoexBaFilterOff", awdlCoexBaFilterOff);
            root->setProperty("ITLAWDLCoexBaFilterChanges", awdlCoexBaFilterChanges, 32);
            root->setProperty("ITLAWDLCoexBaBroken", awdlCoexBaFailedGen >= 0 && awdlCoexBaFailedGen == awdlCoexGeneration);
            root->setProperty("ITLAWDLCoexRateStep", uint32_t(awdlCoexRateStep), 32);
            root->setProperty("ITLAWDLCoexRateUps", awdlCoexRateUps, 32);
            root->setProperty("ITLAWDLCoexRateDowns", awdlCoexRateDowns, 32);
            root->setProperty("ITLAWDLCoexMgmtOK", awdlCoexMgmtOK, 32);
            root->setProperty("ITLAWDLCoexMgmtFailed", awdlCoexMgmtFailed, 32);
            root->setProperty("ITLAWDLCoexBaTxState", uint32_t(awdlCoexBaTxState), 32);
            {
                // The number alone was misread in a report (1 is still asking, not agreed).
                static const char *const kBaTxStateNames[] = {"off", "asking", "agreed", "failed", "enabling"};
                root->setProperty("ITLAWDLCoexBaTxStateName",
                                  awdlCoexBaTxState >= 0 && awdlCoexBaTxState < int(nitems(kBaTxStateNames))
                                      ? kBaTxStateNames[awdlCoexBaTxState] : "unknown");
            }
            root->setProperty("ITLAWDLCoexBaTxQueueResult", awdlCoexBaTxQueueResult, 32);
            root->setProperty("ITLAWDLCoexBaTxPeerAdds", awdlCoexBaTxPeerAdds, 32);
            root->setProperty("ITLAWDLCoexBaTxAsks", awdlCoexBaTxAsks, 32);
            root->setProperty("ITLAWDLCoexBaAskOK", awdlCoexBaAskOK, 32);
            root->setProperty("ITLAWDLCoexBaAskFailed", awdlCoexBaAskFailed, 32);
            root->setProperty("ITLAWDLCoexBaAsksSkippedAway", awdlCoexBaAsksSkippedAway, 32);
            root->setProperty("ITLAWDLCoexBaPeerAccepted", awdlCoexBaPeerAccepted);
            root->setProperty("ITLAWDLCoexBaTxAskRounds", awdlCoexBaTxAskRounds, 32);
            root->setProperty("ITLAWDLCoexBaTxIdleHolds", awdlCoexBaTxIdleHolds, 32);
            root->setProperty("ITLAWDLCoexBaTxAgreements", awdlCoexBaTxAgreements, 32);
            root->setProperty("ITLAWDLCoexBaTxRefusals", awdlCoexBaTxRefusals, 32);
            root->setProperty("ITLAWDLCoexBaTxDelbas", awdlCoexBaTxDelbas, 32);
            root->setProperty("ITLAWDLCoexBaTxFrames", awdlCoexBaTxFrames, 32);
            root->setProperty("ITLAWDLCoexBaTxSubmitErrors", awdlCoexBaTxSubmitErrors, 32);
            root->setProperty("ITLAWDLCoexBaTxNotifs", awdlCoexBaTxNotifs, 32);
            root->setProperty("ITLAWDLCoexBaTxSentAir", awdlCoexBaTxSentAir, 32);
            root->setProperty("ITLAWDLCoexBaTxAcked", awdlCoexBaTxAcked, 32);
            root->setProperty("ITLAWDLCoexBaTxBulk", awdlCoexBaTxBulk.bulk);
            root->setProperty("ITLAWDLCoexAdvertise80Frames", awdlCoexAdvertise80Frames, 32);
            if (auto *seen = OSData::withBytes(awdlCoexBaActionSeen, sizeof(awdlCoexBaActionSeen))) {
                root->setProperty("ITLAWDLCoexBaActionSeen", seen);
                seen->release();
            }
            root->setProperty("ITLAWDLCoexBaActionAwdlBssid", awdlCoexBaActionAwdlBssid, 32);
            root->setProperty("ITLAWDLCoexBaActionOtherBssid", awdlCoexBaActionOtherBssid, 32);
            root->setProperty("ITLAWDLCoexRxWhileFilterOff", awdlCoexRxWhileFilterOff, 32);
            root->setProperty("ITLAWDLCoexTxPauses", awdlCoexTxPauses, 32);
            root->setProperty("ITLAWDLCoexWedgedRebuilds", awdlCoexWedgedRebuilds, 32);
            root->setProperty("ITLAWDLCoexBaTxEnabled", awdlCoexBaTxEnabled);
            root->setProperty("ITLAWDLCoexPeerPauseEnabled", awdlCoexBaPeerPauseEnabled);
            root->setProperty("ITLAWDLCoexPeerPaused", awdlCoexPeerPause.paused);
            root->setProperty("ITLAWDLCoexPeerPauses", awdlCoexPeerPause.pauses, 32);
            root->setProperty("ITLAWDLCoexPeerForcedResumes", awdlCoexPeerPause.forcedResumes, 32);
            root->setProperty("ITLAWDLCoexPeerPauseErrors", awdlCoexPeerPause.commandErrors, 32);
            root->setProperty("ITLAWDLCoexBaTxLastRate", awdlCoexBaTxLastRate, 32);
            root->setProperty("ITLAWDLCoexBaTxVht80TwoStreamNotifs", awdlCoexBaTxVht80TwoStreamNotifs, 32);
            root->setProperty("ITLAWDLCoexBaTxPeakReportedFrames", awdlCoexBaTxPeakReportedFrames, 32);
            root->setProperty("ITLAWDLCoexRxVht80TwoStream", awdlCoexRxVht80TwoStream, 32);
            root->setProperty("ITLAWDLCoexBaTxResponses", awdlCoexBaTxResponses, 32);
            root->setProperty("ITLAWDLCoexBaTxResponseFrames", awdlCoexBaTxResponseFrames, 32);
            root->setProperty("ITLAWDLCoexBaTxAggResponses", awdlCoexBaTxAggResponses, 32);
            root->setProperty("ITLAWDLCoexBaTxPeakQueued", awdlCoexBaTxPeakQueued, 32);
            root->setProperty("ITLAWDLCoexBaTxPausedFullDeferrals", awdlCoexBaTxPausedFullDeferrals, 32);
            root->setProperty("ITLAWDLCoexBaRefillEnabled", awdlCoexBaRefillEnabled);
            root->setProperty("ITLAWDLCoexBaRefillKicks", awdlCoexBaRefillKicks, 32);
            root->setProperty("ITLAWDLCoexBaEmptyWithReady", awdlCoexBaEmptyWithReady, 32);
            root->setProperty("ITLAWDLCoexBaEmptyNoReady", awdlCoexBaEmptyNoReady, 32);
            root->setProperty("ITLAWDLCoexBaRefillStillEmptyReady", awdlCoexBaRefillStillEmptyReady, 32);
            root->setProperty("ITLAWDLCoexBaFilterHysteresis", awdlCoexBaFilterHysteresis);
            root->setProperty("ITLAWDLCoexAwHold", awdlCoexAwHold);
            root->setProperty("ITLAWDLCoexOrder", awdlCoexOrder);
            root->setProperty("ITLAWDLCoexOrderHeld", awdlCoexOrderHeld, 32);
            root->setProperty("ITLAWDLCoexOrderViaAgg", awdlCoexOrderViaAgg, 32);
            root->setProperty("ITLAWDLCoexOrderSingleBehindAgg", awdlCoexOrderSingleBehindAgg, 32);
            root->setProperty("ITLAWDLCoexOrderStalled", awdlCoexOrderStalled, 32);
            root->setProperty("ITLAWDLCoexBaTxRespOK", awdlCoexBaTxRespOK, 32);
            root->setProperty("ITLAWDLCoexBaTxRespFailed", awdlCoexBaTxRespFailed, 32);
            root->setProperty("ITLAWDLCoexBaTxRespLastFailStatus", awdlCoexBaTxRespLastFailStatus, 32);
            root->setProperty("ITLAWDLCoexAwSyncAssume", awdlCoexAwSyncAssume);
            root->setProperty("ITLAWDLCoexBaEarlyAggFrames", awdlCoexBaEarlyAggFrames, 32);
            root->setProperty("ITLAWDLCoexPauseResumeFailures", awdlCoexPauseResumeFailures, 32);
            root->setProperty("ITLAWDLCoexResumeRetirements", awdlCoexResumeRetirements, 32);
            root->setProperty("ITLAWDLCoexBaRxIdleTeardowns", awdlCoexBaRxIdleTeardowns, 32);
            root->setProperty("ITLAWDLCoexBaDelbasSent", awdlCoexBaDelbasSent, 32);
            {
                // One row per event: "index ms type a b c d id". The first 64 of the boot and the newest 128; the
                // reader removes the overlap by index and shows any gap. A row is at most 52 bytes.
                static char text[128 * 56], first[64 * 56];
                const uint32_t total = awdlCoexBaEventCount;
                auto dump = [](char *out, size_t cap, uint32_t from, uint32_t to, const AwdlCoexBaEvent *ring,
                               uint32_t ringSize) {
                    size_t used = 0;
                    for (uint32_t i = from; i < to && used + 56 <= cap; ++i) {
                        const auto &e = ring[i % ringSize];
                        used += snprintf(out + used, cap - used, "%u %u %c %u %u %u %u %u\n", i, e.ms, e.type, e.a,
                                         e.b, e.c, e.d, e.id);
                    }
                    out[used < cap ? used : cap - 1] = 0;
                };
                dump(text, sizeof(text), total > 128 ? total - 128 : 0, total, awdlCoexBaEvents,
                     nitems(awdlCoexBaEvents));
                dump(first, sizeof(first), 0, total < 64 ? total : 64, awdlCoexBaEventsFirst, 64);
                root->setProperty("ITLAWDLCoexBaEvents", text);
                root->setProperty("ITLAWDLCoexBaEventsFirst", first);
                root->setProperty("ITLAWDLCoexBaEventFormat", 154, 32);
                root->setProperty("ITLAWDLCoexDelbaForced", awdlCoexDelbaForced, 32);
                root->setProperty("ITLAWDLCoexDelbaConfirmed", awdlCoexDelbaConfirmed, 32);
                root->setProperty("ITLAWDLCoexDelbaFailedTx", awdlCoexDelbaFailedTx, 32);
                root->setProperty("ITLAWDLCoexStatusIdxHits", awdlCoexStatusIdxHits, 32);
                root->setProperty("ITLAWDLCoexStatusIdxMisses", awdlCoexStatusIdxMisses, 32);
                root->setProperty("ITLAWDLCoexMultiReclaims", awdlCoexMultiReclaims, 32);
                root->setProperty("ITLAWDLCoexReclaimUnknown", awdlCoexReclaimUnknown, 32);
                root->setProperty("ITLAWDLCoexSyncReclaimedUnknown", awdlCoexSyncReclaimedUnknown, 32);
                root->setProperty("ITLAWDLCoexBaTxWindow", awdlCoexBaTxWindow, 32);
                root->setProperty("ITLAWDLCoexBaTxSmallWindows", awdlCoexBaTxSmallWindows, 32);
                root->setProperty("ITLAWDLCoexBaTxPolicyRefusals", awdlCoexBaTxPolicyRefusals, 32);
                root->setProperty("ITLAWDLCoexBaNonAwdlBssidAccepted", awdlCoexBaNonAwdlBssidAccepted, 32);
                root->setProperty("ITLAWDLCoexBaNonAwdlBssidApplied", awdlCoexBaNonAwdlBssidApplied, 32);
                root->setProperty("ITLAWDLCoexDelbaRxTidRemoved", awdlCoexDelbaRxTidRemoved, 32);
                root->setProperty("ITLAWDLCoexBaEventCount", awdlCoexBaEventCount, 32);
            }
            root->setProperty("ITLAWDLCoexLowLatency", awdlCoexLowLatency);
            root->setProperty("ITLAWDLCoexLowLatencyResult", awdlCoexLowLatencyResult, 32);
            root->setProperty("ITLAWDLCoexHolds", awdlCoexHolds, 32);
            root->setProperty("ITLAWDLCoexHoldTicks", awdlCoexHoldTicks, 32);
            root->setProperty("ITLAWDLCoexHoldForced", awdlCoexHoldForced, 32);
            root->setProperty("ITLAWDLCoexGate", awdlCoexGate);
            root->setProperty("ITLAWDLCoexGateHolds", awdlCoexGateHolds, 32);
            root->setProperty("ITLAWDLCoexGateAwayTicks", awdlCoexGateAwayTicks, 32);
            root->setProperty("ITLAWDLCoexGateDozeTicks", awdlCoexGateDozeTicks, 32);
            root->setProperty("ITLAWDLCoexGateForced", awdlCoexGateForced, 32);
            root->setProperty("ITLAWDLCoexGateQueuedPauses", awdlCoexGateQueuedPauses, 32);
            root->setProperty("ITLAWDLCoexAssumeZero", awdlCoexAssumeZero);
            root->setProperty("ITLAWDLCoexScheduleKnown", awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.known() &&
                              awdlCoexPeerSchedule.fresh(awdlUptimeUS()));
            root->setProperty("ITLAWDLCoexScheduleRefutations", awdlCoexPeerSchedule.refutations, 32);
            root->setProperty("ITLAWDLCoexPeerPresentEntries", awdlCoexPeerSchedule.presentEntries(), 32);
            root->setProperty("ITLAWDLCoexBaRefillFrames", awdlCoexBaRefillFrames, 32);
            if (awdlCoexBaTraceEnabled && awdlCoexBaTrace.count != awdlCoexBaTracePublished &&
                (awdlCoexBaTrace.full() || awdlCoexBaTrace.count >= awdlCoexBaTracePublished + 256)) {
                if (auto *trace = OSData::withBytes(&awdlCoexBaTrace, sizeof(awdlCoexBaTrace))) {
                    root->setProperty("ITLAWDLBaTrace", trace);
                    awdlCoexBaTracePublished = awdlCoexBaTrace.count;
                    trace->release();
                }
            }
            root->setProperty("ITLAWDLCoexBaTxSinglesWithBacklog", awdlCoexBaTxSinglesWithBacklog, 32);
            root->setProperty("ITLAWDLCoexVhtFrames", awdlCoexVhtFrames, 32);
            root->setProperty("ITLAWDLCoexBaTxAggEnableStatus", awdlCoexBaTxAggEnableStatus, 32);
            root->setProperty("ITLAWDLCoexPeerSyncFrames", awdlCoexPeerSyncFrames, 32);
            root->setProperty("ITLAWDLCoexAwSyncFrames", awdlCoexAwSyncFrames, 32);
            root->setProperty("ITLAWDLCoexIdleSyncFrames", awdlCoexIdleSyncFrames, 32);
            root->setProperty("ITLAWDLCoexScheduleCalibrated", awdlCoexScheduleCalibrated);
            root->setProperty("ITLAWDLCoexPeerSequenceRejected", awdlCoexPeerSequenceRejected, 32);
            root->setProperty("ITLAWDLCoexPeerSequenceChanges", awdlCoexPeerSchedule.sequenceChanges, 32);
            root->setProperty("ITLAWDLCoexPeerDecalibrations", awdlCoexPeerSchedule.decalibrations, 32);
            root->setProperty("ITLAWDLCoexSvcMergedFrames", awdlServiceMergedFrames, 32);
            root->setProperty("ITLAWDLCoexSvcMergedRecords", awdlServiceMergedRecords, 32);
            root->setProperty("ITLAWDLCoexSvcMergeRefused", awdlServiceMergeRefused, 32);
            root->setProperty("ITLAWDLCoexIntCoalescing", uint32_t(awdlIntCoalescing), 32);
            if (auto *reasons = OSData::withBytes(awdlCoexRejectReasons, sizeof(awdlCoexRejectReasons))) {
                root->setProperty("ITLAWDLCoexRejectReasons", reasons);
                reasons->release();
            }
            root->setProperty("ITLAWDLCoexDataRxUcast", awdlCoexDataRxUcast, 32);
            root->setProperty("ITLAWDLCoexDataRxGroup", awdlCoexDataRxGroup, 32);
            root->setProperty("ITLAWDLCoexUcastOK", awdlCoexUcastOK, 32);
            root->setProperty("ITLAWDLCoexUcastFailed", awdlCoexUcastFailed, 32);
            root->setProperty("ITLAWDLCoexGroupOK", awdlCoexGroupOK, 32);
            root->setProperty("ITLAWDLCoexGroupFailed", awdlCoexGroupFailed, 32);
            root->setProperty("ITLAWDLCoexPromiscLive", awdlCoexPromiscLive);
            root->setProperty("ITLAWDLCoexPromiscDropped", awdlCoexPromiscDropped, 32);
            root->setProperty("ITLAWDLCoexPromiscUncertain", awdlCoexPromiscUncertain);
            root->setProperty("ITLAWDLCoexPromiscAmbiguous", awdlCoexPromiscAmbiguous, 32);
            if (auto *masks = OSData::withBytes(awdlCoexMacMaskSeen, sizeof(awdlCoexMacMaskSeen))) {
                root->setProperty("ITLAWDLCoexMacMaskSeen", masks);
                masks->release();
            }
            root->setProperty("ITLAWDLCoexDataTx", awdlCoexDataTx, 32);
            root->setProperty("ITLAWDLCoexDataTxErrors", awdlCoexDataTxErrors, 32);
            root->setProperty("ITLAWDLCoexDataOK", awdlCoexDataOK, 32);
            root->setProperty("ITLAWDLCoexDataFailed", awdlCoexDataFailed, 32);
            root->setProperty("ITLAWDLCoexDataPumps", awdlCoexDataPumps, 32);
        }
        root->setProperty("ITLAWDLCoexBroken", awdlCoexBrokenGeneration >= 0 && awdlCoexBrokenGeneration == awdlCoexGeneration);
    }
    if (awdlCoexRx) {
        root->setProperty("ITLAWDLCoexForwarded", awdlCoexForwarded, 32);
        root->setProperty("ITLAWDLCoexZeroPadTrimmed", awdlCoexZeroPadTrimmed, 32);
        root->setProperty("ITLAWDLCoexMultiState", awdlCoexMultiState);
        root->setProperty("ITLAWDLCoexPhyResult", awdlCoexPhyResult, 32);
        root->setProperty("ITLAWDLCoexMultiBindResult", awdlCoexMultiBindResult, 32);
        root->setProperty("ITLAWDLCoexOwnWidth", uint32_t(awdlCoexOwnWidth), 32);
        root->setProperty("ITLAWDLCoexMoves", awdlCoexMoves, 32);
        root->setProperty("ITLAWDLCoexMoveFailures", awdlCoexMoveFailures, 32);
        root->setProperty("ITLAWDLCoexMovesSettleDropped", awdlCoexMovesSettleDropped, 32);
        root->setProperty("ITLAWDLCoexCountryNotices", awdlCoexCountryNotices, 32);
        root->setProperty("ITLAWDLCoexCountryAnswers", awdlCoexCountryAnswers, 32);
        root->setProperty("ITLAWDLCoexCountryLastStatus", awdlCoexCountryLastStatus, 32);
        root->setProperty("ITLAWDLCoexCountryLearned", awdlCoexCountryLearned);
        root->setProperty("ITLAWDLCoexBeaconHints", awdlCoexBeaconHints, 32);
        root->setProperty("ITLAWDLCoexOverlap", awdlCoexOverlapState, 8);
        root->setProperty("ITLAWDLCoexPeer5GHz", awdlCoexPeer5G, 32);
        root->setProperty("ITLAWDLCoexStation44", awdlCoexStation44);
        root->setProperty("ITLAWDLCoexPeer5GHzFrames", awdlCoexPeer5GFrames, 32);
        root->setProperty("ITLAWDLCoexPeer5GHzChanges", awdlCoexPeer5GChanges, 32);
        root->setProperty("ITLAWDLCoexCountryFailures", awdlCoexCountryFailures, 32);
        root->setProperty("ITLAWDLCoexMoveDrainTimeouts", awdlCoexMoveDrainTimeouts, 32);
        root->setProperty("ITLAWDLCoexMovePending", awdlCoexMovePending);
        root->setProperty("ITLAWDLCoexForwardRefused", awdlCoexForwardRefused, 32);
        root->setProperty("ITLAWDLCoexForwardMalformed", awdlCoexForwardMalformed, 32);
    }
    root->setProperty("ITLAWDLCoexReclaimRefused", awdlReclaimRefused, 32);
}
// The firmware recognises acknowledgements only to the address in its MAC context. If setting our AWDL
// address there fails, or macOS changes the address, every unicast frame looks unacknowledged: on
// iface104's second boot the one attempt failed and 7 of 166 frames went through. So it is retried,
// and applied again when the address changes, at most once a second.
static uint64_t awdlMacLastTryUS;
static uint32_t awdlMacApplies, awdlMacApplyFailures, awdlMacAddressChanges;
static uint8_t awdlOwnAddress[6];
static bool awdlPeerEverHeard;
static uint64_t awdlPeerLastHeardUS;
static ItlAWDL::ObservedCounts awdlSeen;
// -itlmccprobe: record what the firmware says about its regulatory domain. Read-only.
static bool mccProbe;
static CTimeout *mccProbeTimer;
static bool mccProbeNoticePending;
// AWDL on channel 149: the firmware's own country notice, answered at startup.
static bool awdlCountryDiscovery, awdlCountryScanDone, awdlCountryNoticeSeen, awdlCountryAnswerPending;
static uint16_t awdlCountryNotice, awdlCountryLastAnswered;
static uint8_t awdlCountryNoticeSource;
static uint32_t awdlCountryScans, awdlCountryNotices, awdlCountryAnswers, awdlCountryLastStatus, awdlCountryAnswerSeconds;
static ItlAWDL::BeaconCountry awdlBeaconCountries[32];
static unsigned awdlBeaconCountryCount;
static uint32_t awdlBeaconCountryOverflow;
// -itlawdlpeercctest: read a peer's stated country, ask the firmware once, record the reply.
static bool awdlPeerCountryTest, awdlPeerCountryAsked;
static ItlAWDL::PeerCountryState awdlPeerCountry;
static uint32_t awdlPeerCountryFrames, awdlPeerCountryAskSeconds, awdlPeerCountryReads;
// How the phone divides its time, and how the Mac's sends spend theirs.
struct AWDLSlotChange { uint32_t uptimeMs; ItlAWDL::PeerSlots slots; uint16_t reserved; };
static AWDLSlotChange awdlSlotChanges[128];
static unsigned awdlSlotChangeCount;
static ItlAWDL::PeerSlots awdlLastSlots;
static bool awdlHaveSlots;
static uint32_t awdlSlots6Frames[17];
static uint32_t awdlFlightOK[10], awdlFlightFail[10];
static ItlAWDL::TxServiceStats awdlTxService;
static uint32_t awdlTxWindowFullExits, awdlTxStackEmptyExits;
static uint32_t awdlRxFromPeer;  // Every frame whose transmitter is the last peer heard.
static bool awdlRadioProbe;
static uint32_t awdlRadioRequests, awdlRadioRequestErrors, awdlRadioUnexpectedLengths;
static uint32_t awdlRadioReports, awdlRadioTemperature;
static uint32_t awdlRadioLastCommandLength, awdlRadioLastNotificationLength;
static uint64_t awdlRadioReportUS, awdlRadioRxTime, awdlRadioTxTime, awdlRadioOnTime;
static uint32_t awdlRadioBeacons[256], awdlRadioOtherData[256];

template <typename Statistics>
static void awdlNoteRadioStatistics(const Statistics &stats)
{
    ++awdlRadioReports;
    awdlRadioTemperature = le32toh(stats.radio_temperature);
    awdlRadioRxTime = le64toh(stats.rx_time);
    awdlRadioTxTime = le64toh(stats.tx_time);
    awdlRadioOnTime = le64toh(stats.on_time_rf);
}

static uint32_t awdlRxAllFrames; // Every frame received, never reset.
static ItlAWDL::TxTrace awdlTxTrace;
static uint32_t awdlTxTracePublished;
static ItlAWDL::BaTrace awdlBaTrace;
static uint32_t awdlBaTracePublished;
// The peer's schedule is always tracked (it only counts); -itlawdlpeerpause acts on it.
static ItlAWDL::PeerSchedule awdlPeerSchedule;
static ItlAWDL::PeerPauseState awdlPeerPauseState;
static ItlAWDL::PeerBulkState awdlPeerBulk;
static bool awdlPeerPause;
// -itlawdlawsync: also send a sync or service frame at the start of the peer's AWs in its entries on our
// channel, where an idle peer is awake, so it finds us and our records sooner. At most one per 8 ms.
static bool awdlAwSync;
static uint32_t awdlAwSyncFrames;
constexpr uint64_t kAwdlAwSyncWindowUS = 2000, kAwdlAwSyncMinGapUS = 8000;
static uint32_t awdlPeerSyncFrames;
static uint64_t awdlSubmitUS, awdlFlightSumUS, awdlIdleSumUS, awdlLastDoneUS;
// itlawdlwindow=N: up to N unicast frames in flight. At 1, the single-frame path runs as before.
static unsigned awdlWindow = 1;
static ItlAWDL::TxBurst awdlBurst;
static mbuf_t awdlDeferredMulticast;
// itlawdlmcastrepeat=N: each group frame goes N times in all, 64 TU apart. Needs a window above 1.
static unsigned awdlMulticastCopies = 1;
static ItlAWDL::MulticastRepeats awdlMulticastRepeats;
static uint32_t awdlMulticastRepeatsSent;
static bool awdlBurstSending;
// What the send path looked like when it stopped, so a hang can be read afterwards.
struct AWDLTxStall {
    uint32_t uptimeMs, pending, started, attempted, inFlight, burstCount, retryCount, resendHeld, resendPending;
    uint32_t ringCur, ringTail, ringQueued, lastIndex, lastStatus, submitted;
};
static AWDLTxStall awdlTxStalls[4];
static unsigned awdlTxStallCount;
static uint64_t awdlTxBusySinceUS, awdlTxLastCompletionUS;
static uint32_t awdlTxLastIndex, awdlTxLastStatus;
static bool awdlBackgroundScan, awdlBackgroundScanActive;
static uint64_t awdlBackgroundScanStartUS;
static ItlAWDL::ChannelMoveState awdlChannelMove;
static uint32_t awdlBackgroundScans, awdlMovesUp, awdlMovesDown;
static unsigned awdlMoveTestSeconds;
static bool awdlMoveTestDone;
// -itlawdlba: answer a peer's Block Ack request, only on channel 149. On channel 6 the idle
// scans run, and the firmware got stuck in one with this station present. A few attempts per
// boot, because a firmware that faults on it would fault again each time the peer repeats itself.
constexpr uint32_t kAwdlBaAttemptsMax = 3;
static bool awdlBaProbe, awdlBaPending, awdlBaPeerKnown, awdlBaStationAdded, awdlBaFailed, awdlBaResponseInFlight;
static ItlAWDL::AddbaRequest awdlBaRequest;
static uint8_t awdlBaPeer[6], awdlBaResponse[ItlAWDL::kAddbaResponseLength];
static size_t awdlBaResponseLength;
static int awdlBaGeneration;
static uint16_t awdlBaSequence, awdlRxPhyInfo;
// awdlBaStep is written before each step, so a firmware fault still shows which one it was.
static uint32_t awdlBaStep, awdlBaRequests, awdlBaOtherPeer, awdlBaStationStatus, awdlBaSessionStatus, awdlBaTids;
static uint32_t awdlBaResponsesSent, awdlBaResponsesAcked, awdlBaResponseLastStatus, awdlBaRxAmpdu, awdlBaStale;
static uint32_t awdlBaAttempts, awdlBaOffChannel, awdlBaResponsesDone, awdlBaResponsesRefused, awdlBaBarReleases;
static uint32_t awdlBaRxDelba, awdlBaSessionRestarts;
static uint8_t awdlBaTidToken[8];
static ItlAWDL::RxSequenceTracker awdlRxSequences;
// The BSSID in the peer's request. The context otherwise carries the broadcast address.
static uint8_t awdlBaBssid[6];
static uint32_t awdlBaBssidResult, awdlRxNoFcs;
// Experiments on why Block Acks don't reach the peer, only with -itlawdlba:
// -itlawdlbanopromisc drops the promiscuous filter once a session opens.
// itlawdlbamac=N starts the card in another MAC type: 5 BSS_STA, 7 P2P_STA or 4 IBSS.
// If the card keeps restarting, it goes back to LISTENER for the rest of the boot.
static bool awdlBaNoPromisc;
// -itlawdlbafilterkeepoff: with -itlawdlbanopromisc, the filter goes off once the peer's session exists
// and stays off, instead of coming back on when traffic is quiet. While it's on, the firmware sends no
// Block Acks for the peer's aggregates, and every peer session restart seen on iface102 followed it.
static bool awdlBaFilterKeepOff;
// The filter stays on until the peer acknowledges an answer, and after that it's only off while
// data is arriving. Off before that, a send never starts.
static bool awdlBaPeerAccepted, awdlBaFilterOff;
static ItlAWDL::BaFilterState awdlBaFilter;
static uint32_t awdlBaFilterChanges;
// -itlawdlbatx: send A-MPDUs to the peer. Its own firmware queue and firmware rate control, an
// ADDBA request, then file data goes there. Sending stays on the monitor queue until the peer
// agrees, and goes back there if it stops. Failed frames are the firmware's to retry.
enum : uint32_t { kBaTxOff, kBaTxAsking, kBaTxAgreed, kBaTxFailed };
constexpr uint8_t kAwdlBaTxTid = 0;
constexpr uint32_t kAwdlBaTxAsksMax = 40, kAwdlBaTxDelbaMax = 16;
// itlawdlbatxagg=0 to 7: the peer's A-MPDU limit, 8 KB doubling up to 1 MB. Above 3 (64 KB) is VHT
// only, so it applies only to a VHT 80 station (-itlawdlbatx80); an HT station stays at 64 KB at most.
// itlawdlbatxq=N: frames waiting.
static uint32_t awdlBaTxAgg = 3, awdlBaTxQueuedMax = 64;
// -itlawdlbatx80: with -itlawdlbatx, the peer's station and its rate control use VHT at 80 MHz,
// MCS 4 to 9 on one or two streams, if the firmware is listening at 80 MHz on 149 when the station
// is added. Otherwise it stays HT at 20 MHz as before. State: 0 not tried, 1 VHT80, 2 not live then.
static bool awdlBaTx80, awdlBaTx80Active;
static uint32_t awdlBaTx80State;
// itlawdlbatxrate=N, 0 to 9: with a VHT 80 station, the Mac's A-MPDU frames use a fixed VHT rate, MCS N,
// two streams, 80 MHz, long guard interval, instead of the firmware's rate control. Rate control
// falls back to 20 or 40 MHz, probably on losses while the peer is on another channel, and the
// narrow widths are where the slow seconds are. -1, the default, leaves rate control in charge.
static int awdlBaTxFixedMcs = -1;
// itlawdlbatxminmcs=N, 0 to 9: the lowest VHT MCS rate control may use for a VHT 80 station (default 4).
// With only MCS 4 to 9, rate control's way down on losses is a narrower width.
static uint32_t awdlBaTxMinMcs = 4;
static uint32_t awdlBaTxFixedFrames;
static bool awdlBaTx, awdlBaTlc;
static int awdlBaTxQueue = -1;
static uint32_t awdlBaTxState, awdlBaTxAsks, awdlBaTxAnswerStatus = 0xffffffffU, awdlBaTxQueueResult;
static uint32_t awdlBaTxFrames, awdlBaTxNotifs, awdlBaTxSentAir, awdlBaTxAcked, awdlBaTxDelba, awdlBaTxRefused, awdlBaTxSingles;
static uint16_t awdlBaTxSequence;
static ItlAWDL::BaTxBulkState awdlBaTxBulk;
static uint32_t awdlBaTxBulkChanges, awdlBaTxBulkSkipped;
static uint8_t awdlBaTxToken;
static uint64_t awdlBaTxLastAskUS;
// After a round of unanswered asks the session rests and then asks again, instead of staying off for
// the rest of the boot: on iface103 all 40 asks went while the phone was mostly away.
constexpr uint64_t kAwdlBaTxRestUS = 20000000;
static uint64_t awdlBaTxRestUntilUS;
static uint32_t awdlBaTxAskRounds, awdlBaTxAsksSkippedAway;
static uint32_t awdlBaMacType, awdlBaMacAdds, awdlBaMacFellBack;
constexpr uint32_t kAwdlBaMacAddsMax = 5;
static const uint8_t kAwdlBssid[6] = {0x00, 0x25, 0x00, 0xff, 0x94, 0x73};
static uint16_t mccBiosCountry;
static bool mccBiosSent;
static bool mccEchoAnswered;
static uint32_t mccEchoLastSeconds, mccNoticeTotal, mccNoticeLastSeconds;
static uint16_t mccEchoCountry;
static uint8_t mccEchoSource;
// Set before attach, from the card's ACPI WRDD method. The laptop maker's value.
void itlMccSetBiosCountry(uint16_t country) { mccBiosCountry = country; }
static ItlAWDL::MccSample mccSamples[96];
static unsigned mccSampleCount;
static ItlAWDL::MccNotice mccNotices[16];
static unsigned mccNoticeCount;
static uint32_t mccUptimeSeconds()
{
    uint64_t uptime, ns;
    clock_get_uptime(&uptime);
    absolutetime_to_nanoseconds(uptime, &ns);
    return uint32_t(ns / 1000000000ULL);
}
static void mccProbePublish()
{
    auto *root = IORegistryEntry::getRegistryRoot();
    if (auto *samples = OSData::withBytes(mccSamples, unsigned(mccSampleCount * sizeof(mccSamples[0])))) {
        root->setProperty("ITLMCCSamples", samples);
        samples->release();
    }
    if (auto *notices = OSData::withBytes(mccNotices, unsigned(mccNoticeCount * sizeof(mccNotices[0])))) {
        root->setProperty("ITLMCCNotices", notices);
        notices->release();
    }
    root->setProperty("ITLMCCNoticeTotal", mccNoticeTotal, 32);
    root->setProperty("ITLMCCNoticeLastSeconds", mccNoticeLastSeconds, 32);
}
static ItlAWDL::DataSkipCounts awdlDataSkips;
static unsigned awdlRxIndex;
static bool awdlRxBurstDone;
static struct {
    uint32_t all, mgmt, beacon, psf, mif, other, logged;
    uint32_t syncValid, syncInvalid, rejectedLogged;
    uint32_t dataIPv6, dataMalformed, dataUnsupported;
    int lastChan, lastRssi;
} awdlRxStat;
static uint8_t awdlRxPeers[8][6];
static unsigned awdlRxPeerCount;

static uint64_t awdlUptimeUS()
{
    uint64_t uptime, ns;
    clock_get_uptime(&uptime);
    absolutetime_to_nanoseconds(uptime, &ns);
    return ns / 1000;
}

static bool awdlPeerAudible()
{
    return ItlAWDL::peerRecentlyHeard(awdlPeerEverHeard, awdlUptimeUS(), awdlPeerLastHeardUS);
}

// Bounded to one short sample per key, kept only in this machine's I/O Registry.
// The bodies are unencrypted broadcasts and may carry a device or host name.
static void awdlKeepSample(const char *key, const uint8_t *frame, size_t length)
{
    if (!awdlRawSamples)
        return;
    auto *root = IORegistryEntry::getRegistryRoot();
    if (root->getProperty(key))
        return;
    if (auto *sample = OSData::withBytes(frame, unsigned(MIN(length, size_t(1024))))) {
        root->setProperty(key, sample);
        sample->release();
    }
}

void ItlIwx::
awdlRxObserve(struct iwx_softc *sc, mbuf_t m, int chanidx, int rssi, uint32_t timestamp)
{
    if (sc->sc_ic.ic_opmode != IEEE80211_M_MONITOR)
        return;
    const uint8_t *f = mtod(m, const uint8_t *);
    const size_t len = mbuf_len(m);
    
    awdlRxStat.all++;
    ++awdlRxAllFrames;
    if (len >= 16 && ItlAWDL::knownAddress(awdlLastPeer) && ItlAWDL::sameAddress(f + 10, awdlLastPeer)) {
        ++awdlRxFromPeer;
        const uint64_t peerNowUS = awdlUptimeUS();
        awdlTxTrace.notePeerFrame(peerNowUS);
        awdlPeerSchedule.notePeerFrame(peerNowUS);
    }
    if (awdlRadioProbe && len >= 24 && unsigned(chanidx) < nitems(awdlRadioBeacons) && !awdlBaFilterOff) {
        if (f[0] == 0x80) {
            ++awdlRadioBeacons[chanidx];
        } else if ((f[0] & 0x0c) == 0x08 &&
                   !ItlAWDL::sameAddress(f + 10, awdlLastPeer) &&
                   !ItlAWDL::sameAddress(f + 10, awdlOwnAddress) &&
                   !ItlAWDL::sameAddress(f + 10, sc->sc_ic.ic_myaddr)) {
            ++awdlRadioOtherData[chanidx];
        }
    }
    awdlRxStat.lastChan = chanidx;
    awdlRxStat.lastRssi = rssi;
    ItlAWDL::observeAir(awdlAir, f, len, awdlOwnAddress, sc->sc_ic.ic_myaddr);
    if ((awdlCountryDiscovery || awdlBackgroundScanActive) && !mbuf_next(m)) {
        uint8_t advertised[2];
        if (ItlAWDL::beaconCountry(f, len, advertised))
            ItlAWDL::noteBeaconCountry(awdlBeaconCountries, nitems(awdlBeaconCountries), awdlBeaconCountryCount,
                                       awdlBeaconCountryOverflow, advertised, uint8_t(chanidx));
    }
    // Identify the action frames addressed to us that aren't AWDL's own format.
    if (len >= 26 && f[0] == 0xd0 && ItlAWDL::knownAddress(awdlOwnAddress) &&
        ItlAWDL::sameAddress(f + 4, awdlOwnAddress) && f[24] != 0x7f) {
        awdlKeepSample("ITLAWDLSampleActionToUs", f, len);
        ItlAWDL::AddbaAnswer answer;
        if (awdlBaTx && awdlBaTxState == kBaTxAsking && ItlAWDL::parseAddbaAnswer(f, len, awdlOwnAddress, &answer) &&
            answer.token == awdlBaTxToken && answer.tid == kAwdlBaTxTid && ItlAWDL::sameAddress(f + 10, awdlBaPeer)) {
            awdlBaTxAnswerStatus = answer.status;
            awdlBaTxState = answer.status ? kBaTxFailed : kBaTxAgreed;
            awdlSessLog("mac tx session answer status %u window %u\n", unsigned(answer.status), unsigned(answer.window));
        }
        bool delbaPeerWasSender = false;
        uint8_t delbaTid = 0;
        if (awdlBaProbe && ItlAWDL::parseDelba(f, len, awdlOwnAddress, &delbaPeerWasSender, &delbaTid) &&
            ItlAWDL::sameAddress(f + 10, awdlBaPeer)) {
            awdlSessLog("phone delba tid %u (%s)\n", unsigned(delbaTid), delbaPeerWasSender ? "its sending" : "our sending");
            if (delbaPeerWasSender) {
                ++awdlBaRxDelba;
            } else if (awdlBaTx && awdlBaTxState == kBaTxAgreed && delbaTid == kAwdlBaTxTid) {
                // Sending goes back to the monitor queue, and the timer asks again.
                ++awdlBaTxDelba;
                ++awdlBaTxToken;
                awdlBaTxAsks = 0;
                awdlBaTxLastAskUS = 0;
                awdlBaTxState = awdlBaTxDelba > kAwdlBaTxDelbaMax ? kBaTxFailed : kBaTxAsking;
            }
        }
        ItlAWDL::AddbaRequest request;
        if (awdlBaProbe && ItlAWDL::parseAddbaRequest(f, len, awdlOwnAddress, &request)) {
            ++awdlBaRequests;
            awdlSessLog("phone addba token %u tid %u ssn %u window %u\n", unsigned(request.token), unsigned(request.tid),
                        unsigned(request.ssn), unsigned(request.window));
            if (awdlBaPeerKnown && awdlBaGeneration == sc->sc_generation && !ItlAWDL::sameAddress(awdlBaPeer, request.peer)) {
                ++awdlBaOtherPeer;
            } else {
                awdlBaRequest = request;
                awdlBaPending = true;
            }
        }
    }
    // Read-only accounting of data frames to us that don't become IPv6 packets.
    const bool dataToOwn = len >= 28 && (f[0] & 0x0c) == 8 && ItlAWDL::knownAddress(awdlOwnAddress) &&
        ItlAWDL::sameAddress(f + 4, awdlOwnAddress);
    if (dataToOwn && mbuf_next(m)) {
        ItlAWDL::noteDataSkip(awdlDataSkips, ItlAWDL::DataSkip::Chained, f, mbuf_pkthdr_len(m));
        awdlKeepSample("ITLAWDLSampleSkipChained", f, MIN(len, size_t(48)));
    }
    if (len >= 24 && (f[0] & 0x0c) == 8 && !mbuf_next(m)) {
        ItlAWDL::DataFrameView data;
        auto parsed = ItlAWDL::parseDataFrame(f, len, true, &data);
        // With the promiscuous filter off, the firmware may leave off the FCS. The parser never
        // reads those 4 bytes, so a longer length here only stops it from trimming real data.
        size_t capture = len;
        // Trimming 4 bytes reads as Malformed on a plain frame, and as Unsupported on one with
        // the outer header, whose length field no longer matches. Those carry the file data.
        if (awdlBaNoPromisc && (parsed == ItlAWDL::ParseResult::Malformed || parsed == ItlAWDL::ParseResult::Unsupported) &&
            ItlAWDL::parseDataFrame(f, len, false, &data) == ItlAWDL::ParseResult::Valid) {
            capture = len + 4;
            parsed = ItlAWDL::ParseResult::Valid;
            ++awdlRxNoFcs;
        }
        if (parsed == ItlAWDL::ParseResult::Malformed)
            awdlKeepSample("ITLAWDLSampleMalformed", f, MIN(len, size_t(96)));
        if (dataToOwn) {
            const auto skip = ItlAWDL::dataSkipReason(f, capture, false, parsed);
            ItlAWDL::noteDataSkip(awdlDataSkips, skip, f, len);
            if (skip == ItlAWDL::DataSkip::Bssid)
                awdlKeepSample("ITLAWDLSampleSkipBssid", f, MIN(len, size_t(48)));
            else if (skip == ItlAWDL::DataSkip::Llc)
                awdlKeepSample("ITLAWDLSampleSkipLlc", f, MIN(len, size_t(48)));
            else if (skip == ItlAWDL::DataSkip::FrameType)
                awdlKeepSample("ITLAWDLSampleSkipType", f, MIN(len, size_t(48)));
            else if (parsed == ItlAWDL::ParseResult::Unsupported)
                awdlKeepSample("ITLAWDLSampleUnsupported", f, MIN(len, size_t(48)));
            if (parsed == ItlAWDL::ParseResult::Valid) {
                // A reply will follow, so don't leave it waiting on the idle poll.
                awdlDataEverActive = true;
                awdlLastDataUS = awdlUptimeUS();
                ++awdlDataSkips.parsedLengths[ItlAWDL::dataLengthBin(len)];
                const size_t header = f[0] == 0x88 ? 26 : 24;
                if (ItlAWDL::hasOuterDataHeader(f + header, len - header))
                    ++awdlDataSkips.outerHeader;
            }
        }
        if (parsed == ItlAWDL::ParseResult::Valid) {
            ++awdlRxStat.dataIPv6;
            ItlAWDL::observeData(awdlSeen, data, awdlOwnAddress);
            // Prefer the address a peer actually uses over deriving one from its MAC.
            if (data.ip.bytes[8] == 0xfe && data.ip.bytes[9] == 0x80) {
                memcpy(awdlLearnedPeer, data.source, sizeof(awdlLearnedPeer));
                memcpy(awdlLearnedPeerIP, data.ip.bytes + 8, sizeof(awdlLearnedPeerIP));
            }
#if defined(ITL_AWDL_NATIVE)
            itlAWDLObserveData(container_of(sc, ItlIwx, com)->getController(), f, capture);
#endif
        }
        else if (parsed == ItlAWDL::ParseResult::Malformed) ++awdlRxStat.dataMalformed;
        else if (parsed == ItlAWDL::ParseResult::Unsupported) ++awdlRxStat.dataUnsupported;
        // Do not admit peers, deliver data or change the borrowed Intel mbuf.
    }
    if (len < 24 || (f[0] & 0x0c) != 0)
        return;
    awdlRxStat.mgmt++;
    if (f[0] == 0x80)
        awdlRxStat.beacon++;
    ItlAWDL::ActionFrame decoded;
    // Monitor MAC context enables IWX_MAC_FILTER_IN_CRC32, so the capture
    // includes four FCS bytes. Keep the borrowed mbuf intact for normal RX.
    size_t frameLength = 0;
    const auto result = ItlAWDL::parseCapturedAction(f, len, true, &decoded, &frameLength);
    if (result == ItlAWDL::ParseResult::NotAWDL)
        return;
    if (result != ItlAWDL::ParseResult::Valid) {
        ++awdlRxStat.syncInvalid;
        if (awdlRxStat.rejectedLogged++ < 8)
            awdlLog("rejected ch %d result %u captured %u flags %02x frag %u version %u subtype %u\n",
                    chanidx, static_cast<unsigned>(result), static_cast<unsigned>(len),
                    f[1], f[22] & 0x0f, len > 33 ? f[29] : 0xff, len > 34 ? f[30] : 0xff);
        return;
    }
#if defined(ITL_AWDL_NATIVE)
    // The borrowed Intel mbuf stays in the normal RX path. The receiver makes
    // an owned copy into an Apple pool buffer before invoking the peer engine.
    // rxi_rssi is dBm normalized by IWX_MIN_DBM; the native stack expects dBm.
    // -itlawdlnopsf: a peer's sync frames carry no services, and handing them up seems to make
    // the native stack drop the peer's services until its next MIF, so they stay here.
    const bool fromOwn = ItlAWDL::knownAddress(awdlOwnAddress) && ItlAWDL::sameAddress(f + 10, awdlOwnAddress);
    if (awdlServiceMerge && !fromOwn) {
        const uint32_t resetsBefore = awdlServiceCache.resets;
        const uint16_t suiBefore = awdlServiceCache.sui;
        const unsigned recordsBefore = awdlServiceCache.records;
        awdlServiceCache.note(f + 10, f, frameLength);
        if (awdlServiceCache.resets != resetsBefore)
            awdlSessLog("phone services %u -> %u (%u records before)\n", unsigned(suiBefore),
                        unsigned(awdlServiceCache.sui), recordsBefore);
    }
    if (awdlNoPeerPsf && decoded.subtype == 0 && !fromOwn) {
        ++awdlPeerPsfKept;
    } else {
        // -itlawdlsvcmerge: hand up the frame with the peer's other records added, if any are missing.
        bool handed = false;
        if (awdlServiceMerge && !fromOwn) {
            unsigned added = 0;
            mbuf_t merged = nullptr;
            if (!mbuf_getpacket(MBUF_DONTWAIT, &merged) && merged && mbuf_maxlen(merged) > frameLength + 4) {
                const size_t room = MIN(size_t(mbuf_maxlen(merged)) - 4, ItlAWDL::kServiceMergeFrameMax);
                const size_t n = awdlServiceCache.merge(f + 10, f, frameLength, static_cast<uint8_t *>(mbuf_data(merged)), room, &added);
                if (n) {
                    // The hand-off expects the 4 FCS bytes after the frame, as from the radio.
                    memset(static_cast<uint8_t *>(mbuf_data(merged)) + n, 0, 4);
                    mbuf_setlen(merged, n + 4);
                    mbuf_pkthdr_setlen(merged, n + 4);
                    const IOReturn sent = itlAWDLReceiveAction(getController(), merged, n, static_cast<uint32_t>(chanidx), rssi + IWX_MIN_DBM);
                    if (sent == kIOReturnSuccess) {
                        handed = true;
                        ++awdlServiceMergedFrames;
                        awdlServiceMergedRecords += added;
                    } else {
                        ++awdlServiceMergeRefused;
                        awdlSessLog("merged frame refused 0x%x\n", unsigned(sent));
                        awdlServiceMergeLastError = uint32_t(sent);
                    }
                }
            }
            if (merged)
                mbuf_freem(merged);
        }
        if (!handed)
            itlAWDLReceiveAction(getController(), m, frameLength, static_cast<uint32_t>(chanidx), rssi + IWX_MIN_DBM);
    }
#endif
    if (decoded.hasSync)
        ++awdlRxStat.syncValid;
    const uint8_t subtype = decoded.subtype;
    const bool isOwn = ItlAWDL::knownAddress(awdlOwnAddress) && ItlAWDL::sameAddress(f + 10, awdlOwnAddress);
    if (ItlAWDL::observeAction(awdlSeen, f, frameLength, awdlOwnAddress)) {
        awdlKeepSample("ITLAWDLSampleMention", f, frameLength);
        if (awdlSeen.actionMentions == 1)
            awdlLog("first peer frame carrying our address: ch %d subtype %u rssi %d\n", chanidx, subtype, rssi);
    }
    if (!isOwn) {
        // Our own echo must never keep the peer-gated train alive.
        awdlPeerEverHeard = true;
        const uint64_t heardNowUS = awdlUptimeUS();
        if (awdlPeerLastHeardUS && heardNowUS - awdlPeerLastHeardUS > 2000000)
            awdlSessLog("phone heard again after %u ms\n", unsigned((heardNowUS - awdlPeerLastHeardUS) / 1000));
        awdlPeerLastHeardUS = heardNowUS;
        memcpy(awdlLastPeer, f + 10, sizeof(awdlLastPeer));
        awdlLastPeerRssi = rssi;
        awdlKeepSample(subtype == 0 ? "ITLAWDLSamplePSF" : "ITLAWDLSampleMIF", f, frameLength);
        ItlAWDL::countActionTLVs(awdlPeerTLVs, f, frameLength);
        awdlNoteServices(f, frameLength, true);
        ItlAWDL::PeerSyncInfo peerSync{};
        if (ItlAWDL::knownAddress(awdlBaPeer) && ItlAWDL::sameAddress(f + 10, awdlBaPeer) &&
            ItlAWDL::peerSyncFromAction(f, frameLength, &peerSync)) {
            awdlPeerSchedule.note(peerSync, awdlUptimeUS(), uint8_t(awdlFixedChannel));
            ++awdlPeerSyncFrames;
        }
        ItlAWDL::PeerSlots slots{};
        if (ItlAWDL::peerSlotsFromAction(f, frameLength, &slots)) {
            ++awdlSlots6Frames[MIN(slots.channel6, uint8_t(16))];
            if (!awdlHaveSlots || memcmp(&slots, &awdlLastSlots, sizeof(slots))) {
                awdlHaveSlots = true;
                awdlLastSlots = slots;
                if (awdlSlotChangeCount < nitems(awdlSlotChanges))
                    awdlSlotChanges[awdlSlotChangeCount++] = AWDLSlotChange{uint32_t(awdlUptimeUS() / 1000), slots, 0};
            }
        }
        uint16_t statedCountry = 0;
        if (awdlPeerCountryTest && ItlAWDL::peerCountryFromAction(f, frameLength, &statedCountry)) {
            ++awdlPeerCountryFrames;
            ItlAWDL::notePeerCountry(awdlPeerCountry, statedCountry);
        }
        // The first frame of a kind can be much smaller than the ones carrying services.
        const unsigned kind = subtype == 0 ? 0 : 1;
        if (frameLength > awdlLargestPeer[kind]) {
            awdlLargestPeer[kind] = frameLength;
            if (!awdlRawSamples) {
            } else if (auto *largest = OSData::withBytes(f, unsigned(MIN(frameLength, size_t(2048))))) {
                IORegistryEntry::getRegistryRoot()->setProperty(kind ? "ITLAWDLSampleLargestMIF" : "ITLAWDLSampleLargestPSF", largest);
                largest->release();
            }
        }
    }
    if (subtype == 0)
        awdlRxStat.psf++;
    else if (subtype == 3)
        awdlRxStat.mif++;
    else
        awdlRxStat.other++;
    unsigned i;
    for (i = 0; i < awdlRxPeerCount; i++)
        if (!memcmp(awdlRxPeers[i], f + 10, 6))
            break;
    if (i == awdlRxPeerCount && i < nitems(awdlRxPeers)) {
        memcpy(awdlRxPeers[i], f + 10, 6);
        awdlRxPeerCount++;
        // Random AWDL address, not a hardware address: show only its last bytes.
        awdlLog("new peer ..:%02x:%02x ch %d rssi %d\n", f[14], f[15], chanidx, rssi);
    }
    if (awdlRxStat.logged < 24) {
        uint32_t phy, target;
        memcpy(&phy, f + 32, 4);
        memcpy(&target, f + 36, 4);
        awdlRxStat.logged++;
        awdlLog("frame ch %d subtype %u len %u rssi %d gp2 %u phy %u target %u\n",
              chanidx, subtype, (unsigned)len, rssi, timestamp, phy, target);
        if (decoded.hasSync)
            awdlLog("sync AW %u TU AF %u TU remaining %u TU counter %u masterch %u nextch %u\n",
                    decoded.awPeriod, decoded.afPeriod, decoded.remainingAW,
                    decoded.txDownCounter, decoded.masterChannel, decoded.nextChannel);
    }
}

void ItlIwx::
awdlRxTimeout(void *arg)
{
    if (!awdlStopping)
        task_add(systq, &awdlRxTaskEntry);
}

void ItlIwx::
awdlCoexCycleTimeout(void *arg)
{
    if (!awdlStopping)
        task_add(systq, &awdlCoexTaskEntry);
}

void ItlIwx::
awdlCoexCycleTask(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                awdlCoexCycleTask(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    if (awdlStopping)
        return;
    struct ieee80211com *ic = &sc->sc_ic;
    if ((IC2IFP(ic)->if_flags & IFF_RUNNING) && ic->ic_state == IEEE80211_S_RUN &&
        !(sc->sc_flags & (IWX_FLAG_HW_ERR | IWX_FLAG_SHUTDOWN | IWX_FLAG_RFKILL))) {
        awdlCoexWant = !awdlCoexWant;
        ++awdlCoexCycleFlips;
        (void)that->awdlCoexListener(sc, awdlCoexWant);
        IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLCoexCycleFlips", awdlCoexCycleFlips, 32);
    }
    if (!awdlStopping)
        timeout_add_sec(&awdlCoexTimer, awdlCoexCycleSecs);
}

// Passive (no initiating) for the listener: the NVM's passive flag, unless a beaconing AP was heard on that
// channel (net80211's beacon hint, cleared when the country changes). Radar and no-ad-hoc are checked apart.
// UNII sub-band of a 5 GHz channel for the IR-concurrent rule (0 = not 5 GHz or not grouped).
static inline unsigned awdlCoexUnii(unsigned ch)
{
    return (ch >= 36 && ch <= 48) ? 1 : (ch >= 52 && ch <= 64) ? 2 : (ch >= 100 && ch <= 144) ? 3 :
        (ch >= 149 && ch <= 165) ? 4 : 0;
}

static inline bool awdlCoexNoIr(const struct ieee80211com *ic, unsigned ch)
{
    if (ch > IEEE80211_CHAN_MAX || !(ic->ic_channels[ch].ic_flags & IEEE80211_CHAN_PASSIVE) ||
        isset(ic->ic_beacon_hint, ch))
        return false;
    // IR-concurrent: allowed while the station is associated on this channel or in the same UNII sub-band.
    if (!awdlCoexIrConcurrentOff && isset(awdlCoexIrConcurrent, ch) && ic->ic_state == IEEE80211_S_RUN &&
        ic->ic_bss && ic->ic_bss->ni_chan && ic->ic_bss->ni_chan != IEEE80211_CHAN_ANYC) {
        const unsigned station = ieee80211_chan2ieee(const_cast<struct ieee80211com *>(ic), ic->ic_bss->ni_chan);
        if (station == ch || (awdlCoexUnii(ch) && awdlCoexUnii(ch) == awdlCoexUnii(station))) {
            ++awdlCoexIrConcurrentUsed;
            return false;
        }
    }
    return true;
}

// The one channel check for the listener's sending, used before building and again just before sending.
// Records the reason (and clears it when the channel is fine) and publishes when what it would show changes.
// The listener's own context at 80 MHz covers 149-161: every one of them has to stay allowed, not only the
// primary, and the move has to be complete (iface129 review, 2).
static bool awdlCoexBlockIneligible(struct ieee80211com *ic, struct ieee80211_channel *channel)
{
    if (awdlCoexMovePending)
        return true;
    if (!channel || channel != awdlCoexOwnChan || awdlCoexOwnWidth != 80)
        return false;
    // 149-161 or 36-48, whichever block the listener's primary is in.
    const unsigned primary = ieee80211_chan2ieee(ic, channel);
    const unsigned first = awdlCoex80BlockFirst(primary);
    if (!first || !(ic->ic_channels[primary].ic_flags & IEEE80211_CHAN_VHT80))
        return true;
    for (unsigned ch = first; ch <= first + 12; ch += 4) {
        const auto &sub = ic->ic_channels[ch];
        if (!sub.ic_freq || !isset(ic->ic_chan_active, ch) || awdlCoexNoIr(ic, ch) ||
            (sub.ic_flags & (IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC)))
            return true;
    }
    return false;
}

static bool awdlCoexChannelEligible(struct ieee80211com *ic, struct ieee80211_channel *channel, const char *phase,
                                    int generation)
{
    const unsigned number = channel ? ieee80211_chan2ieee(ic, channel) : 0;
    const uint32_t flags = channel ? channel->ic_flags : 0;
    const uint32_t reason = (!channel || number > 255 || !ItlAWDL::fixedScheduleChannel(uint8_t(number)) ? 1U : 0U) |
        ((channel && awdlCoexNoIr(ic, number)) ? 2U : 0U) | ((flags & IEEE80211_CHAN_DFS) ? 4U : 0U) |
        ((flags & IEEE80211_CHAN_NOADHOC) ? 8U : 0U) |
        (!channel || number > 255 || !isset(ic->ic_chan_active, number) ? 16U : 0U) |
        (number != awdlFixedChannel ? 32U : 0U) |
        (awdlCoexBlockIneligible(ic, channel) ? 64U : 0U);
    const bool changed = reason != awdlCoexRefusedReason || (reason && flags != awdlCoexRefusedChannelFlags);
    awdlCoexRefusedReason = reason;
    if (reason) {
        awdlCoexRefusedChannelFlags = flags;
        ++awdlCoexTxRefusedChannel;
        snprintf(awdlCoexRefusalSnapshot, sizeof(awdlCoexRefusalSnapshot),
                 "%s channel %u expected %u flags 0x%x reason 0x%x generation %d", phase, number, awdlFixedChannel,
                 flags, reason, generation);
    }
    if (changed)
        awdlCoexPublish();
    return !reason;
}

static void awdlStopTimers()
{
    // Set first; every arm site checks it inside the command gate, and the frees below run in the gate,
    // so work that was already past its check finishes, and its timer is freed after it.
    awdlStopping = true;
    timeout_free(&awdlCoexTxTimer);
    timeout_free(&awdlCoexTimer);
    timeout_free(&awdlRxTimer);
    task_del(systq, &awdlCoexTxTaskEntry);
    task_del(systq, &awdlCoexTaskEntry);
    task_del(systq, &awdlRxTaskEntry);
}

void ItlIwx::
awdlCoexTxTimeout(void *arg)
{
    if (!awdlStopping)
        task_add(systq, &awdlCoexTxTaskEntry);
}

void ItlIwx::
awdlCoexTxTask(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (awdlStopping)
        return;
    if (!that->getMainWorkLoop() || !that->getMainCommandGate()) {
        // Too early in startup: try again later.
        timeout_add_msec(&awdlCoexTxTimer, kAwdlCoexTxPeriodMS);
        return;
    }
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                awdlCoexTxTask(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    if (awdlStopping)
        return;
    struct ieee80211com *ic = &sc->sc_ic;
    const bool running = (IC2IFP(ic)->if_flags & IFF_RUNNING) && ic->ic_state == IEEE80211_S_RUN &&
        ic->ic_opmode == IEEE80211_M_STA && !(sc->sc_flags & (IWX_FLAG_HW_ERR | IWX_FLAG_SHUTDOWN | IWX_FLAG_RFKILL));
    if (running && awdlCoexCountryPending && awdlCoexCountryGen == sc->sc_generation &&
        (!awdlCoexCountryRetryUS || awdlUptimeUS() >= awdlCoexCountryRetryUS) &&
        (!ItlAWDL::countryNoticeUsable(awdlCoexCountryNotice, awdlCoexCountrySource) ||
         ItlAWDL::mccEchoDue(awdlCoexCountryAnswers != 0, mccUptimeSeconds(), awdlCoexCountryAnswerSeconds)))
        that->awdlCoexCountryAnswer(sc);
    if (running && !awdlStopping && awdlCoexAdded && awdlCoexGeneration == sc->sc_generation)
        that->awdlCoexRetarget(sc);
    if (running && awdlCoexAdded && awdlCoexGeneration == sc->sc_generation) {
        if (!awdlCoexTxStaAdded && awdlCoexTxSetupTried < kAwdlCoexTxSetupTries &&
            awdlCoexBrokenGeneration != sc->sc_generation) {
            ++awdlCoexTxSetupTried;
            (void)that->awdlCoexTxSetup(sc);
        }
        const uint64_t watchNowUS = awdlUptimeUS();
        if (awdlCoexTxStaAdded && awdlCoexInFlight && watchNowUS - awdlCoexInFlightUS > kAwdlCoexTxStuckUS &&
            (!awdlCoexLastCompletionUS || watchNowUS - awdlCoexLastCompletionUS > 1000000ULL ||
             watchNowUS - awdlCoexInFlightUS > 5000000ULL)) {
            // A late completion for this frame no longer matches the pending one.
            awdlCoexInFlight = false;
            awdlCoexPendingSlot = -1;
            ++awdlCoexTxStuck;
            const bool halt = ++awdlCoexStuckStreak >= 3;
            if (halt) {
                awdlCoexTxHalted = true;
                // Three stalls with no completion: the queue may be wedged. Flush and remove the listener's
                // station and queue (descriptors included); setup then rebuilds them, within its try limit.
                // If the firmware doesn't confirm, quarantine until it restarts.
                const int wedgedGen = sc->sc_generation;
                const uint32_t wedgedTok = awdlCoexToken;
                const int teardownErr = that->awdlCoexTxTeardown(sc);
                if (wedgedGen == sc->sc_generation) {
                    if (teardownErr)
                        awdlCoexBrokenGeneration = wedgedGen;
                    else if (wedgedTok == awdlCoexToken)
                        ++awdlCoexWedgedRebuilds;
                    awdlCoexStuckStreak = 0;
                }
            } else {
                ++awdlCoexTxPauses;
                awdlCoexTxPauseUntilUS = watchNowUS + 500000ULL;
            }
            {
                const auto &haltRing = sc->txq[awdlCoexQueue >= 0 ? awdlCoexQueue : 0];
                snprintf(awdlCoexFaultSnapshot, sizeof(awdlCoexFaultSnapshot),
                         "%s queue %d token %u gen %d last-ssn %u tail %d queued %d last-slot %d streak %u "
                         "pending-ms %u last-completion-ms %u",
                         halt ? "halt" : "pause", awdlCoexQueue, awdlCoexToken, sc->sc_generation, awdlCoexLastSsn,
                         haltRing.tail, haltRing.queued, awdlCoexLastSlot, awdlCoexStuckStreak,
                         unsigned((watchNowUS - awdlCoexInFlightUS) / 1000),
                         awdlCoexLastCompletionUS ? unsigned((watchNowUS - awdlCoexLastCompletionUS) / 1000) : 0xffffffffU);
            }
            awdlCoexPublish();
        }
        // Setup waits on the firmware; detach or a RUN exit may have come meanwhile.
        // With the data pump the task runs every few milliseconds; sync frames keep their own pace.
        const uint64_t taskNowUS = awdlUptimeUS();
        // Sync pacing. While data moves, every 100 ms. While idle, every 45 ms as dedicated mode did
        // (kSyncIdleIntervalUS), and with -itlawdlawsync also at the start of the phone's AWs on our channel,
        // at most one per 8 ms (iface106): an idle phone is reliably awake only then.
        const bool coexDataActive = awdlCoexLastDataUS && taskNowUS - awdlCoexLastDataUS < 1000000ULL;
        awdlCoexScheduleCalibrated = awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.calibrated &&
            awdlCoexPeerSchedule.fresh(taskNowUS);
        const uint64_t sinceSync = taskNowUS - awdlCoexLastSyncUS;
        const bool awTimingUsable = (awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.known() &&
                                     awdlCoexPeerSchedule.fresh(taskNowUS)) ||
            (awdlCoexAwSyncAssume && awdlCoexScheduleCurrent() &&
             awdlCoexPeerSchedule.timingUsable(taskNowUS, true));
        const bool awTimed = awdlCoexData && awdlAwSync && !coexDataActive && sinceSync >= kAwdlAwSyncMinGapUS &&
            awTimingUsable &&
            awdlCoexPeerSchedule.inPresentAwStart(taskNowUS, kAwdlAwSyncWindowUS, awdlCoexAwSyncAssume);
        const bool syncDue = !awdlCoexData || awTimed ||
            sinceSync >= (coexDataActive ? 100000ULL : ItlAWDL::kSyncIdleIntervalUS);
        if (awdlCoexTxStaAdded && !awdlCoexInFlight && !awdlCoexTxHalted && !awdlStopping && awdlCoexAdded &&
            taskNowUS >= awdlCoexTxPauseUntilUS && syncDue) {
            awdlCoexLastSyncUS = taskNowUS;
            if (awTimed)
                ++awdlCoexAwSyncFrames;
            else if (awdlCoexData && !coexDataActive)
                ++awdlCoexIdleSyncFrames;
            that->awdlCoexTxSend(sc);
        }
        if (awdlCoexData && !awdlStopping && awdlCoexAdded) {
            that->awdlCoexBaHandle(sc);
            that->awdlCoexBaPauseStep(sc);
            that->awdlCoexDataPump(sc);
        }
        if (awdlCoexBaTraceEnabled && !awdlStopping && awdlCoexAdded && awdlCoexGeneration == sc->sc_generation) {
            const uint64_t now = awdlUptimeUS();
            if (now - awdlCoexBaTimelineLastUS >= 50000ULL) {
                awdlCoexBaTimelineLastUS = now;
                const int queue = awdlCoexBaTxQueue;
                const bool hasQueue = queue >= 0 && queue < int(nitems(sc->txq));
                const bool scheduleUsable = awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.known() &&
                    awdlCoexPeerSchedule.eawUS && awdlCoexPeerSchedule.fresh(now);
                const auto &last = awdlCoexBaLastRefillSample;
                const bool sameQueue = hasQueue && last.queue == queue && last.generation == uint32_t(sc->sc_generation) &&
                    last.listener == awdlCoexToken && last.peer == awdlCoexBaPeerEpoch;
                const uint8_t flags = (hasQueue ? 1U : 0U) | (awdlCoexBaTxBulk.bulk ? 2U : 0U) |
                    (awdlCoexPeerPause.paused ? 4U : 0U) | (scheduleUsable ? 8U : 0U) |
                    (scheduleUsable && awdlCoexPeerSchedule.shouldPause(now) ? 16U : 0U) |
                    (awdlCoexTxHalted ? 32U : 0U) | (awdlCoexMovePending ? 64U : 0U) |
                    (awdlCoexBaRefillEnabled ? 128U : 0U);
                auto &timeline = awdlCoexBaTimeline;
                timeline.entries[timeline.count++ % CoexBaTimeline::capacity] = {
                    now, sameQueue ? last.uptimeUS : 0, uint32_t(sc->sc_generation), awdlCoexToken,
                    awdlCoexBaPeerEpoch, awdlCoexBaTxNotifs, awdlCoexBaTxAcked, awdlCoexBaRefillFrames,
                    awdlCoexBaEmptyWithReady, awdlCoexBaEmptyNoReady,
                    uint16_t(itlAWDLTransmitQueued(that->getController())),
                    uint16_t(hasQueue ? sc->txq[queue].queued : 0),
                    uint16_t(sameQueue ? last.host : 0), uint16_t(sameQueue ? last.reclaimed : 0),
                    uint16_t(sameQueue ? last.refilled : 0), flags, uint8_t(awdlCoexChannel), awdlCoexBaRefillKicks
                };
                if (now - awdlCoexBaTimelinePublishedUS >= 1000000ULL) {
                    const size_t size = offsetof(CoexBaTimeline, entries) +
                        MIN(timeline.count, CoexBaTimeline::capacity) * sizeof(CoexBaTimelineEntry);
                    if (auto *data = OSData::withBytes(&timeline, size)) {
                        if (IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLCoexBaTimeline", data))
                            awdlCoexBaTimelinePublishedUS = now;
                        data->release();
                    }
                }
            }
        }
        const uint64_t publishNow = awdlUptimeUS();
        if (!awdlStopping && publishNow - awdlCoexLastRoutinePublishUS >= 1000000ULL) {
            awdlCoexLastRoutinePublishUS = publishNow;
            awdlCoexPublish();
        }
    }
    if (!awdlStopping) {
        // Every 2 ms while data moved in the last second, otherwise the sync period.
        const uint64_t timerNowUS = awdlUptimeUS();
        const bool dataActive = awdlCoexData && awdlCoexLastDataUS && timerNowUS - awdlCoexLastDataUS < 1000000ULL;
        unsigned nextMS = dataActive ? 2 : (awdlCoexData ? 20 : unsigned(kAwdlCoexTxPeriodMS));
        if (awdlCoexBaPeerPauseEnabled && running && awdlCoexGeneration == sc->sc_generation &&
            (awdlCoexPeerPause.paused || (awdlCoexPeerBulk.active && awdlCoexScheduleCurrent())))
            nextMS = 1;
        if (awdlCoexGate && awdlCoexGateSinceUS && running && awdlCoexGeneration == sc->sc_generation)
            nextMS = 1;  // Holding for the phone: look again as soon as it may be back.
        if (running && awdlCoexGeneration == sc->sc_generation && awdlCoexData && awdlAwSync &&
            !dataActive && awdlCoexScheduleCurrent()) {
            // Wake for the phone's next AW on our channel, not just every 20 ms.
            const uint64_t untilAW = awdlCoexPeerSchedule.usUntilPresentAw(timerNowUS, awdlCoexAwSyncAssume);
            if (untilAW)
                nextMS = MIN(nextMS, MAX(1U, unsigned(untilAW / 1000)));
        }
        timeout_add_msec(&awdlCoexTxTimer, nextMS);
    }
}

// Sends what macOS queued on awdl0 out the listener's queue, keeping room in the ring for sync frames.
void ItlIwx::
awdlCoexDataPump(struct iwx_softc *sc, unsigned budget)
{
#if defined(ITL_AWDL_NATIVE)
    struct ieee80211com *ic = &sc->sc_ic;
    const int gen = sc->sc_generation;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    if (!awdlCoexData || !awdlCoexTxStaAdded || !awdlCoexAdded || awdlCoexGeneration != gen || awdlCoexTxHalted ||
        awdlStopping || awdlCoexQueue < 0 || awdlCoexQueue >= int(nitems(sc->txq)) || !in || !in->in_phyctxt ||
        ic->ic_state != IEEE80211_S_RUN || ic->ic_opmode != IEEE80211_M_STA)
        return;
    if (awdlUptimeUS() < awdlCoexTxPauseUntilUS) {
        (void)itlAWDLServiceTransmit(getController());
        return;
    }
    ++awdlCoexDataPumps;
    // The firmware's regulatory decision stands: nothing starts on a channel it doesn't allow.
    struct ieee80211_channel *listen = awdlCoexMultiActive ? sc->sc_phyctxt[kAwdlCoexPhyId].channel :
        in->in_phyctxt->channel;
    if (!awdlCoexChannelEligible(ic, listen, "data", gen)) {
        (void)itlAWDLServiceTransmit(getController());
        return;
    }
    const struct iwx_tx_ring &ring = sc->txq[awdlCoexQueue];
    const bool aggregate = awdlCoexBaTxState == kCoexBaTxAgreed && awdlCoexBaTxBulk.bulk && awdlCoexBaPeerAdded &&
        awdlCoexBaTxQueue >= 0 && awdlCoexBaTxQueue < int(nitems(sc->txq));
    // Eligible for the aggregate queue at all: agreed with the peer whose station exists. Payload frames
    // use it before bulk is declared, so the paused-full guard below has to cover that case too.
    const bool aggregateEligible = awdlCoexBaTxState == kCoexBaTxAgreed && awdlCoexBaPeerAdded &&
        awdlCoexBaTxQueue >= 0 && awdlCoexBaTxQueue < int(nitems(sc->txq));
    // iface161 send gate; see awdlCoexGate. It replaces -itlawdlcoexawhold, which held everything and only
    // with a calibrated schedule.
    bool gateClosed = false;
    if (awdlCoexGate && !aggregate && awdlCoexScheduleCurrent()) {
        const uint64_t gateNowUS = awdlUptimeUS();
        const bool dozing = awdlCoexPeerSchedule.presentEntries() <= ItlAWDL::kPeerDozeMaxEntries &&
            (!awdlCoexSchedPeerRxUS || gateNowUS - awdlCoexSchedPeerRxUS > kAwdlGateAwakeUS);
        const auto gate = awdlCoexPeerSchedule.sendGate(gateNowUS, dozing, kAwdlGateAwWindowUS);
        if (gate == ItlAWDL::PeerSchedule::SendGate::Open) {
            awdlCoexGateSinceUS = 0;
            awdlCoexGateKind = 0;
        } else {
            const uint8_t kind = uint8_t(gate);
            if (!awdlCoexGateSinceUS || kind != awdlCoexGateKind) {
                if (!awdlCoexGateSinceUS)
                    ++awdlCoexGateHolds;
                awdlCoexGateSinceUS = gateNowUS;
                awdlCoexGateKind = kind;
                // Away: through the away run (450 ms ceiling). Doze: until the next AW start, with 2 ms spare.
                awdlCoexGateLimitUS = gate == ItlAWDL::PeerSchedule::SendGate::Away ?
                    awdlCoexPeerSchedule.pauseLimitUS(gateNowUS) : awdlCoexPeerSchedule.awUS() + 2000;
            }
            if (gateNowUS - awdlCoexGateSinceUS < awdlCoexGateLimitUS) {
                gateClosed = true;
                if (gate == ItlAWDL::PeerSchedule::SendGate::Away)
                    ++awdlCoexGateAwayTicks;
                else
                    ++awdlCoexGateDozeTicks;
            } else if (awdlCoexGateLimitUS) {
                // The schedule still says no past its own limit: send rather than starve, until it opens.
                ++awdlCoexGateForced;
                awdlCoexGateLimitUS = 0;
            }
        }
    } else {
        awdlCoexGateSinceUS = 0;
        awdlCoexGateKind = 0;
    }
    if (!awdlCoexGate && awdlCoexAwHold && !aggregate && awdlCoexScheduleCurrent()) {
        const uint64_t holdNowUS = awdlUptimeUS();
        if (awdlCoexPeerSchedule.shouldPause(holdNowUS)) {
            if (!awdlCoexHoldSinceUS) {
                awdlCoexHoldSinceUS = holdNowUS;
                awdlCoexHoldLimitUS = awdlCoexPeerSchedule.pauseLimitUS(holdNowUS);
                ++awdlCoexHolds;
            }
            if (holdNowUS - awdlCoexHoldSinceUS < awdlCoexHoldLimitUS) {
                ++awdlCoexHoldTicks;
                (void)itlAWDLServiceTransmit(getController());
                return;
            }
            // The limit passed with the schedule still saying away: send rather than starve. A new hold
            // starts only after the peer is back.
            if (awdlCoexHoldLimitUS) {
                ++awdlCoexHoldForced;
                awdlCoexHoldLimitUS = 0;
            }
        } else {
            awdlCoexHoldSinceUS = 0;
        }
    }
    while (budget && ring.queued < 64 && awdlCoexAdded && awdlCoexGeneration == sc->sc_generation && !awdlStopping) {
        // Leave output queued while the paused aggregate ring is full. Sending it on
        // the listener's single-frame ring would defeat the peer-away pause.
        if (aggregateEligible && awdlCoexPeerPause.paused &&
            uint32_t(sc->txq[awdlCoexBaTxQueue].queued) >= awdlCoexBaTxQueuedCap() &&
            awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.shouldPause(awdlUptimeUS())) {
            ++awdlCoexBaTxPausedFullDeferrals;
            break;
        }
        // Keep payload on the aggregate path through a pause or a full ring. With awdlCoexOrder every
        // unicast frame for that peer waits with it, so nothing overtakes on the single-frame queue.
        const bool holdAggregatePayload = aggregateEligible && (awdlCoexPeerPause.paused ||
            uint32_t(sc->txq[awdlCoexBaTxQueue].queued) >= awdlCoexBaTxQueuedCap());
        mbuf_t next = nullptr;
        // A pause is bounded (450 ms). A full queue isn't, so it holds short frames only while draining.
        const bool draining = awdlCoexBaTxLastNotifUS && awdlUptimeUS() - awdlCoexBaTxLastNotifUS < 1000000ULL;
        const bool holdEverySize = awdlCoexOrder && (awdlCoexPeerPause.paused || draining);
        if (awdlCoexOrder && holdAggregatePayload && !holdEverySize)
            ++awdlCoexOrderStalled;
        // A closed gate holds every frame for the schedule peer; frames for others still go.
        const uint8_t *holdFor = gateClosed ? awdlCoexSchedPeer : holdAggregatePayload ? awdlCoexBaPeer : nullptr;
        if (itlAWDLBuildTransmit(getController(), &next, holdFor, gateClosed || holdEverySize) != kIOReturnSuccess ||
            !next)
            break;
        --budget;
        const uint8_t *nextBytes = static_cast<const uint8_t *>(mbuf_data(next));
        const bool unicast = mbuf_len(next) >= 24 && !(nextBytes[4] & 1);
        if (unicast) {
            if (!ItlAWDL::sameAddress(nextBytes + 4, awdlCoexTxDest)) {
                memcpy(awdlCoexTxDest, nextBytes + 4, sizeof(awdlCoexTxDest));
                awdlCoexBaTxBulk = ItlAWDL::BaTxBulkState{};
            }
            // Count payload-sized frames so incoming TCP ACK bursts do not start bulk TX.
            if (mbuf_len(next) >= 1200)
                ++awdlCoexTxDestFrames;
            if (awdlCoexBaPeerAdded && ItlAWDL::sameAddress(nextBytes + 4, awdlCoexBaPeer))
                awdlCoexBaPeerLastUS = awdlUptimeUS();
        }
        const bool earlyPayload = aggregateEligible && !aggregate && mbuf_len(next) >= 1200;
        // A short frame follows the peer's payload onto the aggregate queue while that queue still holds
        // frames, or took one in the last 300 ms (the same test the pause uses), so order is kept there too.
        const bool followAgg = awdlCoexOrder && aggregateEligible && !aggregate && !earlyPayload &&
            (sc->txq[awdlCoexBaTxQueue].queued > 0 ||
             (awdlCoexBaTxLastAggUS && awdlUptimeUS() - awdlCoexBaTxLastAggUS < 300000ULL));
        if ((aggregate || earlyPayload || followAgg) && !awdlCoexPeerPause.paused &&
            unicast && !mbuf_next(next) && nextBytes[0] == 0x08 &&
            uint32_t(sc->txq[awdlCoexBaTxQueue].queued) < awdlCoexBaTxQueuedCap() &&
            ItlAWDL::sameAddress(nextBytes + 4, awdlCoexBaPeer)) {
            // QoS data on TID 0 with our sequence, on the peer's aggregation queue, at firmware-chosen rates.
            mbuf_t qos = nullptr;
            if (!mbuf_getpacket(MBUF_DONTWAIT, &qos) && qos) {
                const size_t qosLength = ItlAWDL::buildQosData(nextBytes, mbuf_len(next), kAwdlBaTxTid, awdlCoexBaTxSeq,
                                                               static_cast<uint8_t *>(mbuf_data(qos)), mbuf_maxlen(qos));
                if (qosLength) {
                    mbuf_setlen(qos, qosLength);
                    mbuf_pkthdr_setlen(qos, qosLength);
                    auto *aggNode = ieee80211_ref_node(ic->ic_bss);
                    awdlCoexBaSendingAgg = true;
                    const int aggErr = iwx_tx(sc, qos, aggNode, EDCA_AC_BE, awdlCoexBaTxQueue);
                    awdlCoexBaSendingAgg = false;
                    if (!aggErr) {
                        awdlCoexBaTxSeq = (awdlCoexBaTxSeq + 1) & 0xfff;
                        ++awdlCoexBaTxFrames;
                        awdlCoexBaTxLastAggUS = awdlUptimeUS();
                        if (earlyPayload)
                            ++awdlCoexBaEarlyAggFrames; // Counted only once the firmware took it.
                        if (followAgg)
                            ++awdlCoexOrderViaAgg;
                        awdlCoexBaTxPeakQueued = MAX(awdlCoexBaTxPeakQueued, uint32_t(sc->txq[awdlCoexBaTxQueue].queued));
                        ++awdlCoexDataTx;
                        awdlCoexLastDataUS = awdlUptimeUS();
                        mbuf_freem(next);
                        continue;
                    }
                    ieee80211_release_node(ic, aggNode);
                    ++awdlCoexBaTxSubmitErrors;
                } else {
                    mbuf_freem(qos);
                }
            }
            // Couldn't aggregate it: it goes the single-frame way below.
        }
        // What still takes the single-frame queue for the Block Ack peer while its aggregate queue holds
        // frames. With awdlCoexOrder this should stay near zero; without it, it counts the overtaking.
        if (unicast && aggregateEligible && sc->txq[awdlCoexBaTxQueue].queued > 0 &&
            ItlAWDL::sameAddress(nextBytes + 4, awdlCoexBaPeer))
            ++awdlCoexOrderSingleBehindAgg;
        auto *node = ieee80211_ref_node(ic->ic_bss);
        awdlCoexSending = true;
        awdlCoexSendingData = true;
        const int err = iwx_tx(sc, next, node, EDCA_AC_BE, awdlCoexQueue);
        awdlCoexSendingData = false;
        awdlCoexSending = false;
        if (err) {
            ieee80211_release_node(ic, node);
            ++awdlCoexDataTxErrors;
            continue;
        }
        ++awdlCoexDataTx;
        awdlCoexLastDataUS = awdlUptimeUS();
    }
    // Hands macOS back its finished packets, so awdl0's ring keeps moving.
    (void)itlAWDLServiceTransmit(getController());
    if (awdlCoexOrder) {
        const unsigned held = itlAWDLTransmitHeldShort(getController());
        if (held)
            awdlCoexOrderHeld = held;
    }
#endif
}

// Removes the phone's station, with its sessions and its aggregation queue. Returns nonzero if the firmware
// may still hold it; BA is then quarantined for the generation.
int ItlIwx::
awdlCoexBaRemovePeer(struct iwx_softc *sc)
{
    awdlCoexBaRequestsPending.clear();
    awdlCoexBaAnswerLength = 0;
    if (!awdlCoexBaPeerAdded)
        return 0;
    const int gen = sc->sc_generation;
    awdlCoexBaPeerAdded = false;
    awdlCoexBaPeerAccepted = false;
    awdlCoexBaQueueAllocPending = false;
    awdlCoexPeerPause.paused = false;
    awdlCoexResumePending = false;
    awdlCoexPeerBulk = ItlAWDL::PeerBulkState{};
    awdlCoexBaTids = 0;
    awdlCoexBaTidTeardown = 0;
    awdlCoexBaRxIdleTids = 0;
    const int txQueue = awdlCoexBaTxQueue;
    awdlCoexBaTxState = kCoexBaTxOff;
    awdlCoexBaTxQueue = -1;
    awdlCoexBaTxBulk = ItlAWDL::BaTxBulkState{};
    awdlCoexRateStep = 0;
    awdlCoexRateWindowOK = awdlCoexRateWindowFailed = 0;
    int flushErr = 0;
    if (txQueue >= 0)
        flushErr = iwx_flush_sta_tids(sc, kAwdlBaStationId, 0xffff);
    if (gen != sc->sc_generation)
        return 0;
    struct iwx_rm_sta_cmd rm;
    memset(&rm, 0, sizeof(rm));
    rm.sta_id = kAwdlBaStationId;
    const int rmErr = iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm), &rm);
    if (gen != sc->sc_generation)
        return 0;
    // The ring is freed (with its node references) only when the firmware has let go of it.
    if (txQueue >= 0 && txQueue < int(nitems(sc->txq)) && !flushErr && !rmErr) {
        awdlCoexBaTxResetting = txQueue;
        iwx_reset_tx_ring(sc, &sc->txq[txQueue]);
        awdlCoexBaTxResetting = -1;
    }
    if (flushErr || rmErr)
        awdlCoexBaFailedGen = gen;
    if (awdlCoexBaFilterOff || (awdlCoexSameChannelProbe.applied || awdlCoexSameChannelProbe.restorePending)) {
        awdlCoexBaFilterOff = false;
        awdlCoexBaFilter = ItlAWDL::BaFilterState{};
        if (awdlCoexAdded)
            (void)awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_MODIFY);
    }
    return flushErr ? flushErr : rmErr;
}

// The width the peer station and its rate control use: the listener's own context's with it, the station's
// when the listener shares the station's binding (80 MHz for a 5 GHz station at 80 or 160 MHz, else 20).
static int awdlCoexBaWidth(struct ieee80211com *ic)
{
    if (awdlCoexMultiActive)
        return awdlCoexOwnWidth;
    const struct ieee80211_node *ni = ic->ic_bss;
    if (!ni || !ni->ni_chan || IEEE80211_IS_CHAN_2GHZ(ni->ni_chan))
        return 20;
    return ni->ni_chw == IEEE80211_CHAN_WIDTH_80 || ni->ni_chw == IEEE80211_CHAN_WIDTH_160 ? 80 : 20;
}

// Adds the peer station for `peer`, bound to the listener. Nonzero on failure (BA is then quarantined).
int ItlIwx::
awdlCoexBaAddPeer(struct iwx_softc *sc, const uint8_t *peer)
{
    const int gen = sc->sc_generation;
    const int width = awdlCoexBaWidth(&sc->sc_ic);
    struct iwx_add_sta_cmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.sta_id = kAwdlBaStationId;
    cmd.station_type = IWX_STA_LINK;
    cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0));
    IEEE80211_ADDR_COPY(&cmd.addr, peer);
    cmd.tid_disable_tx = htole16(0xffff);
    cmd.station_flags = htole32((width == 80 ? IWX_STA_FLG_FAT_EN_80MHZ : IWX_STA_FLG_FAT_EN_20MHZ) |
                                IWX_STA_FLG_MIMO_EN_MIMO2 |
                                (awdlCoexBaTxEnabled && width == 80 ? IWX_STA_FLG_MAX_AGG_SIZE_1024K :
                                 IWX_STA_FLG_MAX_AGG_SIZE_64K));
    cmd.station_flags_msk = htole32(IWX_STA_FLG_FAT_EN_MSK | IWX_STA_FLG_MIMO_EN_MSK | IWX_STA_FLG_MAX_AGG_SIZE_MSK |
                                    IWX_STA_FLG_AGG_MPDU_DENS_MSK);
    uint32_t status = IWX_ADD_STA_SUCCESS;
    const int err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
    if (gen != sc->sc_generation)
        return ECANCELED;
    awdlCoexBaStatus = err ? 0x80000000U | uint32_t(err) : status;
    if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
        // A transport failure doesn't say whether the station exists.
        awdlCoexBaFailedGen = gen;
        return err ? err : EIO;
    }
    awdlCoexBaPeerAdded = true;
    awdlCoexBaPeerWidth = uint32_t(width);
    awdlCoexBaPeerAccepted = false;
    awdlCoexBaQueueAllocPending = false;
    ++awdlCoexBaPeerEpoch;
    awdlCoexDelbaWaitTid = -1;
    memset(awdlCoexBaRxTidLastUS, 0, sizeof(awdlCoexBaRxTidLastUS));
    awdlCoexPeerPause.paused = false;
    awdlCoexResumePending = false;
    awdlCoexResumeRetryUS = 0;
    awdlCoexResumeFailStreak = 0;
    awdlCoexPeerPause.holdOffUntilUS = 0;
    awdlCoexPeerBulk = ItlAWDL::PeerBulkState{};
    ++awdlCoexBaTxToken;
    awdlCoexBaTxRestUntilUS = 0;
    awdlCoexBaProbeTried = false;
    awdlCoexBaProbeUntilUS = awdlCoexBaLastRxPayloadUS = awdlCoexBaTxLastAggUS = 0;
    memcpy(awdlCoexBaPeer, peer, sizeof(awdlCoexBaPeer));
    awdlCoexBaRequestsPending.keepPeer(peer);
    awdlCoexBaPeerLastUS = awdlUptimeUS();
    return 0;
}

// Sends one of our 33-byte Block Ack frames from the listener's queue, tagged as management.
bool ItlIwx::
awdlCoexSendMgmt(struct iwx_softc *sc, const uint8_t *frame, size_t length, uint8_t kind)
{
    struct ieee80211com *ic = &sc->sc_ic;
    if (awdlUptimeUS() < awdlCoexTxPauseUntilUS)
        return false;
    if (awdlCoexQueue < 0 || awdlCoexQueue >= int(nitems(sc->txq)) || sc->txq[awdlCoexQueue].queued >= 64)
        return false;
    mbuf_t m = nullptr;
    if (mbuf_getpacket(MBUF_DONTWAIT, &m) || !m)
        return false;
    if (mbuf_maxlen(m) < length) {
        mbuf_freem(m);
        return false;
    }
    memcpy(mbuf_data(m), frame, length);
    mbuf_setlen(m, length);
    mbuf_pkthdr_setlen(m, length);
    auto *node = ieee80211_ref_node(ic->ic_bss);
    awdlCoexSending = true;
    awdlCoexSendingData = true;
    awdlCoexSendingMgmt = kind;
    // ADDBA: the dialog token. DELBA: the TID, from its parameter field.
    awdlCoexSendingMgmtToken = kind == kCoexSlotDelba ? uint8_t(frame[27] >> 4) : (length > 26 ? frame[26] : 0);
    const int err = iwx_tx(sc, m, node, EDCA_AC_BE, awdlCoexQueue);
    awdlCoexSendingMgmt = 0;
    awdlCoexSendingData = false;
    awdlCoexSending = false;
    if (err) {
        ieee80211_release_node(ic, node);
        return false;
    }
    return true;
}

// Only the AWDL peer station's aggregate queue is paused. The listener's
// management and single-frame queues, and the infrastructure station, stay live.
void ItlIwx::
awdlCoexBaPauseStep(struct iwx_softc *sc)
{
    if (!awdlCoexBaPeerPauseEnabled || !awdlCoexBaPeerAdded || !awdlCoexAdded || awdlCoexResumePending ||
        awdlCoexBaGen != sc->sc_generation || awdlCoexGeneration != sc->sc_generation)
        return;

    const uint64_t now = awdlUptimeUS();
    const bool bulk = awdlCoexPeerBulk.note(now, awdlCoexBaTxFrames);
    // While aggregate frames are moving: in bulk, or within 300 ms of an aggregate submission.
    const bool aggActive = bulk || awdlCoexBaTxBulk.bulk ||
        (awdlCoexBaTxLastAggUS && now - awdlCoexBaTxLastAggUS < 300000ULL);
    // iface161: frames already in the aggregate queue are held through the phone's away time too.
    const bool queuedForPeer = awdlCoexGate && awdlCoexBaTxQueue >= 0 && awdlCoexBaTxQueue < int(nitems(sc->txq)) &&
        sc->txq[awdlCoexBaTxQueue].queued > 0;
    const bool want = (aggActive || queuedForPeer) && awdlCoexBaTxState == kCoexBaTxAgreed &&
        !awdlCoexMovePending && !awdlCoexTxHalted && awdlCoexScheduleCurrent() &&
        awdlCoexPeerSchedule.shouldPause(now);
    const auto before = awdlCoexPeerPause;
    const int change = awdlCoexPeerPause.step(want, now, awdlCoexPeerSchedule.pauseLimitUS(now));
    if (!change)
        return;
    if (change > 0 && !aggActive)
        ++awdlCoexGateQueuedPauses;

    struct iwx_add_sta_cmd cmd = {};
    cmd.sta_id = kAwdlBaStationId;
    cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0));
    cmd.add_modify = IWX_STA_MODE_MODIFY;
    cmd.station_flags = htole32(change > 0 ? IWX_STA_FLG_DISABLE_TX : 0);
    cmd.station_flags_msk = htole32(IWX_STA_FLG_DISABLE_TX);
    if (change > 0) {
        if (iwx_send_cmd_pdu(sc, IWX_ADD_STA, IWX_CMD_ASYNC, sizeof(cmd), &cmd)) {
            awdlCoexPeerPause = before;
            ++awdlCoexPeerPause.commandErrors;
        }
        return;
    }
    // A resume must take: a station left with transmit disabled blocks everything to the peer. Confirmed
    // with the firmware's status. The result applies only to the same listener, peer and generation it was
    // sent for. A failure keeps the pause recorded and retries after 50 ms; after 5 in a row the peer
    // station is retired, which removes its transmit state with it.
    if (now < awdlCoexResumeRetryUS) {
        awdlCoexPeerPause = before;
        return;
    }
    const int gen = sc->sc_generation;
    const uint32_t tok = awdlCoexToken;
    const uint32_t epoch = awdlCoexBaPeerEpoch;
    uint8_t peer[6];
    memcpy(peer, awdlCoexBaPeer, sizeof(peer));
    const auto resumed = awdlCoexPeerPause;
    awdlCoexPeerPause = before;
    awdlCoexResumePending = true;
    uint32_t status = IWX_ADD_STA_SUCCESS;
    const int err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
    if (gen != sc->sc_generation || tok != awdlCoexToken || !awdlCoexBaPeerAdded || epoch != awdlCoexBaPeerEpoch ||
        !ItlAWDL::sameAddress(peer, awdlCoexBaPeer))
        return; // A newer owner's state stands; removal or replacement already cleared the pause.
    awdlCoexResumePending = false;
    if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
        ++awdlCoexPeerPause.commandErrors;
        ++awdlCoexPauseResumeFailures;
        awdlCoexResumeRetryUS = awdlUptimeUS() + 50000ULL;
        if (++awdlCoexResumeFailStreak >= 5) {
            awdlCoexResumeFailStreak = 0;
            ++awdlCoexResumeRetirements;
            (void)awdlCoexBaRemovePeer(sc);
        }
        return;
    }
    awdlCoexPeerPause = resumed;
    awdlCoexResumeFailStreak = 0;
}

static bool awdlVht80TwoStream(uint32_t rate)
{
    constexpr uint32_t mask = IWX_RATE_MCS_MOD_TYPE_MSK | IWX_RATE_MCS_CHAN_WIDTH_MSK | IWX_RATE_MCS_NSS_MSK;
    constexpr uint32_t mode = IWX_RATE_MCS_VHT_MSK | IWX_RATE_MCS_CHAN_WIDTH_80 | IWX_RATE_MCS_NSS_MSK;
    return (rate & mask) == mode;
}

// From the coex task. Receive BA: the phone's ADDBA request gets the peer station and a firmware session,
// then an answer. Send BA: a bulk stream to one peer gets the station, an aggregation queue and our ADDBA
// request. Every firmware wait is followed by a check that the same listener and generation still hold,
// before any further command or state change.
void ItlIwx::
awdlCoexBaHandle(struct iwx_softc *sc)
{
#if defined(ITL_AWDL_NATIVE)
    const int gen = sc->sc_generation;
    if (awdlCoexBaGen != gen) {
        awdlCoexBaGen = gen;
        awdlCoexBaRequestsPending.clear();
        awdlCoexBaPeerAdded = false;
        awdlCoexBaPeerAccepted = false;
        awdlCoexBaTids = 0;
        awdlCoexBaTidTeardown = 0;
        awdlCoexBaRxIdleTids = 0;
        awdlCoexBaAnswerLength = 0;
        awdlCoexBaTxState = kCoexBaTxOff;
        awdlCoexBaTxQueue = -1;
    }
    // On the listener's own context, or on the station's when it shares that (unless -itlawdlnosharedba).
    if (!awdlCoexData || !awdlCoexAdded || (!awdlCoexMultiActive && awdlCoexNoSharedBa) || !awdlCoexTxStaAdded ||
        awdlCoexTxHalted ||
        awdlCoexBaFailedGen == gen || awdlCoexMovePending || awdlCoexGeneration != gen || !awdlCoexAddrKnown) {
        awdlCoexBaRequestsPending.clear();
        return;
    }
    const uint32_t tok = awdlCoexToken;
    auto stillOurs = [&]() { return gen == sc->sc_generation && tok == awdlCoexToken && awdlCoexAdded &&
                                    awdlCoexBaFailedGen != gen; };
    const uint64_t now = awdlUptimeUS();
    // Keep the station and TX agreement while the peer is still known and
    // has exchanged data in the last ten minutes.
    if (awdlCoexBaPeerAdded && awdlCoexBaRequestsPending.empty()) {
        const bool expired = !awdlCoexPeerKnown(awdlCoexBaPeer, now);
        const bool idle = now - awdlCoexBaPeerLastUS > 600000000ULL;
        if (expired || idle) {
            awdlCoexBaEvent('X', expired ? 1U : 2U, awdlCoexBaTxState, 0);
            (void)awdlCoexBaRemovePeer(sc);
            return;
        }
    }
    const auto rxTidIdle = [&](unsigned tid) {
        const uint64_t last = awdlCoexBaRxTidLastUS[tid];
        return last && now >= last && now - last > 60000000ULL;
    };
    const auto waitingForDelba = [&]() {
        return awdlCoexDelbaWaitTid >= 0 && awdlCoexDelbaWaitGen == gen &&
            awdlCoexDelbaWaitEpoch == awdlCoexBaPeerEpoch;
    };
    if (awdlCoexBaPeerAdded) {
        uint8_t idle = 0;
        for (unsigned tid = 0; tid < 8; ++tid) {
            const uint8_t bit = uint8_t(1U << tid);
            const bool submitted = waitingForDelba() && awdlCoexDelbaWaitTid == int(tid) && awdlCoexDelbaTries;
            const bool requested = awdlCoexBaRequestsPending.has(tid) ||
                (awdlCoexBaAnswerLength && awdlCoexBaAnswerTid == tid);
            if ((awdlCoexBaRxIdleTids & bit) && !submitted && (!rxTidIdle(tid) || requested)) {
                awdlCoexBaRxIdleTids &= uint8_t(~bit);
                awdlCoexBaTidTeardown &= uint8_t(~bit);
                if (waitingForDelba() && awdlCoexDelbaWaitTid == int(tid))
                    awdlCoexDelbaWaitTid = -1;
            }
            if ((awdlCoexBaTids & bit) && !(awdlCoexBaTidTeardown & bit) && !requested && rxTidIdle(tid))
                idle |= bit;
        }
        if (idle) {
            awdlCoexBaTidTeardown |= idle;
            awdlCoexBaRxIdleTids |= idle;
            ++awdlCoexBaRxIdleTeardowns;
        }
    }
    struct iwx_add_sta_cmd cmd;
    uint32_t status;
    int err;
    const uint32_t macColor = IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0);
    const uint8_t teardown = awdlCoexBaTidTeardown & awdlCoexBaTids;
    if (awdlCoexBaPeerAdded && teardown) {
        const uint8_t remote = teardown & ~awdlCoexBaRxIdleTids;
        const uint8_t active = waitingForDelba() ? teardown & (1U << awdlCoexDelbaWaitTid) : 0;
        const unsigned tid = unsigned(__builtin_ctz(remote ? remote : active ? active : teardown));
        const uint8_t bit = uint8_t(1U << tid);
        const bool local = awdlCoexBaRxIdleTids & bit;
        bool retire = !local;
        if (local) {
            if (!waitingForDelba() || awdlCoexDelbaWaitTid != int(tid)) {
                awdlCoexDelbaWaitTid = int(tid);
                awdlCoexDelbaWaitEpoch = awdlCoexBaPeerEpoch;
                awdlCoexDelbaWaitGen = gen;
                awdlCoexDelbaTries = 0;
                awdlCoexDelbaResult = 0;
                awdlCoexDelbaAttemptId = 0;
                awdlCoexDelbaDeadlineUS = now + 3000000ULL;
                awdlCoexDelbaNextTryUS = 0;
            }
            if (awdlCoexDelbaResult == 1) {
                ++awdlCoexDelbaConfirmed;
                retire = true;
            } else if (now >= awdlCoexDelbaDeadlineUS || (awdlCoexDelbaResult == 2 && awdlCoexDelbaTries >= 3)) {
                ++awdlCoexDelbaForced;
                awdlCoexBaEvent('F', tid, awdlCoexDelbaTries, now >= awdlCoexDelbaDeadlineUS ? 1 : 0,
                                0, awdlCoexDelbaAttemptId);
                retire = true;
            } else if ((awdlCoexDelbaTries == 0 || awdlCoexDelbaResult == 2) && now >= awdlCoexDelbaNextTryUS) {
                static const uint8_t kDelbaBssid[6] = {0x00, 0x25, 0x00, 0xff, 0x94, 0x73};
                uint8_t delba[ItlAWDL::kDelbaLength];
                if (now >= awdlCoexTxPauseUntilUS &&
                    ItlAWDL::buildDelba(delba, sizeof(delba), awdlCoexBaPeer, awdlCoexAddr, kDelbaBssid,
                                       uint8_t(tid), false, 39, ++awdlCoexBaSequence) &&
                    awdlCoexSendMgmt(sc, delba, sizeof(delba), kCoexSlotDelba)) {
                    ++awdlCoexBaDelbasSent;
                    ++awdlCoexDelbaTries;
                    awdlCoexDelbaResult = 0;
                    awdlCoexDelbaAttemptId = awdlCoexLastMgmtEnqueueId;
                    awdlCoexDelbaNextTryUS = now + 300000ULL;
                    awdlCoexBaEvent('L', tid, awdlCoexDelbaTries, 0, 0, awdlCoexDelbaAttemptId);
                } else {
                    awdlCoexDelbaNextTryUS = now + 100000ULL;
                }
                if (!stillOurs())
                    return;
            }
        }
        if (retire) {
            if (waitingForDelba() && awdlCoexDelbaWaitTid == int(tid))
                awdlCoexDelbaWaitTid = -1;
            memset(&cmd, 0, sizeof(cmd));
            cmd.sta_id = kAwdlBaStationId;
            cmd.mac_id_n_color = htole32(macColor);
            cmd.add_modify = IWX_STA_MODE_MODIFY;
            cmd.remove_immediate_ba_tid = uint8_t(tid);
            cmd.modify_mask = IWX_STA_MODIFY_REMOVE_BA_TID;
            status = IWX_ADD_STA_SUCCESS;
            err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
            if (!stillOurs())
                return;
            if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
                awdlCoexBaStatus = err ? 0x80000000U | uint32_t(err) : status;
                awdlCoexBaFailedGen = gen;
                return;
            }
            awdlCoexBaTids &= uint8_t(~bit);
            awdlCoexBaTidTeardown &= uint8_t(~bit);
            awdlCoexBaRxIdleTids &= uint8_t(~bit);
            awdlCoexBaRxTidLastUS[tid] = 0;
            if (local)
                ++awdlCoexDelbaRxTidRemoved;
            return;
        }
    }
    awdlCoexBaTidTeardown &= awdlCoexBaTids;
    // A fresh request for the retiring session waits, while other BA work continues.
    ItlAWDL::AddbaRequest request;
    if (!awdlCoexBaAnswerLength && awdlCoexBaRequestsPending.take(awdlCoexBaTidTeardown, request)) {
        if (awdlCoexBaPeerAdded && !ItlAWDL::sameAddress(request.peer, awdlCoexBaPeer)) {
            ++awdlCoexBaOtherPeer;
            return;
        }
        if (!awdlCoexBaPeerAdded) {
            if (awdlCoexBaAddPeer(sc, request.peer))
                return;
            if (!stillOurs()) {
                (void)awdlCoexBaRemovePeer(sc);
                return;
            }
        }
        const uint8_t tidBit = uint8_t(1U << request.tid);
        if ((awdlCoexBaTids & tidBit) && awdlCoexBaTidToken[request.tid] != request.token) {
            memset(&cmd, 0, sizeof(cmd));
            cmd.sta_id = kAwdlBaStationId;
            cmd.mac_id_n_color = htole32(macColor);
            cmd.add_modify = IWX_STA_MODE_MODIFY;
            cmd.remove_immediate_ba_tid = request.tid;
            cmd.modify_mask = IWX_STA_MODIFY_REMOVE_BA_TID;
            status = IWX_ADD_STA_SUCCESS;
            err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
            if (!stillOurs())
                return;
            if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
                awdlCoexBaStatus = err ? 0x80000000U | uint32_t(err) : status;
                awdlCoexBaFailedGen = gen;
                return;
            }
            awdlCoexBaTids &= uint8_t(~tidBit);
        }
        if (!(awdlCoexBaTids & tidBit)) {
            memset(&cmd, 0, sizeof(cmd));
            cmd.sta_id = kAwdlBaStationId;
            cmd.mac_id_n_color = htole32(macColor);
            cmd.add_modify = IWX_STA_MODE_MODIFY;
            cmd.add_immediate_ba_tid = request.tid;
            cmd.add_immediate_ba_ssn = htole16(request.ssn);
            cmd.rx_ba_window = htole16(request.window);
            cmd.modify_mask = IWX_STA_MODIFY_ADD_BA_TID;
            status = IWX_ADD_STA_SUCCESS;
            err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
            if (!stillOurs())
                return;
            awdlCoexBaStatus = err ? 0x80000000U | uint32_t(err) : status;
            if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS ||
                !(status & IWX_ADD_STA_BAID_VALID_MASK)) {
                awdlCoexBaFailedGen = gen;
                return;
            }
            awdlCoexBaTids |= tidBit;
            awdlCoexBaTidToken[request.tid] = request.token;
            ++awdlCoexBaSessions;
            awdlCoexBaRxTidLastUS[request.tid] = awdlUptimeUS();
        }
        // A DELBA received during the firmware wait takes precedence over this answer.
        if (!(awdlCoexBaTidTeardown & tidBit)) {
            awdlCoexBaAnswerTid = request.tid;
            awdlCoexBaAnswerRetryUS = 0;
            awdlCoexBaAnswerLength = ItlAWDL::buildAddbaResponse(awdlCoexBaAnswer, sizeof(awdlCoexBaAnswer), request,
                                                                 awdlCoexAddr, ++awdlCoexBaSequence);
        }
    }
    const uint64_t answerNow = awdlUptimeUS();
    if (awdlCoexBaAnswerLength && stillOurs() && answerNow >= awdlCoexTxPauseUntilUS &&
        answerNow >= awdlCoexBaAnswerRetryUS) {
        if (awdlCoexSendMgmt(sc, awdlCoexBaAnswer, awdlCoexBaAnswerLength, kCoexSlotBaAnswer)) {
            ++awdlCoexBaAnswers;
            awdlCoexBaAnswerLength = 0;
        } else {
            ++awdlCoexBaAnswerErrors;
            awdlCoexBaAnswerRetryUS = answerNow + 20000ULL;
        }
    }
    // Promiscuous receive off for as long as the peer's station exists (or, with the A/B flag, the old
    // traffic hysteresis). It comes back on when the peer station goes. (PR #57)
    const bool filterWasOff = awdlCoexBaFilterOff;
    bool filterChange = false;
    if (awdlCoexBaFilterHysteresis) {
        filterChange = awdlCoexBaPeerAdded && awdlCoexBaTids && stillOurs() &&
            ItlAWDL::noteBaFilterTraffic(awdlCoexBaFilter, awdlUptimeUS(), awdlCoexDataRxUcast);
    } else if (stillOurs()) {
        const bool receiveSession = awdlCoexBaPeerAdded && awdlCoexBaTids;
        const bool recentRxPayload = awdlCoexBaLastRxPayloadUS &&
            answerNow - awdlCoexBaLastRxPayloadUS < 300000ULL;
        const bool canProbe = receiveSession && !recentRxPayload && awdlCoexBaTxState == kCoexBaTxAsking &&
            !awdlCoexBaTxRestUntilUS;
        if (!canProbe)
            awdlCoexBaProbeUntilUS = 0;
        if (canProbe && !awdlCoexBaProbeTried && awdlCoexBaFilterOff && awdlCoexBaTxAsks >= 3 &&
            awdlCoexBaTxAsks < kAwdlBaTxAsksMax && answerNow >= awdlCoexTxPauseUntilUS &&
            answerNow - awdlCoexBaTxLastAskUS >= 200000ULL &&
            !(awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.shouldPause(answerNow))) {
            // Test reply delivery with promiscuous RX briefly open, once per dialog.
            awdlCoexBaProbeTried = true;
            awdlCoexBaProbeUntilUS = answerNow + 250000ULL;
            awdlCoexBaEvent('P', awdlCoexBaTxToken, awdlCoexBaTxAsks, 0);
        }
        // Off while the peer's station exists, not only while a receive TID is open. A receive TID is torn
        // down after 60 s idle, but the station and our send agreement live for ten minutes. With promiscuous
        // receive on in that gap the firmware does not acknowledge the phone's replies to a send we start, so
        // nothing arrives (DataRxUcast frozen, SYNs unanswered) until the phone opens a session itself, which
        // took about two minutes on 2026-11-15. canProbe (and #47's same-channel window) still applies only to a
        // real receive session. -itlawdlfilterbysession keeps the old rule for an A/B.
        const bool wantOff = (awdlCoexBaFilterBySession ? receiveSession : awdlCoexBaPeerAdded) &&
            answerNow >= awdlCoexBaProbeUntilUS;
        if (wantOff != awdlCoexBaFilterOff) {
            awdlCoexBaFilter.off = wantOff;
            filterChange = true;
        }
    }
    // Restore expired windows even if opening failed with an uncertain firmware state.
    const bool probeWanted = awdlCoexSameChannelProbeWanted(sc, awdlUptimeUS());
    if ((awdlCoexSameChannelProbe.applied && !probeWanted) ||
        (awdlCoexSameChannelProbe.restorePending && !probeWanted))
        filterChange = true;
    if (filterChange) {
        awdlCoexBaFilterOff = awdlCoexBaFilter.off;
        ++awdlCoexBaFilterChanges;
        if (awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_MODIFY) && gen == sc->sc_generation) {
            awdlCoexBaFilterOff = filterWasOff;
            awdlCoexBaFilter.off = awdlCoexBaFilterOff;
        }
        if (!stillOurs())
            return;
    }
    // ---- Send BA (only with -itlawdlcoexbatx).
    if (!awdlCoexBaTxEnabled)
        return;
    if (awdlCoexBaEventLastState != awdlCoexBaTxState) {
        awdlCoexBaEvent('S', unsigned(awdlCoexBaEventLastState & 0xff), unsigned(awdlCoexBaTxState), 0);
        awdlCoexBaEventLastState = awdlCoexBaTxState;
    }
    // Detect outbound payload bursts within a quarter second after BA is ready.
    (void)ItlAWDL::noteBaTxTraffic(awdlCoexBaTxBulk, now, awdlCoexTxDestFrames,
                                  awdlCoexBaTxState == kCoexBaTxAgreed);

    if (!awdlCoexBaPeerAdded) {
        if (!awdlCoexBaTxBulk.bulk || !ItlAWDL::knownAddress(awdlCoexTxDest) ||
            !awdlCoexPeerKnown(awdlCoexTxDest, now))
            return;
        ++awdlCoexBaTxPeerAdds;
        if (awdlCoexBaAddPeer(sc, awdlCoexTxDest))
            return;
        if (!stillOurs()) {
            (void)awdlCoexBaRemovePeer(sc);
            return;
        }
    }
    // Dedicated mode negotiates as soon as the peer ACKs our receive BA answer.
    // Keep the bulk trigger for peers that have not opened an inbound session.
    if (!awdlCoexBaPeerAccepted &&
        (!awdlCoexBaTxBulk.bulk || !ItlAWDL::sameAddress(awdlCoexTxDest, awdlCoexBaPeer)))
        return;
    if (awdlCoexBaTxState == kCoexBaTxOff) {
        if (awdlCoexBaQueueAllocPending)
            return;
        awdlCoexBaQueueAllocPending = true;
        const CoexBaQueueOwner owner{gen, tok, awdlCoexBaPeerEpoch};
        const int queue = iwx_tvqm_enable_txq(sc, kAwdlBaTxTid, 0, IWX_DEFAULT_QUEUE_SIZE, kAwdlBaStationId, &owner);
        if (!stillOurs() || !awdlCoexBaQueueCurrent(gen, tok, owner.peer))
            return;
        awdlCoexBaTxQueueResult = queue < 0 ? 0x80000000U | uint32_t(-queue) : uint32_t(queue);
        if (queue < 0) {
            awdlCoexBaQueueAllocPending = false;
            awdlCoexBaTxState = kCoexBaTxFailed;
            return;
        }
        awdlCoexBaTxQueue = queue;
        awdlCoexBaTxSeq = uint16_t(sc->txq[queue].cur) & 0xfff;
        // Firmware rate control for the peer's station: high rates only, VHT 80 MHz when the peer station is.
        const bool before80 = awdlBaTx80Active;
        awdlBaTx80Active = awdlCoexBaPeerWidth == 80;
        awdlBaTlc = true;
        err = iwx_rs_init(sc, reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss), true);
        awdlBaTlc = false;
        awdlBaTx80Active = before80;
        if (!stillOurs() || !awdlCoexBaQueueCurrent(gen, tok, owner.peer))
            return;
        awdlCoexBaQueueAllocPending = false;
        if (err) {
            awdlCoexBaTxQueueResult = 0x40000000U | uint32_t(err);
            awdlCoexBaTxState = kCoexBaTxFailed;
            return;
        }
        awdlCoexBaTxState = kCoexBaTxAsking;
        awdlCoexBaTxAsks = 0;
        awdlCoexBaTxLastAskUS = 0;
    }
    if (awdlCoexBaTxState == kCoexBaTxEnabling && awdlCoexBaPeerAdded) {
        if (now < awdlCoexTxPauseUntilUS)
            return;
        const uint8_t dialog = awdlCoexBaTxToken;
        memset(&cmd, 0, sizeof(cmd));
        cmd.sta_id = kAwdlBaStationId;
        cmd.mac_id_n_color = htole32(macColor);
        cmd.add_modify = IWX_STA_MODE_MODIFY;
        cmd.tid_disable_tx = htole16(uint16_t(0xffff & ~(1U << kAwdlBaTxTid)));
        cmd.modify_mask = IWX_STA_MODIFY_TID_DISABLE_TX;
        status = IWX_ADD_STA_SUCCESS;
        err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
        if (!stillOurs())
            return;
        awdlCoexBaTxAggEnableStatus = err ? 0x80000000U | uint32_t(err) : status;
        if (awdlCoexBaTxState == kCoexBaTxEnabling && dialog == awdlCoexBaTxToken) {
            awdlCoexBaTxState = !err && (status & IWX_ADD_STA_STATUS_MASK) == IWX_ADD_STA_SUCCESS
                ? kCoexBaTxAgreed : kCoexBaTxFailed;
        }
        return;
    }
    if (awdlCoexBaTxState != kCoexBaTxAsking)
        return;
    const uint64_t askNow = awdlUptimeUS();
    // Idle peer, no bulk send: hold, and let the next data start a fresh round without waiting out a rest.
    if (!awdlCoexBaTxBulk.bulk && askNow - awdlCoexBaPeerLastUS > kAwdlCoexBaIdleAskUS) {
        if (awdlCoexBaTxAsks || awdlCoexBaTxRestUntilUS) {
            awdlCoexBaTxAsks = 0;
            awdlCoexBaTxRestUntilUS = 0;
            ++awdlCoexBaTxIdleHolds;
        }
        return;
    }
    if (awdlCoexBaTxRestUntilUS && askNow < awdlCoexBaTxRestUntilUS)
        return;
    awdlCoexBaTxRestUntilUS = 0;
    if (awdlCoexBaTxLastAskUS && askNow - awdlCoexBaTxLastAskUS < 200000ULL)
        return;
    // A calibrated schedule can rule out this window. Otherwise keep the ordinary retry cadence.
    if (awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.shouldPause(askNow)) {
        ++awdlCoexBaAsksSkippedAway;
        ++awdlCoexAskSkipsSinceLast;
        return;
    }
    if (awdlCoexBaTxAsks >= kAwdlBaTxAsksMax) {
        awdlCoexBaTxAsks = 0;
        ++awdlCoexBaTxToken;
        awdlCoexBaProbeTried = false;
        awdlCoexBaProbeUntilUS = 0;
        ++awdlCoexBaTxAskRounds;
        awdlCoexBaTxRestUntilUS = askNow + kAwdlBaTxRestUS;
        return;
    }
    if (askNow < awdlCoexTxPauseUntilUS)
        return;
    static const uint8_t kBssid[6] = {0x00, 0x25, 0x00, 0xff, 0x94, 0x73};
    uint8_t ask[ItlAWDL::kAddbaResponseLength];
    const size_t askLength = ItlAWDL::buildAddbaRequest(ask, sizeof(ask), awdlCoexBaPeer, awdlCoexAddr, kBssid,
        awdlCoexBaTxToken, kAwdlBaTxTid, ItlAWDL::kBaWindowMax, awdlCoexBaTxSeq, ++awdlCoexBaSequence);
    if (askLength && awdlCoexSendMgmt(sc, ask, askLength, kCoexSlotBaAsk)) {
        awdlCoexBaTxLastAskUS = askNow;
        ++awdlCoexBaTxAsks;
        awdlCoexBaEvent('A', awdlCoexBaTxToken, awdlCoexBaTxSeq,
                        (awdlCoexBaFilterOff ? 1U : 0U) |
                        (awdlCoexScheduleCurrent() && awdlCoexPeerSchedule.known() &&
                         awdlCoexPeerSchedule.fresh(askNow) ? 2U : 0U) |
                        (awdlCoexBaTids ? 4U : 0U),
                        MIN(awdlCoexAskSkipsSinceLast, 255U), awdlCoexLastMgmtEnqueueId);
        awdlCoexAskSkipsSinceLast = 0;
    }
#endif
}

void ItlIwx::
awdlRxTask(void *arg)
{
    struct iwx_softc *sc = (struct iwx_softc *)arg;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (awdlStopping)
        return;
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                awdlRxTask(arg0);
                return kIOReturnSuccess;
            }, arg);
        return;
    }
    if (awdlStopping)
        return;
    struct ieee80211com *ic = &sc->sc_ic;
    const bool running = ic->ic_opmode == IEEE80211_M_MONITOR && ic->ic_state == IEEE80211_S_RUN &&
        (sc->sc_flags & IWX_FLAG_MAC_ACTIVE) && sc->sc_phyctxt[0].channel;
    if (running && awdlRadioProbe && !awdlBackgroundScanActive) {
        static uint64_t lastRequestUS;
        const uint64_t nowUS = awdlUptimeUS();
        if (!lastRequestUS || nowUS - lastRequestUS >= 2000000) {
            lastRequestUS = nowUS;
            struct iwx_statistics_cmd request = {};
            ++awdlRadioRequests;
            if (that->iwx_send_cmd_pdu(sc, IWX_STATISTICS_CMD, IWX_CMD_ASYNC, sizeof(request), &request))
                ++awdlRadioRequestErrors;
        }
    }
    // A fast timer must not flush the event ring with periodic summaries.
    static uint64_t lastSummaryUS;
    const uint64_t summaryNowUS = awdlUptimeUS();
    if (!awdlPeerTrain || !lastSummaryUS || summaryNowUS - lastSummaryUS >= 6000000) {
    lastSummaryUS = summaryNowUS;
    awdlLog("mode %d state %d ch %d: all %u mgmt %u beacon %u psf %u mif %u other %u peers %u lastch %d rssi %d\n",
          ic->ic_opmode, ic->ic_state, running ? ieee80211_chan2ieee(ic, sc->sc_phyctxt[0].channel) : -1,
          awdlRxStat.all, awdlRxStat.mgmt, awdlRxStat.beacon, awdlRxStat.psf, awdlRxStat.mif, awdlRxStat.other,
          awdlRxPeerCount, awdlRxStat.lastChan, awdlRxStat.lastRssi);
    awdlRxStat.all = awdlRxStat.mgmt = awdlRxStat.beacon = awdlRxStat.psf = awdlRxStat.mif = awdlRxStat.other = 0;
    awdlLog("decoded sync %u invalid/unsupported %u\n", awdlRxStat.syncValid, awdlRxStat.syncInvalid);
    awdlRxStat.syncValid = awdlRxStat.syncInvalid = 0;
    awdlRxStat.logged = 0;
    static uint64_t lastDataCounters = ~0ULL;
    const uint64_t dataCounters = uint64_t(awdlRxStat.dataIPv6) + awdlRxStat.dataMalformed + awdlRxStat.dataUnsupported;
    if (dataCounters != lastDataCounters) {
        lastDataCounters = dataCounters;
        auto *root = IORegistryEntry::getRegistryRoot();
        root->setProperty("ITLAWDLDataIPv6Frames", awdlRxStat.dataIPv6, 32);
        root->setProperty("ITLAWDLDataMalformed", awdlRxStat.dataMalformed, 32);
        root->setProperty("ITLAWDLDataUnsupported", awdlRxStat.dataUnsupported, 32);
    }
    {
        auto *root = IORegistryEntry::getRegistryRoot();
        root->setProperty("ITLAWDLHeardSelfEchoes", awdlSeen.selfEchoes, 32);
        root->setProperty("ITLAWDLHeardActionToUs", awdlSeen.actionToUs, 32);
        root->setProperty("ITLAWDLHeardActionMentions", awdlSeen.actionMentions, 32);
        root->setProperty("ITLAWDLHeardDataMulticast", awdlSeen.dataMulticast, 32);
        root->setProperty("ITLAWDLHeardDataToUs", awdlSeen.dataToUs, 32);
        root->setProperty("ITLAWDLHeardDataToOther", awdlSeen.dataToOther, 32);
        root->setProperty("ITLAWDLHeardDataMDNS", awdlSeen.dataMDNS, 32);
        root->setProperty("ITLAWDLTrainSubmitted", that->awdlMonitorSubmitted, 32);
        root->setProperty("ITLAWDLDataRateMbps", ItlAWDL::dataRateMbps(awdlDataRate.step), 32);
            root->setProperty("ITLAWDLTxKicks", awdlTxKicks, 32);
            root->setProperty("ITLAWDLResendSent", awdlResendSent, 32);
            root->setProperty("ITLAWDLResendRecovered", awdlResendRecovered, 32);
            root->setProperty("ITLAWDLResendGaveUp", awdlResendGaveUp, 32);
            if (auto *rateResults = OSData::withBytes(awdlRateResults, sizeof(awdlRateResults))) {
                root->setProperty("ITLAWDLTxRateResults", rateResults);
                rateResults->release();
            }
        root->setProperty("ITLAWDLFixedChannel", awdlFixedChannel, 32);
        root->setProperty("ITLAWDLBtCoexMode", ItlAWDL::btCoexModeFor(awdlBtCoexRequest, IWX_BT_COEX_WIFI), 32);
        root->setProperty("ITLAWDLRequestedCountry", awdlCountry);
        root->setProperty("ITLAWDLCountryScans", awdlCountryScans, 32);
        root->setProperty("ITLAWDLBackgroundScans", awdlBackgroundScans, 32);
        root->setProperty("ITLAWDLMovesUp", awdlMovesUp, 32);
        root->setProperty("ITLAWDLMovesDown", awdlMovesDown, 32);
        root->setProperty("ITLAWDLLastMoveMs", awdlChannelMove.lastMoveMs, 32);
        root->setProperty("ITLAWDLMulticastCopies", awdlMulticastCopies, 32);
        root->setProperty("ITLAWDLMulticastRepeatsSent", awdlMulticastRepeatsSent, 32);
        root->setProperty("ITLAWDLMulticastOverwritten", awdlMulticastRepeats.overwritten, 32);
        root->setProperty("ITLAWDLTxWindow", awdlWindow, 32);
        root->setProperty("ITLAWDLIntCoalescing", awdlIntCoalescing, 32);
        root->setProperty("ITLAWDLFlightSumUS", awdlFlightSumUS, 64);
        root->setProperty("ITLAWDLIdleSumUS", awdlIdleSumUS, 64);
        if (auto *o = OSData::withBytes(awdlFlightOK, sizeof(awdlFlightOK))) { root->setProperty("ITLAWDLFlightOK", o); o->release(); }
        if (auto *o = OSData::withBytes(awdlFlightFail, sizeof(awdlFlightFail))) { root->setProperty("ITLAWDLFlightFail", o); o->release(); }
        if (auto *o = OSData::withBytes(&awdlTxService, sizeof(awdlTxService))) { root->setProperty("ITLAWDLTxService", o); o->release(); }
        if (auto *o = OSData::withBytes(&awdlPeerSchedule, sizeof(awdlPeerSchedule))) { root->setProperty("ITLAWDLPeerSchedule", o); o->release(); }
        if (auto *o = OSData::withBytes(&awdlPeerPauseState, sizeof(awdlPeerPauseState))) { root->setProperty("ITLAWDLPeerPause", o); o->release(); }
        root->setProperty("ITLAWDLPeerSyncFrames", awdlPeerSyncFrames, 32);
        root->setProperty("ITLAWDLPeerPauseOn", awdlPeerPause);
        if (awdlAwSync)
            root->setProperty("ITLAWDLAwSyncFrames", awdlAwSyncFrames, 32);
        root->setProperty("ITLAWDLPeerBulkChanges", awdlPeerBulk.changes, 32);
        root->setProperty("ITLAWDLPeerBulkActive", awdlPeerBulk.active);
        // About 80 KB, so only a few times while it fills, and once when full.
        if (awdlTxTrace.count && awdlTxTrace.count != awdlTxTracePublished &&
            (awdlTxTrace.full() || awdlTxTrace.count >= awdlTxTracePublished + 1024)) {
            awdlTxTracePublished = awdlTxTrace.count;
            if (auto *o = OSData::withBytes(&awdlTxTrace, sizeof(awdlTxTrace))) { root->setProperty("ITLAWDLTxTrace", o); o->release(); }
        }
        if (awdlBaTrace.count && awdlBaTrace.count != awdlBaTracePublished &&
            (awdlBaTrace.full() || awdlBaTrace.count >= awdlBaTracePublished + 1024)) {
            awdlBaTracePublished = awdlBaTrace.count;
            if (auto *o = OSData::withBytes(&awdlBaTrace, sizeof(awdlBaTrace))) { root->setProperty("ITLAWDLBaTrace", o); o->release(); }
        }
        if (awdlRadioProbe) {
            root->setProperty("ITLAWDLRadioRequests", awdlRadioRequests, 32);
            root->setProperty("ITLAWDLRadioRequestErrors", awdlRadioRequestErrors, 32);
            root->setProperty("ITLAWDLRadioUnexpectedLengths", awdlRadioUnexpectedLengths, 32);
            root->setProperty("ITLAWDLRadioReports", awdlRadioReports, 32);
            root->setProperty("ITLAWDLRadioLastCommandLength", awdlRadioLastCommandLength, 32);
            root->setProperty("ITLAWDLRadioLastNotificationLength", awdlRadioLastNotificationLength, 32);
            if (awdlRadioReports) {
                root->setProperty("ITLAWDLRadioReportUS", awdlRadioReportUS, 64);
                root->setProperty("ITLAWDLRadioTemperature", awdlRadioTemperature, 32);
                root->setProperty("ITLAWDLRadioRxTime", awdlRadioRxTime, 64);
                root->setProperty("ITLAWDLRadioTxTime", awdlRadioTxTime, 64);
                root->setProperty("ITLAWDLRadioOnTime", awdlRadioOnTime, 64);
            }
            if (auto *o = OSData::withBytes(awdlRadioBeacons, sizeof(awdlRadioBeacons))) {
                root->setProperty("ITLAWDLRadioBeacons", o);
                o->release();
            }
            if (auto *o = OSData::withBytes(awdlRadioOtherData, sizeof(awdlRadioOtherData))) {
                root->setProperty("ITLAWDLRadioOtherData", o);
                o->release();
            }
        }
        root->setProperty("ITLAWDLTxWindowFullExits", awdlTxWindowFullExits, 32);
        root->setProperty("ITLAWDLTxStackEmptyExits", awdlTxStackEmptyExits, 32);
        if (auto *o = OSData::withBytes(awdlSlots6Frames, sizeof(awdlSlots6Frames))) { root->setProperty("ITLAWDLSlots6Frames", o); o->release(); }
        if (auto *o = OSData::withBytes(awdlSlotChanges, unsigned(awdlSlotChangeCount * sizeof(awdlSlotChanges[0])))) { root->setProperty("ITLAWDLSlotChanges", o); o->release(); }
        root->setProperty("ITLAWDLPeerCountryFrames", awdlPeerCountryFrames, 32);
        root->setProperty("ITLAWDLPeerCountryChanges", awdlPeerCountry.changes, 32);
        root->setProperty("ITLAWDLPeerCountryConfirmed", awdlPeerCountry.confirmed, 32);
        root->setProperty("ITLAWDLPeerCountryAsked", awdlPeerCountryAsked ? 1ULL : 0ULL, 32);
        root->setProperty("ITLAWDLBeaconCountryOverflow", awdlBeaconCountryOverflow, 32);
        if (auto *beacons = OSData::withBytes(awdlBeaconCountries, unsigned(awdlBeaconCountryCount * sizeof(awdlBeaconCountries[0])))) {
            root->setProperty("ITLAWDLBeaconCountries", beacons);
            beacons->release();
        }
        if (awdlBaProbe) {
            root->setProperty("ITLAWDLBaStep", awdlBaStep, 32);
            root->setProperty("ITLAWDLBaRequests", awdlBaRequests, 32);
            root->setProperty("ITLAWDLBaOtherPeer", awdlBaOtherPeer, 32);
            root->setProperty("ITLAWDLBaStationStatus", awdlBaStationStatus, 32);
            root->setProperty("ITLAWDLBaSessionStatus", awdlBaSessionStatus, 32);
            root->setProperty("ITLAWDLBaTids", awdlBaTids, 32);
            root->setProperty("ITLAWDLBaResponsesSent", awdlBaResponsesSent, 32);
            root->setProperty("ITLAWDLBaResponsesAcked", awdlBaResponsesAcked, 32);
            root->setProperty("ITLAWDLBaResponseLastStatus", awdlBaResponseLastStatus, 32);
            root->setProperty("ITLAWDLBaRxAmpdu", awdlBaRxAmpdu, 32);
            root->setProperty("ITLAWDLBaStale", awdlBaStale, 32);
            root->setProperty("ITLAWDLBaAttempts", awdlBaAttempts, 32);
            root->setProperty("ITLAWDLBaBssidResult", awdlBaBssidResult, 32);
            root->setProperty("ITLAWDLBaMacType", awdlBaMacType, 32);
            root->setProperty("ITLAWDLRxNoFcs", awdlRxNoFcs, 32);
            root->setProperty("ITLAWDLBaMacAdds", awdlBaMacAdds, 32);
            root->setProperty("ITLAWDLBaMacFellBack", awdlBaMacFellBack, 32);
            root->setProperty("ITLAWDLBaNoPromisc", awdlBaNoPromisc ? 1U : 0U, 32);
            root->setProperty("ITLAWDLBaFilterOff", awdlBaFilterOff ? 1U : 0U, 32);
            root->setProperty("ITLAWDLBaFilterChanges", awdlBaFilterChanges, 32);
            if (awdlBaTx) {
                root->setProperty("ITLAWDLBaTxState", awdlBaTxState, 32);
                root->setProperty("ITLAWDLBaTxAgg", awdlBaTxAgg, 32);
                root->setProperty("ITLAWDLBaRxDelba", awdlBaRxDelba, 32);
                root->setProperty("ITLAWDLBaSessionRestarts", awdlBaSessionRestarts, 32);
                root->setProperty("ITLAWDLBaTxQueuedMax", awdlBaTxQueuedMax, 32);
                root->setProperty("ITLAWDLBaTxQueue", uint32_t(awdlBaTxQueue + 1), 32);
                root->setProperty("ITLAWDLBaTxQueueResult", awdlBaTxQueueResult, 32);
                root->setProperty("ITLAWDLBaTxAsks", awdlBaTxAsks, 32);
                root->setProperty("ITLAWDLBaTxAnswerStatus", awdlBaTxAnswerStatus, 32);
                root->setProperty("ITLAWDLBaTxFrames", awdlBaTxFrames, 32);
                root->setProperty("ITLAWDLBaTxNotifs", awdlBaTxNotifs, 32);
                root->setProperty("ITLAWDLBaTxAskRounds", awdlBaTxAskRounds, 32);
                root->setProperty("ITLAWDLMacApplies", awdlMacApplies, 32);
                root->setProperty("ITLAWDLMacApplyFailures", awdlMacApplyFailures, 32);
                root->setProperty("ITLAWDLMacAddressChanges", awdlMacAddressChanges, 32);
                root->setProperty("ITLAWDLBaTxAsksSkippedAway", awdlBaTxAsksSkippedAway, 32);
                if (awdlBaTx80) {
                    root->setProperty("ITLAWDLBaTx80State", awdlBaTx80State, 32);
                    root->setProperty("ITLAWDLBaTxMinMcs", awdlBaTxMinMcs, 32);
                }
                if (awdlBaTxFixedMcs >= 0) {
                    root->setProperty("ITLAWDLBaTxFixedMcs", uint32_t(awdlBaTxFixedMcs), 32);
                    root->setProperty("ITLAWDLBaTxFixedFrames", awdlBaTxFixedFrames, 32);
                }
                root->setProperty("ITLAWDLBaTxSentAir", awdlBaTxSentAir, 32);
                root->setProperty("ITLAWDLBaTxAcked", awdlBaTxAcked, 32);
                root->setProperty("ITLAWDLBaTxSingles", awdlBaTxSingles, 32);
                root->setProperty("ITLAWDLBaTxDelba", awdlBaTxDelba, 32);
                root->setProperty("ITLAWDLBaTxRefused", awdlBaTxRefused, 32);
                root->setProperty("ITLAWDLBaTxBulk", awdlBaTxBulk.bulk ? 1U : 0U, 32);
                root->setProperty("ITLAWDLBaTxBulkChanges", awdlBaTxBulkChanges, 32);
                root->setProperty("ITLAWDLBaTxBulkSkipped", awdlBaTxBulkSkipped, 32);
            }
            root->setProperty("ITLAWDLBaOffChannel", awdlBaOffChannel, 32);
            root->setProperty("ITLAWDLBaResponsesDone", awdlBaResponsesDone, 32);
            root->setProperty("ITLAWDLBaResponsesRefused", awdlBaResponsesRefused, 32);
        }
        if (awdlRx) {
            const auto &rxCounts = awdlRxSequences.counts;
            if (auto *rxData = OSData::withBytes(&rxCounts, sizeof(rxCounts))) {
                root->setProperty("ITLAWDLRxSequences", rxData);
                rxData->release();
            }
            root->setProperty("ITLAWDLBaBarReleases", awdlBaBarReleases, 32);
        }
        root->setProperty("ITLAWDLCountryNotices", awdlCountryNotices, 32);
        root->setProperty("ITLAWDLCountryAnswers", awdlCountryAnswers, 32);
        root->setProperty("ITLAWDLCountryLastStatus", awdlCountryLastStatus, 32);
        root->setProperty("ITLAWDLCountryLastAnswered", awdlCountryLastAnswered, 32);
        root->setProperty("ITLAWDLChannel149Flags", that->com.sc_ic.ic_channels[149].ic_flags, 32);
        if (awdlDataTx) {
            root->setProperty("ITLAWDLTxMulticastSent", awdlDataSent[0], 32);
            root->setProperty("ITLAWDLTxUnicastSent", awdlDataSent[1], 32);
            root->setProperty("ITLAWDLTxUnicastOK", awdlDataOK[1], 32);
            root->setProperty("ITLAWDLTxUnicastFail", awdlDataFailed[1], 32);
            root->setProperty("ITLAWDLTxLastFailure", awdlDataLastFailure, 32);
            if (ItlAWDL::knownAddress(awdlLastPeer)) {
                uint8_t peerIP[16];
                if (ItlAWDL::sameAddress(awdlLearnedPeer, awdlLastPeer))
                    memcpy(peerIP, awdlLearnedPeerIP, sizeof(peerIP));
                else
                    ItlAWDL::linkLocalFromAddress(awdlLastPeer, peerIP);
                if (auto *address = OSData::withBytes(peerIP, sizeof(peerIP))) {
                    root->setProperty("ITLAWDLPeerLinkLocal", address);
                    address->release();
                }
            }
        }
        root->setProperty("ITLAWDLHeardEchoReply", awdlSeen.dataEchoReply, 32);
        root->setProperty("ITLAWDLHeardNeighborAdvert", awdlSeen.dataNeighbor, 32);
        root->setProperty("ITLAWDLHeardNeighborSolicit", awdlSeen.dataSolicit, 32);
        if (awdlServiceLog.dirty) {
            // Only when something changed: this is about 16 KB.
            awdlServiceLog.dirty = false;
            constexpr uint32_t kept = ItlAWDL::ServiceSnapshotLog::kEntries;
            const uint32_t held = awdlServiceLog.total < kept ? awdlServiceLog.total : kept;
            const uint32_t start = awdlServiceLog.total < kept ? 0 : awdlServiceLog.total % kept;
            static ItlAWDL::ServiceSnapshot ordered[kept];
            for (uint32_t i = 0; i < held; ++i)
                ordered[i] = awdlServiceLog.entries[(start + i) % kept];
            if (auto *changes = OSData::withBytes(ordered, unsigned(held * sizeof(ordered[0])))) {
                root->setProperty("ITLAWDLServiceChanges", changes);
                changes->release();
            }
            root->setProperty("ITLAWDLServiceChangeTotal", awdlServiceLog.total, 32);
        }
        if (awdlNoPeerPsf)
            root->setProperty("ITLAWDLPeerPsfKept", awdlPeerPsfKept, 32);
        if (awdlWide80) {
            root->setProperty("ITLAWDLWide80State", awdlWide80State, 32);
            root->setProperty("ITLAWDLWide80Error", awdlWide80Error, 32);
            root->setProperty("ITLAWDLWide80Live", awdlWide80Live);
            if (awdlTx80) {
                root->setProperty("ITLAWDLTx80Requested", awdlTx80Requested, 32);
                root->setProperty("ITLAWDLTx80Completed", awdlTx80Completed, 32);
                root->setProperty("ITLAWDLTx80Reported", awdlTx80Reported, 32);
                root->setProperty("ITLAWDLTx80Acked", awdlTx80Acked, 32);
                root->setProperty("ITLAWDLTx80Disabled", awdlTx80ConsecutiveMisses >= 8 ? 1U : 0U, 32);
            }
            if (awdlAdvertise80)
                root->setProperty("ITLAWDLAdvertise80Frames", awdlAdvertise80Frames, 32);
        }
        if (awdlServiceMerge) {
            root->setProperty("ITLAWDLSvcMergedFrames", awdlServiceMergedFrames, 32);
            root->setProperty("ITLAWDLSvcMergedRecords", awdlServiceMergedRecords, 32);
            root->setProperty("ITLAWDLSvcMergeRefused", awdlServiceMergeRefused, 32);
            root->setProperty("ITLAWDLSvcMergeLastError", awdlServiceMergeLastError, 32);
            root->setProperty("ITLAWDLSvcCacheRecords", awdlServiceCache.records, 32);
            root->setProperty("ITLAWDLSvcCacheResets", awdlServiceCache.resets, 32);
            root->setProperty("ITLAWDLSvcCacheOverflow", awdlServiceCache.overflow, 32);
        }
        if (awdlMcastUnicast) {
            root->setProperty("ITLAWDLMcastUnicastCopies", awdlMcastUnicastCopies, 32);
            root->setProperty("ITLAWDLMcastUnicastSkipped", awdlMcastUnicastSkipped, 32);
        }
        if (auto *tlvs = OSData::withBytes(awdlPeerTLVs, sizeof(awdlPeerTLVs))) {
            root->setProperty("ITLAWDLPeerTLVCounts", tlvs);
            tlvs->release();
        }
        root->setProperty("ITLAWDLAirAckToAWDL", awdlAir.ackToAWDL, 32);
        root->setProperty("ITLAWDLAirAckToHardware", awdlAir.ackToHardware, 32);
        root->setProperty("ITLAWDLAirUnicastToUs", awdlAir.unicastToUs, 32);
        root->setProperty("ITLAWDLAirUnicastToUsRetried", awdlAir.unicastToUsRetried, 32);
        root->setProperty("ITLAWDLAirAckToForeign", awdlAir.ackToForeign, 32);
        root->setProperty("ITLAWDLAirUnicastToForeign", awdlAir.unicastToForeign, 32);
        root->setProperty("ITLAWDLAirUnicastToForeignRetried", awdlAir.unicastToForeignRetried, 32);
        root->setProperty("ITLAWDLSkipChained", awdlDataSkips.chained, 32);
        root->setProperty("ITLAWDLSkipFrameType", awdlDataSkips.frameType, 32);
        root->setProperty("ITLAWDLSkipBssid", awdlDataSkips.bssid, 32);
        root->setProperty("ITLAWDLSkipLlc", awdlDataSkips.llc, 32);
        root->setProperty("ITLAWDLSkipOther", awdlDataSkips.other, 32);
        root->setProperty("ITLAWDLSkipRetried", awdlDataSkips.retried, 32);
        root->setProperty("ITLAWDLRxOuterHeader", awdlDataSkips.outerHeader, 32);
        root->setProperty("ITLAWDLRxRatesOverflow", awdlRxRatesOverflow, 32);
        if (auto *rxRates = OSData::withBytes(awdlRxRates, sizeof(awdlRxRates))) {
            root->setProperty("ITLAWDLRxRates", rxRates);
            rxRates->release();
        }
        if (auto *skipped = OSData::withBytes(awdlDataSkips.skippedLengths, sizeof(awdlDataSkips.skippedLengths))) {
            root->setProperty("ITLAWDLSkipLengths", skipped);
            skipped->release();
        }
        if (auto *parsedLengths = OSData::withBytes(awdlDataSkips.parsedLengths, sizeof(awdlDataSkips.parsedLengths))) {
            root->setProperty("ITLAWDLParsedLengths", parsedLengths);
            parsedLengths->release();
        }
        if (auto *types = OSData::withBytes(awdlAir.typesToUs, sizeof(awdlAir.typesToUs))) {
            root->setProperty("ITLAWDLAirTypesToUs", types);
            types->release();
        }
        if (awdlPeerProbeCount) {
            // Last two address bytes only; these addresses are random per session.
            static char table[8 * 48];
            size_t used = 0;
            for (unsigned i = 0; i < awdlPeerProbeCount && used < sizeof(table); i++) {
                const auto &p = awdlPeerProbes[i];
                used += snprintf(table + used, sizeof(table) - used, "..:%02x:%02x acks %u of %u rssi %d; ",
                                 p.address[4], p.address[5], p.acked, p.tries, p.rssi);
            }
            root->setProperty("ITLAWDLAckPeers", table);
        }
        if (awdlAckProbe) {
            static const char *const acked[] = {"ITLAWDLAckPeerAWDLOK", "ITLAWDLAckPeerHardwareOK", "ITLAWDLAckControlAWDLOK", "ITLAWDLAckControlHardwareOK", "ITLAWDLAckPeerNeighborOK", "ITLAWDLAckPeerEchoOK", "ITLAWDLAckPeerForeignOK"};
            static const char *const failed[] = {"ITLAWDLAckPeerAWDLFail", "ITLAWDLAckPeerHardwareFail", "ITLAWDLAckControlAWDLFail", "ITLAWDLAckControlHardwareFail", "ITLAWDLAckPeerNeighborFail", "ITLAWDLAckPeerEchoFail", "ITLAWDLAckPeerForeignFail"};
            static const char *const retries[] = {"ITLAWDLAckPeerAWDLRetries", "ITLAWDLAckPeerHardwareRetries", "ITLAWDLAckControlAWDLRetries", "ITLAWDLAckControlHardwareRetries", "ITLAWDLAckPeerNeighborRetries", "ITLAWDLAckPeerEchoRetries", "ITLAWDLAckPeerForeignRetries"};
            static const char *const last[] = {"ITLAWDLAckPeerAWDLLastFailure", "ITLAWDLAckPeerHardwareLastFailure", "ITLAWDLAckControlAWDLLastFailure", "ITLAWDLAckControlHardwareLastFailure", "ITLAWDLAckPeerNeighborLastFailure", "ITLAWDLAckPeerEchoLastFailure", "ITLAWDLAckPeerForeignLastFailure"};
            for (unsigned i = 0; i < 7; i++) {
                root->setProperty(acked[i], awdlAcks.acked[i], 32);
                root->setProperty(failed[i], awdlAcks.failed[i], 32);
                root->setProperty(retries[i], awdlAcks.retries[i], 32);
                root->setProperty(last[i], awdlAcks.lastFailure[i], 32);
            }
        }
    }
    }
    if (running && !that->awdlMonitorPending) {
        if (!awdlRxBurstDone) {
            const unsigned candidates[] = {6, 44, 149};
            for (unsigned channelNumber : candidates) {
                const auto *candidate = &ic->ic_channels[channelNumber];
                const bool eligible = candidate->ic_freq && isset(ic->ic_chan_active, channelNumber) &&
                    !(candidate->ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC));
                awdlLog("TX preflight channel %u freq %u flags %x active %u eligible %u\n",
                        channelNumber, candidate->ic_freq, candidate->ic_flags,
                        isset(ic->ic_chan_active, channelNumber) ? 1U : 0U, eligible ? 1U : 0U);
            }
            awdlLog("TX preflight queue %d generation %d node-channel %d node-rates %u mode %u armed %u\n",
                    that->awdlMonitorQueue, that->awdlMonitorGeneration,
                    ic->ic_bss && ic->ic_bss->ni_chan ? ieee80211_chan2ieee(ic, ic->ic_bss->ni_chan) : -1,
                    ic->ic_bss ? ic->ic_bss->ni_rates.rs_nrates : 0, ic->ic_curmode,
                    that->awdlMonitorTxArmed ? 1U : 0U);
            awdlTxLog("TX context queue %d generation %d radio-generation %d channel %d rates %u armed %u\n",
                    that->awdlMonitorQueue, that->awdlMonitorGeneration, sc->sc_generation,
                    ieee80211_chan2ieee(ic, sc->sc_phyctxt[0].channel),
                    ic->ic_bss ? ic->ic_bss->ni_rates.rs_nrates : 0,
                    that->awdlMonitorTxArmed ? 1U : 0U);
            if (awdlRxChannel6)
                awdlLog("fixed channel 6 RX: physical-match %u node-rates %u min-rate %d; no TX submitted\n",
                        ic->ic_bss && ic->ic_bss->ni_chan == sc->sc_phyctxt[0].channel ? 1U : 0U,
                        ic->ic_bss ? ic->ic_bss->ni_rates.rs_nrates : 0,
                        ic->ic_bss ? ieee80211_min_basic_rate(ic) : -1);
            uint64_t minNs = ~0ULL, maxNs = 0, sumNs = 0;
            unsigned done = 0;
            awdlRxBurstDone = true;
            for (unsigned i = 0; !awdlRxChannel6 && i < 20; i++) {
                uint64_t a, b, ns;
                clock_get_uptime(&a);
                int err = that->iwx_awdl_monitor_channel(sc, awdlRxChannels[i & 1]);
                clock_get_uptime(&b);
                if (err) {
                    awdlLog("channel switch %u failed: %d\n", i, err);
                    break;
                }
                absolutetime_to_nanoseconds(b - a, &ns);
                minNs = MIN(minNs, ns);
                maxNs = MAX(maxNs, ns);
                sumNs += ns;
                done++;
            }
            if (done)
                awdlLog("%u channel switches: min %llu us avg %llu us max %llu us\n", done,
                      minNs / 1000, sumNs / done / 1000, maxNs / 1000);
        }
        if (!awdlRxChannel6) {
            awdlRxIndex = (awdlRxIndex + 1) % nitems(awdlRxChannels);
            int err = that->iwx_awdl_monitor_channel(sc, awdlRxChannels[awdlRxIndex]);
            if (err)
                awdlLog("could not move to channel %u: %d\n", awdlRxChannels[awdlRxIndex], err);
        }
    }
    if (running && awdlPeerCountryTest && mccSampleCount < nitems(mccSamples)) {
        // Unapplied, so this boot stays on its channel whatever the firmware says.
        const uint32_t now = mccUptimeSeconds();
        const bool ask = !awdlPeerCountryAsked && awdlPeerCountry.confirmed && awdlPeerAudible();
        const bool read = awdlPeerCountryAsked && awdlPeerCountryReads < 6 && now - awdlPeerCountryAskSeconds >= 30U * (awdlPeerCountryReads + 1);
        if (ask || read) {
            ItlAWDL::MccSample sample{};
            sample.uptimeSeconds = now;
            sample.state = uint8_t(that->com.sc_ic.ic_state);
            sample.trigger = ask ? ItlAWDL::kMccPeerReply : ItlAWDL::kMccRead;
            int err;
            if (ask) {
                awdlPeerCountryAsked = true;
                awdlPeerCountryAskSeconds = now;
                err = that->iwx_mcc_request(sc, awdlPeerCountry.confirmed, ItlAWDL::kMccSourceWifi, &sample, false);
            } else {
                ++awdlPeerCountryReads;
                err = that->iwx_mcc_request(sc, 'Z' << 8 | 'Z', IWX_MCC_SOURCE_GET_CURRENT, &sample, false);
            }
            if (!err)
                ItlAWDL::regulatoryAppend(mccSamples, nitems(mccSamples), mccSampleCount, sample);
            if (ask) {
                ItlAWDL::MccSample after{};
                after.uptimeSeconds = now;
                after.state = sample.state;
                after.trigger = ItlAWDL::kMccRead;
                if (that->iwx_mcc_request(sc, 'Z' << 8 | 'Z', IWX_MCC_SOURCE_GET_CURRENT, &after, false) == 0)
                    ItlAWDL::regulatoryAppend(mccSamples, nitems(mccSamples), mccSampleCount, after);
            }
            mccProbePublish();
        }
    }
    if (running && awdlWindow > 1) {
        const bool busy = that->awdlMonitorPending || awdlBurst.count;
        const uint64_t stallNow = awdlUptimeUS();
        if (!busy)
            awdlTxBusySinceUS = 0;
        else if (!awdlTxBusySinceUS)
            awdlTxBusySinceUS = stallNow;
        if (ItlAWDL::txStalled(busy, stallNow, awdlTxBusySinceUS, awdlTxLastCompletionUS)) {
            // Record it, then restart the card, the same recovery as a firmware fault. If it
            // happens twice, the window isn't safe here, so go back to one frame at a time.
            auto *ring = that->awdlMonitorQueue >= 0 ? &sc->txq[that->awdlMonitorQueue] : nullptr;
            if (awdlTxStallCount < nitems(awdlTxStalls)) {
                awdlTxStalls[awdlTxStallCount] = AWDLTxStall{uint32_t(stallNow / 1000), that->awdlMonitorPending != nullptr,
                    that->awdlMonitorProbeStarted, that->awdlMonitorTxAttempted, awdlDataInFlight, awdlBurst.count,
                    awdlBurst.retryCount, awdlResend.held, awdlResend.pending, uint32_t(ring ? ring->cur : 0),
                    uint32_t(ring ? ring->tail : 0), uint32_t(ring ? ring->queued : 0), awdlTxLastIndex, awdlTxLastStatus,
                    that->awdlMonitorSubmitted};
                ++awdlTxStallCount;
            }
            auto *root = IORegistryEntry::getRegistryRoot();
            if (auto *stalls = OSData::withBytes(awdlTxStalls, unsigned(awdlTxStallCount * sizeof(awdlTxStalls[0])))) {
                root->setProperty("ITLAWDLTxStalls", stalls);
                stalls->release();
            }
            if (awdlTxStallCount >= 2) {
                awdlWindow = 1;
                root->setProperty("ITLAWDLTxWindow", awdlWindow, 32);
            }
            awdlTxBusySinceUS = 0;
            task_add(systq, &sc->init_task);
            return;
        }
    }
    if (running && awdlTx80)
        ItlAWDL::noteBaTxTraffic(awdlTx80Bulk, awdlUptimeUS(), awdlDataSent[1]);
    if (running && awdlBaPending) {
        awdlBaPending = false;
        that->awdlBaHandle(sc);
    }
    if (running && awdlBaTx) {
        that->awdlBaTxStep(sc);
        if (ItlAWDL::noteBaTxTraffic(awdlBaTxBulk, awdlUptimeUS(), awdlDataSent[1] + awdlBaTxFrames))
            ++awdlBaTxBulkChanges;
    }
    bool awdlFilterChange = false;
    if (running && awdlBaNoPromisc && awdlBaPeerAccepted && awdlBaStationAdded) {
        if (awdlBaFilterKeepOff) {
            awdlFilterChange = !awdlBaFilter.off;
            awdlBaFilter.off = true;
        } else {
            awdlFilterChange = ItlAWDL::noteBaFilterTraffic(awdlBaFilter, awdlUptimeUS(), awdlRxSequences.counts.frames);
        }
    }
    if (awdlFilterChange) {
        awdlBaFilterOff = awdlBaFilter.off;
        ++awdlBaFilterChanges;
        awdlSessLog("promiscuous filter %s\n", awdlBaFilterOff ? "off" : "on");
        if (that->iwx_mac_ctxt_cmd(sc, reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss), IWX_FW_CTXT_ACTION_MODIFY, 0)) {
            // Keep the record the same as what the firmware has.
            awdlBaFilterOff = !awdlBaFilterOff;
            awdlBaFilter.off = awdlBaFilterOff;
        }
    }
    if (running && awdlCountryAnswerPending) {
        awdlCountryAnswerPending = false;
        (void)that->awdlCountryAnswer(&that->com);
        // Passive again means no more sending here, so go back to the fallback channel.
        const auto &onChannel = ic->ic_channels[149];
        if (awdlBackgroundScan && awdlFixedChannel == 149 && (onChannel.ic_flags & IEEE80211_CHAN_PASSIVE))
            awdlChannelMove.wantDown = true;
    }
    if (running && awdlBackgroundScan) {
        const uint64_t moveNow = awdlUptimeUS();
        if (awdlChannelMove.moveStartUS) {
            // The first timer tick that finds the card running again.
            awdlChannelMove.lastMoveMs = uint32_t((moveNow - awdlChannelMove.moveStartUS) / 1000);
            awdlChannelMove.moveStartUS = 0;
        }
        if (ItlAWDL::forcedMoveDue(awdlMoveTestSeconds, awdlMoveTestDone, awdlFixedChannel, moveNow)) {
            awdlMoveTestDone = true;
            awdlChannelMove.wantDown = true;
        }
        if (awdlChannelMove.upNoticed && awdlFixedChannel != 149 &&
            ItlAWDL::channelMoveUpAllowed(moveNow, awdlChannelMove.lastUpUS)) {
            awdlChannelMove.upNoticed = false;
            awdlChannelMove.wantUp = true;
        }
        const bool busy = that->awdlMonitorPending || awdlBurst.count || awdlBurst.retryCount || awdlResend.held;
        if (awdlBackgroundScanActive && moveNow - awdlBackgroundScanStartUS >= ItlAWDL::kBackgroundScanLimitUS) {
            (void)that->iwx_umac_scan_abort(sc);
            awdlBackgroundScanActive = false;
        }
        if (!awdlBackgroundScanActive && (awdlChannelMove.wantUp || awdlChannelMove.wantDown) &&
            ItlAWDL::channelMoveReady(busy, moveNow, awdlLastDataUS)) {
            if (awdlChannelMove.wantDown) {
                awdlChannelMove.skipStartupScan = true;
                ++awdlMovesDown;
            } else {
                awdlChannelMove.lastUpUS = moveNow;
                ++awdlMovesUp;
            }
            awdlChannelMove.wantUp = awdlChannelMove.wantDown = false;
            awdlChannelMove.moveStartUS = moveNow;
            task_add(systq, &sc->init_task);
            return;
        }
        if (!awdlBackgroundScanActive && !awdlChannelMove.wantUp && !awdlChannelMove.wantDown &&
            ItlAWDL::backgroundScanDue(awdlFixedChannel != 149, busy, moveNow, awdlChannelMove.lastScanUS, awdlLastDataUS)) {
            awdlChannelMove.lastScanUS = moveNow;
            ++awdlBackgroundScans;
            awdlBackgroundScanStartUS = moveNow;
            awdlBackgroundScanActive = that->iwx_umac_scan(sc, 1) == 0;
        }
    }
    if (running && awdlPeerPause) {
        // Only while the Mac's A-MPDU session to the peer exists: that station is what's paused.
        const bool session = awdlBaStationAdded && awdlBaTxState == kBaTxAgreed && sc->sc_ic.ic_bss;
        const uint64_t pauseNowUS = awdlUptimeUS();
        const bool bulk = awdlPeerBulk.note(pauseNowUS, awdlBaTxFrames);
        const int change = awdlPeerPauseState.step(session && bulk && awdlPeerSchedule.shouldPause(pauseNowUS), pauseNowUS,
                                                   awdlPeerSchedule.pauseLimitUS(pauseNowUS));
        if (change && sc->sc_ic.ic_bss) {
            auto *in = reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss);
            struct iwx_add_sta_cmd cmd;
            memset(&cmd, 0, sizeof(cmd));
            cmd.sta_id = kAwdlBaStationId;
            cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
            cmd.add_modify = IWX_STA_MODE_MODIFY;
            cmd.station_flags = htole32(change > 0 ? IWX_STA_FLG_DISABLE_TX : 0);
            cmd.station_flags_msk = htole32(IWX_STA_FLG_DISABLE_TX);
            if (that->iwx_send_cmd_pdu(sc, IWX_ADD_STA, IWX_CMD_ASYNC, sizeof(cmd), &cmd))
                ++awdlPeerPauseState.commandErrors;
        }
    }
    if (running)
        that->iwx_awdl_transport_probe(sc);
    unsigned nextDelay = awdlPeerTrain ?
        ItlAWDL::peerTrainDelayUS(that->awdlMonitorSubmitted, awdlPeerAudible(),
            that->awdlMonitorPending != nullptr, that->awdlMonitorTxAttempted) :
        ItlAWDL::probeDelayUS(awdlFastProbe,
            that->awdlMonitorSubmitted, that->awdlMonitorPending != nullptr, that->awdlMonitorTxAttempted);
#if defined(ITL_AWDL_NATIVE)
    if (awdlDataTx)
        // Output arrives without notice, so never sleep for long while it's on.
        nextDelay = MIN(nextDelay, (itlAWDLServiceTransmit(that->getController()) ||
            ItlAWDL::dataRecentlyActive(awdlDataEverActive, awdlUptimeUS(), awdlLastDataUS)) ? 1000U : 50000U);
#endif
    // A pause has to end on time even with nothing else to do.
    if (awdlPeerPause && (awdlPeerPauseState.paused || awdlPeerSchedule.calibrated))
        nextDelay = MIN(nextDelay, 1000U);
    if (awdlAwSync && !ItlAWDL::dataRecentlyActive(awdlDataEverActive, awdlUptimeUS(), awdlLastDataUS)) {
        // Wake for the peer's next AW on our channel, not every millisecond.
        const uint64_t untilAW = awdlPeerSchedule.usUntilPresentAw(awdlUptimeUS());
        if (untilAW)
            nextDelay = MIN(nextDelay, unsigned(MAX(untilAW, uint64_t(1000))));
    }
    if (!awdlStopping)
        timeout_add_usec(&awdlRxTimer, nextDelay);
}

void ItlIwx::
iwx_rx_frame(struct iwx_softc *sc, mbuf_t m, int chanidx,
             uint32_t rx_pkt_status, int is_shortpre, int rate_n_flags,
             uint32_t device_timestamp, struct ieee80211_rxinfo *rxi,
             struct mbuf_list *ml)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_frame *wh;
    struct ieee80211_node *ni;
    struct _ifnet *ifp = IC2IFP(ic);
    
    // Whether the firmware's channel is real, before a stand-in replaces it.
    const bool chanValid = chanidx > 0 && chanidx < int(nitems(ic->ic_channels));
    if (chanidx < 0 || chanidx >= nitems(ic->ic_channels))
        chanidx = ieee80211_chan2ieee(ic, ic->ic_ibss_chan);
    if (awdlCoexProbe && awdlCoexAdded && awdlRxMacMaskValid)
        ++awdlCoexMacMaskSeen[awdlRxMacMask < 3 ? awdlRxMacMask : 3];
    
    if (awdlCoexProbe && awdlCoexAdded && mbuf_len(m) >= 24) {
        static const uint8_t awdlBssid[6] = {0x00, 0x25, 0x00, 0xff, 0x94, 0x73};
        const uint8_t *cf = mtod(m, const uint8_t *);
        const bool awdlFrame = !memcmp(cf + 16, awdlBssid, 6);
        // A Block Ack action frame to our AWDL address is ours whatever BSSID it carries.
        const bool baToUs = cf[0] == 0xd0 && mbuf_len(m) >= 26 && cf[24] == 3 && awdlCoexAddrKnown &&
            ItlAWDL::sameAddress(cf + 4, awdlCoexAddr);
        if (baToUs) {
            ++awdlCoexBaActionSeen[cf[25] < 3 ? cf[25] : 3];
            awdlCoexBaEvent('B', cf[25], awdlCoexBaPeerAdded && ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer) ? 1 : 0,
                            awdlFrame ? 1 : 0,
                            (chanValid && unsigned(chanidx) == awdlCoexChannel ? 1U : 0U) |
                            (awdlCoexPeerKnown(cf + 10, awdlUptimeUS()) ? 2U : 0U));
            ++(awdlFrame ? awdlCoexBaActionAwdlBssid : awdlCoexBaActionOtherBssid);
        }
        if (awdlCoexBaFilterOff && (cf[0] & 0x0c) == 0x08 && awdlFrame)
            ++awdlCoexRxWhileFilterOff;
        if ((awdlFrame || baToUs) && cf[0] == 0xd0) {
            ++awdlCoexAwdlAction;
            ++(unsigned(chanidx) == awdlCoexChannel ? awdlCoexActionOnChannel : awdlCoexActionOffChannel);
#if defined(ITL_AWDL_NATIVE)
            // The listener's frames come without the FCS; the hand-off expects four bytes after the
            // frame, as from monitor mode, so a copy gets them. Some setups also pad the frame with zeros
            // after its last TLV; that padding is cut, so the frame parses and is handed off as sent.
            size_t coexLen = mbuf_len(m);
            if (awdlCoexRx && !mbuf_next(m)) {
                const size_t unpadded = ItlAWDL::trimZeroPadding(cf, coexLen);
                if (unpadded != coexLen) {
                    coexLen = unpadded;
                    ++awdlCoexZeroPadTrimmed;
                }
            }
            ItlAWDL::ActionFrame coexAction;
            if (awdlCoexRx && !mbuf_next(m) &&
                ItlAWDL::parseAction(cf, coexLen, &coexAction) == ItlAWDL::ParseResult::Valid) {
                const uint64_t heardUS = awdlUptimeUS();
                const bool ourChannel = chanValid && unsigned(chanidx) == awdlCoexChannel;
                const bool fromOwnAddr = awdlCoexAddrKnown && ItlAWDL::sameAddress(cf + 10, awdlCoexAddr);
                // Which 5 GHz channel Apple uses here, from the peer's own channel sequence, heard on any
                // channel: 44 if its AWDL slots name it, else 149 (the min rule). The channel picker follows it.
                if (!(cf[10] & 1) && !fromOwnAddr &&
                    (!awdlCoexBaPeerAdded || ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer))) {
                    uint8_t seq[16];
                    if (awdlCoexPeerSequence(cf, coexLen, seq)) {
                        ++awdlCoexPeerSeqFrames;
                        ++awdlCoexPeer5GFrames;
                        // 44, 149, or 1 when its AWDL slots name neither (ITLAWDLCoexPeer5GHz).
                        const unsigned peerCh = awdlCoexPeerChannel(seq);
                        const uint8_t named = peerCh ? uint8_t(peerCh) : 1;
                        const bool seqChanged = memcmp(seq, awdlCoexPeerSeq, sizeof(seq)) != 0;
                        if (seqChanged || named != awdlCoexPeer5G) {
                            if (seqChanged)
                                ++awdlCoexPeerSeqChanges;
                            if (awdlCoexPeer5G && named != awdlCoexPeer5G)
                                ++awdlCoexPeer5GChanges;
                            memcpy(awdlCoexPeerSeq, seq, sizeof(seq));
                            awdlCoexPeer5G = named;
                            awdlCoexPublish();
                        }
                        awdlCoexPeer5GUS = heardUS;
                    }
                }
                if (!(cf[10] & 1) && ourChannel && !fromOwnAddr) {
                    awdlCoexPeerHeard(cf + 10, heardUS);
                    // The phone's schedule, from its sync frames, as dedicated mode tracks it: its BA peer
                    // once there is one, otherwise the first peer heard.
                    if ((!awdlCoexBaPeerAdded || ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer)) &&
                        (ItlAWDL::sameAddress(cf + 10, awdlCoexSchedPeer) || !awdlCoexScheduleCurrent() ||
                         !awdlCoexPeerSchedule.fresh(heardUS))) {
                        ItlAWDL::PeerSyncInfo peerSync{};
                        bool badSequence = false;
                        if (ItlAWDL::peerSyncFromAction(cf, coexLen, &peerSync, &badSequence)) {
                            if (!awdlCoexScheduleCurrent() || !ItlAWDL::sameAddress(cf + 10, awdlCoexSchedPeer)) {
                                awdlCoexPeerSchedule.reset();
                                awdlCoexSchedToken = awdlCoexToken;
                                memcpy(awdlCoexSchedPeer, cf + 10, sizeof(awdlCoexSchedPeer));
                            }
                            awdlCoexPeerSchedule.notePeerFrame(heardUS);
                            awdlCoexPeerSchedule.note(peerSync, heardUS, uint8_t(awdlCoexChannel));
                            ++awdlCoexPeerSyncFrames;
                        } else if (awdlCoexScheduleCurrent() && ItlAWDL::sameAddress(cf + 10, awdlCoexSchedPeer)) {
                            if (badSequence) {
                                ++awdlCoexPeerSequenceRejected;
                                awdlCoexPeerSchedule.invalidate();
                            } else {
                                awdlCoexPeerSchedule.notePeerFrame(heardUS);
                            }
                        }
                    }
                }
                // -itlawdlsvcmerge: the peer's other service records added, if any are missing (iface81).
                bool handed = false;
                if (awdlServiceMerge && !fromOwnAddr && ourChannel) {
                    if (awdlCoexServiceCacheToken != awdlCoexToken) {
                        awdlServiceCache.clear();
                        awdlCoexServiceCacheToken = awdlCoexToken;
                    }
                    awdlServiceCache.note(cf + 10, cf, coexLen);
                    unsigned added = 0;
                    mbuf_t merged = nullptr;
                    if (!mbuf_getpacket(MBUF_DONTWAIT, &merged) && merged && mbuf_maxlen(merged) > coexLen + 4) {
                        const size_t room = MIN(size_t(mbuf_maxlen(merged)) - 4, ItlAWDL::kServiceMergeFrameMax);
                        const size_t n = awdlServiceCache.merge(cf + 10, cf, coexLen,
                                                                static_cast<uint8_t *>(mbuf_data(merged)), room, &added);
                        if (n) {
                            memset(static_cast<uint8_t *>(mbuf_data(merged)) + n, 0, 4);
                            mbuf_setlen(merged, n + 4);
                            mbuf_pkthdr_setlen(merged, n + 4);
                            const IOReturn sent = itlAWDLReceiveAction(getController(), merged, n,
                                static_cast<uint32_t>(chanidx), rxi->rxi_rssi + IWX_MIN_DBM);
                            if (sent == kIOReturnSuccess) {
                                handed = true;
                                ++awdlCoexForwarded;
                                ++awdlServiceMergedFrames;
                                awdlServiceMergedRecords += added;
                            } else {
                                ++awdlServiceMergeRefused;
                                awdlServiceMergeLastError = uint32_t(sent);
                            }
                        }
                    }
                    if (merged)
                        mbuf_freem(merged);
                }
                mbuf_t copy = nullptr;
                if (!handed && !mbuf_getpacket(MBUF_DONTWAIT, &copy) && copy && mbuf_maxlen(copy) >= coexLen + 4) {
                    memcpy(mbuf_data(copy), cf, coexLen);
                    memset(static_cast<uint8_t *>(mbuf_data(copy)) + coexLen, 0, 4);
                    mbuf_setlen(copy, coexLen + 4);
                    mbuf_pkthdr_setlen(copy, coexLen + 4);
                    if (itlAWDLReceiveAction(getController(), copy, coexLen, static_cast<uint32_t>(chanidx),
                                             rxi->rxi_rssi + IWX_MIN_DBM) == kIOReturnSuccess)
                        ++awdlCoexForwarded;
                    else
                        ++awdlCoexForwardRefused;
                }
                if (copy)
                    mbuf_freem(copy);
            } else if (awdlCoexRx) {
                ++awdlCoexForwardMalformed;
                // Not AWDL's own format: a Block Ack request or teardown to our address, from a peer we hear.
                ItlAWDL::AddbaRequest request;
                bool delbaPeerWasSender = false;
                uint8_t delbaTid = 0;
                if (awdlCoexData && awdlCoexAddrKnown && !mbuf_next(m) && chanValid &&
                    unsigned(chanidx) == awdlCoexChannel && awdlCoexPeerKnown(cf + 10, awdlUptimeUS())) {
                    if (ItlAWDL::parseAddbaRequest(cf, coexLen, awdlCoexAddr, &request) && awdlFrame) {
                        ++awdlCoexBaRequests;
                        awdlCoexBaEvent('Q', request.token, request.tid, 0);
                        if (request.immediate) {
                            if ((awdlCoexBaPeerAdded && !ItlAWDL::sameAddress(request.peer, awdlCoexBaPeer)) ||
                                !awdlCoexBaRequestsPending.note(request)) {
                                ++awdlCoexBaOtherPeer;
                            } else if (awdlCoexBaAnswerLength && awdlCoexBaAnswerTid == request.tid &&
                                       awdlCoexBaAnswer[26] != request.token) {
                                awdlCoexBaAnswerLength = 0;
                            }
                        }
                    } else if (ItlAWDL::parseDelba(cf, coexLen, awdlCoexAddr, &delbaPeerWasSender, &delbaTid) &&
                               delbaTid < 8 && awdlCoexBaPeerAdded && ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer)) {
                        awdlCoexBaEvent('D', delbaTid, delbaPeerWasSender ? 1 : 0, awdlFrame ? 1 : 0);
                        if (!awdlFrame)
                            ++awdlCoexBaNonAwdlBssidAccepted;
                        if (delbaPeerWasSender) {
                            if (!awdlFrame && (awdlCoexBaTids & (1U << delbaTid)))
                                ++awdlCoexBaNonAwdlBssidApplied;
                            // A later request on this TID can be handled once removal finishes.
                            awdlCoexBaRequestsPending.discard(delbaTid);
                            if (awdlCoexBaAnswerLength && awdlCoexBaAnswerTid == delbaTid)
                                awdlCoexBaAnswerLength = 0;
                            awdlCoexBaRxIdleTids &= uint8_t(~(1U << delbaTid));
                            // Its session for sending to us: removed from the firmware on the next pass.
                            ++awdlCoexBaDelbas;
                            awdlCoexBaTidTeardown |= uint8_t(1U << delbaTid);
                        } else if (delbaTid == kAwdlBaTxTid &&
                                   (awdlCoexBaTxState == kCoexBaTxAgreed || awdlCoexBaTxState == kCoexBaTxEnabling)) {
                            // Our session for sending to it: back to the single-frame queue, and ask again.
                            if (!awdlFrame)
                                ++awdlCoexBaNonAwdlBssidApplied;
                            ++awdlCoexBaTxDelbas;
                            awdlCoexBaTxState = kCoexBaTxAsking;
                            ++awdlCoexBaTxToken;
                            awdlCoexBaProbeTried = false;
                            awdlCoexBaProbeUntilUS = 0;
                            awdlCoexBaTxAsks = 0;
                            awdlCoexBaTxLastAskUS = 0;
                        }
                    } else {
                        ItlAWDL::AddbaAnswer answer;
                        const bool parsed = ItlAWDL::parseAddbaAnswer(cf, coexLen, awdlCoexAddr, &answer);
                        const bool matches = parsed && awdlCoexBaTxState == kCoexBaTxAsking && awdlCoexBaTxAsks &&
                            awdlCoexBaPeerAdded && ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer) &&
                            answer.token == awdlCoexBaTxToken && answer.tid == kAwdlBaTxTid;
                        if (parsed)
                            awdlCoexBaEvent('R', answer.token, answer.status,
                                            (matches ? 1U : 0U) | (answer.immediate ? 2U : 0U) |
                                            (awdlFrame ? 4U : 0U), answer.window);
                        if (matches) {
                            if (!awdlFrame)
                                ++awdlCoexBaNonAwdlBssidAccepted;
                            if (!answer.status && !answer.immediate)
                                ++awdlCoexBaTxPolicyRefusals; // Delayed Block Ack isn't supported: treated as a refusal.
                            if (answer.status || !answer.immediate) {
                                ++awdlCoexBaTxRefusals;
                                awdlCoexBaTxRestUntilUS = awdlUptimeUS() + 20000000ULL;
                                ++awdlCoexBaTxToken;
                                awdlCoexBaProbeTried = false;
                                awdlCoexBaProbeUntilUS = 0;
                                awdlCoexBaTxAsks = 0;
                            } else {
                                if (!awdlFrame)
                                    ++awdlCoexBaNonAwdlBssidApplied;
                                ++awdlCoexBaTxAgreements;
                                // A window of 0 isn't valid in an answer; it's taken as our requested 64.
                                awdlCoexBaTxWindow = answer.window && answer.window < 64 ? answer.window : 64;
                                if (awdlCoexBaTxWindow < 64)
                                    ++awdlCoexBaTxSmallWindows;
                                awdlCoexBaTxState = kCoexBaTxEnabling;
                            }
                        }
                    }
                }
            }
#endif
        }
        else if (awdlFrame && (cf[0] & 0x0c) == 0x08) {
            ++awdlCoexAwdlData;
#if defined(ITL_AWDL_NATIVE)
            // AWDL data heard by the listener, without the FCS. awdl0's hand-off expects the monitor-mode
            // layout, four bytes after the frame, so it gets a copy with them zeroed.
            const size_t dataLen = mbuf_len(m);
            ++((cf[4] & 1) ? awdlCoexDataRxGroup : awdlCoexDataRxUcast);
            if (!(cf[4] & 1)) {
                if (cf[1] & 0x08)
                    ++awdlCoexDataRxRetry;
                ++awdlCoexRxModulation[(uint32_t(rate_n_flags) & IWX_RATE_MCS_MOD_TYPE_MSK) >> IWX_RATE_MCS_MOD_TYPE_POS];
                if ((uint32_t(rate_n_flags) & IWX_RATE_MCS_CHAN_WIDTH_MSK) == IWX_RATE_MCS_CHAN_WIDTH_80)
                    ++awdlCoexRxWide80;
                if (awdlVht80TwoStream(rate_n_flags))
                    ++awdlCoexRxVht80TwoStream;
            }
            if (awdlCoexData && !mbuf_next(m) && dataLen + 4 <= sizeof(awdlCoexDataBuf)) {
                ++awdlCoexDataRx;
                ItlAWDL::DataFrameView view;
                if (!chanValid || unsigned(chanidx) != awdlCoexChannel) {
                    ++awdlCoexDataRxOffChannel;
                } else if (!awdlCoexPeerKnown(cf + 10, awdlUptimeUS())) {
                    ++awdlCoexDataRxUnknownPeer;
                    awdlCoexNoteRejectReason(cf + 10, awdlUptimeUS());
                } else if (ItlAWDL::parseDataFrame(cf, dataLen, false, &view) == ItlAWDL::ParseResult::Valid) {
                    memcpy(awdlCoexDataBuf, cf, dataLen);
                    memset(awdlCoexDataBuf + dataLen, 0, 4);
                    if (awdlCoexBaPeerAdded && ItlAWDL::sameAddress(cf + 10, awdlCoexBaPeer)) {
                        awdlCoexBaPeerLastUS = awdlUptimeUS();
                        if (awdlCoexAddrKnown && ItlAWDL::sameAddress(view.destination, awdlCoexAddr))
                            (void)awdlCoexPeerKnown(cf + 10, awdlCoexBaPeerLastUS, true);
                        if (!(cf[4] & 1) && dataLen >= 1200)
                            awdlCoexBaLastRxPayloadUS = awdlCoexBaPeerLastUS;
                        if ((cf[0] & 0xf0) == 0x80 && dataLen >= 26) // QoS data: TID in the QoS control field.
                            awdlCoexBaRxTidLastUS[cf[24] & 7] = awdlCoexBaPeerLastUS;
                    }
                    itlAWDLObserveData(getController(), awdlCoexDataBuf, dataLen + 4);
                    if (awdlCoexScheduleCurrent() && ItlAWDL::sameAddress(cf + 10, awdlCoexSchedPeer)) {
                        awdlCoexSchedPeerRxUS = awdlUptimeUS();
                        awdlCoexPeerSchedule.notePeerFrame(awdlCoexSchedPeerRxUS);
                    }
                    ++awdlCoexDataRxDelivered;
                    awdlCoexLastDataUS = awdlUptimeUS();
                } else {
                    ++awdlCoexDataRxMalformed;
                }
            }
#endif
        }
        else
            ++awdlCoexOther;
        if (++awdlCoexPublished % 512 == 0)
            awdlCoexPublish();
        // Frames with AWDL's BSSID are never the station's, whatever the filter: they stop at the hand-off.
        if ((awdlFrame || baToUs) && awdlCoexRx) {
            mbuf_freem(m);
            return;
        }
    }
    // With promiscuous receive (or a filter state the firmware may hold), what the listener hears goes no
    // further than the AWDL hand-off above, whatever its length. A frame is the listener's if the firmware's
    // MAC mask names the listener and not the station, or if it came in on the listener's channel while the
    // station is on another. A frame with neither usable is counted and left to the station.
    if (awdlCoexProbe && (awdlCoexPromiscLive || awdlCoexPromiscUncertain)) {
        struct iwx_node *stationNode = (struct iwx_node *)ic->ic_bss;
        const unsigned stationChannel = stationNode && stationNode->in_phyctxt && stationNode->in_phyctxt->channel ?
            unsigned(ieee80211_chan2ieee(ic, stationNode->in_phyctxt->channel)) : 0;
        const bool maskListenerOnly = awdlRxMacMaskValid && (awdlRxMacMask & (1U << kAwdlCoexMacId)) &&
            !(awdlRxMacMask & 1U);
        const bool channelListener = chanValid && stationChannel && unsigned(chanidx) == awdlCoexChannel &&
            stationChannel != awdlCoexChannel;
        if (maskListenerOnly || channelListener) {
            ++awdlCoexPromiscDropped;
            mbuf_freem(m);
            return;
        }
        // A present but zero mask names no context (iface132: always 0), so it doesn't count as evidence.
        if (!chanValid && !(awdlRxMacMaskValid && awdlRxMacMask))
            ++awdlCoexPromiscAmbiguous;
    }

    if (awdlRx) {
        awdlRxObserve(sc, m, chanidx, rxi->rxi_rssi, device_timestamp);
        const uint8_t *frameBytes = mtod(m, const uint8_t *);
        if (mbuf_len(m) >= 24 && (frameBytes[0] & 0x0c) == 8 && ItlAWDL::knownAddress(awdlOwnAddress) &&
            ItlAWDL::sameAddress(frameBytes + 4, awdlOwnAddress))
        {
            if (awdlTx80 && awdlWide80Live && chanidx == 149 &&
                (rate_n_flags & IWX_RATE_MCS_MOD_TYPE_MSK) == IWX_RATE_MCS_VHT_MSK &&
                (rate_n_flags & IWX_RATE_MCS_CHAN_WIDTH_MSK) == IWX_RATE_MCS_CHAN_WIDTH_80 &&
                ItlAWDL::knownAddress(awdlLastPeer) && ItlAWDL::sameAddress(frameBytes + 10, awdlLastPeer)) {
                memcpy(awdlTx80Peer, frameBytes + 10, sizeof(awdlTx80Peer));
                awdlTx80PeerUS = awdlUptimeUS();
                awdlTx80PeerGeneration = sc->sc_generation;
            }
            ItlAWDL::noteRxRate(awdlRxRates, nitems(awdlRxRates), uint32_t(rate_n_flags), awdlRxRatesOverflow);
            if (awdlRxPhyInfo & IWX_RX_MPDU_PHY_AMPDU)
                ++awdlBaRxAmpdu;
        }
    }
    wh = mtod(m, struct ieee80211_frame *);
    ni = ieee80211_find_rxnode(ic, wh);
    if ((rxi->rxi_flags & IEEE80211_RXI_HWDEC) &&
        iwx_ccmp_decap(sc, m, ni, rxi) != 0) {
        ifp->netStat->inputErrors++;
        mbuf_freem(m);
        ieee80211_release_node(ic, ni);
        return;
    }
    
#if NBPFILTER > 0
    if (sc->sc_drvbpf != NULL) {
        struct iwx_rx_radiotap_header *tap = &sc->sc_rxtap;
        uint16_t chan_flags;
        
        tap->wr_flags = 0;
        if (is_shortpre)
            tap->wr_flags |= IEEE80211_RADIOTAP_F_SHORTPRE;
        tap->wr_chan_freq =
        htole16(ic->ic_channels[chanidx].ic_freq);
        chan_flags = ic->ic_channels[chanidx].ic_flags;
        if (ic->ic_curmode != IEEE80211_MODE_11N)
            chan_flags &= ~IEEE80211_CHAN_HT;
        tap->wr_chan_flags = htole16(chan_flags);
        tap->wr_dbm_antsignal = (int8_t)rxi->rxi_rssi;
        tap->wr_dbm_antnoise = (int8_t)sc->sc_noise;
        tap->wr_tsft = device_timestamp;
        if (rate_n_flags & IWX_RATE_MCS_HT_MSK) {
            uint8_t mcs = (rate_n_flags &
                           (IWX_RATE_HT_MCS_RATE_CODE_MSK |
                            IWX_RATE_HT_MCS_NSS_MSK));
            tap->wr_rate = (0x80 | mcs);
        } else {
            uint8_t rate = (rate_n_flags &
                            IWX_RATE_LEGACY_RATE_MSK);
            switch (rate) {
                    /* CCK rates. */
                case  10: tap->wr_rate =   2; break;
                case  20: tap->wr_rate =   4; break;
                case  55: tap->wr_rate =  11; break;
                case 110: tap->wr_rate =  22; break;
                    /* OFDM rates. */
                case 0xd: tap->wr_rate =  12; break;
                case 0xf: tap->wr_rate =  18; break;
                case 0x5: tap->wr_rate =  24; break;
                case 0x7: tap->wr_rate =  36; break;
                case 0x9: tap->wr_rate =  48; break;
                case 0xb: tap->wr_rate =  72; break;
                case 0x1: tap->wr_rate =  96; break;
                case 0x3: tap->wr_rate = 108; break;
                    /* Unknown rate: should not happen. */
                default:  tap->wr_rate =   0;
            }
        }
        
        bpf_mtap_hdr(sc->sc_drvbpf, tap, sc->sc_rxtap_len,
                     m, BPF_DIRECTION_IN);
    }
#endif
    ieee80211_inputm(IC2IFP(ic), m, ni, rxi, ml);
    ieee80211_release_node(ic, ni);
}

void ItlIwx::
iwx_flip_address(uint8_t *addr)
{
    int i;
    uint8_t mac_addr[ETHER_ADDR_LEN];

    for (i = 0; i < ETHER_ADDR_LEN; i++)
        mac_addr[i] = addr[ETHER_ADDR_LEN - i - 1];
    IEEE80211_ADDR_COPY(addr, mac_addr);
}

/*
 * Drop duplicate 802.11 retransmissions
 * (IEEE 802.11-2012: 9.3.2.10 "Duplicate detection and recovery")
 * and handle pseudo-duplicate frames which result from deaggregation
 * of A-MSDU frames in hardware.
 */
int ItlIwx::
iwx_detect_duplicate(struct iwx_softc *sc, mbuf_t m,
    struct iwx_rx_mpdu_desc *desc, struct ieee80211_rxinfo *rxi)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    struct iwx_rxq_dup_data *dup_data = &in->dup_data;
    uint8_t tid = IWX_MAX_TID_COUNT, subframe_idx;
    struct ieee80211_frame *wh = mtod(m, struct ieee80211_frame *);
    uint8_t type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
    uint8_t subtype = wh->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK;
    int hasqos = ieee80211_has_qos(wh);
    uint16_t seq;

    if (type == IEEE80211_FC0_TYPE_CTL ||
        (hasqos && (subtype & IEEE80211_FC0_SUBTYPE_NODATA)) ||
        IEEE80211_IS_MULTICAST(wh->i_addr1))
        return 0;

    if (hasqos) {
        tid = (ieee80211_get_qos(wh) & IEEE80211_QOS_TID);
        if (tid > IWX_MAX_TID_COUNT)
            tid = IWX_MAX_TID_COUNT;
    }

    /* If this wasn't a part of an A-MSDU the sub-frame index will be 0 */
    subframe_idx = desc->amsdu_info &
        IWX_RX_MPDU_AMSDU_SUBFRAME_IDX_MASK;

    seq = letoh16(*(u_int16_t *)wh->i_seq) >> IEEE80211_SEQ_SEQ_SHIFT;
    if ((wh->i_fc[1] & IEEE80211_FC1_RETRY) &&
        dup_data->last_seq[tid] == seq &&
        dup_data->last_sub_frame[tid] >= subframe_idx)
        return 1;

    /*
     * Allow the same frame sequence number for all A-MSDU subframes
     * following the first subframe.
     * Otherwise these subframes would be discarded as replays.
     */
    if (dup_data->last_seq[tid] == seq &&
        subframe_idx > dup_data->last_sub_frame[tid] &&
        (desc->mac_flags2 & IWX_RX_MPDU_MFLG2_AMSDU)) {
        rxi->rxi_flags |= IEEE80211_RXI_SAME_SEQ;
    }

    dup_data->last_seq[tid] = seq;
    dup_data->last_sub_frame[tid] = subframe_idx;

    return 0;
}

/*
 * Returns true if sn2 - buffer_size < sn1 < sn2.
 * To be used only in order to compare reorder buffer head with NSSN.
 * We fully trust NSSN unless it is behind us due to reorder timeout.
 * Reorder timeout can only bring us up to buffer_size SNs ahead of NSSN.
 */
int ItlIwx::
iwx_is_sn_less(uint16_t sn1, uint16_t sn2, uint16_t buffer_size)
{
    return SEQ_LT(sn1, sn2) && !SEQ_LT(sn1, sn2 - buffer_size);
}

void ItlIwx::
iwx_release_frames(struct iwx_softc *sc, struct ieee80211_node *ni,
    struct iwx_rxba_data *rxba, struct iwx_reorder_buffer *reorder_buf,
    uint16_t nssn, struct mbuf_list *ml)
{
    struct iwx_reorder_buf_entry *entries = &rxba->entries[0];
    uint16_t ssn = reorder_buf->head_sn;

    /* ignore nssn smaller than head sn - this can happen due to timeout */
    if (iwx_is_sn_less(nssn, ssn, reorder_buf->buf_size))
        goto set_timer;

    while (iwx_is_sn_less(ssn, nssn, reorder_buf->buf_size)) {
        int index = ssn % reorder_buf->buf_size;
        mbuf_t m;
        int chanidx, is_shortpre;
        uint32_t rx_pkt_status, rate_n_flags, device_timestamp;
        struct ieee80211_rxinfo *rxi;

        /* This data is the same for all A-MSDU subframes. */
        chanidx = entries[index].chanidx;
        rx_pkt_status = entries[index].rx_pkt_status;
        is_shortpre = entries[index].is_shortpre;
        rate_n_flags = entries[index].rate_n_flags;
        device_timestamp = entries[index].device_timestamp;
        rxi = &entries[index].rxi;

        /*
         * Empty the list. Will have more than one frame for A-MSDU.
         * Empty list is valid as well since nssn indicates frames were
         * received.
         */
        while ((m = ml_dequeue(&entries[index].frames)) != NULL) {
            iwx_rx_frame(sc, m, chanidx, rx_pkt_status, is_shortpre,
                rate_n_flags, device_timestamp, rxi, ml);
            reorder_buf->num_stored--;

            /*
             * Allow the same frame sequence number and CCMP PN for
             * all A-MSDU subframes following the first subframe.
             * Otherwise they would be discarded as replays.
             */
            rxi->rxi_flags |= IEEE80211_RXI_SAME_SEQ;
            rxi->rxi_flags |= IEEE80211_RXI_HWDEC_SAME_PN;
        }

        ssn = (ssn + 1) & 0xfff;
    }
    reorder_buf->head_sn = nssn;

set_timer:
    if (reorder_buf->num_stored && !reorder_buf->removed) {
        timeout_add_usec(&reorder_buf->reorder_timer,
            RX_REORDER_BUF_TIMEOUT_MQ_USEC);
    } else
        timeout_del(&reorder_buf->reorder_timer);
}

int ItlIwx::
iwx_oldsn_workaround(struct iwx_softc *sc, struct ieee80211_node *ni, int tid,
    struct iwx_reorder_buffer *buffer, uint32_t reorder_data, uint32_t gp2)
{
    struct ieee80211com *ic = &sc->sc_ic;

    if (gp2 != buffer->consec_oldsn_ampdu_gp2) {
        /* we have a new (A-)MPDU ... */

        /*
         * reset counter to 0 if we didn't have any oldsn in
         * the last A-MPDU (as detected by GP2 being identical)
         */
        if (!buffer->consec_oldsn_prev_drop)
            buffer->consec_oldsn_drops = 0;

        /* either way, update our tracking state */
        buffer->consec_oldsn_ampdu_gp2 = gp2;
    } else if (buffer->consec_oldsn_prev_drop) {
        /*
         * tracking state didn't change, and we had an old SN
         * indication before - do nothing in this case, we
         * already noted this one down and are waiting for the
         * next A-MPDU (by GP2)
         */
        return 0;
    }

    /* return unless this MPDU has old SN */
    if (!(reorder_data & IWX_RX_MPDU_REORDER_BA_OLD_SN))
        return 0;

    /* update state */
    buffer->consec_oldsn_prev_drop = 1;
    buffer->consec_oldsn_drops++;

    /* if limit is reached, send del BA and reset state */
    if (buffer->consec_oldsn_drops == IWX_AMPDU_CONSEC_DROPS_DELBA) {
        XYLog("reached %d old SN frames, stopping BA session on TID %d\n",
              IWX_AMPDU_CONSEC_DROPS_DELBA, tid);
        ieee80211_delba_request(ic, ni, IEEE80211_REASON_UNSPECIFIED,
            0, tid);
        buffer->consec_oldsn_prev_drop = 0;
        buffer->consec_oldsn_drops = 0;
        return 1;
    }

    return 0;
}

/*
 * Handle re-ordering of frames which were de-aggregated in hardware.
 * Returns 1 if the MPDU was consumed (buffered or dropped).
 * Returns 0 if the MPDU should be passed to upper layer.
 */
int ItlIwx::
iwx_rx_reorder(struct iwx_softc *sc, mbuf_t m, int chanidx,
    struct iwx_rx_mpdu_desc *desc, int is_shortpre, int rate_n_flags,
    uint32_t device_timestamp, struct ieee80211_rxinfo *rxi,
    struct mbuf_list *ml)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_frame *wh;
    struct ieee80211_node *ni;
    struct iwx_rxba_data *rxba;
    struct iwx_reorder_buffer *buffer;
    uint32_t reorder_data = le32toh(desc->reorder_data);
    int is_amsdu = (desc->mac_flags2 & IWX_RX_MPDU_MFLG2_AMSDU);
    int last_subframe =
        (desc->amsdu_info & IWX_RX_MPDU_AMSDU_LAST_SUBFRAME);
    uint8_t tid;
    uint8_t subframe_idx = (desc->amsdu_info &
        IWX_RX_MPDU_AMSDU_SUBFRAME_IDX_MASK);
    struct iwx_reorder_buf_entry *entries;
    int index;
    uint16_t nssn, sn;
    uint8_t baid, type, subtype;
    int hasqos;

    wh = mtod(m, struct ieee80211_frame *);
    hasqos = ieee80211_has_qos(wh);
    tid = hasqos ? ieee80211_get_qos(wh) & IEEE80211_QOS_TID : 0;

    type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
    subtype = wh->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK;

    /*
     * We are only interested in Block Ack requests and unicast QoS data.
     */
    if (IEEE80211_IS_MULTICAST(wh->i_addr1))
        return 0;
    if (hasqos) {
        if (subtype & IEEE80211_FC0_SUBTYPE_NODATA)
            return 0;
    } else {
        if (type != IEEE80211_FC0_TYPE_CTL ||
            subtype != IEEE80211_FC0_SUBTYPE_BAR)
            return 0;
    }

    baid = (reorder_data & IWX_RX_MPDU_REORDER_BAID_MASK) >>
    IWX_RX_MPDU_REORDER_BAID_SHIFT;
    if (baid == IWX_RX_REORDER_DATA_INVALID_BAID ||
        baid >= nitems(sc->sc_rxba_data))
        return 0;

    rxba = &sc->sc_rxba_data[baid];
    if (rxba->reorder_buf.buf_size == 0 || tid != rxba->tid || rxba->sta_id != IWX_STATION_ID)
        return 0;
    
    if (rxba->timeout != 0)
        getmicrouptime(&rxba->last_rx);

    /* Bypass A-MPDU re-ordering in net80211. */
    rxi->rxi_flags |= IEEE80211_RXI_AMPDU_DONE;

    nssn = reorder_data & IWX_RX_MPDU_REORDER_NSSN_MASK;
    sn = (reorder_data & IWX_RX_MPDU_REORDER_SN_MASK) >>
        IWX_RX_MPDU_REORDER_SN_SHIFT;

    buffer = &rxba->reorder_buf;
    entries = &rxba->entries[0];

    if (!buffer->valid) {
        if (reorder_data & IWX_RX_MPDU_REORDER_BA_OLD_SN)
            return 0;
        buffer->valid = 1;
    }

    ni = ieee80211_find_rxnode(ic, wh);
    if (type == IEEE80211_FC0_TYPE_CTL &&
        subtype == IEEE80211_FC0_SUBTYPE_BAR) {
        iwx_release_frames(sc, ni, rxba, buffer, nssn, ml);
        goto drop;
    }

    /*
     * If there was a significant jump in the nssn - adjust.
     * If the SN is smaller than the NSSN it might need to first go into
     * the reorder buffer, in which case we just release up to it and the
     * rest of the function will take care of storing it and releasing up to
     * the nssn.
     */
    if (!iwx_is_sn_less(nssn, buffer->head_sn + buffer->buf_size,
        buffer->buf_size) ||
        !SEQ_LT(sn, buffer->head_sn + buffer->buf_size)) {
        uint16_t min_sn = SEQ_LT(sn, nssn) ? sn : nssn;
        ic->ic_stats.is_ht_rx_frame_above_ba_winend++;
        iwx_release_frames(sc, ni, rxba, buffer, min_sn, ml);
    }

    if (iwx_oldsn_workaround(sc, ni, tid, buffer, reorder_data,
        device_timestamp)) {
         /* BA session will be torn down. */
        ic->ic_stats.is_ht_rx_ba_window_jump++;
        goto drop;

    }

    /* drop any outdated packets */
    if (SEQ_LT(sn, buffer->head_sn)) {
        ic->ic_stats.is_ht_rx_frame_below_ba_winstart++;
        goto drop;
    }

    /* release immediately if allowed by nssn and no stored frames */
    if (!buffer->num_stored && SEQ_LT(sn, nssn)) {
        if (iwx_is_sn_less(buffer->head_sn, nssn, buffer->buf_size) &&
           (!is_amsdu || last_subframe))
            buffer->head_sn = nssn;
        ieee80211_release_node(ic, ni);
        return 0;
    }

    /*
     * release immediately if there are no stored frames, and the sn is
     * equal to the head.
     * This can happen due to reorder timer, where NSSN is behind head_sn.
     * When we released everything, and we got the next frame in the
     * sequence, according to the NSSN we can't release immediately,
     * while technically there is no hole and we can move forward.
     */
    if (!buffer->num_stored && sn == buffer->head_sn) {
        if (!is_amsdu || last_subframe)
            buffer->head_sn = (buffer->head_sn + 1) & 0xfff;
        ieee80211_release_node(ic, ni);
        return 0;
    }

    index = sn % buffer->buf_size;

    /*
     * Check if we already stored this frame
     * As AMSDU is either received or not as whole, logic is simple:
     * If we have frames in that position in the buffer and the last frame
     * originated from AMSDU had a different SN then it is a retransmission.
     * If it is the same SN then if the subframe index is incrementing it
     * is the same AMSDU - otherwise it is a retransmission.
     */
    if (!ml_empty(&entries[index].frames)) {
        if (!is_amsdu) {
            ic->ic_stats.is_ht_rx_ba_no_buf++;
            goto drop;
        } else if (sn != buffer->last_amsdu ||
            buffer->last_sub_index >= subframe_idx) {
            ic->ic_stats.is_ht_rx_ba_no_buf++;
            goto drop;
        }
    } else {
        /* This data is the same for all A-MSDU subframes. */
        entries[index].chanidx = chanidx;
        entries[index].is_shortpre = is_shortpre;
        entries[index].rate_n_flags = rate_n_flags;
        entries[index].device_timestamp = device_timestamp;
        memcpy(&entries[index].rxi, rxi, sizeof(entries[index].rxi));
    }

    /* put in reorder buffer */
    ml_enqueue(&entries[index].frames, m);
    buffer->num_stored++;
    getmicrouptime(&entries[index].reorder_time);

    if (is_amsdu) {
        buffer->last_amsdu = sn;
        buffer->last_sub_index = subframe_idx;
    }

    /*
     * We cannot trust NSSN for AMSDU sub-frames that are not the last.
     * The reason is that NSSN advances on the first sub-frame, and may
     * cause the reorder buffer to advance before all the sub-frames arrive.
     * Example: reorder buffer contains SN 0 & 2, and we receive AMSDU with
     * SN 1. NSSN for first sub frame will be 3 with the result of driver
     * releasing SN 0,1, 2. When sub-frame 1 arrives - reorder buffer is
     * already ahead and it will be dropped.
     * If the last sub-frame is not on this queue - we will get frame
     * release notification with up to date NSSN.
     */
    if (!is_amsdu || last_subframe)
        iwx_release_frames(sc, ni, rxba, buffer, nssn, ml);

    ieee80211_release_node(ic, ni);
    return 1;

drop:
    mbuf_freem(m);
    ieee80211_release_node(ic, ni);
    return 1;
}

void ItlIwx::
iwx_rx_mpdu_mq(struct iwx_softc *sc, mbuf_t m, void *pktdata,
               size_t maxlen, struct mbuf_list *ml)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_rxinfo rxi;
    struct iwx_rx_mpdu_desc *desc;
    uint32_t len, hdrlen, rate_n_flags, device_timestamp;
    int rssi;
    uint8_t chanidx;
    uint16_t phy_info;
    size_t desc_size;
    
    desc = (struct iwx_rx_mpdu_desc *)pktdata;
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        desc_size = sizeof(struct iwx_rx_mpdu_desc);
    else
        desc_size = IWX_RX_DESC_SIZE_V1;
    
    // The whole descriptor must be present before any field of it is read (security audit C02).
    if (maxlen < desc_size) {
        IC2IFP(ic)->netStat->inputErrors++;
        mbuf_freem(m);
        return;
    }
    if (!(desc->status & htole16(IWX_RX_MPDU_RES_STATUS_CRC_OK)) ||
        !(desc->status & htole16(IWX_RX_MPDU_RES_STATUS_OVERRUN_OK))) {
        mbuf_freem(m);
        return; /* drop */
    }
    
    len = le16toh(desc->mpdu_len);
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        /* Allow control frames in monitor mode. */
        if (len < sizeof(struct ieee80211_frame_cts)) {
            ic->ic_stats.is_rx_tooshort++;
            IC2IFP(ic)->netStat->inputErrors++;
            mbuf_freem(m);
            return;
        }
    } else if (len < sizeof(struct ieee80211_frame)) {
        ic->ic_stats.is_rx_tooshort++;
        IC2IFP(ic)->netStat->inputErrors++;
        mbuf_freem(m);
        return;
    }
    if (len > maxlen - desc_size) {
        IC2IFP(ic)->netStat->inputErrors++;
        mbuf_freem(m);
        return;
    }
    
    //    m->m_data = pktdata + sizeof(*desc);
    //    m->m_pkthdr.len = m->m_len = len;
    mbuf_setdata(m, (uint8_t*)pktdata + desc_size, len);
    mbuf_pkthdr_setlen(m, len);
    mbuf_setlen(m, len);
    
    /* Account for padding following the frame header. */
    if (desc->mac_flags2 & IWX_RX_MPDU_MFLG2_PAD) {
        struct ieee80211_frame *wh = mtod(m, struct ieee80211_frame *);
        int type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
        if (type == IEEE80211_FC0_TYPE_CTL) {
            switch (wh->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK) {
                case IEEE80211_FC0_SUBTYPE_CTS:
                    hdrlen = sizeof(struct ieee80211_frame_cts);
                    break;
                case IEEE80211_FC0_SUBTYPE_ACK:
                    hdrlen = sizeof(struct ieee80211_frame_ack);
                    break;
                default:
                    hdrlen = sizeof(struct ieee80211_frame_min);
                    break;
            }
        } else
            hdrlen = ieee80211_get_hdrlen(wh);
        
        if ((le16toh(desc->status) &
             IWX_RX_MPDU_RES_STATUS_SEC_ENC_MSK) ==
            IWX_RX_MPDU_RES_STATUS_SEC_CCM_ENC) {
            /* Padding is inserted after the IV. */
            hdrlen += IEEE80211_CCMP_HDRLEN;
        }
        // The header, its IV and the two padding bytes must all lie inside the frame.
        if (hdrlen + 2 > len) {
            ic->ic_stats.is_rx_tooshort++;
            IC2IFP(ic)->netStat->inputErrors++;
            mbuf_freem(m);
            return;
        }
        
        //        memmove(m->m_data + 2, m->m_data, hdrlen);
        memmove((uint8_t*)mbuf_data(m) + 2, mbuf_data(m), hdrlen);
        mbuf_adj(m, 2);
    }
    
    memset(&rxi, 0, sizeof(rxi));
    
    /*
     * Hardware de-aggregates A-MSDUs and copies the same MAC header
     * in place for each subframe. But it leaves the 'A-MSDU present'
     * bit set in the frame header. We need to clear this bit ourselves.
     * (XXX This workaround is not required on AX200/AX201 devices that
     * have been tested by me, but it's unclear when this problem was
     * fixed in the hardware. It definitely affects the 9k generation.
     * Leaving this in place for now since some 9k/AX200 hybrids seem
     * to exist that we may eventually add support for.)
     *
     * And we must allow the same CCMP PN for subframes following the
     * first subframe. Otherwise they would be discarded as replays.
     */
    if (desc->mac_flags2 & IWX_RX_MPDU_MFLG2_AMSDU) {
        struct ieee80211_frame *wh = mtod(m, struct ieee80211_frame *);
        uint8_t subframe_idx = (desc->amsdu_info &
                                IWX_RX_MPDU_AMSDU_SUBFRAME_IDX_MASK);
        if (subframe_idx > 0)
            rxi.rxi_flags |= IEEE80211_RXI_HWDEC_SAME_PN;
        if (ieee80211_has_qos(wh) && ieee80211_has_addr4(wh) &&
            mbuf_len(m) >= sizeof(struct ieee80211_qosframe_addr4)) {
            struct ieee80211_qosframe_addr4 *qwh4 = mtod(m,
                                                         struct ieee80211_qosframe_addr4 *);
            qwh4->i_qos[0] &= htole16(~IEEE80211_QOS_AMSDU);
        } else if (ieee80211_has_qos(wh) &&
                   mbuf_len(m) >= sizeof(struct ieee80211_qosframe)) {
            struct ieee80211_qosframe *qwh = mtod(m,
                                                  struct ieee80211_qosframe *);
            qwh->i_qos[0] &= htole16(~IEEE80211_QOS_AMSDU);
        }    
    }
    
    /*
     * Verify decryption before duplicate detection. The latter uses
     * the TID supplied in QoS frame headers and this TID is implicitly
     * verified as part of the CCMP nonce.
     */
    if (iwx_rx_hwdecrypt(sc, m, le16toh(desc->status), &rxi)) {
        mbuf_freem(m);
        return;
    }
    
    bool awdlPeerData = false;
    if (awdlRx && mbuf_len(m) >= 24 && ItlAWDL::knownAddress(awdlOwnAddress)) {
        const uint8_t *f = mtod(m, const uint8_t *);
        awdlPeerData = (f[0] & 0x0c) == 8 && !(f[0] & 0x40) && ItlAWDL::sameAddress(f + 4, awdlOwnAddress);
        if (awdlPeerData) {
            const bool qos = (f[0] & 0x80) && mbuf_len(m) >= 26;
            if (!qos)
                ++awdlRxSequences.counts.noQos;
            awdlRxSequences.note(qos ? f[24] & 7U : 0U, uint16_t((f[22] | f[23] << 8) >> 4), f[1] & 0x08, mbuf_pkthdr_len(m));
            const uint16_t framePhy = le16toh(desc->phy_info);
            if (framePhy & IWX_RX_MPDU_PHY_AMPDU)
                awdlRxSequences.noteAmpdu(framePhy & IWX_RX_MPDU_PHY_AMPDU_TOGGLE);
        }
    }
    if (iwx_detect_duplicate(sc, m, desc, &rxi)) {
        if (awdlPeerData)
            ++awdlRxSequences.counts.duplicatesDropped;
        mbuf_freem(m);
        return;
    }
    
    rssi = iwx_rxmq_get_signal_strength(sc, desc);
    rssi = (0 - IWX_MIN_DBM) + rssi;    /* normalize */
    rssi = MIN(rssi, ic->ic_max_rssi);    /* clip to max. 100% */
    
    rxi.rxi_rssi = rssi;
    
    phy_info = le16toh(desc->phy_info);
    awdlRxPhyInfo = phy_info;
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        rate_n_flags = le32toh(desc->v3.rate_n_flags);
        chanidx = desc->v3.channel;
        device_timestamp = desc->v3.gp2_on_air_rise;
        rxi.rxi_tstamp = (uint32_t)le64toh(desc->v3.tsf_on_air_rise);
    } else {
        rate_n_flags = le32toh(desc->v1.rate_n_flags);
        chanidx = desc->v1.channel;
        device_timestamp = desc->v1.gp2_on_air_rise;
        rxi.rxi_tstamp = (uint32_t)le64toh(desc->v1.tsf_on_air_rise);
    }
    rxi.rxi_chan = chanidx;
    
    if (iwx_rx_reorder(sc, m, chanidx, desc,
                       (phy_info & IWX_RX_MPDU_PHY_SHORT_PREAMBLE),
                       rate_n_flags, device_timestamp, &rxi, ml))
        return;
    
    awdlRxMacMaskValid = sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210;
    awdlRxMacMask = awdlRxMacMaskValid ? desc->v3.mac_context : 0;
    iwx_rx_frame(sc, m, chanidx, le16toh(desc->status),
                 (phy_info & IWX_RX_MPDU_PHY_SHORT_PREAMBLE),
                 rate_n_flags, device_timestamp, &rxi, ml);
    awdlRxMacMaskValid = false;
}

void ItlIwx::
iwx_rx_tx_cmd_single(struct iwx_softc *sc, struct iwx_rx_packet *pkt,
                     struct iwx_tx_data *txd)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = IC2IFP(ic);
    struct iwx_tx_resp *tx_resp = (struct iwx_tx_resp *)pkt->data;
    int status = le16toh(tx_resp->status.status) & IWX_TX_STATUS_MSK;
    int txfail;
    
    KASSERT(tx_resp->frame_count == 1, "tx_resp->frame_count == 1");
    
    const bool coexFrame = (awdlCoexQueue >= 0 && tx_resp->tx_queue == awdlCoexQueue) ||
        (awdlCoexOrphanQueue >= 0 && tx_resp->tx_queue == awdlCoexOrphanQueue);
    bool burstFrame = false;
    if (awdlWindow > 1 && !awdlMonitorPending && awdlBurst.count && awdlMonitorGeneration == sc->sc_generation &&
        tx_resp->tx_queue == awdlMonitorQueue) {
        // Single frames only go when none of these are in flight, so this is the oldest.
        burstFrame = true;
        const bool sentOK = status == IWX_TX_STATUS_SUCCESS;
        const auto *sent = awdlBurst.front();
        const bool resent = sent->isRetry;
        if (sent->requestedWideRate) {
            const uint32_t rate = le32toh(tx_resp->initial_rate);
            const bool reportedWide = (rate & IWX_RATE_MCS_MOD_TYPE_MSK) == IWX_RATE_MCS_VHT_MSK &&
                (rate & IWX_RATE_MCS_CHAN_WIDTH_MSK) == IWX_RATE_MCS_CHAN_WIDTH_80;
            ++awdlTx80Completed;
            if (reportedWide)
                ++awdlTx80Reported;
            if (sentOK && reportedWide) {
                ++awdlTx80Acked;
                if (awdlTx80ConsecutiveMisses < 8)
                    awdlTx80ConsecutiveMisses = 0;
            } else if (awdlTx80ConsecutiveMisses < 8) {
                ++awdlTx80ConsecutiveMisses;
            }
        }
        const uint64_t doneUS = awdlUptimeUS();
        awdlTxTrace.noteCompletion(doneUS, sent->submitUS, awdlTxService.lastBusy, sentOK, sent->requestedWideRate,
                                   le16toh(tx_resp->wireless_media_time), awdlBurst.count);
        awdlTxService.note(doneUS, awdlBurst.count > 1, le16toh(tx_resp->wireless_media_time), tx_resp->failure_frame,
                           tx_resp->failure_rts, tx_resp->bt_kill_count, le32toh(tx_resp->initial_rate),
                           awdlRxAllFrames, awdlRxFromPeer);
        if (doneUS >= sent->submitUS) {
            const uint64_t flight = doneUS - sent->submitUS;
            ++(sentOK ? awdlFlightOK : awdlFlightFail)[ItlAWDL::flightBin(flight)];
            awdlFlightSumUS += flight;
        }
        awdlLastDoneUS = doneUS;
        auto &results = awdlRateResults[sent->step];
        ++results[sentOK ? 1 : 2];
        results[3] += tx_resp->failure_frame;
        if (!sentOK)
            awdlDataLastFailure = unsigned(status);
        if (resent) {
            if (sentOK) {
                ++awdlResendRecovered;
                awdlResend = ItlAWDL::ResendState{};
            } else {
                const bool wasHeld = awdlResend.held;
                if (!ItlAWDL::resendAfterFailure(awdlResend, doneUS) && wasHeld)
                    ++awdlResendGaveUp;
            }
        } else {
            ++(sentOK ? awdlDataOK : awdlDataFailed)[1];
            ItlAWDL::noteDataResult(awdlDataRate, sentOK);
        }
        awdlBurst.complete(sentOK);
        awdlKickTransmit = true;
    }
    if (awdlMonitorPending && awdlMonitorGeneration == sc->sc_generation &&
        tx_resp->tx_queue == awdlMonitorQueue) {
        awdlMonitorCompletedOK = status == IWX_TX_STATUS_SUCCESS;
        ItlAWDL::recordAck(awdlAcks, int(awdlAckPending), unsigned(status), tx_resp->failure_frame);
        if (awdlDataInFlight) {
            const unsigned kind = awdlDataInFlight - 1;
            const bool sentOK = status == IWX_TX_STATUS_SUCCESS;
            // Resends have their own counters, so these stay per frame, on its first try.
            const bool firstTry = kind == 0 || !awdlResend.attempts;
            if (!sentOK)
                awdlDataLastFailure = unsigned(status);
            if (firstTry)
                ++(sentOK ? awdlDataOK : awdlDataFailed)[kind];
            if (kind == 1) {
                const uint64_t doneUS = awdlUptimeUS();
                if (doneUS >= awdlSubmitUS) {
                    const uint64_t flight = doneUS - awdlSubmitUS;
                    ++(sentOK ? awdlFlightOK : awdlFlightFail)[ItlAWDL::flightBin(flight)];
                    awdlFlightSumUS += flight;
                }
                awdlLastDoneUS = doneUS;
                if (firstTry)
                    ItlAWDL::noteDataResult(awdlDataRate, sentOK);
                auto &results = awdlRateResults[awdlDataStepInFlight];
                ++results[sentOK ? 1 : 2];
                results[3] += tx_resp->failure_frame;
                if (sentOK) {
                    if (!firstTry)
                        ++awdlResendRecovered;
                    awdlResend = ItlAWDL::ResendState{};
                } else {
                    const bool wasHeld = awdlResend.held;
                    if (!ItlAWDL::resendAfterFailure(awdlResend, awdlUptimeUS()) && wasHeld)
                        ++awdlResendGaveUp;
                }
            }
        }
        // Firmware can't credit ACKs to the foreign address, so it would skew this table.
        if (ItlAWDL::ackProbeIsPeer(awdlAckPending) && awdlAckPending != ItlAWDL::AckProbe::PeerForeign)
            ItlAWDL::recordPeerProbe(awdlPeerProbes, nitems(awdlPeerProbes), awdlPeerProbeCount, awdlAckTarget,
                                     status == IWX_TX_STATUS_SUCCESS, awdlAckTargetRssi);
        if (awdlBaResponseInFlight) {
            awdlBaResponseInFlight = false;
            ++awdlBaResponsesDone;
            awdlBaResponseLastStatus = unsigned(status);
            if (status == IWX_TX_STATUS_SUCCESS) {
                ++awdlBaResponsesAcked;
                awdlBaPeerAccepted = true;
            }
            awdlSessLog("addba answer sent, status %d\n", status);
        }
        awdlTxLog("single-frame firmware completion queue %d status %d\n", awdlMonitorQueue, status);
    }
    txfail = (status != IWX_TX_STATUS_SUCCESS);
    
    if (txfail) {
        // Unanswered probes are expected and would flush the startup log.
        if (awdlAckPending == ItlAWDL::AckProbe::None && !awdlDataInFlight && !burstFrame)
            XYLog("%s %d OUTPUT_ERROR type=%d status=%d\n", __FUNCTION__, __LINE__, txd->type, status);
        // The second context's frames are AWDL's, not Wi-Fi's: they don't count against en0 or move
        // the station's management antenna.
        if (!coexFrame) {
            ifp->netStat->outputErrors++;
            if (txd->type == IEEE80211_FC0_TYPE_MGT)
                iwx_toggle_tx_ant(sc, &sc->sc_mgmt_last_antenna_idx);
        }
    }
}

void
iwx_clear_tx_desc(struct iwx_softc *sc, struct iwx_tx_ring *ring, int idx)
{
    struct iwx_tfh_tfd *desc = &ring->desc[idx];
    uint8_t num_tbs = le16toh(desc->num_tbs) & 0x1f;
    int i;
    
    /* First TB is never cleared - it is bidirectional DMA data. */
    for (i = 1; i < num_tbs; i++) {
        struct iwx_tfh_tb *tb = &desc->tbs[i];
        memset(tb, 0, sizeof(*tb));
    }
    desc->num_tbs = 0;
    
//    bus_dmamap_sync(sc->sc_dmat, ring->desc_dma.map,
//                    (char *)(void *)desc - (char *)(void *)ring->desc_dma.vaddr,
//                    sizeof(*desc), BUS_DMASYNC_PREWRITE);
}

void ItlIwx::
iwx_txd_done(struct iwx_softc *sc, struct iwx_tx_data *txd)
{
    struct ieee80211com *ic = &sc->sc_ic;
    
    //    bus_dmamap_sync(sc->sc_dmat, txd->map, 0, txd->map->dm_mapsize,
    //        BUS_DMASYNC_POSTWRITE);
    //    bus_dmamap_unload(sc->sc_dmat, txd->map);
    mbuf_freem(txd->m);
    txd->m = NULL;
    
    KASSERT(txd->in, "txd->in");
    ieee80211_release_node(ic, &txd->in->in_ni);
    txd->in = NULL;
    if (txd == awdlMonitorPending) {
        awdlMonitorPending = nullptr;
        awdlTxLog("single-frame buffer and node reclaimed on completion\n");
        // An unacknowledged probe is the measurement, not a transmit fault.
        const bool ackProbeDone = awdlAckPending != ItlAWDL::AckProbe::None || awdlDataInFlight;
        const bool dataFinished = awdlDataInFlight != 0;
        awdlAckPending = ItlAWDL::AckProbe::None;
        awdlDataInFlight = 0;
        if (awdlSyncTrain && (awdlMonitorCompletedOK || ackProbeDone) && awdlMonitorSubmitted < awdlTrainLimit() &&
            awdlMonitorGeneration == sc->sc_generation) {
            awdlMonitorProbeStarted = false;
            awdlMonitorTxAttempted = false;
            // Only one frame is in flight, so waiting for the timer would limit throughput.
            // The ring slot isn't reclaimed yet, so the next send waits for awdlAfterCompletion.
            if (dataFinished && awdlDataTx)
                awdlKickTransmit = true;
        }
        if (awdlSyncTrain)
            awdlTxLog("sync train completed %u of %u success %u\n", awdlMonitorSubmitted,
                      awdlTrainLimit(),
                      awdlMonitorCompletedOK ? 1U : 0U);
    }
}

void ItlIwx::
iwx_clear_oactive(struct iwx_softc *sc, struct iwx_tx_ring *ring)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = &ic->ic_if;

    if (ring->queued < ring->low_mark) {
        sc->qfullmsk.clear(ring->qid);
        if (sc->qfullmsk.empty() && ifq_is_oactive(&ifp->if_snd)) {
            ifq_clr_oactive(&ifp->if_snd);
            (*ifp->if_start)(ifp);
        }
#ifdef __PRIVATE_SPI__
        ifp->iface->signalOutputThread();
#endif
    }
}

// Whether a firmware completion boundary may be reclaimed on this ring: the ring has to be allocated
// (a power-of-two size that fits its slot array), the boundary inside it, and the slots it would free no
// more than are outstanding. A stale or backward boundary would otherwise wrap and free newer frames,
// and an unallocated ring would reclaim modulo zero.
static bool
iwx_txq_reclaim_ok(const struct iwx_tx_ring *ring, int idx)
{
    const unsigned n = ring->ring_count;
    if (n == 0 || n > nitems(ring->data) || (n & (n - 1)) != 0 || ring->desc == NULL)
        return false;
    if (idx < 0 || unsigned(idx) >= n || ring->tail < 0 || unsigned(ring->tail) >= n)
        return false;
    const unsigned freed = (unsigned(idx) - unsigned(ring->tail) + n) % n;
    const unsigned written = (unsigned(ring->cur) - unsigned(ring->tail) + n) % n;
    const unsigned queued = ring->queued > 0 ? unsigned(ring->queued) : 0;
    return freed <= (queued > written ? queued : written);
}


void ItlIwx::
iwx_rx_tx_ba_notif(struct iwx_softc *sc, struct iwx_rx_packet *pkt, struct iwx_rx_data *data)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_compressed_ba_notif *ba_res = (struct iwx_compressed_ba_notif *)pkt->data;
    uint8_t tid;
    uint16_t qid; // The full TVQM queue number; 8 bits would alias queue 256 onto queue 0.
    int i;
    struct iwx_tx_ring *ring;

    // The firmware's entry count says how many TFD records follow. Nothing is read, the station watchdog
    // isn't touched and no ring changes unless the payload holds them all and every record names an
    // allocated queue with a boundary that is safe to reclaim. (The TID isn't used as an index here.)
    {
        const size_t payload = iwx_rx_packet_payload_len(pkt);
        if (payload < offsetof(struct iwx_compressed_ba_notif, tfd))
            return;
        const size_t count = le16toh(ba_res->tfd_cnt);
        if (payload < offsetof(struct iwx_compressed_ba_notif, tfd) + count * sizeof(ba_res->tfd[0]))
            return;
        for (size_t n = 0; n < count; ++n) {
            const uint16_t q = le16toh(ba_res->tfd[n].q_num);
            if (q >= nitems(sc->txq))
                return;
            const struct iwx_tx_ring *r = &sc->txq[q];
            if (!iwx_txq_reclaim_ok(r, int(IWX_AGG_SSN_TO_TXQ_IDX(le16toh(ba_res->tfd[n].tfd_index),
                                                                   r->ring_count)))) {
                ++awdlReclaimRefused;
                return;
            }
        }
    }

    if (le32toh(ba_res->flags) != IWX_BA_RESP_TX_BAR && le32toh(ba_res->flags) != IWX_BA_RESP_TX_AGG){
        DPRINTFN(3, ("BA_NOTIFICATION flags %x, sent:%d, acked:%d, tfd_cnt:%d, query_frame_cnt:%d, retry_cnt:%d\n",
              le32toh(ba_res->flags),
              le16toh(ba_res->txed),
              le16toh(ba_res->done),
                     le16toh(ba_res->tfd_cnt),
              ba_res->query_frame_cnt,
              ba_res->retry_cnt));
    }

    if (ic->ic_state != IEEE80211_S_RUN)
        return;

    if (!le16toh(ba_res->tfd_cnt))
        return;

    bool coexReclaimed = false, coexNotified = false;
    /* Free per TID */
    for (i = 0; i < le16toh(ba_res->tfd_cnt); i++) {
        struct iwx_compressed_ba_tfd *ba_tfd = &ba_res->tfd[i];

        qid = le16toh(ba_tfd->q_num);
        if (qid >= nitems(sc->txq) || !sc->txq[qid].ring_count)
            continue;
        ring = &sc->txq[qid];
        const bool awdlBaQueue = int(qid) == awdlBaTxQueue;
        const bool coexQueue = (awdlCoexQueue >= 0 && int(qid) == awdlCoexQueue) ||
            (awdlCoexOrphanQueue >= 0 && int(qid) == awdlCoexOrphanQueue) ||
            (awdlCoexBaTxQueue >= 0 && int(qid) == awdlCoexBaTxQueue);
        const bool coexBaQueue = awdlCoexBaTxQueue >= 0 && int(qid) == awdlCoexBaTxQueue;
        if (coexBaQueue) {
            coexNotified = true;
            ++awdlCoexBaTxNotifs;
            awdlCoexBaTxLastNotifUS = awdlUptimeUS();
            awdlCoexBaTxSentAir += le16toh(ba_res->txed);
            awdlCoexBaTxAcked += le16toh(ba_res->done);
            awdlCoexBaTxLastRate = le32toh(ba_res->tx_rate);
            awdlCoexBaTxPeakReportedFrames = MAX(awdlCoexBaTxPeakReportedFrames, uint32_t(le16toh(ba_res->txed)));
            if (awdlVht80TwoStream(awdlCoexBaTxLastRate))
                ++awdlCoexBaTxVht80TwoStreamNotifs;
        }
        const int queuedBefore = ring->queued;
        if (awdlBaQueue) {
            ++awdlBaTxNotifs;
            awdlBaTxSentAir += le16toh(ba_res->txed);
            awdlBaTxAcked += le16toh(ba_res->done);
            awdlKickTransmit = true;
        }

        // Only progress on a station queue says the station's transmit path is alive.
        if (!awdlBaQueue && !coexQueue &&
            int(IWX_AGG_SSN_TO_TXQ_IDX(le16toh(ba_tfd->tfd_index), ring->ring_count)) != ring->tail)
            sc->sc_tx_timer = 0;

        iwx_ampdu_txq_advance(sc, ring, IWX_AGG_SSN_TO_TXQ_IDX(le16toh(ba_tfd->tfd_index), ring->ring_count));
        if (awdlBaQueue || (coexBaQueue && awdlCoexBaTraceEnabled)) {
            auto &trace = awdlBaQueue ? awdlBaTrace : awdlCoexBaTrace;
            trace.note(awdlUptimeUS(), le32toh(ba_res->wireless_time), le32toh(ba_res->tx_rate),
                       le16toh(ba_res->txed), le16toh(ba_res->done), ba_res->retry_cnt,
                       unsigned(queuedBefore), unsigned(ring->queued), le32toh(ba_res->flags));
        }
        if (coexBaQueue && ring->queued < queuedBefore)
            coexReclaimed = true;
        iwx_clear_oactive(sc, ring);
        awdlAfterCompletion(sc);
    }

    // Refill only after the whole notification has been reclaimed, with a
    // bounded budget so infrastructure RX and TX still get workloop time.
    const int queue = awdlCoexBaTxQueue;
    // Counted only in the gate, where awdl0's queue can be read.
    const bool traceNotification = awdlCoexBaTraceEnabled && coexNotified;
    const bool queueInGate = (coexReclaimed || traceNotification) && queue >= 0 && queue < int(nitems(sc->txq)) &&
        getMainWorkLoop()->inGate();
    const bool emptyAfterReclaim = coexReclaimed && queueInGate && sc->txq[queue].queued == 0;
    const bool sampleRefill = traceNotification && queueInGate;
    const unsigned readyAfterReclaim = emptyAfterReclaim || sampleRefill ? itlAWDLTransmitQueued(getController()) : 0;
    const uint64_t baUS = sampleRefill ? awdlUptimeUS() : 0;
    const uint16_t afterReclaim = sampleRefill ? uint16_t(sc->txq[queue].queued) : 0;
    if (emptyAfterReclaim)
        ++(readyAfterReclaim ? awdlCoexBaEmptyWithReady : awdlCoexBaEmptyNoReady);
    const bool recentAggregate = awdlCoexBaTxLastAggUS &&
        awdlUptimeUS() - awdlCoexBaTxLastAggUS < 300000ULL;
    if (awdlCoexBaRefillEnabled && coexReclaimed && queueInGate &&
        sc->txq[queue].queued < int((awdlCoexBaTxQueuedCap() + 1) / 2) &&
        awdlCoexBaTxState == kCoexBaTxAgreed && (awdlCoexBaTxBulk.bulk || recentAggregate) &&
        !awdlCoexPeerPause.paused && !awdlCoexMovePending) {
        const uint32_t before = awdlCoexBaTxFrames;
        awdlCoexDataPump(sc, 64);
        ++awdlCoexBaRefillKicks;
        awdlCoexBaRefillFrames += awdlCoexBaTxFrames - before;
        if (sc->txq[queue].queued == 0 && itlAWDLTransmitQueued(getController()))
            ++awdlCoexBaRefillStillEmptyReady;
    }
    if (sampleRefill)
        awdlCoexBaLastRefillSample = {baUS, uint32_t(sc->sc_generation), awdlCoexToken, awdlCoexBaPeerEpoch,
                                     queue, uint16_t(readyAfterReclaim), afterReclaim,
                                     uint16_t(sc->txq[queue].queued)};
}

// After a completion has been fully reclaimed. If the next frame can't go from here, the
// timer still picks it up, as it always did.
void ItlIwx::
awdlAfterCompletion(struct iwx_softc *sc)
{
    if (!awdlKickTransmit)
        return;
    awdlKickTransmit = false;
#if defined(ITL_AWDL_NATIVE)
    // A busy link would otherwise never let the timer hand finished packets back.
    (void)itlAWDLServiceTransmit(getController());
#endif
    const auto before = awdlMonitorSubmitted;
    iwx_awdl_transport_probe(sc);
    if (awdlMonitorSubmitted != before)
        ++awdlTxKicks;
    else if (!awdlStopping)
        timeout_add_usec(&awdlRxTimer, 1000); // This timer has millisecond resolution.
}

void ItlIwx::
iwx_ampdu_txq_advance(struct iwx_softc *sc, struct iwx_tx_ring *ring, int idx)
{
    if (!iwx_txq_reclaim_ok(ring, idx)) {
        ++awdlReclaimRefused;
        return;
    }
    struct iwx_tx_data *txd;

    while (ring->tail != idx) {
        txd = &ring->data[ring->tail];
        if (txd->m != NULL) {
            iwx_txd_done(sc, txd);
            iwx_clear_tx_desc(sc, ring, ring->tail);
            ring->queued--;
        }
        ring->tail = (ring->tail + 1) % ring->ring_count;
    }
}

#define IWX_AGG_TX_STATE_(x) case IWX_AGG_TX_STATE_ ## x: return #x
static const char *iwx_get_agg_tx_status(uint16_t status)
{
    switch (status & IWX_AGG_TX_STATE_STATUS_MSK) {
            IWX_AGG_TX_STATE_(TRANSMITTED);
            IWX_AGG_TX_STATE_(UNDERRUN);
            IWX_AGG_TX_STATE_(BT_PRIO);
            IWX_AGG_TX_STATE_(FEW_BYTES);
            IWX_AGG_TX_STATE_(ABORT);
            IWX_AGG_TX_STATE_(TX_ON_AIR_DROP);
            IWX_AGG_TX_STATE_(LAST_SENT_TRY_CNT);
            IWX_AGG_TX_STATE_(LAST_SENT_BT_KILL);
            IWX_AGG_TX_STATE_(SCD_QUERY);
            IWX_AGG_TX_STATE_(TEST_BAD_CRC32);
            IWX_AGG_TX_STATE_(RESPONSE);
            IWX_AGG_TX_STATE_(DUMP_TX);
            IWX_AGG_TX_STATE_(DELAY_TX);
    }

    return "UNKNOWN";
}

void ItlIwx::
iwx_rx_tx_cmd(struct iwx_softc *sc, struct iwx_rx_packet *pkt,
              struct iwx_rx_data *data)
{
    uint32_t ssn;
    int idx;
    int tid;
    struct iwx_tx_resp *tx_resp = (struct iwx_tx_resp *)pkt->data;
    // The firmware's frame count says how many statuses follow, with the SSN after them. Nothing is read
    // unless the payload really holds all of that.
    {
        const size_t payload = iwx_rx_packet_payload_len(pkt);
        if (payload < sizeof(*tx_resp) || tx_resp->frame_count < 1 ||
            payload < sizeof(*tx_resp) + size_t(tx_resp->frame_count - 1) * sizeof(tx_resp->status) + sizeof(uint32_t))
            return;
    }
    int qid = tx_resp->tx_queue;
    if (qid < 0 || qid >= int(nitems(sc->txq)))
        return;
    struct iwx_tx_ring *ring = &sc->txq[qid];
    struct iwx_tx_data *txd;
    // An in-range queue number can still name a ring that isn't allocated; nothing indexes it then.
    if (ring->ring_count == 0 || ring->ring_count > nitems(ring->data) || ring->desc == NULL)
        return;

    bus_dmamap_sync(sc->sc_dmat, data->map, 0, IWX_RBUF_SIZE,
                    BUS_DMASYNC_POSTREAD);
    
    // The listener's completions say nothing about the station's transmit path.
    const bool coexQueue = (awdlCoexQueue >= 0 && qid == awdlCoexQueue) ||
        (awdlCoexOrphanQueue >= 0 && qid == awdlCoexOrphanQueue);
    if (!coexQueue && !(awdlCoexBaTxQueue >= 0 && qid == awdlCoexBaTxQueue))
        sc->sc_tx_timer = 0;
    if (awdlCoexBaTxQueue >= 0 && qid == awdlCoexBaTxQueue) {
        ++awdlCoexBaTxResponses;
        awdlCoexBaTxResponseFrames += tx_resp->frame_count;
        if (tx_resp->frame_count > 1)
            ++awdlCoexBaTxAggResponses;
        else if (ring->queued > 1)
            ++awdlCoexBaTxSinglesWithBacklog;
        if (tx_resp->frame_count == 1) {
            const uint16_t respStatus = le16toh(tx_resp->status.status) & IWX_TX_STATUS_MSK;
            if (respStatus == IWX_TX_STATUS_SUCCESS || respStatus == IWX_TX_STATUS_DIRECT_DONE) {
                ++awdlCoexBaTxRespOK;
            } else {
                ++awdlCoexBaTxRespFailed;
                awdlCoexBaTxRespLastFailStatus = respStatus;
            }
        }
    }

    if (tx_resp->frame_count > 1) {
        for (int i = 0; i < tx_resp->frame_count; i++) {
            uint16_t fstatus = le16_to_cpu((&tx_resp->status)[i].status);

            DPRINTFN(3, ("status %s (0x%04x), try-count (%d) qid (%d) seq (0x%x)\n",
                         iwx_get_agg_tx_status(fstatus),
                         fstatus & IWX_AGG_TX_STATE_STATUS_MSK,
                         (fstatus & IWX_AGG_TX_STATE_TRY_CNT_MSK) >>
                         IWX_AGG_TX_STATE_TRY_CNT_POS,
                         qid,
                         le16_to_cpu((&tx_resp->status)[i].sequence)));
        }
    } else {
        tid = tx_resp->ra_tid & 0x0f;
        memcpy(&ssn, &tx_resp->status + tx_resp->frame_count, sizeof(ssn));
        ssn = le32toh(ssn) & 0xfff;
        idx = IWX_AGG_SSN_TO_TXQ_IDX(ssn, ring->ring_count);
        txd = &ring->data[idx];
        // laobamac d695c97: on the station's own queues the SSN is the next frame to send, so the
        // completed frame is the one before it. The AWDL queues keep their own accounting below.
        if (!coexQueue && qid != awdlBaTxQueue && qid != awdlMonitorQueue &&
            !(awdlCoexBaTxQueue >= 0 && qid == awdlCoexBaTxQueue)) {
            if (!itlTxCompletionValid(ring->tail, ring->queued, idx, ring->ring_count))
                return;
            if (idx == ring->tail) {
                awdlAfterCompletion(sc);
                return;
            }
            txd = &ring->data[(idx + ring->ring_count - 1) % ring->ring_count];
        }
        if (coexQueue) {
            // This completion frees slots from the tail up to, not including, idx. That has to be at least
            // one and at most what is outstanding; anything else is a fault, and nothing is freed for it.
            const int n = ring->ring_count;
            const int freed = n > 0 ? (idx - ring->tail + n) % n : 0;
            awdlCoexLastBoundary = idx;
            awdlCoexLastSsn = ssn;
            if (qid == awdlCoexQueue && n > 0 && freed >= 1 && freed <= ring->queued) {
                awdlCoexLastCompletionUS = awdlUptimeUS();
                awdlCoexStuckStreak = 0;
            }
            if (n <= 0 || freed < 1 || freed > ring->queued) {
                ++awdlCoexBadCompletions;
                snprintf(awdlCoexFaultSnapshot, sizeof(awdlCoexFaultSnapshot),
                         "bad completion queue %d token %u gen %d ssn %u tail %d queued %d pending %d status 0x%x",
                         qid, awdlCoexToken, sc->sc_generation, ssn, ring->tail, ring->queued, awdlCoexPendingSlot,
                         unsigned(le16toh(tx_resp->status.status)));
                awdlCoexPublish();
                return;
            }
            // The status belongs to the descriptor the response header names (the index we put in the command
            // header). The SSN is only the reclaim boundary. Every reclaimed slot is cleared; only the named one
            // takes this status. A missing index identifies a candidate only when one descriptor was reclaimed.
            const int status = le16toh(tx_resp->status.status) & IWX_TX_STATUS_MSK;
            const bool ok = status == IWX_TX_STATUS_SUCCESS;
            int statusSlot = ItlAWDL::reclaimStatusSlot(ring->tail, freed, n, pkt->hdr.idx);
            const bool indexed = statusSlot >= 0;
            if (indexed) {
                ++awdlCoexStatusIdxHits;
            } else {
                ++awdlCoexStatusIdxMisses;
                if (freed == 1)
                    statusSlot = ring->tail;
            }
            const unsigned reclaimCount = MIN(unsigned(freed), 255U);
            const unsigned statusSource = unsigned(pkt->hdr.idx) | (indexed ? 0U : 0x100U);
            if (freed > 1)
                ++awdlCoexMultiReclaims;
            bool attributed = false;
            for (int k = 0; k < freed; ++k) {
                const int slot = (ring->tail + k) % n;
                const bool own = slot == statusSlot;
                if (qid == awdlCoexQueue && slot == awdlCoexPendingSlot && awdlCoexInFlight &&
                    awdlCoexPendingGeneration == sc->sc_generation) {
                    awdlCoexInFlight = false;
                    awdlCoexPendingSlot = -1;
                    if (own) {
                        ++(ok ? awdlCoexTxOK : awdlCoexTxFailed);
                        attributed = true;
                    } else {
                        ++awdlCoexSyncReclaimedUnknown; // Reclaimed; its own status isn't in this response.
                    }
                }
                if (!awdlCoexDataTx || qid != awdlCoexQueue || slot >= int(nitems(awdlCoexSlotKind)) ||
                    !awdlCoexSlotKind[slot])
                    continue;
                const uint8_t kind = awdlCoexSlotKind[slot];
                awdlCoexSlotKind[slot] = 0;
                const bool sameEpoch = awdlCoexBaPeerAdded && awdlCoexSlotBaPeerEpoch[slot] == awdlCoexBaPeerEpoch;
                const bool delbaAttempt = kind == kCoexSlotDelba && sameEpoch &&
                    awdlCoexDelbaWaitGen == sc->sc_generation && awdlCoexDelbaWaitEpoch == awdlCoexBaPeerEpoch &&
                    awdlCoexDelbaWaitTid == int(awdlCoexSlotToken[slot]) &&
                    awdlCoexDelbaAttemptId == awdlCoexSlotEnqueueId[slot];
                if (!own) {
                    ++awdlCoexReclaimUnknown;
                    if (kind >= kCoexSlotBaAnswer)
                        awdlCoexBaEvent('u', kind, awdlCoexSlotToken[slot], reclaimCount, statusSource,
                                        awdlCoexSlotEnqueueId[slot]);
                    if (delbaAttempt)
                        awdlCoexDelbaResult = 2; // Unknown result: eligible for a bounded retry.
                    continue;
                }
                attributed = true;
                if (kind < kCoexSlotBaAnswer)
                    ++(ok ? awdlCoexDataOK : awdlCoexDataFailed);
                if (kind == 2) {
                    ++(ok ? awdlCoexUcastOK : awdlCoexUcastFailed);
                    ++(ok ? awdlCoexRateWindowOK : awdlCoexRateWindowFailed);
                    const uint32_t window = awdlCoexRateWindowOK + awdlCoexRateWindowFailed;
                    if (window >= 64) {
                        if (awdlCoexRateWindowFailed * 5 > window && awdlCoexRateStep > 0) {
                            --awdlCoexRateStep;
                            ++awdlCoexRateDowns;
                        } else if (awdlCoexRateWindowFailed * 20 < window &&
                                   awdlCoexRateStep + 1 < (awdlCoexOwnWidth == 80 ? nitems(kAwdlCoexRateMcs) : 4U)) {
                            ++awdlCoexRateStep;
                            ++awdlCoexRateUps;
                        }
                        awdlCoexRateWindowOK = awdlCoexRateWindowFailed = 0;
                    }
                } else if (kind == 1) {
                    ++(ok ? awdlCoexGroupOK : awdlCoexGroupFailed);
                } else if (kind >= kCoexSlotBaAnswer) {
                    ++(ok ? awdlCoexMgmtOK : awdlCoexMgmtFailed);
                    awdlCoexBaEvent(kind == kCoexSlotBaAsk ? 'a' : kind == kCoexSlotDelba ? 'd' : 'q',
                                    awdlCoexSlotToken[slot], ok ? 1 : 0, reclaimCount, statusSource,
                                    awdlCoexSlotEnqueueId[slot]);
                    if (kind == kCoexSlotBaAsk)
                        ++(ok ? awdlCoexBaAskOK : awdlCoexBaAskFailed);
                    else if (kind == kCoexSlotBaAnswer && ok && sameEpoch)
                        awdlCoexBaPeerAccepted = true; // Only an acknowledged ADDBA answer opens the gate.
                    else if (delbaAttempt) {
                        awdlCoexDelbaResult = ok ? 1 : 2;
                        if (!ok)
                            ++awdlCoexDelbaFailedTx;
                    }
                }
            }
            if (!attributed)
                ++awdlCoexLateCompletions;
        }
        if (qid == awdlBaTxQueue) {
            ++awdlBaTxSingles;
            awdlKickTransmit = true;
        }
        if (qid == awdlMonitorQueue) {
            awdlTxLastCompletionUS = awdlUptimeUS();
            awdlTxLastIndex = uint32_t(idx);
            awdlTxLastStatus = le16toh(tx_resp->status.status);
        }
        iwx_rx_tx_cmd_single(sc, pkt, txd);
        DPRINTFN(3, ("%s tid=%d ssn=%d idx=%d\n", __FUNCTION__, tid, ssn, idx));
        iwx_ampdu_txq_advance(sc, ring, idx);
        iwx_clear_oactive(sc, ring);
        awdlAfterCompletion(sc);
    }
}

// Whether a notification's payload holds a whole T. The fixed-size notifications in iwx_rx_bmiss and iwx_rx_pkt were read without
// checking, so a short record made the driver read past it or into the next one (audit HL05).
#define IWX_NOTIF_FITS(pkt, T) (iwx_rx_packet_payload_len(pkt) >= sizeof(T))

void ItlIwx::
iwx_rx_bmiss(struct iwx_softc *sc, struct iwx_rx_packet *pkt,
             struct iwx_rx_data *data)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_missed_beacons_notif *mbn = (struct iwx_missed_beacons_notif *)pkt->data;
    uint32_t missed;
    
    if (!IWX_NOTIF_FITS(pkt, struct iwx_missed_beacons_notif))     // audit HL05
        return;
    if ((ic->ic_opmode != IEEE80211_M_STA) ||
        (ic->ic_state != IEEE80211_S_RUN))
        return;
    
    //    bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*pkt),
    //        sizeof(*mbn), BUS_DMASYNC_POSTREAD);
    
    missed = le32toh(mbn->consec_missed_beacons_since_last_rx);
    if (missed > ic->ic_bmissthres && ic->ic_mgt_timer == 0) {
        if (ic->ic_if.if_flags & IFF_DEBUG) {
            XYLog("%s: receiving no beacons from %s; checking if "
                  "this AP is still responding to probe requests\n",
                  DEVNAME(sc), ether_sprintf(ic->ic_bss->ni_macaddr));
            /* Dump driver status (TX and RX rings) while we're here. */
            XYLog("%s driver queue status:\n", __FUNCTION__);
            for (int i = 0; i < IWX_MAX_QUEUES; i++) {
                struct iwx_tx_ring *ring = &sc->txq[i];
                XYLog("  tx ring %2d: qid=%-2d cur=%-3d "
                      "queued=%-3d\n",
                      i, ring->qid, ring->cur, ring->queued);
            }
            XYLog("  rx ring: cur=%d\n", sc->rxq.cur);
            XYLog("  802.11 state %s\n",
                  ieee80211_state_name[sc->sc_ic.ic_state]);
        }
        /*
         * Rather than go directly to scan state, try to send a
         * directed probe request first. If that fails then the
         * state machine will drop us into scanning after timing
         * out waiting for a probe response.
         */
        IEEE80211_SEND_MGMT(ic, ic->ic_bss,
                            IEEE80211_FC0_SUBTYPE_PROBE_REQ, 0);
    }
    
}

int ItlIwx::
iwx_binding_cmd(struct iwx_softc *sc, struct iwx_node *in, uint32_t action)
{
    struct iwx_binding_cmd cmd;
    struct iwx_phy_ctxt *phyctxt = in->in_phyctxt;
    uint32_t mac_id = IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color);
    int i, err, active = (sc->sc_flags & IWX_FLAG_BINDING_ACTIVE);
    uint32_t status;
    
    if (action == IWX_FW_CTXT_ACTION_ADD && active) {
        XYLog("binding already added\n");
        return 0;
    }
    if (action == IWX_FW_CTXT_ACTION_REMOVE && !active) {
        XYLog("binding already removed\n");
        return 0;
    }
    
    if (phyctxt == NULL) /* XXX race with iwx_stop() */
        return EINVAL;
    
    memset(&cmd, 0, sizeof(cmd));
    
    cmd.id_and_color
    = htole32(IWX_FW_CMD_ID_AND_COLOR(phyctxt->id, phyctxt->color));
    cmd.action = htole32(action);
    cmd.phy = htole32(IWX_FW_CMD_ID_AND_COLOR(phyctxt->id, phyctxt->color));
    
    cmd.macs[0] = htole32(mac_id);
    for (i = 1; i < IWX_MAX_MACS_IN_BINDING; i++)
        cmd.macs[i] = htole32(IWX_FW_CTXT_INVALID);
    
    if (IEEE80211_IS_CHAN_2GHZ(phyctxt->channel) ||
        !isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT))
        cmd.lmac_id = htole32(IWX_LMAC_24G_INDEX);
    else
        cmd.lmac_id = htole32(IWX_LMAC_5G_INDEX);
    
    status = 0;
    err = iwx_send_cmd_pdu_status(sc, IWX_BINDING_CONTEXT_CMD, sizeof(cmd),
                                  &cmd, &status);
    if (err == 0 && status != 0)
        err = EIO;
    
    return err;
}

static uint8_t
iwx_get_channel_width(struct ieee80211com *ic, struct ieee80211_channel *c)
{
    uint8_t ret = IWX_PHY_VHT_CHANNEL_MODE20;
    if (awdlCoexPhyWidth >= 0 && awdlCoexMulti && awdlPhyBuildingId == kAwdlCoexPhyId)
        return uint8_t(awdlCoexPhyWidth);
    if (awdlWide80Applies(ic, c))
        return IWX_PHY_VHT_CHANNEL_MODE80;
    if (ic->ic_bss == NULL || ic->ic_state < IEEE80211_S_ASSOC) {
        return ret;
    }
    switch (ic->ic_bss->ni_chw) {
        case IEEE80211_CHAN_WIDTH_20_NOHT:
        case IEEE80211_CHAN_WIDTH_20:
            return IWX_PHY_VHT_CHANNEL_MODE20;
        case IEEE80211_CHAN_WIDTH_40:
            return IWX_PHY_VHT_CHANNEL_MODE40;
        case IEEE80211_CHAN_WIDTH_80:
            return IWX_PHY_VHT_CHANNEL_MODE80;
        case IEEE80211_CHAN_WIDTH_160:
            return IWX_PHY_VHT_CHANNEL_MODE160;
        default:
            XYLog("Invalid channel width=%u\n", ic->ic_bss->ni_chw);
            return ret;
    }
}

static uint8_t
iwx_get_ctrl_pos(struct ieee80211com *ic, struct ieee80211_channel *c)
{
    // Control channel 149 is 30 MHz below the centre, 155.
    if (awdlWide80Applies(ic, c))
        return IWX_PHY_VHT_CTRL_POS_2_BELOW;
    // The listener's own context at 80 MHz is only ever in 149-161, centred on 155.
    if (awdlCoexPhyWidth == IWX_PHY_VHT_CHANNEL_MODE80 && awdlCoexMulti && awdlPhyBuildingId == kAwdlCoexPhyId) {
        switch (ieee80211_chan2ieee(ic, c)) {
            case 149: case 36: return IWX_PHY_VHT_CTRL_POS_2_BELOW;
            case 153: case 40: return IWX_PHY_VHT_CTRL_POS_1_BELOW;
            case 157: case 44: return IWX_PHY_VHT_CTRL_POS_1_ABOVE;
            case 161: case 48: return IWX_PHY_VHT_CTRL_POS_2_ABOVE;
            default: break;
        }
    }
    if (ic->ic_bss == NULL || ic->ic_state < IEEE80211_S_ASSOC || iwx_get_channel_width(ic, c) == IWX_PHY_VHT_CHANNEL_MODE20)
        return IWX_PHY_VHT_CTRL_POS_1_BELOW;

    signed int offset = ic->ic_bss->ni_chan->ic_freq - ic->ic_bss->ni_chan->ic_center_freq1;
    switch (offset) {
        case -70:
            return IWX_PHY_VHT_CTRL_POS_4_BELOW;
        case -50:
            return IWX_PHY_VHT_CTRL_POS_3_BELOW;
        case -30:
            return IWX_PHY_VHT_CTRL_POS_2_BELOW;
        case -10:
            return IWX_PHY_VHT_CTRL_POS_1_BELOW;
        case  10:
            return IWX_PHY_VHT_CTRL_POS_1_ABOVE;
        case  30:
            return IWX_PHY_VHT_CTRL_POS_2_ABOVE;
        case  50:
            return IWX_PHY_VHT_CTRL_POS_3_ABOVE;
        case  70:
            return IWX_PHY_VHT_CTRL_POS_4_ABOVE;
        default:
            XYLog("Invalid channel definition freq=%d %d\n", ic->ic_bss->ni_chan->ic_freq, offset);
            /* fall through */
        case 0:
            /*
             * The FW is expected to check the control channel position only
             * when in HT/VHT and the channel width is not 20MHz. Return
             * this value as the default one.
             */
            return IWX_PHY_VHT_CTRL_POS_1_BELOW;
    }
}

int ItlIwx::
iwx_phy_ctxt_cmd_v3(struct iwx_softc *sc, struct iwx_phy_ctxt *ctxt,
    uint8_t chains_static, uint8_t chains_dynamic, uint32_t action,
    uint32_t apply_time)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_phy_context_cmd cmd;
    uint8_t active_cnt, idle_cnt;
    struct ieee80211_channel *chan = ctxt->channel;
    memset(&cmd, 0, sizeof(cmd));
    cmd.id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(ctxt->id,
                                                       ctxt->color));
    cmd.action = htole32(action);
    cmd.lmac_id = htole32(iwx_lmac_id(sc, chan));
    
    cmd.ci.band = IEEE80211_IS_CHAN_2GHZ(chan) ?
    IWX_PHY_BAND_24 : IWX_PHY_BAND_5;
    cmd.ci.channel = htole32(ieee80211_chan2ieee(ic, chan));
    cmd.ci.width = iwx_get_channel_width(ic, chan);
    cmd.ci.ctrl_pos = iwx_get_ctrl_pos(ic, chan);

    XYLog("%s: 2ghz=%d, channel=%d, channel_width=%d pos=%d chains static=0x%x, dynamic=0x%x, "
          "rx_ant=0x%x, tx_ant=0x%x\n",
          __FUNCTION__,
          cmd.ci.band,
          cmd.ci.channel,
          cmd.ci.width,
          cmd.ci.ctrl_pos,
          chains_static,
          chains_dynamic,
          iwx_fw_valid_rx_ant(sc),
          iwx_fw_valid_tx_ant(sc));
    
    idle_cnt = chains_static;
    active_cnt = chains_dynamic;
    
    /* In scenarios where we only ever use a single-stream rates,
     * i.e. legacy 11b/g/a associations, single-stream APs or even
     * static SMPS, enable both chains to get diversity, improving
     * the case where we're far enough from the AP that attenuation
     * between the two antennas is sufficiently different to impact
     * performance.
     */
    if (active_cnt == 1 && iwx_num_of_ant(iwx_fw_valid_rx_ant(sc)) != 1) {
        idle_cnt = 2;
        active_cnt = 2;
    }
    
    cmd.rxchain_info = htole32(iwx_fw_valid_rx_ant(sc) <<
                               IWX_PHY_RX_CHAIN_VALID_POS);
    cmd.rxchain_info |= htole32(idle_cnt << IWX_PHY_RX_CHAIN_CNT_POS);
    cmd.rxchain_info |= htole32(active_cnt <<
                                IWX_PHY_RX_CHAIN_MIMO_CNT_POS);
    return iwx_send_cmd_pdu(sc, IWX_PHY_CONTEXT_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_phy_ctxt_cmd_uhb(struct iwx_softc *sc, struct iwx_phy_ctxt *ctxt,
    uint8_t chains_static, uint8_t chains_dynamic, uint32_t action,
    uint32_t apply_time)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_phy_context_cmd_uhb cmd;
    uint8_t active_cnt, idle_cnt;
    struct ieee80211_channel *chan = ctxt->channel;
    memset(&cmd, 0, sizeof(cmd));
    cmd.id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(ctxt->id,
                                                       ctxt->color));
    cmd.action = htole32(action);
    cmd.apply_time = htole32(apply_time);
    
    cmd.ci.band = IEEE80211_IS_CHAN_2GHZ(chan) ?
    IWX_PHY_BAND_24 : IWX_PHY_BAND_5;
    cmd.ci.channel = htole32(ieee80211_chan2ieee(ic, chan));
    cmd.ci.width = iwx_get_channel_width(ic, chan);
    cmd.ci.ctrl_pos = iwx_get_ctrl_pos(ic, chan);

    XYLog("%s: [%s:%s] 2ghz=%d, channel=%d, channel_width=%d pos=%d chains static=0x%x, dynamic=0x%x, "
          "rx_ant=0x%x, tx_ant=0x%x\n",
          __FUNCTION__,
          ic->ic_bss == NULL ? "" : (const char *)ic->ic_bss->ni_essid,
          ic->ic_bss == NULL ? "" : ether_sprintf(ic->ic_bss->ni_bssid),
          cmd.ci.band,
          cmd.ci.channel,
          cmd.ci.width,
          cmd.ci.ctrl_pos,
          chains_static,
          chains_dynamic,
          iwx_fw_valid_rx_ant(sc),
          iwx_fw_valid_tx_ant(sc));
    
    idle_cnt = chains_static;
    active_cnt = chains_dynamic;
    
    cmd.rxchain_info = htole32(iwx_fw_valid_rx_ant(sc) <<
                               IWX_PHY_RX_CHAIN_VALID_POS);
    cmd.rxchain_info |= htole32(idle_cnt << IWX_PHY_RX_CHAIN_CNT_POS);
    cmd.rxchain_info |= htole32(active_cnt <<
                                IWX_PHY_RX_CHAIN_MIMO_CNT_POS);
    cmd.txchain_info = htole32(iwx_fw_valid_tx_ant(sc));
    return iwx_send_cmd_pdu(sc, IWX_PHY_CONTEXT_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_phy_ctxt_cmd(struct iwx_softc *sc, struct iwx_phy_ctxt *ctxt,
                 uint8_t chains_static, uint8_t chains_dynamic, uint32_t action,
                 uint32_t apply_time)
{
    XYLog("%s\n", __FUNCTION__);
    awdlPhyBuildingId = ctxt ? int(ctxt->id) : -1;
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_phy_context_cmd_v1 cmd;
    uint8_t active_cnt, idle_cnt;
    struct ieee80211_channel *chan = ctxt->channel;
    
    static bool awdlWide80Trying;
    static int awdlWide80Generation;
    static uint32_t awdlWide80Starts;
    if (!awdlWide80Trying && action != IWX_FW_CTXT_ACTION_REMOVE && awdlWide80Applies(ic, ctxt->channel) &&
        awdlWide80Generation != sc->sc_generation) {
        // A firmware that faults later, rather than refusing the command, would restart the card
        // and try again. A few starts are normal, from channel moves, so stop after 3.
        awdlWide80Generation = sc->sc_generation;
        if (++awdlWide80Starts > 3) {
            awdlWide80Refused = true;
            awdlWide80State = 3;
        }
    }
    if (!awdlWide80Trying && action != IWX_FW_CTXT_ACTION_REMOVE && awdlWide80Applies(ic, ctxt->channel)) {
        awdlWide80Trying = true;
        const int wideErr = iwx_phy_ctxt_cmd(sc, ctxt, chains_static, chains_dynamic, action, apply_time);
        awdlWide80Trying = false;
        if (!wideErr) {
            awdlWide80State = 1;
            awdlWide80Live = true;
            return 0;
        }
        // Refused at 80 MHz: carry on at 20 MHz from here.
        awdlWide80Refused = true;
        awdlWide80State = 2;
        awdlWide80Error = uint32_t(wideErr);
    }
    // Any other context set up from here is 20 MHz.
    if (!awdlWide80Trying && action != IWX_FW_CTXT_ACTION_REMOVE)
        awdlWide80Live = false;
    if (iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_PHY_CONTEXT_CMD) == 3)
        return iwx_phy_ctxt_cmd_v3(sc, ctxt, chains_static,
                                   chains_dynamic, action, apply_time);
    
    /*
     * Intel increased the size of the fw_channel_info struct and neglected
     * to bump the phy_context_cmd struct, which contains an fw_channel_info
     * member in the middle.
     * To keep things simple we use a separate function to handle the larger
     * variant of the phy context command.
     */
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_ULTRA_HB_CHANNELS))
        return iwx_phy_ctxt_cmd_uhb(sc, ctxt, chains_static,
                                    chains_dynamic, action, apply_time);
    
    memset(&cmd, 0, sizeof(cmd));
    cmd.id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(ctxt->id,
                                                       ctxt->color));
    cmd.action = htole32(action);
    cmd.apply_time = htole32(apply_time);
    
    cmd.ci.band = IEEE80211_IS_CHAN_2GHZ(chan) ?
    IWX_PHY_BAND_24 : IWX_PHY_BAND_5;
    cmd.ci.channel = ieee80211_chan2ieee(ic, chan);
    cmd.ci.width = iwx_get_channel_width(ic, chan);
    cmd.ci.ctrl_pos = iwx_get_ctrl_pos(ic, chan);
    
    idle_cnt = chains_static;
    active_cnt = chains_dynamic;
    cmd.rxchain_info = htole32(iwx_fw_valid_rx_ant(sc) <<
                               IWX_PHY_RX_CHAIN_VALID_POS);
    cmd.rxchain_info |= htole32(idle_cnt << IWX_PHY_RX_CHAIN_CNT_POS);
    cmd.rxchain_info |= htole32(active_cnt <<
                                IWX_PHY_RX_CHAIN_MIMO_CNT_POS);
    cmd.txchain_info = htole32(iwx_fw_valid_tx_ant(sc));
    
    return iwx_send_cmd_pdu(sc, IWX_PHY_CONTEXT_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_send_cmd(struct iwx_softc *sc, struct iwx_host_cmd *hcmd)
{
    if (!getMainWorkLoop()->inGate()) {
        return getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *arg2, void *) -> IOReturn {
                ItlIwx *that = (ItlIwx *)arg0;
                return that->iwx_send_cmd((struct iwx_softc *)arg1, (struct iwx_host_cmd *)arg2);
            }, this, sc, hcmd);
    }

    struct iwx_tx_ring *ring = &sc->txq[IWX_DQA_CMD_QUEUE];
    struct iwx_tfh_tfd *desc;
    struct iwx_tx_data *txdata;
    struct iwx_device_cmd *cmd;
    mbuf_t m;
    bus_addr_t paddr;
    uint64_t addr;
    int err = 0, i, paylen, off;
    int idx, code, async, group_id;
    size_t hdrlen, datasz;
    uint8_t *data;
    int generation = sc->sc_generation;
#ifdef AIRPORT_VTD
    uint64_t epoch = dmaEpoch;
#endif
    unsigned int max_chunks = 1;
    IOPhysicalSegment seg;
    AbsoluteTime deadline;

    hcmd->resp_pkt = NULL;
    if (dmaDetaching)       // every build (audit HL01)
        return ENXIO;
    if ((sc->sc_flags & (IWX_FLAG_SHUTDOWN | IWX_FLAG_HW_ERR)) ||
        ring->ring_count == 0)
        return ENXIO;

    code = hcmd->id;
    async = hcmd->flags & IWX_CMD_ASYNC;
    idx = (ring->cur & (ring->ring_count - 1));
    desc = &ring->desc[idx];
    txdata = &ring->data[idx];
    /* A completed synchronous command owns its slot until its caller wakes. */
    if (ring->queued >= ring->ring_count - 1 ||
        (txdata->flags & (IWX_TXDATA_FLAG_CMD_PENDING | IWX_TXDATA_FLAG_CMD_WAITING)))
        return ENOSPC;
    if ((hcmd->flags & IWX_CMD_WANT_RESP) && async)
        return EINVAL;
    
    for (i = 0, paylen = 0; i < nitems(hcmd->len); i++) {
        paylen += hcmd->len[i];
    }
    
    /* If this command waits for a response, allocate response buffer. */
    hcmd->resp_pkt = NULL;
    if (hcmd->flags & IWX_CMD_WANT_RESP) {
        uint8_t *resp_buf;
        //        KASSERT(!async);
        //        KASSERT(hcmd->resp_pkt_len >= sizeof(struct iwx_rx_packet));
        //        KASSERT(hcmd->resp_pkt_len <= IWX_CMD_RESP_MAX);
        if (sc->sc_cmd_resp_pkt[idx] != NULL)
            return ENOSPC;
        resp_buf = (uint8_t *)malloc(hcmd->resp_pkt_len, 0,
                                     M_NOWAIT | M_ZERO);
        if (resp_buf == NULL)
            return ENOMEM;
        bzero(resp_buf, hcmd->resp_pkt_len);
        sc->sc_cmd_resp_pkt[idx] = resp_buf;
        sc->sc_cmd_resp_len[idx] = hcmd->resp_pkt_len;
    } else {
        sc->sc_cmd_resp_pkt[idx] = NULL;
    }

    /*
     * XXX Intel inside (tm)
     * Firmware API versions >= 50 reject old-style commands in
     * group 0 with a "BAD_COMMAND" firmware error. We must pretend
     * that such commands were in the LONG_GROUP instead in order
     * for firmware to accept them.
     */
    if (iwx_cmd_groupid(code) == 0) {
        code = IWX_WIDE_ID(IWX_LONG_GROUP, code);
        txdata->flags |= IWX_TXDATA_FLAG_CMD_IS_NARROW;
    } else
        txdata->flags &= ~IWX_TXDATA_FLAG_CMD_IS_NARROW;
    
    group_id = iwx_cmd_groupid(code);
    hdrlen = sizeof(cmd->hdr_wide);
    datasz = sizeof(cmd->data_wide);
    
    if (paylen > datasz) {
                /* Command is too large to fit in pre-allocated space. */
        size_t totlen = hdrlen + paylen;
        if (paylen > IWX_MAX_CMD_PAYLOAD_SIZE) {
            XYLog("%s: firmware command too long (%zd bytes)\n",
                  DEVNAME(sc), totlen);
            err = EINVAL;
            goto out;
        }
        m = NULL;
        mbuf_allocpacket(MBUF_DONTWAIT, totlen, &max_chunks, &m);
        if (m == NULL) {
            XYLog("%s: could not get fw cmd mbuf (%zd bytes)\n",
                  DEVNAME(sc), totlen);
            err = ENOMEM;
            goto out;
        }
        mbuf_setlen(m, totlen);
        mbuf_pkthdr_setlen(m, totlen);
        cmd = mtod(m, struct iwx_device_cmd *);
        txdata->map->dm_nsegs = bus_dmamap_packet(txdata->map, m, &seg, 1, false);
        if (txdata->map->dm_nsegs == 0) {
            XYLog("%s: could not load fw cmd mbuf (%zd bytes)\n",
                  DEVNAME(sc), totlen);
            mbuf_freem(m);
            err = EIO;
            goto out;
        }
//                XYLog("map fw cmd dm_nsegs=%d\n", txdata->map->dm_nsegs);
        txdata->m = m; /* mbuf will be freed in iwm_cmd_done() */
        paddr = seg.location;
    } else {
        cmd = &ring->cmd[idx];
        paddr = txdata->cmd_paddr;
    }
    
    cmd->hdr_wide.cmd = iwx_cmd_opcode(code);
    cmd->hdr_wide.group_id = group_id;
    cmd->hdr_wide.qid = ring->qid;
    cmd->hdr_wide.idx = idx;
    cmd->hdr_wide.length = htole16(paylen);
    cmd->hdr_wide.reserved = htole16(0);
    cmd->hdr_wide.version = iwx_cmd_version(code);
    data = cmd->data_wide;
    
    for (i = 0, off = 0; i < nitems(hcmd->data); i++) {
        if (hcmd->len[i] == 0)
            continue;
        memcpy(data + off, hcmd->data[i], hcmd->len[i]);
        off += hcmd->len[i];
    }
    KASSERT(off == paylen, "off == paylen");
    if (paylen > datasz && !bus_dmamap_write(txdata->map, txdata->m)) {
        mbuf_freem(txdata->m);
        txdata->m = nullptr;
        err = EIO;
        goto out;
    }

    
    desc->tbs[0].tb_len = htole16(MIN(hdrlen + paylen, IWX_FIRST_TB_SIZE));
    addr = htole64(paddr);
    memcpy(&desc->tbs[0].addr, &addr, sizeof(addr));
    if (hdrlen + paylen > IWX_FIRST_TB_SIZE) {
        desc->tbs[1].tb_len = htole16(hdrlen + paylen -
                                      IWX_FIRST_TB_SIZE);
        addr = htole64(paddr + IWX_FIRST_TB_SIZE);
        memcpy(&desc->tbs[1].addr, &addr, sizeof(addr));
        desc->num_tbs = htole16(2);
    } else
        desc->num_tbs = htole16(1);
    
    
    //    if (paylen > datasz) {
    //        bus_dmamap_sync(sc->sc_dmat, txdata->map, 0,
    //            hdrlen + paylen, BUS_DMASYNC_PREWRITE);
    //    } else {
    //        bus_dmamap_sync(sc->sc_dmat, ring->cmd_dma.map,
    //            (char *)(void *)cmd - (char *)(void *)ring->cmd_dma.vaddr,
    //            hdrlen + paylen, BUS_DMASYNC_PREWRITE);
    //    }
    //    bus_dmamap_sync(sc->sc_dmat, ring->desc_dma.map,
    //        (char *)(void *)desc - (char *)(void *)ring->desc_dma.vaddr,
    //        sizeof (*desc), BUS_DMASYNC_PREWRITE);
    /* Kick command ring. */
    DPRINTF(("%s: Sending command (%.2x.%.2x), %d bytes at [%d]:%d ver: %d\n", __func__, group_id, cmd->hdr.cmd, cmd->hdr_wide.length, cmd->hdr.idx, cmd->hdr.qid, cmd->hdr_wide.version));
    txdata->flags |= IWX_TXDATA_FLAG_CMD_PENDING;
    if (!async)
        txdata->flags |= IWX_TXDATA_FLAG_CMD_WAITING;
    ring->queued++;
    ring->cur = (ring->cur + 1) % getTxQueueSize();
    IWX_WRITE(sc, IWX_HBUS_TARG_WRPTR, ring->qid << 16 | ring->cur);
    
    if (!async) {
        clock_interval_to_deadline(1, kSecondScale,
            reinterpret_cast<uint64_t *>(&deadline));
        while (generation == sc->sc_generation &&
            (txdata->flags & IWX_TXDATA_FLAG_CMD_PENDING)) {
            int result = getMainCommandGate()->commandSleep(desc, deadline, THREAD_UNINT);
            if (result != THREAD_AWAKENED) {
                if (txdata->flags & IWX_TXDATA_FLAG_CMD_PENDING)
                    err = (result == THREAD_TIMED_OUT) ? EWOULDBLOCK : EINTR;
                break;
            }
        }
        /* Reset owns the old buffers, including after a timed-out sleep. */
#ifdef AIRPORT_VTD
        if (epoch != dmaEpoch)
            return ENXIO;
#endif
        if (generation != sc->sc_generation)
            return ENXIO;
        txdata->flags &= ~IWX_TXDATA_FLAG_CMD_WAITING;
        if (!err) {
            hcmd->resp_pkt = (struct iwx_rx_packet *)sc->sc_cmd_resp_pkt[idx];
            sc->sc_cmd_resp_pkt[idx] = NULL;
            sc->sc_cmd_resp_len[idx] = 0;
        }
    }
out:
    if (err) {
        ::free(sc->sc_cmd_resp_pkt[idx]);
        sc->sc_cmd_resp_pkt[idx] = NULL;
        sc->sc_cmd_resp_len[idx] = 0;
    }
    return err;
}

int ItlIwx::
iwx_send_cmd_pdu(struct iwx_softc *sc, uint32_t id, uint32_t flags,
                 uint16_t len, const void *data)
{
    struct iwx_host_cmd cmd = {
        .id = id,
        .len = { len, },
        .data = { data, },
        .flags = flags,
    };
    
    return iwx_send_cmd(sc, &cmd);
}

int ItlIwx::
iwx_send_cmd_status(struct iwx_softc *sc, struct iwx_host_cmd *cmd,
                    uint32_t *status)
{
    struct iwx_rx_packet *pkt;
    struct iwx_cmd_response *resp;
    int err, resp_len;
    
    KASSERT((cmd->flags & IWX_CMD_WANT_RESP) == 0, "(cmd->flags & IWX_CMD_WANT_RESP) == 0");
    cmd->flags |= IWX_CMD_WANT_RESP;
    cmd->resp_pkt_len = sizeof(*pkt) + sizeof(*resp);
    
    err = iwx_send_cmd(sc, cmd);
    if (err)
        return err;
    
    pkt = cmd->resp_pkt;
    if (pkt == NULL || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        iwx_free_resp(sc, cmd);
        return EIO;
    }
    
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (resp_len != sizeof(*resp)) {
        iwx_free_resp(sc, cmd);
        return EIO;
    }
    
    resp = (struct iwx_cmd_response *)pkt->data;
    *status = le32toh(resp->status);
    iwx_free_resp(sc, cmd);
    return err;
}

int ItlIwx::
iwx_send_cmd_pdu_status(struct iwx_softc *sc, uint32_t id, uint16_t len,
                        const void *data, uint32_t *status)
{
    struct iwx_host_cmd cmd = {
        .id = id,
        .len = { len, },
        .data = { data, },
    };
    
    return iwx_send_cmd_status(sc, &cmd, status);
}

void ItlIwx::
iwx_free_resp(struct iwx_softc *sc, struct iwx_host_cmd *hcmd)
{
    KASSERT((hcmd->flags & (IWX_CMD_WANT_RESP)) == IWX_CMD_WANT_RESP, "(hcmd->flags & (IWX_CMD_WANT_RESP)) == IWX_CMD_WANT_RESP");
    ::free(hcmd->resp_pkt);
    hcmd->resp_pkt = NULL;
}

void ItlIwx::
iwx_cmd_done(struct iwx_softc *sc, int qid, int idx, int code)
{
    struct iwx_tx_ring *ring = &sc->txq[IWX_DQA_CMD_QUEUE];
    struct iwx_tx_data *data;
    
    if (qid != IWX_DQA_CMD_QUEUE || idx < 0 || idx >= ring->ring_count) {
        return;    /* Not a command ack. */
    }
    
    data = &ring->data[idx];
    if (!(data->flags & IWX_TXDATA_FLAG_CMD_PENDING))
        return;
    data->flags &= ~IWX_TXDATA_FLAG_CMD_PENDING;
    
    if (data->m != NULL) {
        //        bus_dmamap_sync(sc->sc_dmat, data->map, 0,
        //            data->map->dm_mapsize, BUS_DMASYNC_POSTWRITE);
        //        bus_dmamap_unload(sc->sc_dmat, data->map);
        mbuf_freem(data->m);
        data->m = NULL;
    }
    getMainCommandGate()->commandWakeup(&ring->desc[idx]);
    
    DPRINTF(("%s: command 0x%x done\n", __func__, code));
    if (ring->queued == 0) {
        DPRINTF(("%s: unexpected firmware response to command 0x%x\n",
                 DEVNAME(sc), code));
    } else if (ring->queued > 0)
        ring->queued--;
}

uint32_t ItlIwx::
iwx_get_tx_ant(struct iwx_softc *sc, struct ieee80211_node *ni,
                               const struct iwx_rate *rinfo, int type, struct ieee80211_frame *wh)
{
    return ((1 << sc->sc_mgmt_last_antenna_idx) << IWX_RATE_MCS_ANT_POS);
}

void ItlIwx::
iwx_toggle_tx_ant(struct iwx_softc *sc, uint8_t *ant)
{
    uint8_t valid = iwx_fw_valid_tx_ant(sc);
    int i;
    uint8_t ind = *ant; 
    
    for (i = 0; i < IWX_RATE_MCS_ANT_NUM; i++) {
        ind = (ind + 1) % IWX_RATE_MCS_ANT_NUM;
        if (valid & (1 << ind)) {
            *ant = ind;
            break;
        }
    }
}

/*
 * Fill in various bit for management frames, and leave them
 * unfilled for data frames (firmware takes care of that).
 * Return the selected TX rate.
 */
const struct iwx_rate *ItlIwx::
iwx_tx_fill_cmd(struct iwx_softc *sc, struct iwx_node *in,
                struct ieee80211_frame *wh, uint32_t *flags, uint32_t *rate_n_flags)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = &in->in_ni;
    struct ieee80211_rateset *rs = &ni->ni_rates;
    const struct iwx_rate *rinfo;
    int type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
    int min_ridx = iwx_rval2ridx(ieee80211_min_basic_rate(ic));
    int ridx, rate_flags;
    uint8_t cmdver;
    uint8_t hwrate;

    *flags = 0;
    static const int awdlRateIndexes[ItlAWDL::kLegacyRateTop + 1] =
        {IWX_RATE_12M_INDEX, IWX_RATE_24M_INDEX, IWX_RATE_36M_INDEX, IWX_RATE_54M_INDEX};
    if ((ic->ic_opmode == IEEE80211_M_MONITOR && awdlDataInFlight == 3) || awdlCoexBaSendingAgg)
        return &iwx_rates[IWX_RATE_MCS_7_INDEX];
    const bool awdlUnicastData = ic->ic_opmode == IEEE80211_M_MONITOR && awdlDataInFlight == 2 &&
        type == IEEE80211_FC0_TYPE_DATA && !IEEE80211_IS_MULTICAST(wh->i_addr1);
    int awdlMcs = ItlAWDL::htMcsForStep(awdlDataRate.step);
    if (awdlUnicastData && awdlMcs >= 0) {
        // A fixed HT rate, 20 MHz, long guard interval. Two streams need both antennas.
        const uint8_t antennas = IWX_RATE_MCS_ANT_AB_MSK >> IWX_RATE_MCS_ANT_POS;
        if (awdlMcs > 7 && (iwx_fw_valid_tx_ant(sc) & antennas) != antennas)
            awdlMcs = 7;
        const iwx_rate *awdlInfo = &iwx_rates[iwx_mcs2ridx[awdlMcs]];
        uint32_t awdlFlags = awdlMcs > 7 ? IWX_RATE_MCS_ANT_AB_MSK : iwx_get_tx_ant(sc, ni, awdlInfo, type, wh);
        const uint8_t awdlCmdVer = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
        if (awdlCmdVer > 8 && awdlCmdVer != IWX_FW_CMD_VER_UNKNOWN)
            awdlFlags |= IWX_RATE_MCS_HT_MSK | (awdlMcs > 7 ? IWX_RATE_MCS_NSS_MSK : 0U) | uint32_t(awdlMcs & IWX_RATE_HT_MCS_CODE_MSK);
        else
            awdlFlags |= IWX_RATE_MCS_HT_MSK_V1 | uint32_t(awdlMcs);
        *flags |= IWX_TX_FLAGS_CMD_RATE;
        *rate_n_flags = htole32(awdlFlags);
        return awdlInfo;
    }
    // Stays on this step's rate only if the station's rate set has it, otherwise the next lower.
    unsigned awdlStep = awdlMcs >= 0 ? ItlAWDL::kLegacyRateTop : awdlDataRate.step;
    while (awdlStep && !iwx_ridx2rate(rs, awdlRateIndexes[awdlStep]))
        --awdlStep;
    const int awdlDataRidx = awdlRateIndexes[awdlStep];
    if (awdlCoexSending) {
        // The listener's station has no rate table: a fixed OFDM rate valid on either band. 6 Mbit/s for
        // group and management frames, 24 Mbit/s for unicast data.
        ridx = (IEEE80211_IS_MULTICAST(wh->i_addr1) || type != IEEE80211_FC0_TYPE_DATA) ?
            IWX_RATE_6M_INDEX : IWX_RATE_24M_INDEX;
        *flags |= IWX_TX_FLAGS_CMD_RATE;
        const uint8_t vhtCmdVer = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
        const uint8_t bothAntennas = IWX_RATE_MCS_ANT_AB_MSK >> IWX_RATE_MCS_ANT_POS;
        if (ridx == IWX_RATE_24M_INDEX && awdlCoexRateStep >= 4 && awdlCoexRateStep < nitems(kAwdlCoexRateMcs) &&
            awdlCoexOwnWidth == 80 && vhtCmdVer > 8 && vhtCmdVer != IWX_FW_CMD_VER_UNKNOWN &&
            (iwx_fw_valid_tx_ant(sc) & bothAntennas) == bothAntennas) {
            // VHT, 80 MHz, two streams, as dedicated mode's fixed rate for its 80 MHz sends.
            *rate_n_flags = htole32(IWX_RATE_MCS_VHT_MSK | IWX_RATE_MCS_CHAN_WIDTH_80 | IWX_RATE_MCS_NSS_MSK |
                                    IWX_RATE_MCS_ANT_AB_MSK | uint32_t(kAwdlCoexRateMcs[awdlCoexRateStep]));
            ++awdlCoexVhtFrames;
            return &iwx_rates[IWX_RATE_MCS_7_INDEX];
        }
        if (ridx == IWX_RATE_24M_INDEX && awdlCoexRateStep >= 4)
            awdlCoexRateStep = 3; // Not at 80 MHz any more, or no VHT command format: back to HT.
        if (ridx == IWX_RATE_24M_INDEX && awdlCoexRateStep > 0 && awdlCoexRateStep < 4) {
            // A fixed HT rate, 20 MHz, one stream, long guard interval, as dedicated mode sends.
            const unsigned mcs = kAwdlCoexRateMcs[awdlCoexRateStep];
            const iwx_rate *htInfo = &iwx_rates[iwx_mcs2ridx[mcs]];
            uint32_t htFlags = iwx_get_tx_ant(sc, ni, htInfo, type, wh);
            const uint8_t htCmdVer = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
            if (htCmdVer > 8 && htCmdVer != IWX_FW_CMD_VER_UNKNOWN)
                htFlags |= IWX_RATE_MCS_HT_MSK | uint32_t(mcs & IWX_RATE_HT_MCS_CODE_MSK);
            else
                htFlags |= IWX_RATE_MCS_HT_MSK_V1 | uint32_t(mcs);
            *rate_n_flags = htole32(htFlags);
            return htInfo;
        }
    } else if (awdlUnicastData && iwx_ridx2rate(rs, awdlDataRidx)) {
        // macOS's unicast AWDL data, not a probe: the lowest rate would limit a transfer.
        ridx = awdlDataRidx;
        *flags |= IWX_TX_FLAGS_CMD_RATE;
    // The monitor station has no rate table, so its unicast data needs a fixed rate too.
    } else if (IEEE80211_IS_MULTICAST(wh->i_addr1) ||
        type != IEEE80211_FC0_TYPE_DATA || ic->ic_opmode == IEEE80211_M_MONITOR) {
        /* for non-data, use the lowest supported rate */
        // The listener's frames: OFDM 6 Mbit/s, valid on either band, whatever the BSS's lowest rate is.
        ridx = min_ridx;
        *flags |= IWX_TX_FLAGS_CMD_RATE;
    } else if (ic->ic_fixed_mcs != -1) {
        ridx = sc->sc_fixed_ridx;
        *flags |= IWX_TX_FLAGS_CMD_RATE;
    } else if (ic->ic_fixed_rate != -1) {
        ridx = sc->sc_fixed_ridx;
        *flags |= IWX_TX_FLAGS_CMD_RATE;
    } else if (ni->ni_flags & IEEE80211_NODE_HT) {
        ridx = iwx_mcs2ridx[ni->ni_txmcs];
        return &iwx_rates[ridx];
    } else {
        uint8_t rval;
        rval = (rs->rs_rates[ni->ni_txrate] & IEEE80211_RATE_VAL);
        ridx = iwx_rval2ridx(rval);
        if (ridx < min_ridx)
            ridx = min_ridx;
        return &iwx_rates[ridx];
    }
    
    rinfo = &iwx_rates[ridx];
    
    rate_flags = iwx_get_tx_ant(sc, ni, rinfo, type, wh);
    
    hwrate = rinfo->plcp;
    cmdver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
    if (cmdver > 8 && cmdver != IWX_FW_CMD_VER_UNKNOWN) {
        if (IWX_RIDX_IS_CCK(ridx)) {
            rate_flags |= IWX_RATE_MCS_CCK_MSK;
            hwrate = ridx;
        } else {
            rate_flags |= IWX_RATE_MCS_LEGACY_OFDM_MSK;
            hwrate = awdlCoexSending ? iwx_rate2idx(iwx_rates[ridx].rate) :
                iwx_rate2idx(iwx_ridx2rate(rs, ridx) & IEEE80211_RATE_VAL);
        }
    } else if (IWX_RIDX_IS_CCK(ridx))
        rate_flags |= IWX_RATE_MCS_CCK_MSK_V1;
    // A per-frame line would flush the startup log during a monitor train.
    if (ic->ic_opmode != IEEE80211_M_MONITOR && !awdlCoexSending)
        XYLog("%s hwrate: %d ridx: %d rate: %d minrate: %d\n", __FUNCTION__, hwrate, ridx, iwx_ridx2rate(rs, ridx) & IEEE80211_RATE_VAL, ieee80211_min_basic_rate(ic));
    *rate_n_flags = htole32(rate_flags | hwrate);
    
    return rinfo;
}

void ItlIwx::
iwx_tx_update_byte_tbl(struct iwx_softc *sc, struct iwx_tx_ring *txq, int idx, uint16_t byte_cnt,
                       uint16_t num_tbs)
{
    uint8_t filled_tfd_size, num_fetch_chunks;
    uint16_t len = byte_cnt;
    uint16_t bc_ent;
    
    filled_tfd_size = offsetof(struct iwx_tfh_tfd, tbs) +
    num_tbs * sizeof(struct iwx_tfh_tb);
    /*
     * filled_tfd_size contains the number of filled bytes in the TFD.
     * Dividing it by 64 will give the number of chunks to fetch
     * to SRAM- 0 for one chunk, 1 for 2 and so on.
     * If, for example, TFD contains only 3 TBs then 32 bytes
     * of the TFD are used, and only one chunk of 64 bytes should
     * be fetched
     */
    num_fetch_chunks = howmany(filled_tfd_size, 64) - 1;
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        struct iwx_gen3_bc_tbl *scd_bc_tbl_gen3 = (struct iwx_gen3_bc_tbl *)txq->bc_tbl.vaddr;
        
        /* Starting from AX210, the HW expects bytes */
        bc_ent = htole16(len | (num_fetch_chunks << 14));
        scd_bc_tbl_gen3->tfd_offset[idx] = bc_ent;
    } else {
        struct iwx_agn_scd_bc_tbl *scd_bc_tbl = (struct iwx_agn_scd_bc_tbl *)txq->bc_tbl.vaddr;
        
        /* Before AX210, the HW expects DW */
        len = howmany(len, 4);
        bc_ent = htole16(len | (num_fetch_chunks << 12));
        scd_bc_tbl->tfd_offset[idx] = bc_ent;
    }
}

// Only with the elicit flag (unicast) or data transmit: one well-formed AWDL IPv6 data frame.
// An AWDL data frame macOS built for awdl0 (any destination), for the listener's queue.
static bool awdlMonitorRequestValidCoex(mbuf_t m)
{
    ItlAWDL::DataFrameView data;
    return ItlAWDL::parseDataFrame(mtod(m, const uint8_t *), mbuf_len(m), false, &data) == ItlAWDL::ParseResult::Valid;
}

static bool awdlMonitorRequestValid(mbuf_t m)
{
    ItlAWDL::DataFrameView data;
    if (ItlAWDL::parseDataFrame(mtod(m, const uint8_t *), mbuf_len(m), false, &data) != ItlAWDL::ParseResult::Valid)
        return false;
    return awdlDataTx || (awdlElicit && !(*data.destination & 1));
}

// Once per driver load. The sender's frame is held across this synchronous
// command; a firmware fault changes the generation, and the sender then refuses
// it. A firmware reinitialization re-adds the context with the same address.
void ItlIwx::awdlApplyMacAddress(struct iwx_softc *sc, const uint8_t *address)
{
    memcpy(awdlMacOverride, address, sizeof(awdlMacOverride));
    const int result = iwx_mac_ctxt_cmd(sc, (struct iwx_node *)sc->sc_ic.ic_bss, IWX_FW_CTXT_ACTION_MODIFY, 0);
    if (result)
        memset(awdlMacOverride, 0, sizeof(awdlMacOverride));
    ++(result ? awdlMacApplyFailures : awdlMacApplies);
    awdlSessLog("firmware address set %s (%d)\n", result ? "failed" : "ok", result);
    awdlTxLog("MAC context address change result %d\n", result);
    IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLMacContextResult", uint64_t(result ? 1 : 0), 32);
    IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLMacContextGeneration", sc->sc_generation, 32);
}

void ItlIwx::iwx_awdl_transport_probe(struct iwx_softc *sc)
{
    auto *ic = &sc->sc_ic;
    auto *channel = sc->sc_phyctxt[0].channel;
    // The radio is away on other channels, so anything sent now would be wasted.
    if (awdlBackgroundScanActive)
        return;
    if (!awdlRx || !awdlRxChannel6 || !awdlMonitorTxArmed || awdlMonitorProbeStarted || awdlMonitorTxAttempted ||
        !getMainWorkLoop() || !getMainWorkLoop()->inGate() ||
        awdlMonitorGeneration != sc->sc_generation || awdlMonitorQueue < 0 ||
        awdlMonitorPending || !ic->ic_bss || !channel ||
        ic->ic_state != IEEE80211_S_RUN || ic->ic_opmode != IEEE80211_M_MONITOR ||
        !(sc->sc_flags & IWX_FLAG_MAC_ACTIVE) || !(sc->sc_flags & IWX_FLAG_STA_ACTIVE) ||
        (sc->sc_flags & (IWX_FLAG_HW_ERR | IWX_FLAG_SHUTDOWN | IWX_FLAG_RFKILL)) ||
        ieee80211_chan2ieee(ic, channel) != awdlFixedChannel || ic->ic_bss->ni_chan != channel ||
        !ic->ic_bss->ni_rates.rs_nrates || !isset(ic->ic_chan_active, awdlFixedChannel) ||
        (channel->ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC)))
        return;
    const uint64_t syncNowUS = awdlUptimeUS();
#if defined(ITL_AWDL_NATIVE)
    if (awdlBaResponseLength && !awdlBurst.count && !awdlResend.held) {
        mbuf_t answer = nullptr;
        if (!mbuf_getpacket(MBUF_DONTWAIT, &answer) && answer && mbuf_maxlen(answer) >= awdlBaResponseLength) {
            memcpy(mbuf_data(answer), awdlBaResponse, awdlBaResponseLength);
            mbuf_setlen(answer, awdlBaResponseLength);
            mbuf_pkthdr_setlen(answer, awdlBaResponseLength);
            awdlBaResponseLength = 0;
            awdlMonitorProbeStarted = true;
            awdlDataInFlight = 1;
            awdlBaResponseInFlight = true;
            ++awdlBaResponsesSent;
            if (iwx_tx_monitor_frame(sc, answer, ic->ic_bss) && !awdlMonitorPending) {
                awdlMonitorProbeStarted = false;
                awdlMonitorTxAttempted = false;
                awdlDataInFlight = 0;
                awdlBaResponseInFlight = false;
                ++awdlBaResponsesRefused;
            }
            return;
        }
        if (answer)
            mbuf_freem(answer);
    }
    if (awdlDataTx && !(awdlPeerTrain && awdlSyncProbe && ItlAWDL::syncBeforeData(awdlPeerAudible(), syncNowUS, awdlLastSyncUS))) {
        // With a window, failed frames are resent through the single-frame path below.
        if (awdlWindow > 1 && !awdlResend.held && awdlBurst.readyForRetry()) {
            size_t retryLength = 0;
            if (awdlBurst.takeRetry(awdlResendFrame, sizeof(awdlResendFrame), &retryLength)) {
                awdlResendLength = retryLength;
                awdlResend = ItlAWDL::ResendState{};
                awdlResend.held = true;
                awdlResend.pending = true;
                awdlResend.attempts = 1;
                awdlResend.firstUS = syncNowUS;
                awdlResend.notBeforeUS = syncNowUS;
            }
        }
        // A held frame goes before anything newer, so the order stays the same.
        if (awdlResend.pending) {
            if (ItlAWDL::resendExpired(awdlResend, syncNowUS)) {
                awdlResend = ItlAWDL::ResendState{};
                ++awdlResendGaveUp;
            } else if (syncNowUS < awdlResend.notBeforeUS) {
                return;
            } else {
                mbuf_t again = nullptr;
                if (mbuf_getpacket(MBUF_DONTWAIT, &again) || !again || mbuf_maxlen(again) < awdlResendLength) {
                    if (again)
                        mbuf_freem(again);
                    awdlResend = ItlAWDL::ResendState{};
                    ++awdlResendGaveUp;
                    return;
                }
                memcpy(mbuf_data(again), awdlResendFrame, awdlResendLength);
                mbuf_setlen(again, awdlResendLength);
                mbuf_pkthdr_setlen(again, awdlResendLength);
                static_cast<uint8_t *>(mbuf_data(again))[1] |= 0x08; // The 802.11 retry bit.
                awdlSubmitUS = syncNowUS;
                awdlResend.pending = false;
                if (awdlWindow > 1) {
                    // Stays in the window's path, so completions keep their order.
                    ++awdlResendSent;
                    ++awdlRateResults[awdlDataRate.step][0];
                    awdlLastDataUS = syncNowUS;
                    if (!awdlBurst.push(static_cast<const uint8_t *>(mbuf_data(again)), awdlResendLength,
                                        syncNowUS, uint8_t(awdlDataRate.step), true)) {
                        mbuf_freem(again);
                        awdlResend = ItlAWDL::ResendState{};
                        ++awdlResendGaveUp;
                        return;
                    }
                    if (iwx_tx_monitor_burst(sc, again, ic->ic_bss)) {
                        awdlBurst.dropNewest();
                        awdlResend = ItlAWDL::ResendState{};
                        ++awdlResendGaveUp;
                    }
                    return;
                }
                awdlMonitorProbeStarted = true;
                awdlDataInFlight = 2;
                ++awdlResendSent;
                awdlDataStepInFlight = awdlDataRate.step;
                ++awdlRateResults[awdlDataStepInFlight][0];
                awdlLastDataUS = syncNowUS;
                if (iwx_tx_monitor_frame(sc, again, ic->ic_bss) && !awdlMonitorPending) {
                    awdlMonitorProbeStarted = false;
                    awdlMonitorTxAttempted = false;
                    awdlDataInFlight = 0;
                    awdlResend = ItlAWDL::ResendState{};
                    ++awdlResendGaveUp;
                }
                return;
            }
        }
        auto sendMulticast = [&](mbuf_t packet, bool isRepeat = false) {
            if (!isRepeat)
                awdlMulticastRepeats.add(static_cast<const uint8_t *>(mbuf_data(packet)), mbuf_len(packet), syncNowUS, awdlMulticastCopies);
            awdlMonitorProbeStarted = true;
            awdlDataInFlight = 1;
            ++awdlDataSent[0];
            if (iwx_tx_monitor_frame(sc, packet, ic->ic_bss) && !awdlMonitorPending) {
                awdlMonitorProbeStarted = false;
                awdlMonitorTxAttempted = false;
                awdlDataInFlight = 0;
            }
        };
        if (awdlWindow > 1) {
            if (awdlResend.held)
                return;
            if (!awdlBurst.count) {
                if (auto *repeat = awdlMulticastRepeats.due(syncNowUS)) {
                    mbuf_t copy = nullptr;
                    if (!mbuf_getpacket(MBUF_DONTWAIT, &copy) && copy && mbuf_maxlen(copy) >= repeat->length) {
                        memcpy(mbuf_data(copy), repeat->bytes, repeat->length);
                        mbuf_setlen(copy, repeat->length);
                        mbuf_pkthdr_setlen(copy, repeat->length);
                        ItlAWDL::MulticastRepeats::sent(*repeat, syncNowUS);
                        ++awdlMulticastRepeatsSent;
                        --awdlDataSent[0]; // sendMulticast counts it, and this is a repeat.
                        sendMulticast(copy, true);
                        return;
                    }
                    if (copy)
                        mbuf_freem(copy);
                    ItlAWDL::MulticastRepeats::sent(*repeat, syncNowUS);
                }
            }
            if (awdlDeferredMulticast && !awdlBurst.count) {
                mbuf_t held = awdlDeferredMulticast;
                awdlDeferredMulticast = nullptr;
                sendMulticast(held);
                return;
            }
            while (!awdlDeferredMulticast && awdlBurst.canSend(awdlWindow)) {
                // The peer is away: what macOS sends waits in the driver's queue.
                if (awdlPeerPause && awdlPeerPauseState.paused) {
                    ++awdlPeerPauseState.framesHeldBack;
                    break;
                }
                mbuf_t next = nullptr;
                if (itlAWDLBuildTransmit(getController(), &next) != kIOReturnSuccess || !next) {
                    if (awdlBurst.count)
                        ++awdlTxStackEmptyExits;
                    break;
                }
                if (static_cast<const uint8_t *>(mbuf_data(next))[4] & 1) {
                    if (awdlMcastUnicast && ItlAWDL::knownAddress(awdlLastPeer) && !mbuf_next(next) &&
                        syncNowUS - awdlPeerLastHeardUS < kAwdlMcastPeerRecentUS) {
                        mbuf_t copy = nullptr;
                        if (!mbuf_getpacket(MBUF_DONTWAIT, &copy) && copy && mbuf_maxlen(copy) >= mbuf_len(next)) {
                            const size_t copyLength = mbuf_len(next);
                            memcpy(mbuf_data(copy), mbuf_data(next), copyLength);
                            mbuf_setlen(copy, copyLength);
                            mbuf_pkthdr_setlen(copy, copyLength);
                            memcpy(static_cast<uint8_t *>(mbuf_data(copy)) + 4, awdlLastPeer, 6);
                            if (awdlBaTxSend(sc, copy)) {
                                ++awdlMcastUnicastCopies;
                            } else if (awdlBurst.canSend(awdlWindow) &&
                                       awdlBurst.push(static_cast<const uint8_t *>(mbuf_data(copy)), copyLength,
                                                      syncNowUS, uint8_t(awdlDataRate.step))) {
                                ++awdlMcastUnicastCopies;
                                ++awdlRateResults[awdlDataRate.step][0];
                                if (iwx_tx_monitor_burst(sc, copy, ic->ic_bss))
                                    awdlBurst.dropNewest();
                            } else {
                                ++awdlMcastUnicastSkipped;
                                mbuf_freem(copy);
                            }
                        } else {
                            ++awdlMcastUnicastSkipped;
                            if (copy)
                                mbuf_freem(copy);
                        }
                    }
                    // Group frames take the single-frame path, once this window has finished.
                    if (!awdlBurst.count) {
                        sendMulticast(next);
                        return;
                    }
                    awdlDeferredMulticast = next;
                    break;
                }
                if (awdlBaTxSend(sc, next)) {
                    awdlDataEverActive = true;
                    awdlLastDataUS = syncNowUS;
                    if (awdlBaTxQueueFull(sc))
                        break;
                    continue;
                }
                // iwx_tx changes the packet, so the copy has to come first.
                if (mbuf_next(next) || !awdlBurst.push(static_cast<const uint8_t *>(mbuf_data(next)), mbuf_len(next),
                                                       syncNowUS, uint8_t(awdlDataRate.step))) {
                    mbuf_freem(next);
                    ++awdlResendGaveUp;
                    continue;
                }
                ++awdlDataSent[1];
                ++awdlRateResults[awdlDataRate.step][0];
                if (awdlLastDoneUS && syncNowUS >= awdlLastDoneUS && syncNowUS - awdlLastDoneUS < 1000000)
                    awdlIdleSumUS += syncNowUS - awdlLastDoneUS;
                awdlLastDoneUS = 0;
                awdlDataEverActive = true;
                awdlLastDataUS = syncNowUS;
                if (iwx_tx_monitor_burst(sc, next, ic->ic_bss)) {
                    awdlBurst.dropNewest();
                    ++awdlResendGaveUp;
                    break;
                }
            }
            if (!awdlBurst.canSend(awdlWindow))
                ++awdlTxWindowFullExits;
            if (awdlBurst.count || awdlDeferredMulticast || awdlBurst.retryCount)
                return;
        } else {
        // macOS's output goes first, whether or not a peer is audible right now.
        mbuf_t dataPacket = nullptr;
        if (itlAWDLBuildTransmit(getController(), &dataPacket) == kIOReturnSuccess && dataPacket) {
            const unsigned kind = (static_cast<const uint8_t *>(mbuf_data(dataPacket))[4] & 1) ? 0U : 1U;
            awdlMonitorProbeStarted = true;
            awdlDataInFlight = kind + 1;
            ++awdlDataSent[kind];
            if (kind == 1) {
                awdlDataStepInFlight = awdlDataRate.step;
                ++awdlRateResults[awdlDataStepInFlight][0];
                if (awdlLastDoneUS && syncNowUS >= awdlLastDoneUS && syncNowUS - awdlLastDoneUS < 1000000)
                    awdlIdleSumUS += syncNowUS - awdlLastDoneUS;
                awdlSubmitUS = syncNowUS;
                awdlDataEverActive = true;
                awdlLastDataUS = syncNowUS;
                // iwx_tx changes the packet, so the copy has to come first.
                awdlResend = ItlAWDL::ResendState{};
                const size_t dataLength = mbuf_len(dataPacket);
                if (!mbuf_next(dataPacket) && dataLength <= sizeof(awdlResendFrame)) {
                    memcpy(awdlResendFrame, mbuf_data(dataPacket), dataLength);
                    awdlResendLength = dataLength;
                    awdlResend.held = true;
                    awdlResend.firstUS = syncNowUS;
                }
            }
            // A refused frame has no completion, so it must not leave the gate closed.
            if (iwx_tx_monitor_frame(sc, dataPacket, ic->ic_bss) && !awdlMonitorPending) {
                awdlMonitorProbeStarted = false;
                awdlMonitorTxAttempted = false;
                awdlDataInFlight = 0;
            }
            return;
        }
        }
    } else if (awdlWindow > 1 && awdlBurst.count) {
        // A sync frame is due. It takes the single-frame path, so what's in flight finishes
        // first. A frame waiting to be resent doesn't hold it back, or the peer would lose us.
        return;
    }
#endif
    if (awdlPeerTrain && !awdlPeerAudible())
        return;
#if defined(ITL_AWDL_NATIVE)
    // The timer runs every millisecond around a transfer, so sync frames need their own pace.
    if (awdlDataTx && awdlPeerTrain) {
        // Only while no data has moved for a second: these frames take the single-frame path, and
        // on iface106 they held back connection setup and the start of sends.
        const bool awTimed = awdlAwSync && !ItlAWDL::dataRecentlyActive(awdlDataEverActive, syncNowUS, awdlLastDataUS) &&
            syncNowUS - awdlLastSyncUS >= kAwdlAwSyncMinGapUS &&
            awdlPeerSchedule.inPresentAwStart(syncNowUS, kAwdlAwSyncWindowUS);
        if (awTimed)
            ++awdlAwSyncFrames;
        else if (!ItlAWDL::syncIdleDue(syncNowUS, awdlLastSyncUS))
            return;
    }
#endif
    // Once per driver load, including allocation/build failures and FW resets.
    awdlMonitorProbeStarted = true;
    awdlLastSyncUS = syncNowUS;
    uint64_t uptime, ns;
    clock_get_uptime(&uptime);
    absolutetime_to_nanoseconds(uptime, &ns);
#if defined(ITL_AWDL_NATIVE)
    if (awdlSyncProbe) {
        mbuf_t syncPacket = nullptr;
        const auto result = itlAWDLBuildSyncProbe(getController(), &syncPacket, ns / 1000);
        awdlTxLog("single-frame sync build result 0x%x bytes %u packet-length %u\n", unsigned(result),
                  syncPacket ? unsigned(mbuf_len(syncPacket)) : 0U,
                  syncPacket ? unsigned(mbuf_pkthdr_len(syncPacket)) : 0U);
        // The data transmit timer polls every 50 ms, so 20 tries would last one second
        // and permanently close transmit if a peer was already audible during boot.
        if (result == kIOReturnNotReady && !syncPacket && ++awdlMonitorReadinessPolls < (awdlDataTx ? 2400U : 20U)) {
            // Native AWDL configuration can arrive after the radio is ready.
            // Retry only readiness, never a submitted frame or other failure.
            awdlMonitorProbeStarted = false;
            awdlTxLog("waiting for native configuration, poll %u\n", awdlMonitorReadinessPolls);
        }
        if (result == kIOReturnSuccess && syncPacket) {
            const auto *built = static_cast<const uint8_t *>(mbuf_data(syncPacket));
            if (mbuf_len(syncPacket) >= 24) {
                if (ItlAWDL::knownAddress(awdlOwnAddress) && memcmp(awdlOwnAddress, built + 10, sizeof(awdlOwnAddress))) {
                    ++awdlMacAddressChanges;
                    awdlSessLog("our AWDL address changed\n");
                }
                memcpy(awdlOwnAddress, built + 10, sizeof(awdlOwnAddress));
                awdlKeepSample("ITLAWDLSampleTX", built, mbuf_len(syncPacket));
                awdlNoteServices(built, mbuf_len(syncPacket), false);
                // First time, after a failure (the override is cleared), or after the address changed.
                const bool macStale = memcmp(awdlMacOverride, awdlOwnAddress, sizeof(awdlMacOverride)) != 0;
                if (awdlMacProbe && (!awdlMacTried || (macStale && syncNowUS - awdlMacLastTryUS >= 1000000))) {
                    awdlMacTried = true;
                    awdlMacLastTryUS = syncNowUS;
                    awdlApplyMacAddress(sc, awdlOwnAddress);
                }
                const auto probe = awdlAckProbe ?
                    ItlAWDL::ackProbeFor(awdlMonitorSubmitted, ItlAWDL::knownAddress(awdlLastPeer), awdlElicit, awdlForeignControl) : ItlAWDL::AckProbe::None;
                if (probe != ItlAWDL::AckProbe::None) {
                    // Locally administered and unused, so nothing should ACK it.
                    static const uint8_t control[6] = {0x02, 0x11, 0x22, 0x33, 0x44, 0x55};
                    auto *editable = static_cast<uint8_t *>(mbuf_data(syncPacket));
                    memcpy(editable + 4, ItlAWDL::ackProbeIsPeer(probe) ? awdlLastPeer : control, 6);
                    memcpy(awdlAckTarget, editable + 4, 6);
                    awdlAckTargetRssi = awdlLastPeerRssi;
                    if (ItlAWDL::ackProbeUsesHardwareSource(probe))
                        memcpy(editable + 10, ic->ic_myaddr, 6);
                    awdlAckPending = probe;
                    if (probe == ItlAWDL::AckProbe::PeerNeighbor || probe == ItlAWDL::AckProbe::PeerEcho ||
                        probe == ItlAWDL::AckProbe::PeerForeign) {
                        uint8_t peerIP[16];
                        const bool learned = ItlAWDL::sameAddress(awdlLearnedPeer, awdlLastPeer);
                        if (learned)
                            memcpy(peerIP, awdlLearnedPeerIP, sizeof(peerIP));
                        else
                            ItlAWDL::linkLocalFromAddress(awdlLastPeer, peerIP);
                        size_t written = 0;
                        const auto request = probe == ItlAWDL::AckProbe::PeerEcho ?
                            ItlAWDL::PeerRequest::Echo : ItlAWDL::PeerRequest::Neighbor;
                        const uint8_t *requestSource = probe == ItlAWDL::AckProbe::PeerForeign ?
                            ItlAWDL::foreignAddress() : awdlOwnAddress;
                        if (ItlAWDL::buildPeerRequest(request, requestSource, awdlLastPeer, peerIP,
                                awdlRequestSequence++, editable, mbuf_maxlen(syncPacket), &written) ==
                            ItlAWDL::BuildResult::Ready) {
                            mbuf_setlen(syncPacket, written);
                            mbuf_pkthdr_setlen(syncPacket, written);
                            awdlKeepSample(probe == ItlAWDL::AckProbe::PeerNeighbor ? "ITLAWDLSampleNeighbor" : "ITLAWDLSampleEcho",
                                           editable, written);
                        } else {
                            // Still a valid sync frame; just don't count it as a request.
                            memset(editable + 4, 0xff, 6);
                            awdlAckPending = ItlAWDL::AckProbe::None;
                        }
                    }
                }
            }
            (void)iwx_tx_monitor_frame(sc, syncPacket, ic->ic_bss);
        }
        else if (syncPacket) mbuf_freem(syncPacket);
        return;
    }
#endif
    uint8_t bytes[40];
    size_t length = 0;
    if (ItlAWDL::buildTransportProbe(ic->ic_myaddr, uint32_t(ns / 1000), bytes,
            sizeof(bytes), &length) != ItlAWDL::BuildResult::Ready) {
        awdlTxLog("single-frame transport probe construction failed\n");
        return;
    }
    mbuf_t packet = nullptr;
    if (mbuf_gethdr(MBUF_DONTWAIT, MBUF_TYPE_DATA, &packet) || !packet) {
        awdlTxLog("single-frame transport probe allocation failed\n");
        return;
    }
    if (mbuf_maxlen(packet) < length) {
        mbuf_freem(packet);
        awdlTxLog("single-frame transport probe buffer too small\n");
        return;
    }
    memcpy(mbuf_data(packet), bytes, length);
    mbuf_setlen(packet, length);
    mbuf_pkthdr_setlen(packet, length);
    awdlTxLog("single-frame transport probe ready: %u bytes ch6 min-rate %d; no schedule TLVs\n",
            unsigned(length), ieee80211_min_basic_rate(ic));
    // The wrapper consumes packet on every path; never free it again here.
    (void)iwx_tx_monitor_frame(sc, packet, ic->ic_bss);
}

// For frames in the window. Consumes the packet on every path. No single-frame state is
// touched, and completions come back in iwx_rx_tx_cmd_single in send order.
int ItlIwx::iwx_tx_monitor_burst(struct iwx_softc *sc, mbuf_t packet, struct ieee80211_node *node)
{
    if (!packet)
        return EINVAL;
    if (!awdlRx || !awdlMonitorTxArmed || !getMainWorkLoop() || !getMainWorkLoop()->inGate() || !node ||
        node != sc->sc_ic.ic_bss || awdlMonitorGeneration != sc->sc_generation || awdlMonitorPending) {
        mbuf_freem(packet);
        return EOPNOTSUPP;
    }
    auto *retainedNode = ieee80211_ref_node(node);
    awdlBurstSending = true;
    awdlDataInFlight = 2; // Selects the data rate in iwx_tx_fill_cmd.
    const int result = iwx_tx(sc, packet, retainedNode, EDCA_AC_BE, awdlMonitorQueue);
    awdlDataInFlight = 0;
    awdlBurstSending = false;
    if (result)
        ieee80211_release_node(&sc->sc_ic, retainedNode);
    else {
        ++awdlMonitorSubmitted;
        sc->sc_tx_timer = 15;
        IC2IFP(&sc->sc_ic)->if_timer = 1;
    }
    return result;
}

int ItlIwx::iwx_tx_monitor_frame(struct iwx_softc *sc, mbuf_t packet, struct ieee80211_node *node)
{
    // This API consumes the packet on every path; node is borrowed. It is not
    // called by the ordinary network output path. The armed fixed-channel
    // diagnostic timer can request exactly one header-only transport probe.
    if (!packet)
        return EINVAL;
    if (!awdlRx || !awdlMonitorTxArmed || awdlMonitorTxAttempted ||
        !getMainWorkLoop() || !getMainWorkLoop()->inGate() || !node || node != sc->sc_ic.ic_bss ||
        awdlMonitorGeneration != sc->sc_generation || awdlMonitorPending) {
        mbuf_freem(packet);
        return EOPNOTSUPP;
    }
    awdlMonitorTxAttempted = true;
    awdlMonitorCompletedOK = false;
    auto *retainedNode = ieee80211_ref_node(node);
    const int result = iwx_tx(sc, packet, retainedNode, EDCA_AC_BE, awdlMonitorQueue);
    if (result)
        ieee80211_release_node(&sc->sc_ic, retainedNode);
    else {
        ++awdlMonitorSubmitted;
        sc->sc_tx_timer = 15;
        IC2IFP(&sc->sc_ic)->if_timer = 1;
    }
    awdlTxLog("single-frame descriptor submission result %d queue %d\n", result, awdlMonitorQueue);
    return result;
}

int ItlIwx::
iwx_tx(struct iwx_softc *sc, mbuf_t m, struct ieee80211_node *ni, int ac, int monitorQueue)
{
    // Receive/queue-allocation experiments must not submit even incidental
    // network traffic to a newly allocated firmware queue.
    if (!awdlRx && awdlCoexData && monitorQueue >= 0 && monitorQueue == awdlCoexBaTxQueue) {
        // The listener peer's aggregation queue: only AWDL data the pump converted, while the session is up.
        if (!awdlCoexBaSendingAgg || awdlCoexBaTxState != kCoexBaTxAgreed || !awdlCoexBaPeerAdded ||
            !awdlCoexAdded || awdlCoexGeneration != sc->sc_generation || !getMainWorkLoop()->inGate() ||
            sc->sc_ic.ic_opmode != IEEE80211_M_STA || sc->sc_ic.ic_state != IEEE80211_S_RUN || mbuf_next(m) ||
            mbuf_len(m) != mbuf_pkthdr_len(m) || mbuf_len(m) > 2304 || !awdlMonitorRequestValidCoex(m)) {
            mbuf_freem(m);
            return EACCES;
        }
    } else if (!awdlRx && awdlCoexTx && monitorQueue >= 0 && monitorQueue == awdlCoexQueue) {
        // The second context's frames: only valid AWDL action frames, in the gate, while it exists.
        ItlAWDL::ActionFrame decoded;
        if (!awdlCoexSending || !awdlCoexTxStaAdded || !awdlCoexAdded || awdlCoexGeneration != sc->sc_generation ||
            !getMainWorkLoop()->inGate() || sc->sc_ic.ic_opmode != IEEE80211_M_STA ||
            sc->sc_ic.ic_state != IEEE80211_S_RUN || mbuf_next(m) || mbuf_len(m) != mbuf_pkthdr_len(m) ||
            mbuf_len(m) > 2304 ||
            (awdlCoexSendingData ? !awdlCoexData || (!awdlMonitorRequestValidCoex(m) &&
                                                      !ItlAWDL::isAddbaFrame(mtod(m, const uint8_t *), mbuf_len(m)) &&
                                                      !ItlAWDL::isDelbaFrame(mtod(m, const uint8_t *), mbuf_len(m))) :
             ItlAWDL::parseAction(mtod(m, const uint8_t *), mbuf_len(m), &decoded) != ItlAWDL::ParseResult::Valid)) {
            mbuf_freem(m);
            return EACCES;
        }
    } else if (awdlRx || monitorQueue >= 0) {
        auto *ic = &sc->sc_ic;
        auto *channel = sc->sc_phyctxt[0].channel;
        ItlAWDL::ActionFrame decoded;
        if (!awdlRx || !awdlMonitorTxArmed || !getMainWorkLoop()->inGate() ||
            monitorQueue < 0 || (monitorQueue != awdlMonitorQueue && monitorQueue != awdlBaTxQueue) ||
            awdlMonitorGeneration != sc->sc_generation || (awdlMonitorPending && monitorQueue != awdlBaTxQueue) ||
            ic->ic_opmode != IEEE80211_M_MONITOR || ic->ic_state != IEEE80211_S_RUN ||
            !(sc->sc_flags & IWX_FLAG_MAC_ACTIVE) || !(sc->sc_flags & IWX_FLAG_STA_ACTIVE) ||
            !ni || !channel || ni->ni_chan != channel || !channel->ic_freq ||
            !ni->ni_rates.rs_nrates ||
            (channel->ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC)) ||
            !isset(ic->ic_chan_active, ieee80211_chan2ieee(ic, channel)) ||
            mbuf_next(m) || mbuf_len(m) != mbuf_pkthdr_len(m) ||
            mbuf_len(m) > 2048 || (ItlAWDL::parseAction(mtod(m, const uint8_t *),
                mbuf_len(m), &decoded) != ItlAWDL::ParseResult::Valid && !awdlMonitorRequestValid(m) &&
                !(awdlBaResponseInFlight && ItlAWDL::isAddbaFrame(mtod(m, const uint8_t *), mbuf_len(m))))) {
            mbuf_freem(m);
            return EACCES;
        }
    }
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ni;
    struct iwx_tx_ring *ring;
    struct iwx_tx_data *data;
    struct iwx_tfh_tfd *desc;
    struct iwx_device_cmd *cmd;
    struct iwx_tx_cmd_gen2 *tx_gen2;
    struct iwx_tx_cmd_gen3 *tx_gen3;
    struct ieee80211_frame *wh;
    struct ieee80211_key *k = NULL;
    const struct iwx_rate *rinfo;
    uint64_t paddr;
    u_int hdrlen;
    IOPhysicalSegment *seg;
    IOPhysicalSegment segs[IWX_TFH_NUM_TBS - 2];
    int nsegs = 0;
    uint32_t flags = 0, rate_n_flags = 0;
    uint16_t offload_assist = 0;
    uint16_t cmd_size = 0;

    uint16_t num_tbs;
    uint8_t tid, type, subtype;
    int i, totlen;
    int qid = IWX_INVALID_QUEUE;
    int idx;

    wh = mtod(m, struct ieee80211_frame *);
    type = wh->i_fc[0] & IEEE80211_FC0_TYPE_MASK;
    subtype = wh->i_fc[0] & IEEE80211_FC0_SUBTYPE_MASK;
#ifdef AIRPORT_WCL
    const int trafficAC = ieee80211_has_qos(wh) ?
        ieee80211_wcl_ac(ieee80211_get_qos(wh) & IEEE80211_QOS_TID) : EDCA_AC_BE;
#endif
    if (type == IEEE80211_FC0_TYPE_CTL)
        hdrlen = sizeof(struct ieee80211_frame_min);
    else
        hdrlen = ieee80211_get_hdrlen(wh);
    
    tid = IWX_MGMT_TID;
    qid = monitorQueue >= 0 ? monitorQueue : sc->first_data_qid;

    /* Put QoS frames on the data queue which maps to their TID. */
    // Not the listener's frames: the BSS node's aggregation queues belong to the station.
    if (ieee80211_has_qos(wh) && monitorQueue < 0) {
        struct ieee80211_tx_ba *ba;
        uint16_t qos = ieee80211_get_qos(wh);
        uint8_t tid = qos & IEEE80211_QOS_TID;

        ba = &ni->ni_tx_ba[tid];
        if (!IEEE80211_IS_MULTICAST(wh->i_addr1) &&
            type == IEEE80211_FC0_TYPE_DATA &&
            subtype != IEEE80211_FC0_SUBTYPE_NODATA &&
            sc->sc_tid_data[tid].qid != 0 &&
            sc->sc_tid_data[tid].qid != IWX_INVALID_QUEUE &&
            ba->ba_state == IEEE80211_BA_AGREED) {
            qid = sc->sc_tid_data[tid].qid;
        }
    }

    // In every build (audit HL01 / S02): a queue number outside the ring array, or a send during detach.
    if (dmaDetaching || qid < 0 || qid >= nitems(sc->txq)) {
        mbuf_freem(m);
        return ENXIO;
    }
    ring = &sc->txq[qid];
    if (ring->ring_count == 0) {
        mbuf_freem(m);
        return EINVAL;
    }
    idx = (ring->cur & (ring->ring_count - 1));
#ifdef AIRPORT_VTD
    if (!ring->desc || ring->data[idx].m || ring->queued >= ring->ring_count - 1) {
        mbuf_freem(m);
        return ENOBUFS;
    }
#endif
    desc = &ring->desc[idx];
    memset(desc, 0, sizeof(*desc));
    data = &ring->data[idx];
    
    cmd = &ring->cmd[idx];
    cmd->hdr.cmd = IWX_TX_CMD;
    cmd->hdr.group_id = 0;
    cmd->hdr.qid = ring->qid;
    cmd->hdr.idx = idx;
    
    rinfo = iwx_tx_fill_cmd(sc, in, wh, &flags, &rate_n_flags);

    if (awdlBaTxFixedMcs >= 0 && awdlDataInFlight == 3 && awdlBaTx80Active && awdlWide80Live &&
        !awdlWide80Refused && awdlFixedChannel == 149 && type == IEEE80211_FC0_TYPE_DATA) {
        const uint8_t cmdVersion = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
        const uint8_t antennas = IWX_RATE_MCS_ANT_AB_MSK >> IWX_RATE_MCS_ANT_POS;
        if (cmdVersion > 8 && cmdVersion != IWX_FW_CMD_VER_UNKNOWN &&
            (iwx_fw_valid_tx_ant(sc) & antennas) == antennas) {
            flags |= IWX_TX_FLAGS_CMD_RATE;
            rate_n_flags = htole32(IWX_RATE_MCS_VHT_MSK | IWX_RATE_MCS_CHAN_WIDTH_80 |
                                    IWX_RATE_MCS_NSS_MSK | IWX_RATE_MCS_ANT_AB_MSK | uint32_t(awdlBaTxFixedMcs));
            ++awdlBaTxFixedFrames;
        }
    }

    // Probe only large first-attempt frames on the existing monitor window.
    bool requestedWideRate = false;
    if (awdlTx80 && !awdlBaTx && awdlTx80Bulk.bulk && awdlBurstSending && awdlBurst.count && awdlWide80Live &&
        awdlFixedChannel == 149 && awdlTx80ConsecutiveMisses < 8 &&
        awdlTx80PeerUS && awdlTx80PeerGeneration == sc->sc_generation &&
        type == IEEE80211_FC0_TYPE_DATA && !(wh->i_fc[1] & IEEE80211_FC1_RETRY) &&
        mbuf_pkthdr_len(m) >= 1200 && ItlAWDL::sameAddress(wh->i_addr1, awdlTx80Peer) &&
        awdlUptimeUS() - awdlTx80PeerUS < 10000000) {
        const uint8_t cmdVersion = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_TX_CMD);
        const uint8_t antennas = IWX_RATE_MCS_ANT_AB_MSK >> IWX_RATE_MCS_ANT_POS;
        if (cmdVersion > 8 && cmdVersion != IWX_FW_CMD_VER_UNKNOWN &&
            (iwx_fw_valid_tx_ant(sc) & antennas) == antennas) {
            flags |= IWX_TX_FLAGS_CMD_RATE;
            // VHT MCS 4, two streams, 80 MHz, long guard interval.
            rate_n_flags = htole32(IWX_RATE_MCS_VHT_MSK | IWX_RATE_MCS_CHAN_WIDTH_80 |
                                    IWX_RATE_MCS_NSS_MSK | IWX_RATE_MCS_ANT_AB_MSK | 4U);
            requestedWideRate = true;
        }
    }
    
#if NBPFILTER > 0
    if (sc->sc_drvbpf != NULL) {
        struct iwx_tx_radiotap_header *tap = &sc->sc_txtap;
        uint16_t chan_flags;
        
        tap->wt_flags = 0;
        tap->wt_chan_freq = htole16(ni->ni_chan->ic_freq);
        chan_flags = ni->ni_chan->ic_flags;
        if (ic->ic_curmode != IEEE80211_MODE_11N)
            chan_flags &= ~IEEE80211_CHAN_HT;
        tap->wt_chan_flags = htole16(chan_flags);
        if ((ni->ni_flags & IEEE80211_NODE_HT) &&
            !IEEE80211_IS_MULTICAST(wh->i_addr1) &&
            type == IEEE80211_FC0_TYPE_DATA &&
            rinfo->ht_plcp != IWX_RATE_HT_SISO_MCS_INV_PLCP) {
            tap->wt_rate = (0x80 | rinfo->ht_plcp);
        } else
            tap->wt_rate = rinfo->rate;
        if ((ic->ic_flags & IEEE80211_F_WEPON) &&
            (wh->i_fc[1] & IEEE80211_FC1_PROTECTED))
            tap->wt_flags |= IEEE80211_RADIOTAP_F_WEP;
        
        bpf_mtap_hdr(sc->sc_drvbpf, tap, sc->sc_txtap_len,
                     m, BPF_DIRECTION_OUT);
    }
#endif
    
    if (wh->i_fc[1] & IEEE80211_FC1_PROTECTED) {
        k = ieee80211_get_txkey(ic, wh, ni);
        if (k->k_cipher != IEEE80211_CIPHER_CCMP) {
            if ((m = ieee80211_encrypt(ic, m, k)) == NULL)
                return ENOBUFS;
            /* 802.11 header may have moved. */
            wh = mtod(m, struct ieee80211_frame *);
            flags |= htole32(IWX_TX_FLAGS_ENCRYPT_DIS);
        } else {
            k->k_tsc++;
            /* Hardware increments PN internally and adds IV. */
        }
    } else
        flags |= htole32(IWX_TX_FLAGS_ENCRYPT_DIS);
    //    totlen = m->m_pkthdr.len;
    totlen = mbuf_pkthdr_len(m);
    
    offload_assist = itlTxOffloadHeader(hdrlen);
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210) {
        tx_gen3 = (struct iwx_tx_cmd_gen3 *)cmd->data;
        
        cmd_size = sizeof(*tx_gen3);
        memset(tx_gen3, 0, cmd_size);
        
        tx_gen3->len = htole16(totlen);
        tx_gen3->offload_assist = htole32(offload_assist);
        /* Copy 802.11 header in TX command. */
        memcpy(((uint8_t *)tx_gen3) + sizeof(*tx_gen3), wh, hdrlen);
        tx_gen3->flags = htole16(flags);
        tx_gen3->rate_n_flags = htole32(rate_n_flags);
    } else {
        tx_gen2 = (struct iwx_tx_cmd_gen2 *)cmd->data;
        
        cmd_size = sizeof(*tx_gen2);
        memset(tx_gen2, 0, cmd_size);
        tx_gen2->len = htole16(totlen);
        tx_gen2->offload_assist = htole16(offload_assist);
        /* Copy 802.11 header in TX command. */
        memcpy(((uint8_t *)tx_gen2) + sizeof(*tx_gen2), wh, hdrlen);
        tx_gen2->flags = htole32(flags);
        tx_gen2->rate_n_flags = htole32(rate_n_flags);
    }
    
    /* Trim 802.11 header. */
    mbuf_adj(m, hdrlen);
    
    nsegs = bus_dmamap_packet(data->map, m, &segs[0], IWX_TFH_NUM_TBS - 2, false);
    if (nsegs == 0) {
        XYLog("%s: can't map mbuf (error %d)\n", DEVNAME(sc),
              nsegs);
        mbuf_freem(m);
        return ENOMEM;
    }
    data->m = m;
    data->in = in;
    data->type = type;
    if (monitorQueue >= 0 && monitorQueue == awdlCoexQueue && idx >= 0 && idx < int(nitems(awdlCoexSlotKind))) {
        awdlCoexSlotKind[idx] = awdlCoexSendingMgmt ? awdlCoexSendingMgmt :
            awdlCoexSendingData ? (IEEE80211_IS_MULTICAST(wh->i_addr1) ? 1 : 2) : 0;
        awdlCoexSlotBaPeerEpoch[idx] = awdlCoexBaPeerEpoch;
        awdlCoexSlotToken[idx] = awdlCoexSendingMgmtToken;
        awdlCoexSlotEnqueueId[idx] = 0;
        if (awdlCoexSendingMgmt) {
            if (++awdlCoexMgmtEnqueueId == 0)
                awdlCoexMgmtEnqueueId = 1;
            awdlCoexSlotEnqueueId[idx] = awdlCoexLastMgmtEnqueueId = awdlCoexMgmtEnqueueId;
        }
    }
    if (monitorQueue >= 0 && monitorQueue == awdlCoexQueue && !awdlCoexSendingData) {
        awdlCoexPendingSlot = idx;
        awdlCoexLastSlot = idx;
        awdlCoexPendingGeneration = sc->sc_generation;
    }

    DPRINTFN(3, ("sending data: 嘤嘤嘤 tid=%d qid=%d idx=%d queued=%d len=%d nsegs=%d flags=0x%08x rate_n_flags=0x%08x offload_assist=%u\n",
          tid, ring->qid, ring->cur, ring->queued, totlen, nsegs, le32toh(flags),
          le32toh(rate_n_flags), offload_assist));
    
    /* Fill TX descriptor. */
    num_tbs = 2 + nsegs;
    desc->num_tbs = htole16(num_tbs);
    
    desc->tbs[0].tb_len = htole16(IWX_FIRST_TB_SIZE);
    paddr = htole64(data->cmd_paddr);
    memcpy(&desc->tbs[0].addr, &paddr, sizeof(paddr));
    if (data->cmd_paddr >> 32 != (data->cmd_paddr + le32toh(desc->tbs[0].tb_len)) >> 32)
        DPRINTF(("%s: TB0 crosses 32bit boundary\n", __func__));
    desc->tbs[1].tb_len = htole16(_ALIGN(sizeof(struct iwx_cmd_header) +
                                  cmd_size + hdrlen - IWX_FIRST_TB_SIZE, 4));
    paddr = htole64(data->cmd_paddr + IWX_FIRST_TB_SIZE);
    memcpy(&desc->tbs[1].addr, &paddr, sizeof(paddr));
    
    if (data->cmd_paddr >> 32 != (data->cmd_paddr + le32toh(desc->tbs[1].tb_len)) >> 32)
        DPRINTF(("%s: TB1 crosses 32bit boundary\n", __func__));
    
    /* Other DMA segments are for data payload. */
    for (i = 0; i < nsegs; i++) {
        seg = &segs[i];
        desc->tbs[i + 2].tb_len = htole16(seg->length);
        paddr = htole64(seg->location);
        memcpy(&desc->tbs[i + 2].addr, &paddr, sizeof(paddr));
        if (data->cmd_paddr >> 32 != (data->cmd_paddr + le32toh(desc->tbs[i + 2].tb_len)) >> 32)
            DPRINTF(("%s: TB%d crosses 32bit boundary\n", __func__, i + 2));
//        XYLog("DMA segments index=%d location=0x%llx length=%llu", i, seg->location, seg->length);
    }
    
    //    bus_dmamap_sync(sc->sc_dmat, data->map, 0, data->map->dm_mapsize,
    //        BUS_DMASYNC_PREWRITE);
    //    bus_dmamap_sync(sc->sc_dmat, ring->cmd_dma.map,
    //        (char *)(void *)cmd - (char *)(void *)ring->cmd_dma.vaddr,
    //        sizeof (*cmd), BUS_DMASYNC_PREWRITE);
    //    bus_dmamap_sync(sc->sc_dmat, ring->desc_dma.map,
    //        (char *)(void *)desc - (char *)(void *)ring->desc_dma.vaddr,
    //        sizeof (*desc), BUS_DMASYNC_PREWRITE);
    
    iwx_tx_update_byte_tbl(sc, ring, idx, totlen, num_tbs);
    if (requestedWideRate) {
        awdlBurst.markNewestWideRate();
        ++awdlTx80Requested;
    }
    
    if (monitorQueue >= 0 && monitorQueue != awdlCoexQueue && !awdlBurstSending) {
        awdlMonitorPending = data;
        awdlTxLog("single-frame descriptor prepared queue %d index %d bytes %d\n", qid, idx, totlen);
    }
    /* Kick TX ring. */
    ring->cur = (ring->cur + 1) % getTxQueueSize();
    IWX_WRITE(sc, IWX_HBUS_TARG_WRPTR, ring->qid << 16 | ring->cur);
    
    /* Mark TX ring as full if we reach a certain threshold. */
    if (++ring->queued > ring->hi_mark) {
//        XYLog("%s sc->qfullmsk is FULL qid=%d ring->cur=%d ring->queued=%d\n", __FUNCTION__, ring->qid, ring->cur, ring->queued);
        sc->qfullmsk.set(ring->qid);
    }
    
#ifdef AIRPORT_WCL
    if (type == IEEE80211_FC0_TYPE_DATA && !(subtype & IEEE80211_FC0_SUBTYPE_NODATA))
        ++ic->ic_wcl_tx_packets[trafficAC];
#endif
    return 0;
}

int ItlIwx::
iwx_flush_sta_tids(struct iwx_softc *sc, int sta_id, uint16_t tids)
{
    struct iwx_rx_packet *pkt;
    struct iwx_tx_path_flush_cmd_rsp *resp;
    struct iwx_tx_path_flush_cmd flush_cmd = {
        .sta_id = htole32(sta_id),
        .tid_mask = htole16(tids),
    };
    struct iwx_host_cmd hcmd = {
        .id = IWX_TXPATH_FLUSH,
        .len = { sizeof(flush_cmd), },
        .data = { &flush_cmd, },
        .flags = IWX_CMD_WANT_RESP,
        .resp_pkt_len = sizeof(*pkt) + sizeof(*resp),
    };
    int err, resp_len, i, num_flushed_queues;
    
    err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    
    pkt = hcmd.resp_pkt;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        err = EIO;
        goto out;
    }
    
    resp_len = iwx_rx_packet_payload_len(pkt);
    /* Some firmware versions don't provide a response. */
    if (resp_len == 0)
        goto out;
    else if (resp_len != sizeof(*resp)) {
        err = EIO;
        goto out;
    }
    
    resp = (struct iwx_tx_path_flush_cmd_rsp *)pkt->data;
    
    if (le16toh(resp->sta_id) != sta_id) {
        err = EIO;
        goto out;
    }
    
    num_flushed_queues = le16toh(resp->num_flushed_queues);
    if (num_flushed_queues > IWX_TX_FLUSH_QUEUE_RSP) {
        err = EIO;
        goto out;
    }
    
    for (i = 0; i < num_flushed_queues; i++) {
        struct iwx_flush_queue_info *queue_info = &resp->queues[i];
        uint16_t tid = le16toh(queue_info->tid);
        uint16_t read_after = le16toh(queue_info->read_after_flush);
        uint16_t qid = le16toh(queue_info->queue_num);
        struct iwx_tx_ring *txq;
        
        if (qid >= nitems(sc->txq) || tid >= nitems(sc->sc_tid_data))
            continue;

        if (sc->sc_tid_data[tid].qid != qid)
            continue;
        txq = &sc->txq[qid];
        
        iwx_ampdu_txq_advance(sc, txq, IWX_AGG_SSN_TO_TXQ_IDX(read_after, txq->ring_count));
    }
out:
    iwx_free_resp(sc, &hcmd);
    return err;
}

int ItlIwx::
iwx_flush_sta(struct iwx_softc *sc, struct iwx_node *in)
{
    int err, generation = sc->sc_generation;
    
    splassert(IPL_NET);
    
    sc->sc_flags |= IWX_FLAG_TXFLUSH;
    
    err = iwx_drain_sta(sc, in, 1);
    
    if (err)
        goto done;
    
    err = iwx_flush_sta_tids(sc, IWX_STATION_ID, 0xffff);
    if (err) {
        XYLog("%s: could not flush Tx path (error %d)\n",
               __FUNCTION__, err);
        goto done;
    }
    
    err = iwx_drain_sta(sc, in, 0);
    if (err)
        goto done;

done:
    if (generation == sc->sc_generation)
        sc->sc_flags &= ~IWX_FLAG_TXFLUSH;
    return err;
}

int ItlIwx::
iwx_drain_sta(struct iwx_softc *sc, struct iwx_node* in, int drain)
{
    struct iwx_add_sta_cmd cmd;
    int err;
    uint32_t status;
    
    memset(&cmd, 0, sizeof(cmd));
    cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id,
                                                         in->in_color));
    cmd.sta_id = IWX_STATION_ID;
    cmd.add_modify = IWX_STA_MODE_MODIFY;
    cmd.station_flags = drain ? htole32(IWX_STA_FLG_DRAIN_FLOW) : 0;
    cmd.station_flags_msk = htole32(IWX_STA_FLG_DRAIN_FLOW);
    
    status = IWX_ADD_STA_SUCCESS;
    err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA,
                                  sizeof(cmd), &cmd, &status);
    if (err) {
        printf("%s: could not update sta (error %d)\n",
               DEVNAME(sc), err);
        return err;
    }
    
    switch (status & IWX_ADD_STA_STATUS_MASK) {
        case IWX_ADD_STA_SUCCESS:
            break;
        default:
            err = EIO;
            printf("%s: Couldn't %s draining for station\n",
                   DEVNAME(sc), drain ? "enable" : "disable");
            break;
    }
    
    return err;
}

#define IWX_POWER_KEEP_ALIVE_PERIOD_SEC    25

int ItlIwx::
iwx_beacon_filter_send_cmd(struct iwx_softc *sc,
                           struct iwx_beacon_filter_cmd *cmd)
{
    size_t len;
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_BEACON_FILTER_V4))
        len = sizeof(struct iwx_beacon_filter_cmd);
    else
        len = offsetof(struct iwx_beacon_filter_cmd,
                       bf_threshold_absolute_low);
    return iwx_send_cmd_pdu(sc, IWX_REPLY_BEACON_FILTERING_CMD,
                            0, len, cmd);
}

int ItlIwx::
iwx_update_beacon_abort(struct iwx_softc *sc, struct iwx_node *in, int enable)
{
    struct iwx_beacon_filter_cmd cmd = {
        IWX_BF_CMD_CONFIG_DEFAULTS,
        .bf_enable_beacon_filter = htole32(1),
        .ba_enable_beacon_abort = htole32(enable),
    };
    
    if (!sc->sc_bf.bf_enabled)
        return 0;
    
    sc->sc_bf.ba_enabled = enable;
    return iwx_beacon_filter_send_cmd(sc, &cmd);
}

void ItlIwx::
iwx_power_build_cmd(struct iwx_softc *sc, struct iwx_node *in,
                    struct iwx_mac_power_cmd *cmd)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = &in->in_ni;
    int dtim_period, dtim_msec, keep_alive;
    
    cmd->id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id,
                                                        in->in_color));
    if (ni->ni_dtimperiod)
        dtim_period = ni->ni_dtimperiod;
    else
        dtim_period = 1;
    
    /*
     * Regardless of power management state the driver must set
     * keep alive period. FW will use it for sending keep alive NDPs
     * immediately after association. Check that keep alive period
     * is at least 3 * DTIM.
     */
    dtim_msec = dtim_period * ni->ni_intval;
    keep_alive = MAX(3 * dtim_msec, 1000 * IWX_POWER_KEEP_ALIVE_PERIOD_SEC);
    keep_alive = roundup(keep_alive, 1000) / 1000;
    cmd->keep_alive_seconds = htole16(keep_alive);
    
    if (ic->ic_opmode != IEEE80211_M_MONITOR)
        cmd->flags = htole16(IWX_POWER_FLAGS_POWER_SAVE_ENA_MSK);
}

int ItlIwx::
iwx_power_mac_update_mode(struct iwx_softc *sc, struct iwx_node *in)
{
    int err;
    int ba_enable;
    struct iwx_mac_power_cmd cmd;
    
    memset(&cmd, 0, sizeof(cmd));
    
    iwx_power_build_cmd(sc, in, &cmd);
    
    err = iwx_send_cmd_pdu(sc, IWX_MAC_PM_POWER_TABLE, 0,
                           sizeof(cmd), &cmd);
    if (err != 0)
        return err;
    
    ba_enable = !!(cmd.flags &
                   htole16(IWX_POWER_FLAGS_POWER_MANAGEMENT_ENA_MSK));
    return iwx_update_beacon_abort(sc, in, ba_enable);
}

int ItlIwx::
iwx_power_update_device(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_device_power_cmd cmd = { };
    struct ieee80211com *ic = &sc->sc_ic;
    
    if (ic->ic_opmode != IEEE80211_M_MONITOR)
        cmd.flags = htole16(IWX_DEVICE_POWER_FLAGS_POWER_SAVE_ENA_MSK);
    
    return iwx_send_cmd_pdu(sc,
                            IWX_POWER_TABLE_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_enable_beacon_filter(struct iwx_softc *sc, struct iwx_node *in)
{
    struct iwx_beacon_filter_cmd cmd = {
        IWX_BF_CMD_CONFIG_DEFAULTS,
        .bf_enable_beacon_filter = htole32(1),
        .ba_enable_beacon_abort = htole32(sc->sc_bf.ba_enabled),
    };
    int err;
    
    err = iwx_beacon_filter_send_cmd(sc, &cmd);
    if (err == 0)
        sc->sc_bf.bf_enabled = 1;
    
    return err;
}

int ItlIwx::
iwx_disable_beacon_filter(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_beacon_filter_cmd cmd;
    int err;
    
    memset(&cmd, 0, sizeof(cmd));
    
    err = iwx_beacon_filter_send_cmd(sc, &cmd);
    if (err == 0)
        sc->sc_bf.bf_enabled = 0;
    
    return err;
}

int ItlIwx::
iwx_add_sta_cmd(struct iwx_softc *sc, struct iwx_node *in, int update)
{
    struct iwx_add_sta_cmd add_sta_cmd;
    int err;
    uint32_t status, agg_size = 0;
    uint32_t max_aggsize = (IWX_STA_FLG_MAX_AGG_SIZE_4M >> IWX_STA_FLG_MAX_AGG_SIZE_SHIFT);
    struct ieee80211com *ic = &sc->sc_ic;
    
    if (!update && (sc->sc_flags & IWX_FLAG_STA_ACTIVE)) {
        XYLog("STA already added\n");
        return 0;
    }
    
    memset(&add_sta_cmd, 0, sizeof(add_sta_cmd));
    
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        add_sta_cmd.sta_id = IWX_MONITOR_STA_ID;
        add_sta_cmd.station_type = IWX_STA_GENERAL_PURPOSE;
    } else {
        add_sta_cmd.sta_id = IWX_STATION_ID;
        add_sta_cmd.station_type = IWX_STA_LINK;
    }
    add_sta_cmd.mac_id_n_color
    = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
    if (!update) {
        if (ic->ic_opmode == IEEE80211_M_MONITOR)
            IEEE80211_ADDR_COPY(&add_sta_cmd.addr,
                                etheranyaddr);
        else
            IEEE80211_ADDR_COPY(&add_sta_cmd.addr,
                                in->in_macaddr);
    }
    add_sta_cmd.add_modify = update ? 1 : 0;
    add_sta_cmd.station_flags_msk
    |= htole32(IWX_STA_FLG_FAT_EN_MSK | IWX_STA_FLG_MIMO_EN_MSK);
    add_sta_cmd.tid_disable_tx = htole16(0xffff);
        
    if ((in->in_ni.ni_flags & IEEE80211_NODE_HT) ||
        (in->in_ni.ni_flags & IEEE80211_NODE_VHT) ||
        (in->in_ni.ni_flags & IEEE80211_NODE_HE)) {
        add_sta_cmd.station_flags_msk
        |= htole32(IWX_STA_FLG_MAX_AGG_SIZE_MSK |
                   IWX_STA_FLG_AGG_MPDU_DENS_MSK);
        
        if (ic->ic_state >= IEEE80211_S_ASSOC) {
            switch (in->in_ni.ni_chw) {
                case IEEE80211_CHAN_WIDTH_80P80:
                case IEEE80211_CHAN_WIDTH_160:
                    add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_FAT_EN_160MHZ);
                case IEEE80211_CHAN_WIDTH_80:
                    add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_FAT_EN_80MHZ);
                case IEEE80211_CHAN_WIDTH_40:
                    add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_FAT_EN_40MHZ);
                case IEEE80211_CHAN_WIDTH_20:
                default:
                    add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_FAT_EN_20MHZ);
                    break;
            }
        }
        
        if (iwx_mimo_enabled(sc) && ic->ic_bss->ni_rx_nss > 1)
            add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_MIMO_EN_MIMO2);
        else
            add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_MIMO_EN_SISO);
        
        if (in->in_ni.ni_flags & IEEE80211_NODE_HE) {
            agg_size = in->in_ni.ni_vhtcaps &
            IEEE80211_VHTCAP_MAX_A_MPDU_LENGTH_EXPONENT_MASK;
            agg_size >>=
            IEEE80211_VHTCAP_MAX_A_MPDU_LENGTH_EXPONENT_SHIFT;
            agg_size += u8_get_bits(in->in_ni.ni_he_cap_elem.mac_cap_info[3],
                                    IEEE80211_HE_MAC_CAP3_MAX_AMPDU_LEN_EXP_MASK);
            add_sta_cmd.station_flags |=
            htole32(min(max_aggsize, agg_size) << IWX_STA_FLG_MAX_AGG_SIZE_SHIFT);
        } else if (in->in_ni.ni_flags & IEEE80211_NODE_VHT) {
            agg_size = in->in_ni.ni_vhtcaps &
            IEEE80211_VHTCAP_MAX_A_MPDU_LENGTH_EXPONENT_MASK;
            agg_size >>=
            IEEE80211_VHTCAP_MAX_A_MPDU_LENGTH_EXPONENT_SHIFT;
            add_sta_cmd.station_flags |=
            htole32(min(max_aggsize, agg_size) << IWX_STA_FLG_MAX_AGG_SIZE_SHIFT);
        } else if (in->in_ni.ni_flags & IEEE80211_NODE_HT)
            add_sta_cmd.station_flags |= htole32(IWX_STA_FLG_MAX_AGG_SIZE_64K);
        
        switch (ic->ic_ampdu_params & IEEE80211_AMPDU_PARAM_SS) {
            case IEEE80211_AMPDU_PARAM_SS_2:
                add_sta_cmd.station_flags
                |= htole32(IWX_STA_FLG_AGG_MPDU_DENS_2US);
                break;
            case IEEE80211_AMPDU_PARAM_SS_4:
                add_sta_cmd.station_flags
                |= htole32(IWX_STA_FLG_AGG_MPDU_DENS_4US);
                break;
            case IEEE80211_AMPDU_PARAM_SS_8:
                add_sta_cmd.station_flags
                |= htole32(IWX_STA_FLG_AGG_MPDU_DENS_8US);
                break;
            case IEEE80211_AMPDU_PARAM_SS_16:
                add_sta_cmd.station_flags
                |= htole32(IWX_STA_FLG_AGG_MPDU_DENS_16US);
                break;
            default:
                break;
        }
    }
    
    status = IWX_ADD_STA_SUCCESS;
    err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(add_sta_cmd),
                                  &add_sta_cmd, &status);
    if (!err && (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS)
        err = EIO;
    else
        sc->sc_flags |= IWX_FLAG_STA_ACTIVE;

    return err;
}

int ItlIwx::
iwx_add_aux_sta(struct iwx_softc *sc)
{
    
    XYLog("%s\n", __FUNCTION__);
    struct iwx_add_sta_cmd cmd;
    int err, qid = IWX_DQA_AUX_QUEUE;
    uint32_t status;
    uint8_t cmdver;
    
    /*
     * Add auxiliary station for scanning.
     * Newer versions of this command implies that the fw uses
     * internal aux station for all aux activities that don't
     * requires a dedicated data queue.
     * In old version the aux station uses mac id like other
     * station and not lmac id
     */
    cmdver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_ADD_STA);
    if (cmdver != IWX_FW_CMD_VER_UNKNOWN && cmdver >= 12)
        return 0;
    
    memset(&cmd, 0, sizeof(cmd));
    cmd.sta_id = IWX_AUX_STA_ID;
    cmd.station_type = IWX_STA_AUX_ACTIVITY;
    cmd.mac_id_n_color =
    htole32(IWX_FW_CMD_ID_AND_COLOR(IWX_MAC_INDEX_AUX, 0));
    cmd.tid_disable_tx = htole16(0xffff);
    
    status = IWX_ADD_STA_SUCCESS;
    err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd,
                                  &status);
    if (!err && (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS)
        return EIO;
    
    return iwx_enable_txq(sc, IWX_AUX_STA_ID, qid, IWX_MGMT_TID,
                          sc->txq[qid].ring_count);
    return 0;
}

int ItlIwx::
iwx_rm_sta_cmd(struct iwx_softc *sc, struct iwx_node *in)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_rm_sta_cmd rm_sta_cmd;
    int err;
    
    if ((sc->sc_flags & IWX_FLAG_STA_ACTIVE) == 0) {
        XYLog("sta already removed\n");
        return 0;
    }
    
    memset(&rm_sta_cmd, 0, sizeof(rm_sta_cmd));
    if (ic->ic_opmode == IEEE80211_M_MONITOR)
        rm_sta_cmd.sta_id = IWX_MONITOR_STA_ID;
    else
        rm_sta_cmd.sta_id = IWX_STATION_ID;
    
    err = iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm_sta_cmd),
                           &rm_sta_cmd);
    
    if (!err)
        sc->sc_flags &= ~IWX_FLAG_STA_ACTIVE;

    return err;
}

int ItlIwx::
iwx_rm_sta(struct iwx_softc *sc, struct iwx_node *in)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = &in->in_ni;
    int err, i;

    err = iwx_flush_sta(sc, in);
    if (err) {
        XYLog("%s: could not flush Tx path (error %d)\n",
            __FUNCTION__, err);
        return err;
    }
    if (awdlBaStationAdded && awdlBaGeneration == sc->sc_generation) {
        struct iwx_rm_sta_cmd removePeer;
        memset(&removePeer, 0, sizeof(removePeer));
        removePeer.sta_id = kAwdlBaStationId;
        (void)iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(removePeer), &removePeer);
        awdlBaStationAdded = false;
        awdlBaGeneration = 0;
        awdlBaResponseLength = 0;
        awdlBaPeerAccepted = false;
        awdlBaFilterOff = false;
        awdlBaFilter = ItlAWDL::BaFilterState{};
        awdlBaTxState = kBaTxOff;
        awdlBaTxQueue = -1;
        awdlBaTxLastAskUS = 0;
        awdlBaTxAsks = 0;
        awdlBaTxRestUntilUS = 0;
        ++awdlBaTxToken;
    }
    err = iwx_rm_sta_cmd(sc, in);
    if (err) {
        printf("%s: could not remove STA (error %d)\n",
            DEVNAME(sc), err);
        return err;
    }

    sc->sc_rx_ba_sessions = 0;
    sc->ba_rx.start_tidmask = 0;
    sc->ba_rx.stop_tidmask = 0;
    sc->ba_tx.start_tidmask = 0;
    sc->ba_tx.stop_tidmask = 0;
    for (i = 0; i < IEEE80211_NUM_TID; i++) {
        struct ieee80211_tx_ba *ba = &ni->ni_tx_ba[i];
        if (ba->ba_state != IEEE80211_BA_AGREED)
            continue;
        ieee80211_delba_request(ic, ni, 0, 1, i);
    }

    return 0;
}

uint8_t ItlIwx::
iwx_umac_scan_fill_channels(struct iwx_softc *sc,
                            struct iwx_scan_channel_cfg_umac *chan, int n_ssids, int bgscan)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_channel *c;
    uint8_t nchan;
    
    for (nchan = 0, c = &ic->ic_channels[1];
         c <= &ic->ic_channels[IEEE80211_CHAN_MAX] &&
         nchan < sc->sc_capa_n_scan_channels;
         c++) {
        uint8_t channel_num;
        
        if (c->ic_flags == 0)
            continue;
#ifdef AIRPORT_WCL
        if (!AirportWCL::scanChannelSelected(ic->ic_wcl_scan_channels,
                ic->ic_wcl_scan_requested && ic->ic_wcl_scan_restricted,
                ieee80211_chan2ieee(ic, c)))
            continue;
#endif
        
        channel_num = ieee80211_mhz2ieee(c->ic_freq, 0);
        if (isset(sc->sc_ucode_api,
                  IWX_UCODE_TLV_API_SCAN_EXT_CHAN_VER)) {
            chan->v2.channel_num = channel_num;
            if (IEEE80211_IS_CHAN_2GHZ(c))
                chan->v2.band = IWX_PHY_BAND_24;
            else
                chan->v2.band = IWX_PHY_BAND_5;
            chan->v2.iter_count = 1;
            chan->v2.iter_interval = 0;
        } else {
            chan->v1.channel_num = channel_num;
            chan->v1.iter_count = 1;
            chan->v1.iter_interval = htole16(0);
        }
        
#ifdef AIRPORT_WCL
        if (AirportWCL::probeChannel(n_ssids != 0,
                c->ic_flags & IEEE80211_CHAN_PASSIVE, c->ic_flags & IEEE80211_CHAN_DFS))
#else
        if (n_ssids != 0 && !bgscan)
#endif
            chan->flags = htole32(1 << 0); /* select SSID 0 */
        chan++;
        nchan++;
    }
    
    return nchan;
}

int ItlIwx::
iwx_fill_probe_req_v1(struct iwx_softc *sc, struct iwx_scan_probe_req_v1 *preq1)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_scan_probe_req preq2;
    int err, i;
    
    err = iwx_fill_probe_req(sc, &preq2);
    if (err)
        return err;
    
    preq1->mac_header = preq2.mac_header;
    for (i = 0; i < nitems(preq1->band_data); i++)
        preq1->band_data[i] = preq2.band_data[i];
    preq1->common_data = preq2.common_data;
    memcpy(preq1->buf, preq2.buf, sizeof(preq1->buf));
    return 0;
}

int ItlIwx::
iwx_fill_probe_req(struct iwx_softc *sc, struct iwx_scan_probe_req *preq)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = IC2IFP(ic);
    struct ieee80211_frame *wh = (struct ieee80211_frame *)preq->buf;
    struct ieee80211_rateset *rs;
    size_t remain = sizeof(preq->buf);
    uint8_t *frm, *pos;
    
    memset(preq, 0, sizeof(*preq));
    
    if (remain < sizeof(*wh) + 2)
        return ENOBUFS;
    
    /*
     * Build a probe request frame.  Most of the following code is a
     * copy & paste of what is done in net80211.
     */
    wh->i_fc[0] = IEEE80211_FC0_VERSION_0 | IEEE80211_FC0_TYPE_MGT |
    IEEE80211_FC0_SUBTYPE_PROBE_REQ;
    wh->i_fc[1] = IEEE80211_FC1_DIR_NODS;
//    IEEE80211_ADDR_COPY(ic->ic_myaddr, LLADDR(ifp->if_sadl));
    IEEE80211_ADDR_COPY(wh->i_addr1, etherbroadcastaddr);
    IEEE80211_ADDR_COPY(wh->i_addr2, ic->ic_myaddr);
    IEEE80211_ADDR_COPY(wh->i_addr3, etherbroadcastaddr);
    *(uint16_t *)&wh->i_dur[0] = 0;    /* filled by HW */
    *(uint16_t *)&wh->i_seq[0] = 0;    /* filled by HW */
    
    frm = (uint8_t *)(wh + 1);
    *frm++ = IEEE80211_ELEMID_SSID;
    *frm++ = 0;
    /* hardware inserts SSID */
    
    /* Tell the firmware where the MAC header is. */
    preq->mac_header.offset = 0;
    preq->mac_header.len = htole16(frm - (uint8_t *)wh);
    remain -= frm - (uint8_t *)wh;
    
    /* Fill in 2GHz IEs and tell firmware where they are. */
    rs = &ic->ic_sup_rates[IEEE80211_MODE_11G];
    if (rs->rs_nrates > IEEE80211_RATE_SIZE) {
        if (remain < 4 + rs->rs_nrates)
            return ENOBUFS;
    } else if (remain < 2 + rs->rs_nrates)
        return ENOBUFS;
    preq->band_data[0].offset = htole16(frm - (uint8_t *)wh);
    pos = frm;
    frm = ieee80211_add_rates(frm, rs);
    if (rs->rs_nrates > IEEE80211_RATE_SIZE)
        frm = ieee80211_add_xrates(frm, rs);
    remain -= frm - pos;
    
    if (isset(sc->sc_enabled_capa,
              IWX_UCODE_TLV_CAPA_DS_PARAM_SET_IE_SUPPORT)) {
        if (remain < 3)
            return ENOBUFS;
        *frm++ = IEEE80211_ELEMID_DSPARMS;
        *frm++ = 1;
        *frm++ = 0;
        remain -= 3;
    }
    preq->band_data[0].len = htole16(frm - pos);
    
    if (sc->sc_nvm.sku_cap_band_52GHz_enable) {
        /* Fill in 5GHz IEs. */
        rs = &ic->ic_sup_rates[IEEE80211_MODE_11A];
        if (rs->rs_nrates > IEEE80211_RATE_SIZE) {
            if (remain < 4 + rs->rs_nrates)
                return ENOBUFS;
        } else if (remain < 2 + rs->rs_nrates)
            return ENOBUFS;
        preq->band_data[1].offset = htole16(frm - (uint8_t *)wh);
        pos = frm;
        frm = ieee80211_add_rates(frm, rs);
        if (rs->rs_nrates > IEEE80211_RATE_SIZE)
            frm = ieee80211_add_xrates(frm, rs);
        preq->band_data[1].len = htole16(frm - pos);
        remain -= frm - pos;
        if (ic->ic_flags & IEEE80211_F_VHTON) {
            if (remain < sizeof(struct ieee80211_ie_vhtcap))
                return ENOBUFS;
            frm = ieee80211_add_vhtcaps(frm, ic);
            remain -= frm - pos;
        }
    }
    
    /* Send 11n IEs on both 2GHz and 5GHz bands. */
    preq->common_data.offset = htole16(frm - (uint8_t *)wh);
    pos = frm;
    if (ic->ic_flags & IEEE80211_F_HTON) {
        if (remain < sizeof(struct ieee80211_ie_htcap))
            return ENOBUFS;
        frm = ieee80211_add_htcaps(frm, ic);
        /* XXX add WME info? */
    }

    preq->common_data.len = htole16(frm - pos);
    
    return 0;
}

int ItlIwx::
iwx_config_umac_scan(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_scan_config *scan_config;
    int err;
    size_t cmd_size;
    struct iwx_host_cmd hcmd = {
        .id = iwx_cmd_id(IWX_SCAN_CFG_CMD, IWX_LONG_GROUP, 0),
        .flags = 0,
    };
    uint8_t cmdver;
    
    if (!isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_REDUCED_SCAN_CONFIG))
        return iwx_config_legacy_umac_scan(sc);
    
    cmd_size = sizeof(*scan_config);
    
    scan_config = (struct iwx_scan_config *)malloc(cmd_size, 0, M_ZERO);
    if (scan_config == NULL)
        return ENOMEM;
    
    scan_config->tx_chains = htole32(iwx_fw_valid_tx_ant(sc));
    scan_config->rx_chains = htole32(iwx_fw_valid_rx_ant(sc));
    
    cmdver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_ADD_STA);
    if (cmdver == IWX_FW_CMD_VER_UNKNOWN || cmdver < 12)
        scan_config->bcast_sta_id = IWX_AUX_STA_ID;
    else if (cmdver == IWX_FW_CMD_VER_UNKNOWN || cmdver < 5)
        scan_config->bcast_sta_id = 0xFF;
    
    hcmd.data[0] = scan_config;
    hcmd.len[0] = cmd_size;
    
    err = iwx_send_cmd(sc, &hcmd);
    ::free(scan_config);
    return err;
}

int ItlIwx::
iwx_config_legacy_umac_scan(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_scan_config_v2 *scan_config;
    struct ieee80211com *ic = &sc->sc_ic;
    int err, nchan;
    struct ieee80211_channel *c;
    size_t cmd_size;
    struct iwx_host_cmd hcmd = {
        .id = iwx_cmd_id(IWX_SCAN_CFG_CMD, IWX_LONG_GROUP, 0),
        .flags = 0,
    };
    static const uint32_t rates = (IWX_SCAN_CONFIG_RATE_1M |
                                   IWX_SCAN_CONFIG_RATE_2M | IWX_SCAN_CONFIG_RATE_5M |
                                   IWX_SCAN_CONFIG_RATE_11M | IWX_SCAN_CONFIG_RATE_6M |
                                   IWX_SCAN_CONFIG_RATE_9M | IWX_SCAN_CONFIG_RATE_12M |
                                   IWX_SCAN_CONFIG_RATE_18M | IWX_SCAN_CONFIG_RATE_24M |
                                   IWX_SCAN_CONFIG_RATE_36M | IWX_SCAN_CONFIG_RATE_48M |
                                   IWX_SCAN_CONFIG_RATE_54M);
    
    cmd_size = sizeof(*scan_config) + sc->sc_capa_n_scan_channels;
    
    scan_config = (struct iwx_scan_config_v2 *)malloc(cmd_size, 0, M_ZERO);
    if (scan_config == NULL)
        return ENOMEM;
    
    scan_config->tx_chains = htole32(iwx_fw_valid_tx_ant(sc));
    scan_config->rx_chains = htole32(iwx_fw_valid_rx_ant(sc));
    scan_config->legacy_rates = htole32(rates |
                                        IWX_SCAN_CONFIG_SUPPORTED_RATE(rates));
    
    /* These timings correspond to iwlwifi's UNASSOC scan. */
    scan_config->dwell.active = 10;
    scan_config->dwell.passive = 110;
    scan_config->dwell.fragmented = 44;
    scan_config->dwell.extended = 90;
    scan_config->out_of_channel_time[IWX_SCAN_LB_LMAC_IDX] = htole32(0);
    scan_config->out_of_channel_time[IWX_SCAN_HB_LMAC_IDX] = htole32(0);
    scan_config->suspend_time[IWX_SCAN_LB_LMAC_IDX] = htole32(0);
    scan_config->suspend_time[IWX_SCAN_HB_LMAC_IDX] = htole32(0);
    
    IEEE80211_ADDR_COPY(scan_config->mac_addr, sc->sc_ic.ic_myaddr);
    
    scan_config->bcast_sta_id = IWX_AUX_STA_ID;
    scan_config->channel_flags = 0;
    
    for (c = &ic->ic_channels[1], nchan = 0;
         c <= &ic->ic_channels[IEEE80211_CHAN_MAX] &&
         nchan < sc->sc_capa_n_scan_channels; c++) {
        if (c->ic_flags == 0)
            continue;
        scan_config->channel_array[nchan++] =
        ieee80211_mhz2ieee(c->ic_freq, 0);
    }
    
    scan_config->flags = htole32(IWX_SCAN_CONFIG_FLAG_ACTIVATE |
                                 IWX_SCAN_CONFIG_FLAG_ALLOW_CHUB_REQS |
                                 IWX_SCAN_CONFIG_FLAG_SET_TX_CHAINS |
                                 IWX_SCAN_CONFIG_FLAG_SET_RX_CHAINS |
                                 IWX_SCAN_CONFIG_FLAG_SET_AUX_STA_ID |
                                 IWX_SCAN_CONFIG_FLAG_SET_ALL_TIMES |
                                 IWX_SCAN_CONFIG_FLAG_SET_LEGACY_RATES |
                                 IWX_SCAN_CONFIG_FLAG_SET_MAC_ADDR |
                                 IWX_SCAN_CONFIG_FLAG_SET_CHANNEL_FLAGS|
                                 IWX_SCAN_CONFIG_N_CHANNELS(nchan) |
                                 IWX_SCAN_CONFIG_FLAG_CLEAR_FRAGMENTED);
    
    scan_config->channel_flags = IWX_CHANNEL_FLAG_EBS | 
    IWX_CHANNEL_FLAG_ACCURATE_EBS |
    IWX_CHANNEL_FLAG_EBS_ADD |
    IWX_CHANNEL_FLAG_PRE_SCAN_PASSIVE2ACTIVE;
    
    hcmd.data[0] = scan_config;
    hcmd.len[0] = cmd_size;
    
    err = iwx_send_cmd(sc, &hcmd);
    ::free(scan_config);
    return err;
}

int ItlIwx::
iwx_umac_scan_size(struct iwx_softc *sc)
{
    int base_size = IWX_SCAN_REQ_UMAC_SIZE_V1;
    int tail_size;
    uint8_t scan_ver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_SCAN_REQ_UMAC);
    
    if (scan_ver == 12)
        return sizeof(iwx_scan_req_umac_v12);
    else if (scan_ver == 14)
        return sizeof(iwx_scan_req_umac_v14);
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2))
        base_size = IWX_SCAN_REQ_UMAC_SIZE_V8;
    else if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL))
        base_size = IWX_SCAN_REQ_UMAC_SIZE_V7;
    else
        base_size = IWX_SCAN_REQ_UMAC_SIZE_V6;
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_SCAN_EXT_CHAN_VER))
        tail_size = sizeof(struct iwx_scan_req_umac_tail_v2);
    else
        tail_size = sizeof(struct iwx_scan_req_umac_tail_v1);
    
    return base_size + sizeof(struct iwx_scan_channel_cfg_umac) *
    sc->sc_capa_n_scan_channels + tail_size;
}

struct iwx_scan_umac_chan_param *ItlIwx::
iwx_get_scan_req_umac_chan_param(struct iwx_softc *sc,
                                 struct iwx_scan_req_umac *req)
{
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2))
        return &req->v8.channel;
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL))
        return &req->v7.channel;

    return &req->v6.channel;
}

void *ItlIwx::
iwx_get_scan_req_umac_data(struct iwx_softc *sc, struct iwx_scan_req_umac *req)
{
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2))
        return (void *)&req->v8.data;
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL))
        return (void *)&req->v7.data;
    
    return (void *)&req->v6.data;
}

#define IWL_SCAN_DWELL_ACTIVE        10
#define IWL_SCAN_DWELL_PASSIVE        110
#define IWL_SCAN_DWELL_FRAGMENTED    44
#define IWL_SCAN_DWELL_EXTENDED        90
#define IWL_SCAN_NUM_OF_FRAGS        3
#define IWL_SCAN_LAST_2_4_CHN        14

/* adaptive dwell max budget time [TU] for full scan */
#define IWX_SCAN_ADWELL_MAX_BUDGET_FULL_SCAN 300
/* adaptive dwell max budget time [TU] for directed scan */
#define IWX_SCAN_ADWELL_MAX_BUDGET_DIRECTED_SCAN 100
/* adaptive dwell default high band APs number */
#define IWX_SCAN_ADWELL_DEFAULT_HB_N_APS 8
/* adaptive dwell default low band APs number */
#define IWX_SCAN_ADWELL_DEFAULT_LB_N_APS 2
/* adaptive dwell default APs number in social channels (1, 6, 11) */
#define IWX_SCAN_ADWELL_DEFAULT_N_APS_SOCIAL 10
/* number of scan channels */
#define IWX_SCAN_NUM_CHANNELS 112
/* adaptive dwell number of APs override mask for p2p friendly GO */
#define IWX_SCAN_ADWELL_N_APS_GO_FRIENDLY_BIT (1 << 20)
/* adaptive dwell number of APs override mask for social channels */
#define IWX_SCAN_ADWELL_N_APS_SOCIAL_CHS_BIT (1 << 21)
/* adaptive dwell number of APs override for p2p friendly GO channels */
#define IWX_SCAN_ADWELL_N_APS_GO_FRIENDLY 10
/* adaptive dwell number of APs override for social channels */
#define IWX_SCAN_ADWELL_N_APS_SOCIAL_CHS 2

/* minimal number of 2GHz and 5GHz channels in the regular scan request */
#define IWX_MVM_6GHZ_PASSIVE_SCAN_MIN_CHANS 4

int ItlIwx::
iwx_umac_scan(struct iwx_softc *sc, int bgscan)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    int scanSSIDLength = ic->ic_des_esslen;
    const uint8_t *scanSSID = ic->ic_des_essid;
    bool scanActive = scanSSIDLength != 0 && !bgscan;
#ifdef AIRPORT_WCL
    scanActive = AirportWCL::scanUsesProbes(ic->ic_wcl_scan_requested,
        ic->ic_wcl_scan_active);
    if (ic->ic_wcl_scan_requested) {
        scanSSIDLength = ic->ic_wcl_scan_ssid_length;
        scanSSID = ic->ic_wcl_scan_ssid;
    }
#endif
    struct iwx_host_cmd hcmd = {
        .id = iwx_cmd_id(IWX_SCAN_REQ_UMAC, IWX_LONG_GROUP, 0),
        .len = { 0, },
        .data = { NULL, },
        .flags = 0,
    };
    struct iwx_scan_req_umac *req;
    void *cmd_data, *tail_data;
    struct iwx_scan_req_umac_tail_v2 *tail;
    struct iwx_scan_req_umac_tail_v1 *tailv1;
    struct iwx_scan_umac_chan_param *chanparam;
    size_t req_len;
    int err, async = bgscan;
#ifdef AIRPORT_WCL
    const auto timing = AirportWCL::scanTiming(ic->ic_wcl_scan_away_time_ms, bgscan,
        isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_FRAGMENTED_SCAN), itlScanMaxOutTU);
    const uint32_t timeout = htole32(timing.suspendTU);
    const uint32_t maxOut = htole32(timing.maxOutTU);
#else
    const uint32_t timeout = bgscan ?  htole32(120) : htole32(0);
    const uint32_t maxOut = timeout;
#endif
    uint8_t scan_ver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_SCAN_REQ_UMAC);
    
    if (scan_ver == 12)
        return iwx_umac_scan_v12(sc, bgscan);
    else if (scan_ver == 14)
        return iwx_umac_scan_v14(sc, bgscan);
    
    req_len = iwx_umac_scan_size(sc);
    if ((req_len < IWX_SCAN_REQ_UMAC_SIZE_V1 +
         sizeof(struct iwx_scan_req_umac_tail_v1)) ||
        req_len > IWX_MAX_CMD_PAYLOAD_SIZE)
        return ERANGE;
    req = (struct iwx_scan_req_umac *)malloc(req_len, 0,
                                             (async ? M_NOWAIT : M_WAITOK) | M_ZERO);
    if (req == NULL)
        return ENOMEM;
    
    hcmd.len[0] = (uint16_t)req_len;
    hcmd.data[0] = (void *)req;
    hcmd.flags |= async ? IWX_CMD_ASYNC : 0;
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL)) {
        req->v7.adwell_default_n_aps_social =
        IWX_SCAN_ADWELL_DEFAULT_N_APS_SOCIAL;
        req->v7.adwell_default_n_aps =
        IWX_SCAN_ADWELL_DEFAULT_LB_N_APS;
        
        if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADWELL_HB_DEF_N_AP))
            req->v9.adwell_default_hb_n_aps = IWX_SCAN_ADWELL_DEFAULT_HB_N_APS;
        
        if (scanActive && scanSSIDLength != 0)
            req->v7.adwell_max_budget =
            htole16(IWX_SCAN_ADWELL_MAX_BUDGET_DIRECTED_SCAN);
        else
            req->v7.adwell_max_budget =
            htole16(IWX_SCAN_ADWELL_MAX_BUDGET_FULL_SCAN);
        
        req->v7.scan_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
        req->v7.max_out_time[IWX_SCAN_LB_LMAC_IDX] = maxOut;
        req->v7.suspend_time[IWX_SCAN_LB_LMAC_IDX] = timeout;
        
        if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
            req->v7.max_out_time[IWX_SCAN_HB_LMAC_IDX] =
                maxOut;
            req->v7.suspend_time[IWX_SCAN_HB_LMAC_IDX] =
                timeout;
        }
        
        if (isset(sc->sc_ucode_api,
                  IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2)) {
            req->v8.active_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_ACTIVE;
            req->v8.passive_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_PASSIVE;
            if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
                req->v8.active_dwell[IWX_SCAN_HB_LMAC_IDX] =
                    IWL_SCAN_DWELL_ACTIVE;
                req->v8.passive_dwell[IWX_SCAN_HB_LMAC_IDX] =
                    IWL_SCAN_DWELL_PASSIVE;
            }
        } else {
            req->v7.active_dwell = IWL_SCAN_DWELL_ACTIVE;
            req->v7.passive_dwell = IWL_SCAN_DWELL_PASSIVE;
            req->v7.fragmented_dwell = IWL_SCAN_DWELL_FRAGMENTED;
        }
    } else {
        /* These timings correspond to iwlwifi's UNASSOC scan. */
        req->v1.active_dwell = IWL_SCAN_DWELL_ACTIVE;
        req->v1.passive_dwell = IWL_SCAN_DWELL_PASSIVE;
        req->v1.fragmented_dwell = IWL_SCAN_DWELL_FRAGMENTED;
        req->v1.extended_dwell = IWL_SCAN_DWELL_EXTENDED;
        
        if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
            req->v6.max_out_time[IWX_SCAN_HB_LMAC_IDX] =
                maxOut;
            req->v6.suspend_time[IWX_SCAN_HB_LMAC_IDX] =
                timeout;
        }
        
        req->v6.scan_priority =
            htole32(IWX_SCAN_PRIORITY_EXT_6);
        req->v6.max_out_time[IWX_SCAN_LB_LMAC_IDX] =
            maxOut;
        req->v6.suspend_time[IWX_SCAN_LB_LMAC_IDX] =
            timeout;
    }
    
    req->ooc_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
    
    cmd_data = iwx_get_scan_req_umac_data(sc, req);
    chanparam = iwx_get_scan_req_umac_chan_param(sc, req);
    chanparam->count = iwx_umac_scan_fill_channels(sc,
                                                   (struct iwx_scan_channel_cfg_umac *)cmd_data,
                                                   scanActive, bgscan);
    chanparam->flags = 0;
    
    tail_data = (uint8_t*)cmd_data + sizeof(struct iwx_scan_channel_cfg_umac) *
    sc->sc_capa_n_scan_channels;
    tail = (struct iwx_scan_req_umac_tail_v2 *)tail_data;
    /* tail v1 layout differs in preq and direct_scan member fields. */
    tailv1 = (struct iwx_scan_req_umac_tail_v1 *)tail_data;
    
    req->general_flags = htole32(IWX_UMAC_SCAN_GEN_FLAGS_PASS_ALL |
                                 IWX_UMAC_SCAN_GEN_FLAGS_ITER_COMPLETE);
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2)) {
        req->v8.general_flags2 =
        IWX_UMAC_SCAN_GEN_FLAGS2_ALLOW_CHNL_REORDER;
    }
    
    /* Check if we're doing an active directed scan. */
    if (scanActive) {
        if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_SCAN_EXT_CHAN_VER)) {
            tail->direct_scan[0].id = IEEE80211_ELEMID_SSID;
            tail->direct_scan[0].len = scanSSIDLength;
            memcpy(tail->direct_scan[0].ssid, scanSSID,
                   scanSSIDLength);
        } else {
            tailv1->direct_scan[0].id = IEEE80211_ELEMID_SSID;
            tailv1->direct_scan[0].len = scanSSIDLength;
            memcpy(tailv1->direct_scan[0].ssid, scanSSID,
                   scanSSIDLength);
        }
        if (scanSSIDLength != 0)
            req->general_flags |= htole32(IWX_UMAC_SCAN_GEN_FLAGS_PRE_CONNECT);
    } else
        req->general_flags |= htole32(IWX_UMAC_SCAN_GEN_FLAGS_PASSIVE);
    
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DS_PARAM_SET_IE_SUPPORT) &&
        isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_WFA_TPC_REP_IE_SUPPORT))
        req->general_flags |=
        htole32(IWX_UMAC_SCAN_GEN_FLAGS_RRM_ENABLED);
    
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL)) {
        req->general_flags |=
        htole32(IWX_UMAC_SCAN_GEN_FLAGS_ADAPTIVE_DWELL);
    } else {
        req->general_flags |=
        htole32(IWX_UMAC_SCAN_GEN_FLAGS_EXTENDED_DWELL);
    }
    
#ifdef AIRPORT_WCL
    if (timing.fragmented) {
        req->general_flags &= ~htole16(IWX_UMAC_SCAN_GEN_FLAGS_EXTENDED_DWELL);
        req->general_flags |= htole16(IWX_UMAC_SCAN_GEN_FLAGS_FRAGMENTED);
        bool cdb = isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT);
        if (cdb)
            req->general_flags |= htole16(IWX_UMAC_SCAN_GEN_FLAGS_LMAC2_FRAGMENTED);
        if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_ADAPTIVE_DWELL_V2)) {
            req->v8.num_of_fragments[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
            if (cdb)
                req->v8.num_of_fragments[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
        }
    }
#endif

    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_SCAN_EXT_CHAN_VER))
        err = iwx_fill_probe_req(sc, &tail->preq);
    else
        err = iwx_fill_probe_req_v1(sc, &tailv1->preq);
    if (err) {
        ::free(req);
        return err;
    }
    
    /* Specify the scan plan: We'll do one iteration. */
    tail->schedule[0].interval = 0;
    tail->schedule[0].iter_count = 1;
    
    err = iwx_send_cmd(sc, &hcmd);
    ::free(req);
    return err;
}

int ItlIwx::
iwx_umac_scan_v12(struct iwx_softc *sc, int bgscan)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    int scanSSIDLength = ic->ic_des_esslen;
    const uint8_t *scanSSID = ic->ic_des_essid;
    bool scanActive = scanSSIDLength != 0 && !bgscan;
#ifdef AIRPORT_WCL
    scanActive = AirportWCL::scanUsesProbes(ic->ic_wcl_scan_requested,
        ic->ic_wcl_scan_active);
    if (ic->ic_wcl_scan_requested) {
        scanSSIDLength = ic->ic_wcl_scan_ssid_length;
        scanSSID = ic->ic_wcl_scan_ssid;
    }
#endif
    int err = 0, async = bgscan;
    struct iwx_scan_req_umac_v12 *req;
    size_t req_len;
    uint16_t gen_flags = 0;
#ifdef AIRPORT_WCL
    const auto timing = AirportWCL::scanTiming(ic->ic_wcl_scan_away_time_ms, bgscan,
        isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_FRAGMENTED_SCAN), itlScanMaxOutTU);
    const uint32_t timeout = htole32(timing.suspendTU);
    const uint32_t maxOut = htole32(timing.maxOutTU);
#else
    const uint32_t timeout = bgscan ?  htole32(120) : htole32(0);
    const uint32_t maxOut = timeout;
#endif
    struct iwx_scan_general_params_v10 *general_params;
    struct iwx_scan_channel_params_v4 *cp;
    struct iwx_host_cmd hcmd = {
        .id = iwx_cmd_id(IWX_SCAN_REQ_UMAC, IWX_LONG_GROUP, 0),
        .len = { 0, },
        .data = { NULL, },
        .flags = 0,
    };
    
    req_len = iwx_umac_scan_size(sc);
    req = (struct iwx_scan_req_umac_v12 *)malloc(req_len, 0,
                                             (async ? M_NOWAIT : M_WAITOK) | M_ZERO);
    if (req == NULL)
        return ENOMEM;
    
    hcmd.len[0] = (uint16_t)req_len;
    hcmd.data[0] = (void *)req;
    hcmd.flags |= async ? IWX_CMD_ASYNC : 0;
    
    general_params = &req->scan_params.general_params;
    
    req->ooc_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
    
    if (!scanActive)
        gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FORCE_PASSIVE;
    
    gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_PASS_ALL |
    IWX_UMAC_SCAN_GEN_FLAGS_V2_ADAPTIVE_DWELL;
    
#ifdef AIRPORT_WCL
    if (timing.fragmented) {
        gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FRAGMENTED_LMAC1;
        general_params->num_of_fragments[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
        if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
            gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FRAGMENTED_LMAC2;
            general_params->num_of_fragments[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
        }
    }
#endif
    req->scan_params.general_params.flags = gen_flags;
    
    general_params->adwell_default_social_chn =
        IWX_SCAN_ADWELL_DEFAULT_N_APS_SOCIAL;
    general_params->adwell_default_2g = IWX_SCAN_ADWELL_DEFAULT_LB_N_APS;
    general_params->adwell_default_5g = IWX_SCAN_ADWELL_DEFAULT_HB_N_APS;

    if (scanActive && scanSSIDLength != 0)
        general_params->adwell_max_budget =
            cpu_to_le16(IWX_SCAN_ADWELL_MAX_BUDGET_DIRECTED_SCAN);
    else
        general_params->adwell_max_budget =
            cpu_to_le16(IWX_SCAN_ADWELL_MAX_BUDGET_FULL_SCAN);
    
    general_params->scan_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
    general_params->max_out_of_time[IWX_SCAN_LB_LMAC_IDX] =
        maxOut;
    general_params->suspend_time[IWX_SCAN_LB_LMAC_IDX] =
        timeout;
    
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
        general_params->max_out_of_time[IWX_SCAN_HB_LMAC_IDX] = maxOut;
        general_params->suspend_time[IWX_SCAN_HB_LMAC_IDX] = timeout;
    }

    general_params->active_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_ACTIVE;
    general_params->passive_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_PASSIVE;
    general_params->active_dwell[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_DWELL_ACTIVE;
    general_params->passive_dwell[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_DWELL_PASSIVE;
    
    /* Specify the scan plan: We'll do one iteration. */
    req->scan_params.periodic_params.schedule[0].interval = 0;
    req->scan_params.periodic_params.schedule[0].iter_count = 1;
    
    err = iwx_fill_probe_req(sc, &req->scan_params.probe_params.preq);
    if (err)
        return err;

    if (scanActive) {
        req->scan_params.probe_params.ssid_num = 1;
        req->scan_params.probe_params.direct_scan[0].id = IEEE80211_ELEMID_SSID;
        req->scan_params.probe_params.direct_scan[0].len = scanSSIDLength;
        memcpy(req->scan_params.probe_params.direct_scan[0].ssid, scanSSID,
               scanSSIDLength);
    } else
        req->scan_params.probe_params.ssid_num = 0;
    
    cp = &req->scan_params.channel_params;
    
    cp->flags = IWX_SCAN_CHANNEL_FLAG_ENABLE_CHAN_ORDER;
    cp->count = iwx_umac_scan_fill_channels(sc,
                                            (struct iwx_scan_channel_cfg_umac *)cp->channel_config,
                                            scanActive, bgscan);
    cp->num_of_aps_override = IWX_SCAN_ADWELL_N_APS_GO_FRIENDLY;
    
    err = iwx_send_cmd(sc, &hcmd);
    ::free(req);
    return err;
}

int ItlIwx::
iwx_umac_scan_v14(struct iwx_softc *sc, int bgscan)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    int scanSSIDLength = ic->ic_des_esslen;
    const uint8_t *scanSSID = ic->ic_des_essid;
    bool scanActive = scanSSIDLength != 0 && !bgscan;
#ifdef AIRPORT_WCL
    scanActive = AirportWCL::scanUsesProbes(ic->ic_wcl_scan_requested,
        ic->ic_wcl_scan_active);
    if (ic->ic_wcl_scan_requested) {
        scanSSIDLength = ic->ic_wcl_scan_ssid_length;
        scanSSID = ic->ic_wcl_scan_ssid;
    }
#endif
    int err = 0, async = bgscan;
    struct iwx_scan_req_umac_v14 *req;
    size_t req_len;
    uint16_t gen_flags = 0;
    struct iwx_scan_general_params_v10 *general_params;
    struct iwx_scan_channel_params_v6 *cp;
#ifdef AIRPORT_WCL
    const auto timing = AirportWCL::scanTiming(ic->ic_wcl_scan_away_time_ms, bgscan,
        isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_FRAGMENTED_SCAN), itlScanMaxOutTU);
    const uint32_t timeout = htole32(timing.suspendTU);
    const uint32_t maxOut = htole32(timing.maxOutTU);
#else
    const uint32_t timeout = bgscan ?  htole32(120) : htole32(0);
    const uint32_t maxOut = timeout;
#endif
    struct iwx_host_cmd hcmd = {
        .id = iwx_cmd_id(IWX_SCAN_REQ_UMAC, IWX_LONG_GROUP, 0),
        .len = { 0, },
        .data = { NULL, },
        .flags = 0,
    };
    
    req_len = iwx_umac_scan_size(sc);
    req = (struct iwx_scan_req_umac_v14 *)malloc(req_len, 0,
                                             (async ? M_NOWAIT : M_WAITOK) | M_ZERO);
    if (req == NULL)
        return ENOMEM;
    
    hcmd.len[0] = (uint16_t)req_len;
    hcmd.data[0] = (void *)req;
    hcmd.flags |= async ? IWX_CMD_ASYNC : 0;
    
    general_params = &req->scan_params.general_params;
    
    req->ooc_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
    
    if (!scanActive)
        gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FORCE_PASSIVE;
    
    gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_PASS_ALL |
    IWX_UMAC_SCAN_GEN_FLAGS_V2_ADAPTIVE_DWELL;
    
#ifdef AIRPORT_WCL
    if (timing.fragmented) {
        gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FRAGMENTED_LMAC1;
        general_params->num_of_fragments[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
        if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
            gen_flags |= IWX_UMAC_SCAN_GEN_FLAGS_V2_FRAGMENTED_LMAC2;
            general_params->num_of_fragments[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_NUM_OF_FRAGS;
        }
    }
#endif
    req->scan_params.general_params.flags = gen_flags;
    
    general_params->adwell_default_social_chn =
        IWX_SCAN_ADWELL_DEFAULT_N_APS_SOCIAL;
    general_params->adwell_default_2g = IWX_SCAN_ADWELL_DEFAULT_LB_N_APS;
    general_params->adwell_default_5g = IWX_SCAN_ADWELL_DEFAULT_HB_N_APS;
    if (scanActive && scanSSIDLength != 0)
        general_params->adwell_max_budget =
            cpu_to_le16(IWX_SCAN_ADWELL_MAX_BUDGET_DIRECTED_SCAN);
    else
        general_params->adwell_max_budget =
            cpu_to_le16(IWX_SCAN_ADWELL_MAX_BUDGET_FULL_SCAN);
    
    general_params->scan_priority = htole32(IWX_SCAN_PRIORITY_EXT_6);
    general_params->max_out_of_time[IWX_SCAN_LB_LMAC_IDX] =
        maxOut;
    general_params->suspend_time[IWX_SCAN_LB_LMAC_IDX] =
        timeout;
    
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT)) {
        general_params->max_out_of_time[IWX_SCAN_HB_LMAC_IDX] = maxOut;
        general_params->suspend_time[IWX_SCAN_HB_LMAC_IDX] = timeout;
    }

    general_params->active_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_ACTIVE;
    general_params->passive_dwell[IWX_SCAN_LB_LMAC_IDX] = IWL_SCAN_DWELL_PASSIVE;
    general_params->active_dwell[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_DWELL_ACTIVE;
    general_params->passive_dwell[IWX_SCAN_HB_LMAC_IDX] = IWL_SCAN_DWELL_PASSIVE;
    
    /* Specify the scan plan: We'll do one iteration. */
    req->scan_params.periodic_params.schedule[0].interval = 0;
    req->scan_params.periodic_params.schedule[0].iter_count = 1;
    
    err = iwx_fill_probe_req(sc, &req->scan_params.probe_params.preq);
    if (err)
        return err;
    if (scanActive) {
        req->scan_params.probe_params.direct_scan[0].id = IEEE80211_ELEMID_SSID;
        req->scan_params.probe_params.direct_scan[0].len = scanSSIDLength;
        memcpy(req->scan_params.probe_params.direct_scan[0].ssid, scanSSID,
               scanSSIDLength);
    }
    
    cp = &req->scan_params.channel_params;
    
    cp->flags = IWX_SCAN_CHANNEL_FLAG_ENABLE_CHAN_ORDER;
    cp->count = iwx_umac_scan_fill_channels(sc,
                                            (struct iwx_scan_channel_cfg_umac *)cp->channel_config,
                                            scanActive, bgscan);
    cp->n_aps_override[0] = IWX_SCAN_ADWELL_N_APS_GO_FRIENDLY;
    cp->n_aps_override[1] = IWX_SCAN_ADWELL_N_APS_SOCIAL_CHS;
    
    err = iwx_send_cmd(sc, &hcmd);
    ::free(req);
    return err;
}

void ItlIwx::
iwx_mcc_update(struct iwx_softc *sc, struct iwx_mcc_chub_notif *notif)
{
    if (awdlRx && awdlWant149) {
        const uint16_t reported = le16toh(notif->mcc);
        ++awdlCountryNotices;
        if (awdlCountryDiscovery) {
            if (ItlAWDL::countryNoticeUsable(reported, notif->source_id) && !awdlCountryNoticeSeen) {
                awdlCountryNotice = reported;
                awdlCountryNoticeSource = notif->source_id;
                awdlCountryNoticeSeen = true;
                getMainCommandGate()->commandWakeup(&awdlCountryDiscovery);
            }
        } else if (awdlFixedChannel == 149 && notif->source_id == ItlAWDL::kMccSourceWifi &&
                   reported != awdlCountryLastAnswered &&
                   ItlAWDL::mccEchoDue(awdlCountryAnswers != 0, mccUptimeSeconds(), awdlCountryAnswerSeconds)) {
            // The domain can be taken back, and that has to reach the channel map too.
            awdlCountryNotice = reported;
            awdlCountryNoticeSource = notif->source_id;
            awdlCountryAnswerPending = true;
        } else if (awdlBackgroundScan && awdlFixedChannel != 149 && !awdlCountryDiscovery &&
                   ItlAWDL::countryNoticeUsable(reported, notif->source_id)) {
            awdlChannelMove.upNoticed = true;
        }
    }
    if (awdlCoexMulti && awdlCoexRx && !awdlRx) {
        // Station mode with the listener's own channel: answered from the coex task, which can wait on the
        // firmware. A newly learned country at most every 30 s; a change after an answer (a withdrawal
        // included) at once, so the map never stays more permissive than the firmware.
        const uint16_t reported = le16toh(notif->mcc);
        ++awdlCoexCountryNotices;
        if (awdlCoexCountryGen != sc->sc_generation) {
            // A restart: nothing from the old generation is answered or replayed.
            awdlCoexCountryGen = sc->sc_generation;
            awdlCoexCountryAnswered = 0;
            awdlCoexCountrySourceAnswered = 0;
            awdlCoexCountryLearned = false;
            awdlCoexCountryPending = false;
            awdlCoexCountryRetryUS = 0;
        }
        // Any change is answered, not only a usable country: after a firmware restart the map is the firmware's
        // current one (it keeps a learned country), and a later withdrawal has to reach it even though this
        // generation never answered a country itself.
        const bool changed = reported != awdlCoexCountryAnswered || notif->source_id != awdlCoexCountrySourceAnswered;
        // Only the latest notice is ever answered: one that matches the last answer supersedes anything
        // still pending.
        if (changed) {
            awdlCoexCountryNotice = reported;
            awdlCoexCountrySource = notif->source_id;
            awdlCoexCountryPending = true;
        } else {
            awdlCoexCountryPending = false;
        }
    }
    if (mccProbe) {
        ItlAWDL::regulatoryAppend(mccNotices, nitems(mccNotices), mccNoticeCount,
            ItlAWDL::MccNotice{mccUptimeSeconds(), le16toh(notif->mcc), notif->source_id, 0});
        ++mccNoticeTotal;
        mccNoticeLastSeconds = mccUptimeSeconds();
        mccProbePublish();
        // Answering needs a reply from the firmware, so it can't happen in this handler.
        if (ItlAWDL::mccEchoDue(mccEchoAnswered, mccNoticeLastSeconds, mccEchoLastSeconds)) {
            mccEchoCountry = le16toh(notif->mcc);
            mccEchoSource = notif->source_id;
            mccProbeNoticePending = true;
            timeout_add_msec(&mccProbeTimer, 100);
        }
    }
   struct ieee80211com *ic = &sc->sc_ic;
   struct _ifnet *ifp = IC2IFP(ic);

    snprintf(sc->sc_fw_mcc, sizeof(sc->sc_fw_mcc), "%c%c",
             (le16toh(notif->mcc) & 0xff00) >> 8, le16toh(notif->mcc) & 0xff);
    if (sc->sc_fw_mcc_int != notif->mcc && sc->sc_ic.ic_event_handler) {
        (*sc->sc_ic.ic_event_handler)(&sc->sc_ic, IEEE80211_EVT_COUNTRY_CODE_UPDATE, NULL);
    }
    sc->sc_fw_mcc_int = notif->mcc;

    if (ifp->if_flags & IFF_DEBUG) {
        DPRINTFN(3, ("%s: firmware has detected regulatory domain '%s' "
               "(0x%x)\n", DEVNAME(sc), sc->sc_fw_mcc, le16toh(notif->mcc)));
    }

   /* TODO: Schedule a task to send MCC_UPDATE_CMD? */
}

uint8_t ItlIwx::
iwx_ridx2rate(struct ieee80211_rateset *rs, int ridx)
{
    int i;
    uint8_t rval;
    
    for (i = 0; i < rs->rs_nrates; i++) {
        rval = (rs->rs_rates[i] & IEEE80211_RATE_VAL);
        if (rval == iwx_rates[ridx].rate)
            return rs->rs_rates[i];
    }
    
    return 0;
}

int ItlIwx::
iwx_rval2ridx(int rval)
{
    int ridx;
    
    for (ridx = 0; ridx < nitems(iwx_rates); ridx++) {
        if (iwx_rates[ridx].plcp == IWX_RATE_INVM_PLCP)
            continue;
        if (rval == iwx_rates[ridx].rate)
            break;
    }
    
    return ridx;
}

int ItlIwx::
iwx_rate2idx(int rate)
{
    const struct ieee80211_rateset *rs = &ieee80211_std_rateset_11a;
    int idx;
    
    for (idx = 0; idx < rs->rs_nrates; idx++) {
        if (rs->rs_rates[idx] == rate)
            return idx;
    }
    
    return 0;
}

void ItlIwx::
iwx_ack_rates(struct iwx_softc *sc, struct iwx_node *in, int *cck_rates,
              int *ofdm_rates)
{
    struct ieee80211_node *ni = &in->in_ni;
    struct ieee80211_rateset *rs = &ni->ni_rates;
    int lowest_present_ofdm = -1;
    int lowest_present_cck = -1;
    uint8_t cck = 0;
    uint8_t ofdm = 0;
    int i;
    
    if (ni->ni_chan == IEEE80211_CHAN_ANYC ||
        IEEE80211_IS_CHAN_2GHZ(ni->ni_chan)) {
        for (i = IWX_FIRST_CCK_RATE; i < IWX_FIRST_OFDM_RATE; i++) {
            if ((iwx_ridx2rate(rs, i) & IEEE80211_RATE_BASIC) == 0)
                continue;
            cck |= (1 << i);
            if (lowest_present_cck == -1 || lowest_present_cck > i)
                lowest_present_cck = i;
        }
    }
    for (i = IWX_FIRST_OFDM_RATE; i <= IWX_LAST_NON_HT_RATE; i++) {
        if ((iwx_ridx2rate(rs, i) & IEEE80211_RATE_BASIC) == 0)
            continue;
        ofdm |= (1 << (i - IWX_FIRST_OFDM_RATE));
        if (lowest_present_ofdm == -1 || lowest_present_ofdm > i)
            lowest_present_ofdm = i;
    }
    
    /*
     * Now we've got the basic rates as bitmaps in the ofdm and cck
     * variables. This isn't sufficient though, as there might not
     * be all the right rates in the bitmap. E.g. if the only basic
     * rates are 5.5 Mbps and 11 Mbps, we still need to add 1 Mbps
     * and 6 Mbps because the 802.11-2007 standard says in 9.6:
     *
     *    [...] a STA responding to a received frame shall transmit
     *    its Control Response frame [...] at the highest rate in the
     *    BSSBasicRateSet parameter that is less than or equal to the
     *    rate of the immediately previous frame in the frame exchange
     *    sequence ([...]) and that is of the same modulation class
     *    ([...]) as the received frame. If no rate contained in the
     *    BSSBasicRateSet parameter meets these conditions, then the
     *    control frame sent in response to a received frame shall be
     *    transmitted at the highest mandatory rate of the PHY that is
     *    less than or equal to the rate of the received frame, and
     *    that is of the same modulation class as the received frame.
     *
     * As a consequence, we need to add all mandatory rates that are
     * lower than all of the basic rates to these bitmaps.
     */
    
    if (IWX_RATE_24M_INDEX < lowest_present_ofdm)
        ofdm |= IWX_RATE_BIT_MSK(24) >> IWX_FIRST_OFDM_RATE;
    if (IWX_RATE_12M_INDEX < lowest_present_ofdm)
        ofdm |= IWX_RATE_BIT_MSK(12) >> IWX_FIRST_OFDM_RATE;
    /* 6M already there or needed so always add */
    ofdm |= IWX_RATE_BIT_MSK(6) >> IWX_FIRST_OFDM_RATE;
    
    /*
     * CCK is a bit more complex with DSSS vs. HR/DSSS vs. ERP.
     * Note, however:
     *  - if no CCK rates are basic, it must be ERP since there must
     *    be some basic rates at all, so they're OFDM => ERP PHY
     *    (or we're in 5 GHz, and the cck bitmap will never be used)
     *  - if 11M is a basic rate, it must be ERP as well, so add 5.5M
     *  - if 5.5M is basic, 1M and 2M are mandatory
     *  - if 2M is basic, 1M is mandatory
     *  - if 1M is basic, that's the only valid ACK rate.
     * As a consequence, it's not as complicated as it sounds, just add
     * any lower rates to the ACK rate bitmap.
     */
    if (IWX_RATE_11M_INDEX < lowest_present_cck)
        cck |= IWX_RATE_BIT_MSK(11) >> IWX_FIRST_CCK_RATE;
    if (IWX_RATE_5M_INDEX < lowest_present_cck)
        cck |= IWX_RATE_BIT_MSK(5) >> IWX_FIRST_CCK_RATE;
    if (IWX_RATE_2M_INDEX < lowest_present_cck)
        cck |= IWX_RATE_BIT_MSK(2) >> IWX_FIRST_CCK_RATE;
    /* 1M already there or needed so always add */
    cck |= IWX_RATE_BIT_MSK(1) >> IWX_FIRST_CCK_RATE;
    
    *cck_rates = cck;
    *ofdm_rates = ofdm;
}

static uint8_t iwx_mvm_mac80211_ac_to_ucode_ac(enum ieee80211_edca_ac ac)
{
   static const uint8_t mac80211_ac_to_ucode_ac[] = {
       IWX_AC_BE,
       IWX_AC_BK,
       IWX_AC_VI,
       IWX_AC_VO
   };

   return mac80211_ac_to_ucode_ac[ac];
}

void ItlIwx::
iwx_mac_ctxt_cmd_common(struct iwx_softc *sc, struct iwx_node *in,
                        struct iwx_mac_ctx_cmd *cmd, uint32_t action)
{
#define IWX_EXP2(x)    ((1 << (x)) - 1)    /* CWmin = 2^ECWmin - 1 */
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    int cck_ack_rates, ofdm_ack_rates;
    int i;
    
    cmd->id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id,
                                                        in->in_color));
    cmd->action = htole32(action);

    if (action == IWX_FW_CTXT_ACTION_REMOVE)
        return;

    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        if (awdlBaMacType && action == IWX_FW_CTXT_ACTION_ADD && ++awdlBaMacAdds > kAwdlBaMacAddsMax) {
            awdlBaMacType = 0;
            awdlBaMacFellBack = 1;
        }
        cmd->mac_type = htole32(awdlBaMacType ? awdlBaMacType : uint32_t(IWX_FW_MAC_TYPE_LISTENER));
    }
    else if (ic->ic_opmode == IEEE80211_M_STA)
        cmd->mac_type = htole32(IWX_FW_MAC_TYPE_BSS_STA);
    else
        panic("unsupported operating mode %d\n", ic->ic_opmode);
    cmd->tsf_id = htole32(IWX_TSF_ID_A);
    
    IEEE80211_ADDR_COPY(cmd->node_addr, ic->ic_opmode == IEEE80211_M_MONITOR &&
                        ItlAWDL::knownAddress(awdlMacOverride) ? awdlMacOverride : ic->ic_myaddr);
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        IEEE80211_ADDR_COPY(cmd->bssid_addr, awdlBaMacType ? kAwdlBssid :
                            awdlBaProbe && ItlAWDL::knownAddress(awdlBaBssid) ? awdlBaBssid : etherbroadcastaddr);
        if (awdlBaProbe) {
            // Block Acks are HT control responses, so the firmware may need to know that HT is
            // on and which rates to answer at. Nothing else about this context changes.
            iwx_ack_rates(sc, in, &cck_ack_rates, &ofdm_ack_rates);
            cmd->cck_rates = htole32(cck_ack_rates);
            cmd->ofdm_rates = htole32(ofdm_ack_rates);
            cmd->qos_flags |= htole32(IWX_MAC_QOS_FLG_TGN);
        }
        return;
    }
    
    IEEE80211_ADDR_COPY(cmd->bssid_addr, in->in_macaddr);
    iwx_ack_rates(sc, in, &cck_ack_rates, &ofdm_ack_rates);
    cmd->cck_rates = htole32(cck_ack_rates);
    cmd->ofdm_rates = htole32(ofdm_ack_rates);
    
    cmd->cck_short_preamble
    = htole32((ic->ic_flags & IEEE80211_F_SHPREAMBLE)
              ? IWX_MAC_FLG_SHORT_PREAMBLE : 0);
    cmd->short_slot
    = htole32((ic->ic_flags & IEEE80211_F_SHSLOT)
              ? IWX_MAC_FLG_SHORT_SLOT : 0);
    
    for (i = 0; i < EDCA_NUM_AC; i++) {
        struct ieee80211_edca_ac_params *ac = &ic->ic_edca_ac[i];
        int txf = iwx_ac_to_tx_fifo[i];
        uint8_t ucode_ac = iwx_mvm_mac80211_ac_to_ucode_ac((enum ieee80211_edca_ac)i);
        
        cmd->ac[ucode_ac].cw_min = htole16(IWX_EXP2(ac->ac_ecwmin));
        cmd->ac[ucode_ac].cw_max = htole16(IWX_EXP2(ac->ac_ecwmax));
        cmd->ac[ucode_ac].aifsn = ac->ac_aifsn;
        cmd->ac[ucode_ac].fifos_mask = (1 << txf);
        cmd->ac[ucode_ac].edca_txop = htole16(ac->ac_txoplimit * 32);
    }
    if (ni->ni_flags & IEEE80211_NODE_QOS)
        cmd->qos_flags |= htole32(IWX_MAC_QOS_FLG_UPDATE_EDCA);
    
    if (ni->ni_flags & IEEE80211_NODE_HT) {
        enum ieee80211_htprot htprot =
        (enum ieee80211_htprot)(ni->ni_htop1 & IEEE80211_HTOP1_PROT_MASK);
        
        /* The fw does not distinguish between ht and fat */
        uint32_t ht_flag = IWX_MAC_PROT_FLG_HT_PROT | IWX_MAC_PROT_FLG_FAT_PROT;
        
        /*
         * See section 9.23.3.1 of IEEE 80211-2012.
         * Nongreenfield HT STAs Present is not supported.
         */
        switch (htprot) {
            case IEEE80211_HTPROT_NONE:
                break;
            case IEEE80211_HTPROT_NONMEMBER:
            case IEEE80211_HTPROT_NONHT_MIXED:
                cmd->protection_flags = htole32(ht_flag);
                break;
            case IEEE80211_HTPROT_20MHZ:
                /* Protect when channel wider than 20MHz */
                if (ni->ni_chw > IEEE80211_CHAN_WIDTH_20)
                    cmd->protection_flags = htole32(ht_flag);
                break;
            default:
                XYLog("Illegal protection mode %d\n", htprot);
                break;
        }
        
        cmd->qos_flags |= htole32(IWX_MAC_QOS_FLG_TGN);
    }
    if (ic->ic_flags & IEEE80211_F_USEPROT)
        cmd->protection_flags |= htole32(IWX_MAC_PROT_FLG_TGG_PROTECT);
    
    cmd->filter_flags = htole32(IWX_MAC_FILTER_ACCEPT_GRP);
#undef IWX_EXP2
}

void ItlIwx::
iwx_mac_ctxt_cmd_fill_sta(struct iwx_softc *sc, struct iwx_node *in,
                          struct iwx_mac_data_sta *sta, int assoc)
{
    struct ieee80211_node *ni = &in->in_ni;
    uint32_t dtim_off;
    uint64_t tsf;
    
    dtim_off = ni->ni_dtimcount * ni->ni_intval * IEEE80211_DUR_TU;
    memcpy(&tsf, ni->ni_tstamp, sizeof(tsf));
    tsf = letoh64(tsf);
    
    sta->is_assoc = htole32(assoc);
    sta->dtim_time = htole32(ni->ni_rstamp + dtim_off);
    sta->dtim_tsf = htole64(tsf + dtim_off);
    sta->bi = htole32(ni->ni_intval);
    sta->bi_reciprocal = htole32(iwx_reciprocal(ni->ni_intval));
    sta->dtim_interval = htole32(ni->ni_intval * ni->ni_dtimperiod);
    sta->dtim_reciprocal = htole32(iwx_reciprocal(sta->dtim_interval));
    sta->listen_interval = htole32(10);
    sta->assoc_id = htole32(ni->ni_associd);
    sta->assoc_beacon_arrive_time = htole32(ni->ni_rstamp);
}

int ItlIwx::
iwx_mac_ctxt_cmd(struct iwx_softc *sc, struct iwx_node *in, uint32_t action,
                 int assoc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = &in->in_ni;
    struct iwx_mac_ctx_cmd cmd;
    int active = (sc->sc_flags & IWX_FLAG_MAC_ACTIVE);
    
    if (action == IWX_FW_CTXT_ACTION_ADD && active) {
        XYLog("MAC already added\n");
        return 0;
    }
    if (action == IWX_FW_CTXT_ACTION_REMOVE && !active) {
        XYLog("MAC already removed\n");
        return 0;
    }
    
    memset(&cmd, 0, sizeof(cmd));
    
    iwx_mac_ctxt_cmd_common(sc, in, &cmd, action);

    if (action == IWX_FW_CTXT_ACTION_REMOVE) {
        return iwx_send_cmd_pdu(sc, IWX_MAC_CONTEXT_CMD, 0,
                                sizeof(cmd), &cmd);
    }

    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        cmd.filter_flags |= htole32(IWX_MAC_FILTER_IN_PROMISC |
                                    IWX_MAC_FILTER_IN_CONTROL_AND_MGMT |
                                    IWX_MAC_FILTER_ACCEPT_GRP |
                                    IWX_MAC_FILTER_IN_BEACON |
                                    IWX_MAC_FILTER_IN_PROBE_REQUEST |
                                    IWX_MAC_FILTER_IN_CRC32);
        if (awdlBaFilterOff)
            cmd.filter_flags &= ~htole32(IWX_MAC_FILTER_IN_PROMISC);
        if (awdlBaMacType == IWX_FW_MAC_TYPE_IBSS) {
            // No beacon template is ever sent, so this context shouldn't beacon.
            cmd.ibss.bi = htole32(100);
            cmd.ibss.bi_reciprocal = htole32(iwx_reciprocal(100));
        } else if (awdlBaMacType) {
            // Associated, so the firmware treats the peer's sessions as live. No AP exists
            // here, so there are no beacons, and nothing in monitor mode acts on missing them.
            cmd.sta.is_assoc = htole32(action != IWX_FW_CTXT_ACTION_ADD);
            cmd.sta.bi = htole32(100);
            cmd.sta.bi_reciprocal = htole32(iwx_reciprocal(100));
            cmd.sta.dtim_interval = htole32(100);
            cmd.sta.dtim_reciprocal = htole32(iwx_reciprocal(100));
            cmd.sta.listen_interval = htole32(10);
            cmd.sta.assoc_id = htole32(1);
        }
    } else if (!assoc || !ni->ni_associd || !ni->ni_dtimperiod)
    /*
     * Allow beacons to pass through as long as we are not
     * associated or we do not have dtim period information.
     */
        cmd.filter_flags |= htole32(IWX_MAC_FILTER_IN_BEACON);
    else
        iwx_mac_ctxt_cmd_fill_sta(sc, in, &cmd.sta, assoc);
    
    if (ni->ni_flags & IEEE80211_NODE_HE) {
        cmd.filter_flags |= htole32(IWX_MAC_FILTER_IN_11AX);
    }
    
    return iwx_send_cmd_pdu(sc, IWX_MAC_CONTEXT_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_clear_statistics(struct iwx_softc *sc)
{
    struct iwx_statistics_cmd scmd = {
        .flags = htole32(IWX_STATISTICS_FLG_CLEAR)
    };
    struct iwx_host_cmd cmd = {
        .id = IWX_STATISTICS_CMD,
        .len[0] = sizeof(scmd),
        .data[0] = &scmd,
        .flags = IWX_CMD_WANT_RESP,
        .resp_pkt_len = sizeof(struct iwx_notif_statistics),
    };
    int err;
    
    err = iwx_send_cmd(sc, &cmd);
    if (err)
        return err;
    
    iwx_free_resp(sc, &cmd);
    return 0;
}

int ItlIwx::
iwx_update_quotas(struct iwx_softc *sc, struct iwx_node *in, int running)
{
    struct iwx_time_quota_cmd cmd;
    int i, idx, num_active_macs, quota, quota_rem;
    int colors[IWX_MAX_BINDINGS] = { -1, -1, -1, -1, };
    int n_ifs[IWX_MAX_BINDINGS] = {0, };
    uint16_t id;
    
    memset(&cmd, 0, sizeof(cmd));
    
    /* currently, PHY ID == binding ID */
    if (in && in->in_phyctxt) {
        id = in->in_phyctxt->id;
        KASSERT(id < IWX_MAX_BINDINGS, "id < IWX_MAX_BINDINGS");
        colors[id] = in->in_phyctxt->color;
        if (running)
            n_ifs[id] = 1;
    }
    
    /*
     * The FW's scheduling session consists of
     * IWX_MAX_QUOTA fragments. Divide these fragments
     * equally between all the bindings that require quota
     */
    num_active_macs = 0;
    for (i = 0; i < IWX_MAX_BINDINGS; i++) {
        cmd.quotas[i].id_and_color = htole32(IWX_FW_CTXT_INVALID);
        num_active_macs += n_ifs[i];
    }
    
    quota = 0;
    quota_rem = 0;
    if (num_active_macs) {
        quota = IWX_MAX_QUOTA / num_active_macs;
        quota_rem = IWX_MAX_QUOTA % num_active_macs;
    }
    
    for (idx = 0, i = 0; i < IWX_MAX_BINDINGS; i++) {
        if (colors[i] < 0)
            continue;
        
        cmd.quotas[idx].id_and_color =
        htole32(IWX_FW_CMD_ID_AND_COLOR(i, colors[i]));
        
        if (n_ifs[i] <= 0) {
            cmd.quotas[idx].quota = htole32(0);
            cmd.quotas[idx].max_duration = htole32(0);
        } else {
            cmd.quotas[idx].quota = htole32(quota * n_ifs[i]);
            cmd.quotas[idx].max_duration = htole32(0);
        }
        idx++;
    }
    
    /* Give the remainder of the session to the first binding */
    cmd.quotas[0].quota = htole32(le32toh(cmd.quotas[0].quota) + quota_rem);
    
    return iwx_send_cmd_pdu(sc, IWX_TIME_QUOTA_CMD, 0,
                            sizeof(cmd), &cmd);
}

void ItlIwx::
iwx_add_task(struct iwx_softc *sc, struct taskq *taskq, struct task *task)
{
    XYLog("%s %s\n", __FUNCTION__, task->name);
    int s = splnet();
    
    if (sc->sc_flags & IWX_FLAG_SHUTDOWN) {
        XYLog("%s %s sc->sc_flags & IWX_FLAG_SHUTDOWN\n", __FUNCTION__, task->name);
        splx(s);
        return;
    }
    
    //    refcnt_take(&sc->task_refs);
    if (!task_add(taskq, task)) {
        //        refcnt_rele_wake(&sc->task_refs);
    }
    splx(s);
}

void ItlIwx::
iwx_del_task(struct iwx_softc *sc, struct taskq *taskq, struct task *task)
{
    XYLog("%s %s\n", __FUNCTION__, task->name);
    if (task_del(taskq, task)) {
        //        refcnt_rele(&sc->task_refs);
    }
}

int ItlIwx::
iwx_scan(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = IC2IFP(ic);
    int err;
    
    if (sc->sc_flags & IWX_FLAG_BGSCAN) {
        err = iwx_scan_abort(sc);
        if (err) {
            XYLog("%s: could not abort background scan\n",
                  DEVNAME(sc));
            return err;
        }
    }
    // A foreground scan replaces any background scan, so net80211's flag goes too. Aborting the firmware's
    // background scan clears only the driver's own flags, and if this scan then finds nothing to join (after a
    // disconnect, say), ieee80211_end_scan just scans again without clearing IEEE80211_F_BGSCAN. The flag then
    // stayed set until the next firmware stop, and the WCL scan path refused every macOS scan as busy, so Wi-Fi
    // never reconnected until it was turned off and on.
    ic->ic_flags &= ~IEEE80211_F_BGSCAN;
    
    err = iwx_umac_scan(sc, 0);
    if (err) {
        XYLog("%s: could not initiate scan\n", DEVNAME(sc));
        return err;
    }
    
    /*
     * The current mode might have been fixed during association.
     * Ensure all channels get scanned.
     */
    if (IFM_MODE(ic->ic_media.ifm_cur->ifm_media) == IFM_AUTO)
        ieee80211_setmode(ic, IEEE80211_MODE_AUTO);
    
    sc->sc_flags |= IWX_FLAG_SCANNING;
    if (ifp->if_flags & IFF_DEBUG)
        XYLog("%s: %s -> %s\n", ifp->if_xname,
              ieee80211_state_name[ic->ic_state],
              ieee80211_state_name[IEEE80211_S_SCAN]);
    if ((sc->sc_flags & IWX_FLAG_BGSCAN) == 0) {
        ieee80211_set_link_state(ic, LINK_STATE_DOWN);
        ieee80211_node_cleanup(ic, ic->ic_bss);
    }
    ic->ic_state = IEEE80211_S_SCAN;
    getMainCommandGate()->commandWakeup(&ic->ic_state); /* wake iwx_init() */
    
    return 0;
}

int ItlIwx::
iwx_bgscan(struct ieee80211com *ic)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)IC2IFP(ic)->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    int err;
    
    if (sc->sc_flags & IWX_FLAG_SCANNING)
        return 0;
    
    err = that->iwx_umac_scan(sc, 1);
    if (err) {
        XYLog("%s: could not initiate scan\n", DEVNAME(sc));
        return err;
    }
    
    sc->sc_flags |= IWX_FLAG_BGSCAN;
    return 0;
}

int ItlIwx::
iwx_umac_scan_abort(struct iwx_softc *sc)
{
    struct iwx_umac_scan_abort cmd = { 0 };
    
    return iwx_send_cmd_pdu(sc,
                            IWX_WIDE_ID(IWX_LONG_GROUP, IWX_SCAN_ABORT_UMAC),
                            0, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_scan_abort(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    int err;
    
    err = iwx_umac_scan_abort(sc);
    if (err == 0)
        sc->sc_flags &= ~(IWX_FLAG_SCANNING | IWX_FLAG_BGSCAN);
    return err;
}

int ItlIwx::
iwx_enable_mgmt_queue(struct iwx_softc *sc)
{
    int err;
    int cmdver;

    cmdver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP, IWX_ADD_STA);
    if (cmdver != IWX_FW_CMD_VER_UNKNOWN && cmdver >= 12)
        sc->first_data_qid = IWX_QID_MGMT - 1;
    else
        sc->first_data_qid = IWX_QID_MGMT;
    err = iwx_enable_txq(sc, IWX_STATION_ID,
                         sc->first_data_qid, IWX_MGMT_TID,
                         sc->txq[sc->first_data_qid].ring_count);
    if (err) {
        XYLog("%s: could not enable MGMT Tx queue %d (error %d)\n",
              DEVNAME(sc), sc->first_data_qid, err);
        return err;
    }
    
    return 0;
}

int ItlIwx::
iwx_rs_rval2idx(uint8_t rval)
{
   /* Firmware expects indices which match our 11g rate set. */
   const struct ieee80211_rateset *rs = &ieee80211_std_rateset_11g;
   int i;

   for (i = 0; i < rs->rs_nrates; i++) {
       if ((rs->rs_rates[i] & IEEE80211_RATE_VAL) == rval)
           return i;
   }

   return -1;
}

uint16_t ItlIwx::
iwx_rs_ht_rates(struct iwx_softc *sc, struct ieee80211_node *ni, int rsidx)
{
   struct ieee80211com *ic = &sc->sc_ic;
   const struct ieee80211_ht_rateset *rs;
   uint16_t htrates = 0;
   int mcs;

   rs = &ieee80211_std_ratesets_11n[rsidx];
   for (mcs = rs->min_mcs; mcs <= rs->max_mcs; mcs++) {
       if (!isset(ni->ni_rxmcs, mcs) ||
           !isset(ic->ic_sup_mcs, mcs))
           continue;
       htrates |= (1 << (mcs - rs->min_mcs));
   }

   return htrates;
}

static uint8_t iwx_rs_fw_bw_from_sta_bw(uint8_t bw)
{
    uint8_t fw_bw;
    switch (bw) {
        case IEEE80211_CHAN_WIDTH_20:
            fw_bw = IWX_TLC_MNG_CH_WIDTH_20MHZ;
            break;
        case IEEE80211_CHAN_WIDTH_40:
            fw_bw = IWX_TLC_MNG_CH_WIDTH_40MHZ;
            break;
        case IEEE80211_CHAN_WIDTH_80:
            fw_bw = IWX_TLC_MNG_CH_WIDTH_80MHZ;
            break;
        case IEEE80211_CHAN_WIDTH_80P80:
        case IEEE80211_CHAN_WIDTH_160:
            fw_bw = IWX_TLC_MNG_CH_WIDTH_160MHZ;
            break;
        default:
            fw_bw = IWX_TLC_MNG_CH_WIDTH_20MHZ;
            break;
    }
    return fw_bw;
}

uint16_t ItlIwx::
iwx_rs_fw_get_config_flags(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    uint16_t flags = 0;
    
    if (ic->ic_state < IEEE80211_S_ASSOC) {
        return flags;
    }
    
    if (iwx_num_of_ant(iwx_fw_valid_tx_ant(sc)) > 1) {
        if (ni->ni_flags & IEEE80211_NODE_HE) {
            if (ni->ni_he_cap_elem.phy_cap_info[2] & IEEE80211_HE_PHY_CAP2_STBC_RX_UNDER_80MHZ)
                flags |= IWX_TLC_MNG_CFG_FLAGS_STBC_MSK;
        } else if (ni->ni_vhtcaps & IEEE80211_VHTCAP_RXSTBC_MASK)
            flags |= IWX_TLC_MNG_CFG_FLAGS_STBC_MSK;
        else if (ni->ni_htcaps & IEEE80211_HTCAP_RXSTBC_MASK)
            flags |= IWX_TLC_MNG_CFG_FLAGS_STBC_MSK;
    }
    
    if (((ni->ni_htcaps & IEEE80211_HTCAP_LDPC) ||
         ((ic->ic_flags & IEEE80211_F_VHTON) && (ni->ni_vhtcaps & IEEE80211_VHTCAP_RXLDPC))))
        flags |= IWX_TLC_MNG_CFG_FLAGS_LDPC_MSK;
    
    /* consider LDPC support in case of HE */
    if ((ni->ni_flags & IEEE80211_NODE_HE) &&
        (ni->ni_he_cap_elem.phy_cap_info[1] &
        IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD))
        flags |= IWX_TLC_MNG_CFG_FLAGS_LDPC_MSK;
    
    if ((ni->ni_flags & IEEE80211_NODE_HE) &&
        !(ni->ni_he_cap_elem.phy_cap_info[1] &
         IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD))
        flags &= ~IWX_TLC_MNG_CFG_FLAGS_LDPC_MSK;

    if ((ni->ni_flags & IEEE80211_NODE_HE) &&
        (ic->ic_he_cap_elem.phy_cap_info[3] & IEEE80211_HE_PHY_CAP3_DCM_MAX_CONST_TX_MASK) &&
        (ni->ni_he_cap_elem.phy_cap_info[3] &
         IEEE80211_HE_PHY_CAP3_DCM_MAX_CONST_RX_MASK))
        flags |= IWX_TLC_MNG_CFG_FLAGS_HE_DCM_NSS_1_MSK;
    
    return flags;
}

static
int rs_fw_vht_highest_rx_mcs_index(struct iwx_softc *sc,
                   int nss)
{
    uint16_t rx_mcs = le16toh(sc->sc_ic.ic_bss->ni_vht_mcsinfo.rx_mcs_map) &
        (0x3 << (2 * (nss - 1)));
    rx_mcs >>= (2 * (nss - 1));

    switch (rx_mcs) {
    case IEEE80211_VHT_MCS_SUPPORT_0_7:
        return IWX_TLC_MNG_HT_RATE_MCS7;
    case IEEE80211_VHT_MCS_SUPPORT_0_8:
        return IWX_TLC_MNG_HT_RATE_MCS8;
    case IEEE80211_VHT_MCS_SUPPORT_0_9:
        return IWX_TLC_MNG_HT_RATE_MCS9;
    default:
        WARN_ON_ONCE(1);
        break;
    }

    return 0;
}

static void
iwx_rs_fw_vht_set_enabled_rates(struct iwx_softc *sc,
                struct iwx_tlc_config_cmd_v4 *cmd)
{
    uint16_t supp;
    int i, highest_mcs;
    struct ieee80211com *ic = &sc->sc_ic;

    for (i = 0; i < IWX_TLC_NSS_MAX && i < ic->ic_bss->ni_rx_nss; i++) {
        highest_mcs = rs_fw_vht_highest_rx_mcs_index(sc, i + 1);
        if (!highest_mcs)
            continue;

        supp = (1 << (highest_mcs + 1)) - 1;
        if (ic->ic_bss->ni_chw == IEEE80211_CHAN_WIDTH_20)
            supp &= ~(1 << IWX_TLC_MNG_HT_RATE_MCS9);

        cmd->ht_rates[i][IWX_TLC_MCS_PER_BW_80] = htole16(supp);
        if (ic->ic_bss->ni_chw == IEEE80211_CHAN_WIDTH_80P80 || ic->ic_bss->ni_chw == IEEE80211_CHAN_WIDTH_160)
            cmd->ht_rates[i][1] = cmd->ht_rates[i][0];
    }
}

static uint16_t rs_fw_he_ieee80211_mcs_to_rs_mcs(uint16_t mcs)
{
    switch (mcs) {
    case IEEE80211_HE_MCS_SUPPORT_0_7:
        return BIT(IWX_TLC_MNG_HT_RATE_MCS7 + 1) - 1;
    case IEEE80211_HE_MCS_SUPPORT_0_9:
        return BIT(IWX_TLC_MNG_HT_RATE_MCS9 + 1) - 1;
    case IEEE80211_HE_MCS_SUPPORT_0_11:
        return BIT(IWX_TLC_MNG_HT_RATE_MCS11 + 1) - 1;
    case IEEE80211_HE_MCS_NOT_SUPPORTED:
        return 0;
    }

    XYLog("invalid HE MCS %d\n", mcs);
    return 0;
}

static uint8_t iwx_rs_fw_set_active_chains(uint8_t chains)
{
    uint8_t fw_chains = 0;

    if (chains & IWX_ANT_A)
        fw_chains |= IWX_TLC_MNG_CHAIN_A_MSK;
    if (chains & IWX_ANT_B)
        fw_chains |= IWX_TLC_MNG_CHAIN_B_MSK;

    return fw_chains;
}

static void
iwx_rs_fw_he_set_enabled_rates(struct iwx_softc *sc,
    struct iwx_tlc_config_cmd_v4 *cmd)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    uint16_t maps[2] = {
        ieee80211_he_mcs_intersection(le16toh(ni->ni_he_mcs_nss_supp.rx_mcs_80),
            le16toh(ic->ic_he_mcs_nss_supp.tx_mcs_80)),
        ieee80211_he_mcs_intersection(le16toh(ni->ni_he_mcs_nss_supp.rx_mcs_160),
            le16toh(ic->ic_he_mcs_nss_supp.tx_mcs_160))
    };
    if (ni->ni_chw != IEEE80211_CHAN_WIDTH_160)
        maps[IWX_TLC_MCS_PER_BW_160] = 0xffff;
    bool ldpc = ni->ni_he_cap_elem.phy_cap_info[1] & IEEE80211_HE_PHY_CAP1_LDPC_CODING_IN_PAYLOAD;
    for (unsigned ss = 0; ss < IWX_TLC_NSS_MAX; ss++) {
        for (unsigned bw = 0; bw < 2; bw++) {
            uint16_t mask = ss < ni->ni_rx_nss ?
                rs_fw_he_ieee80211_mcs_to_rs_mcs((maps[bw] >> (2 * ss)) & 3) : 0;
            if (!ldpc)
                mask &= 0x03ff; /* HE MCS10/11 requires LDPC. */
            cmd->ht_rates[ss][bw] = htole16(mask);
        }
    }
}

static uint8_t
iwx_he_ppe_value(const uint8_t *ppe, unsigned bit)
{
    unsigned value = ppe[bit / 8] >> (bit % 8);
    if (bit % 8 > 5)
        value |= unsigned(ppe[bit / 8 + 1]) << (8 - bit % 8);
    return value & 7;
}

static void
iwx_build_he_sta(const struct ieee80211_node *ni, struct iwx_he_sta_context_cmd *cmd)
{
    memset(cmd, 0, sizeof(*cmd));
    cmd->sta_id = IWX_STATION_ID;
    cmd->tid_limit = 1; /* single TID aggregation */
    uint32_t flags = IWX_HE_NIC_NOT_ACK_ENABLED;
    uint32_t op = ni->ni_he_oper_params;
    cmd->bss_color = (op >> 24) & 0x3f;
    if (op & IEEE80211_HE_OPERATION_BSS_COLOR_DISABLED)
        flags |= IWX_HE_BSS_COLOR_DIS;
    if (op & IEEE80211_HE_OPERATION_PARTIAL_BSS_COLOR)
        flags |= IWX_HE_PARTIAL_BSS_COLOR;
    cmd->htc_trig_based_pkt_ext = op & 7;
    cmd->frame_time_rts_th = htole16((op >> 4) & 0x3ff);
    const uint8_t *mac = ni->ni_he_cap_elem.mac_cap_info;
    uint32_t htc = (mac[0] & IEEE80211_HE_MAC_CAP0_HTC_HE) ? 1 : 0;
    if (mac[2] & IEEE80211_HE_MAC_CAP2_BSR) htc |= 1U << 4;
    if (mac[3] & IEEE80211_HE_MAC_CAP3_OMI_CONTROL) htc |= 1U << 5;
    if (mac[4] & IEEE80211_HE_MAC_CAP4_BQR) htc |= 1U << 6;
    cmd->htc_flags = htole32(htc);
    if (mac[2] & IEEE80211_HE_MAC_CAP2_32BIT_BA_BITMAP) flags |= IWX_HE_32BIT_BA_BITMAP;
    if (mac[2] & IEEE80211_HE_MAC_CAP2_ACK_EN) flags |= IWX_HE_ACK_ENABLED;
    memset(cmd->pkt_ext, 7, sizeof(cmd->pkt_ext));
    if (ni->ni_he_cap_elem.phy_cap_info[6] & IEEE80211_HE_PHY_CAP6_PPE_THRESHOLD_PRESENT) {
        unsigned nss = (ni->ni_ppe_thres[0] & 7) + 1;
        unsigned mask = (ni->ni_ppe_thres[0] >> 3) & 15;
        unsigned bit = 7;
        for (unsigned ss = 0; ss < nss && ss < 2; ss++) {
            for (unsigned bw = 0; bw < 4; bw++) {
                if (!(mask & (1U << bw))) continue;
                cmd->pkt_ext[ss][bw][1] = iwx_he_ppe_value(ni->ni_ppe_thres, bit);
                cmd->pkt_ext[ss][bw][0] = iwx_he_ppe_value(ni->ni_ppe_thres, bit + 3);
                bit += 6;
            }
        }
        flags |= IWX_HE_PACKET_EXT;
    } else {
        unsigned padding = (ni->ni_he_cap_elem.phy_cap_info[9] >> 6) & 3;
        if (padding != 3) {
            for (unsigned ss = 0; ss < 2; ss++)
                for (unsigned bw = 0; bw < 4; bw++) {
                    cmd->pkt_ext[ss][bw][0] = padding == 1 ? 0 : 7;
                    cmd->pkt_ext[ss][bw][1] = padding == 2 ? 0 : 7;
                }
            flags |= IWX_HE_PACKET_EXT;
        }
    }
    if (ni->ni_flags & IEEE80211_NODE_HE_MU_EDCA) {
        flags |= IWX_HE_MU_EDCA_CW;
        for (unsigned ac = 0; ac < 4; ac++) {
            const uint8_t *rec = ni->ni_he_mu_edca + 1 + 3 * ac;
            unsigned fw_ac = iwx_mvm_mac80211_ac_to_ucode_ac((enum ieee80211_edca_ac)ac);
            cmd->trig_based_txf[fw_ac].cwmin = htole16(rec[1] & 15);
            cmd->trig_based_txf[fw_ac].cwmax = htole16(rec[1] >> 4);
            cmd->trig_based_txf[fw_ac].aifsn = htole16(rec[0] & 15);
            cmd->trig_based_txf[fw_ac].mu_time = htole16(rec[2]);
        }
    }
    cmd->flags = htole32(flags);
}

int ItlIwx::
iwx_config_he_sta(struct iwx_softc *sc, struct ieee80211_node *ni)
{
    if (!(ni->ni_flags & IEEE80211_NODE_HE))
        return 0;
    if ((ni->ni_flags & (IEEE80211_NODE_HECAP | IEEE80211_NODE_HEOP)) !=
        (IEEE80211_NODE_HECAP | IEEE80211_NODE_HEOP))
        return EINVAL;
    struct iwx_he_sta_context_cmd cmd;
    static_assert(sizeof(cmd) == 88, "HE context v2 ABI");
    static_assert(__offsetof(struct iwx_he_sta_context_cmd, max_bssid_indicator) == 80, "HE context v1 ABI");
    uint8_t ver = iwx_lookup_cmd_ver(sc, IWX_DATA_PATH_GROUP, IWX_STA_HE_CTXT_CMD);
    if (ver != 1 && ver != 2)
        return EOPNOTSUPP;
    iwx_build_he_sta(ni, &cmd);
    int err = iwx_send_cmd_pdu(sc, iwx_cmd_id(IWX_STA_HE_CTXT_CMD, IWX_DATA_PATH_GROUP, 0),
        0, ver == 1 ? 80 : sizeof(cmd), &cmd);
    XYLog("HE context: version=%u color=%u flags=%08x result=%d\n",
        ver, cmd.bss_color, le32toh(cmd.flags), err);
    return err;
}

int ItlIwx::
iwx_rs_init(struct iwx_softc *sc, struct iwx_node *in, bool update)
{
    struct ieee80211_node *ni = &in->in_ni;
    struct ieee80211_rateset *rs = &ni->ni_rates;
    struct iwx_tlc_config_cmd_v4 cfg_cmd;
    uint32_t cmd_id;
    int i;
    uint16_t cmd_size;
    uint8_t cmdver;

    memset(&cfg_cmd, 0, sizeof(cfg_cmd));

    for (i = 0; i < rs->rs_nrates; i++) {
        uint8_t rval = rs->rs_rates[i] & IEEE80211_RATE_VAL;
        int idx = iwx_rs_rval2idx(rval);
        if (idx == -1)
            return EINVAL;
        cfg_cmd.non_ht_rates |= (1 << idx);
    }
    if (ni->ni_flags & IEEE80211_NODE_HE) {
        cfg_cmd.mode = IWX_TLC_MNG_MODE_HE;
        iwx_rs_fw_he_set_enabled_rates(sc, &cfg_cmd);
    } else if (ni->ni_flags & IEEE80211_NODE_VHT) {
        cfg_cmd.mode = IWX_TLC_MNG_MODE_VHT;
        iwx_rs_fw_vht_set_enabled_rates(sc, &cfg_cmd);
    } else if (ni->ni_flags & IEEE80211_NODE_HT) {
        cfg_cmd.mode = IWX_TLC_MNG_MODE_HT;
        cfg_cmd.ht_rates[IWX_TLC_NSS_1][IWX_TLC_MCS_PER_BW_80] = htole16(iwx_rs_ht_rates(sc, ni, ni->ni_chw == IEEE80211_CHAN_WIDTH_40 ? IEEE80211_HT_RATESET_CBW40_SISO : IEEE80211_HT_RATESET_SISO));
        if (ni->ni_rx_nss > 1)
            cfg_cmd.ht_rates[IWX_TLC_NSS_2][IWX_TLC_MCS_PER_BW_80] = htole16(iwx_rs_ht_rates(sc, ni, ni->ni_chw == IEEE80211_CHAN_WIDTH_40 ? IEEE80211_HT_RATESET_CBW40_MIMO2 : IEEE80211_HT_RATESET_MIMO2));
    } else
        cfg_cmd.mode = IWX_TLC_MNG_MODE_NON_HT;

    if (ni->ni_flags & IEEE80211_NODE_HE)
        XYLog("HE TLC: mode=%u width=%s nss=%u rates80=%04x/%04x rates160=%04x/%04x\n",
            cfg_cmd.mode, ieee80211_chan_width_name[ni->ni_chw], ni->ni_rx_nss,
            le16toh(cfg_cmd.ht_rates[0][0]), le16toh(cfg_cmd.ht_rates[1][0]),
            le16toh(cfg_cmd.ht_rates[0][1]), le16toh(cfg_cmd.ht_rates[1][1]));
    if (awdlBaTlc) {
        // The peer has no node here. High HT rates only: it leaves the channel often, and rate
        // control would otherwise take that for a bad link and drop far down.
        cfg_cmd.mode = IWX_TLC_MNG_MODE_HT;
        cfg_cmd.ht_rates[IWX_TLC_NSS_1][IWX_TLC_MCS_PER_BW_80] = htole16(0xf0);
        cfg_cmd.ht_rates[IWX_TLC_NSS_2][IWX_TLC_MCS_PER_BW_80] = htole16(0xf0);
        cfg_cmd.sta_id = kAwdlBaStationId;
        cfg_cmd.max_ch_width = IWX_TLC_MNG_CH_WIDTH_20MHZ;
        // The listener's peer: legacy fallback rates from the listener's band, not the BSS's.
        if (awdlCoexOwnChan)
            cfg_cmd.non_ht_rates = htole16(IEEE80211_IS_CHAN_2GHZ(awdlCoexOwnChan) ? 0xfff : 0xff0);
        if (awdlBaTx80Active) {
            // The same high-rates-only rule, at VHT: MCS 4 to 9.
            cfg_cmd.mode = IWX_TLC_MNG_MODE_VHT;
            const uint16_t vhtMask = uint16_t(0x3ffU & ~((1U << awdlBaTxMinMcs) - 1U));
            cfg_cmd.ht_rates[IWX_TLC_NSS_1][IWX_TLC_MCS_PER_BW_80] = htole16(vhtMask);
            cfg_cmd.ht_rates[IWX_TLC_NSS_2][IWX_TLC_MCS_PER_BW_80] = htole16(vhtMask);
            cfg_cmd.max_ch_width = IWX_TLC_MNG_CH_WIDTH_80MHZ;
        }
        cfg_cmd.chains = iwx_rs_fw_set_active_chains(iwx_fw_valid_tx_ant(sc));
        cfg_cmd.flags = iwx_rs_fw_get_config_flags(sc);
        cfg_cmd.sgi_ch_width_supp = (1 << IWX_TLC_MNG_CH_WIDTH_20MHZ);
        goto send;
    }
    cfg_cmd.sta_id = IWX_STATION_ID;
    cfg_cmd.max_ch_width = update ? iwx_rs_fw_bw_from_sta_bw(ni->ni_chw) : IWX_RATE_MCS_CHAN_WIDTH_20;
    cfg_cmd.chains = iwx_rs_fw_set_active_chains(iwx_fw_valid_tx_ant(sc));
    cfg_cmd.flags = iwx_rs_fw_get_config_flags(sc);
    if ((ni->ni_flags & IEEE80211_NODE_HE) == 0) {
        if (ieee80211_node_supports_ht_sgi20(ni))
            cfg_cmd.sgi_ch_width_supp = (1 << IWX_TLC_MNG_CH_WIDTH_20MHZ);

        if (ieee80211_node_supports_ht_sgi40(ni))
            cfg_cmd.sgi_ch_width_supp |= (1 << IWX_TLC_MNG_CH_WIDTH_40MHZ);
        
        if (ieee80211_node_supports_vht_sgi80(ni)) {
            cfg_cmd.sgi_ch_width_supp |= (1 << IWX_TLC_MNG_CH_WIDTH_80MHZ);
        }
        
        if (ieee80211_node_supports_vht_sgi160(ni)) {
            cfg_cmd.sgi_ch_width_supp |= (1 << IWX_TLC_MNG_CH_WIDTH_160MHZ);
        }
    }

send:
    cmd_id = iwx_cmd_id(IWX_TLC_MNG_CONFIG_CMD, IWX_DATA_PATH_GROUP, 0);
    cmdver = iwx_lookup_cmd_ver(sc, IWX_DATA_PATH_GROUP, IWX_TLC_MNG_CONFIG_CMD);
    XYLog("%s cmdver %d\n", __FUNCTION__, cmdver);
    if (cmdver == 4) {
        return iwx_send_cmd_pdu(sc, cmd_id, IWX_CMD_ASYNC,
                                sizeof(cfg_cmd), &cfg_cmd);
    } else if (cmdver < 4 || cmdver == IWX_FW_CMD_VER_UNKNOWN) {
        struct iwl_tlc_config_cmd_v3 cfg_cmd_v3 = {
            .sta_id = cfg_cmd.sta_id,
            .max_ch_width = cfg_cmd.max_ch_width,
            .mode = cfg_cmd.mode,
            .chains = cfg_cmd.chains,
            .amsdu = !!cfg_cmd.max_mpdu_len,
            .flags = cfg_cmd.flags,
            .non_ht_rates = cfg_cmd.non_ht_rates,
            .ht_rates[0][0] = cfg_cmd.ht_rates[0][0],
            .ht_rates[0][1] = cfg_cmd.ht_rates[0][1],
            .ht_rates[1][0] = cfg_cmd.ht_rates[1][0],
            .ht_rates[1][1] = cfg_cmd.ht_rates[1][1],
            .sgi_ch_width_supp = cfg_cmd.sgi_ch_width_supp,
            .max_mpdu_len = cfg_cmd.max_mpdu_len,
        };
        
        cmd_size = sizeof(cfg_cmd_v3);
        
        /* In old versions of the API the struct is 4 bytes smaller */
        if (cmdver == IWX_FW_CMD_VER_UNKNOWN || cmdver < 3)
            cmd_size -= 4;
        
        return iwx_send_cmd_pdu(sc, cmd_id, IWX_CMD_ASYNC, cmd_size,
                                &cfg_cmd_v3);
    } else {
        return -EINVAL;
    }
}

static uint32_t iwx_new_rate_from_v1(uint32_t rate_v1)
{
    uint32_t rate_v2 = 0;
    uint32_t dup = 0;
    
    if (rate_v1 == 0)
        return rate_v1;
    /* convert rate */
    if (rate_v1 & IWX_RATE_MCS_HT_MSK_V1) {
        uint32_t nss = 0;
        
        rate_v2 |= IWX_RATE_MCS_HT_MSK;
        rate_v2 |=
        rate_v1 & IWX_RATE_HT_MCS_RATE_CODE_MSK_V1;
        nss = (rate_v1 & IWX_RATE_HT_MCS_MIMO2_MSK) >>
        IWX_RATE_HT_MCS_NSS_POS_V1;
        rate_v2 |= nss << IWX_RATE_MCS_NSS_POS;
    } else if (rate_v1 & IWX_RATE_MCS_VHT_MSK_V1 ||
               rate_v1 & IWX_RATE_MCS_HE_MSK_V1) {
        rate_v2 |= rate_v1 & IWX_RATE_VHT_MCS_RATE_CODE_MSK;
        
        rate_v2 |= rate_v1 & IWX_RATE_VHT_MCS_MIMO2_MSK;
        
        if (rate_v1 & IWX_RATE_MCS_HE_MSK_V1) {
            uint32_t he_type_bits = rate_v1 & IWX_RATE_MCS_HE_TYPE_MSK_V1;
            uint32_t he_type = he_type_bits >> IWX_RATE_MCS_HE_TYPE_POS_V1;
            uint32_t he_106t = (rate_v1 & IWX_RATE_MCS_HE_106T_MSK_V1) >>
            IWX_RATE_MCS_HE_106T_POS_V1;
            uint32_t he_gi_ltf = (rate_v1 & IWX_RATE_MCS_HE_GI_LTF_MSK_V1) >>
            IWX_RATE_MCS_HE_GI_LTF_POS;
            
            if ((he_type_bits == IWX_RATE_MCS_HE_TYPE_SU_V1 ||
                 he_type_bits == IWX_RATE_MCS_HE_TYPE_EXT_SU_V1) &&
                he_gi_ltf == IWX_RATE_MCS_HE_SU_4_LTF)
            /* the new rate have an additional bit to
             * represent the value 4 rather then using SGI
             * bit for this purpose - as it was done in the old
             * rate */
                he_gi_ltf += (rate_v1 & IWX_RATE_MCS_SGI_MSK_V1) >>
                IWX_RATE_MCS_SGI_POS_V1;
            
            rate_v2 |= he_gi_ltf << IWX_RATE_MCS_HE_GI_LTF_POS;
            rate_v2 |= he_type << IWX_RATE_MCS_HE_TYPE_POS;
            rate_v2 |= he_106t << IWX_RATE_MCS_HE_106T_POS;
            rate_v2 |= rate_v1 & IWX_RATE_HE_DUAL_CARRIER_MODE_MSK;
            rate_v2 |= IWX_RATE_MCS_HE_MSK;
        } else {
            rate_v2 |= IWX_RATE_MCS_VHT_MSK;
        }
        /* if legacy format */
    } else {
        uint32_t legacy_rate = iwx_hwrate_to_plcp_idx(rate_v1);
        
        WARN_ON(legacy_rate < 0);
        rate_v2 |= legacy_rate;
        if (!(rate_v1 & IWX_RATE_MCS_CCK_MSK_V1))
            rate_v2 |= IWX_RATE_MCS_LEGACY_OFDM_MSK;
    }
    
    /* convert flags */
    if (rate_v1 & IWX_RATE_MCS_LDPC_MSK_V1)
        rate_v2 |= IWX_RATE_MCS_LDPC_MSK;
    rate_v2 |= (rate_v1 & IWX_RATE_MCS_CHAN_WIDTH_MSK_V1) |
    (rate_v1 & IWX_RATE_MCS_ANT_AB_MSK) |
    (rate_v1 & IWX_RATE_MCS_STBC_MSK) |
    (rate_v1 & IWX_RATE_MCS_BF_MSK);
    
    dup = (rate_v1 & IWX_RATE_MCS_DUP_MSK_V1) >> IWX_RATE_MCS_DUP_POS_V1;
    if (dup) {
        rate_v2 |= IWX_RATE_MCS_DUP_MSK;
        rate_v2 |= dup << IWX_RATE_MCS_CHAN_WIDTH_POS;
    }
    
    if ((!(rate_v1 & IWX_RATE_MCS_HE_MSK_V1)) &&
        (rate_v1 & IWX_RATE_MCS_SGI_MSK_V1))
        rate_v2 |= IWX_RATE_MCS_SGI_MSK;
    
    return rate_v2;
}

/* HE SU bitrate from firmware-selected MCS/NSS/BW/GI, in kbit/s.
 * MU/TB needs an RU allocation absent from TLC notifications: report unknown. */
static uint32_t
iwx_he_rate_kbps(uint32_t rate)
{
    if ((rate & IWX_RATE_MCS_MOD_TYPE_MSK) != IWX_RATE_MCS_HE_MSK)
        return 0;
    unsigned type = (rate & IWX_RATE_MCS_HE_TYPE_MSK) >> IWX_RATE_MCS_HE_TYPE_POS;
    unsigned bw = (rate & IWX_RATE_MCS_CHAN_WIDTH_MSK) >> IWX_RATE_MCS_CHAN_WIDTH_POS;
    unsigned mcs = rate & IWX_RATE_MCS_CODE_MSK;
    unsigned gi = (rate & IWX_RATE_MCS_HE_GI_LTF_MSK) >> IWX_RATE_MCS_HE_GI_LTF_POS;
    unsigned nss = ((rate & IWX_RATE_MCS_NSS_MSK) >> IWX_RATE_MCS_NSS_POS) + 1;
    if (type > 1 || bw > 3 || mcs > 11 || gi > 4)
        return 0;
    static const unsigned tones[] = {234, 468, 980, 1960};
    static const unsigned bits[] = {1, 2, 2, 4, 4, 6, 6, 6, 8, 8, 10, 10};
    static const unsigned num[] = {1, 1, 3, 1, 3, 2, 3, 5, 3, 5, 3, 5};
    static const unsigned den[] = {2, 2, 4, 2, 4, 3, 4, 6, 4, 6, 4, 6};
    unsigned symbol = 128 + (gi == 2 ? 16 : gi == 3 ? 32 : 8);
    unsigned nsd = (rate & IWX_RATE_MCS_HE_106T_MSK) ? 102 : tones[bw];
    unsigned divisor = den[mcs] * symbol;
    if (rate & IWX_RATE_HE_DUAL_CARRIER_MODE_MSK) divisor *= 2;
    return nsd * nss * bits[mcs] * num[mcs] * 10000 / divisor;
}

void ItlIwx::
iwx_rs_update(struct iwx_softc *sc, struct iwx_tlc_update_notif *notif)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni = ic->ic_bss;
    struct ieee80211_rateset *rs = &ni->ni_rates;
    uint32_t rate_n_flags;
    int i;
    char pretty_rate[100];
    uint8_t notifver;
    uint32_t format;

    if (notif->sta_id != IWX_STATION_ID ||
        (le32toh(notif->flags) & IWX_TLC_NOTIF_FLAG_RATE) == 0)
        return;

    rate_n_flags = le32toh(notif->rate);
    notifver = iwx_lookup_notif_ver(sc, IWX_DATA_PATH_GROUP, IWX_TLC_MNG_UPDATE_NOTIF);
    if (notifver < 3 || notifver == IWX_FW_CMD_VER_UNKNOWN) {
        iwx_rs_pretty_print_rate_v1(pretty_rate, sizeof(pretty_rate),
                                    rate_n_flags);
        rate_n_flags = iwx_new_rate_from_v1(rate_n_flags);
    } else {
        iwx_rs_pretty_print_rate(pretty_rate, sizeof(pretty_rate),
                                 rate_n_flags);
    }
    XYLog("%s new rate: %s\n", __FUNCTION__, pretty_rate);
    format = rate_n_flags & IWX_RATE_MCS_MOD_TYPE_MSK;
    ni->ni_he_txrate_kbps = iwx_he_rate_kbps(rate_n_flags);
    ni->ni_he_tx_nss = format == IWX_RATE_MCS_HE_MSK ?
        ((rate_n_flags & IWX_RATE_MCS_NSS_MSK) >> IWX_RATE_MCS_NSS_POS) + 1 : 0;
    if (format == IWX_RATE_MCS_VHT_MSK ||
        format == IWX_RATE_MCS_HE_MSK ||
        format == IWX_RATE_MCS_EHT_MSK) {
        ni->ni_txmcs = rate_n_flags & IWX_RATE_MCS_CODE_MSK;
    } else if (format == IWX_RATE_MCS_HT_MSK) {
        ni->ni_txmcs = IWX_RATE_HT_MCS_INDEX(rate_n_flags);
    } else {
        uint8_t plcp = (rate_n_flags & IWX_RATE_LEGACY_RATE_MSK_V1);
        uint8_t rval = 0;
        for (i = IWX_RATE_1M_INDEX; i < nitems(iwx_rates); i++) {
            if (iwx_rates[i].plcp == plcp) {
                rval = iwx_rates[i].rate;
                break;
            }
        }
        if (rval) {
            uint8_t rv;
            for (i = 0; i < rs->rs_nrates; i++) {
                rv = rs->rs_rates[i] & IEEE80211_RATE_VAL;
                if (rv == rval) {
                    ni->ni_txrate = i;
                    break;
                }
            }
        }
    }
}

int ItlIwx::
iwx_phy_ctxt_update(struct iwx_softc *sc, struct iwx_phy_ctxt *phyctxt,
                    struct ieee80211_channel *chan, uint8_t chains_static,
                    uint8_t chains_dynamic, uint32_t apply_time)
{
    uint16_t band_flags = (IEEE80211_CHAN_2GHZ | IEEE80211_CHAN_5GHZ);
    int err;
    
    if (isset(sc->sc_enabled_capa,
              IWX_UCODE_TLV_CAPA_BINDING_CDB_SUPPORT) &&
        (phyctxt->channel->ic_flags & band_flags) !=
        (chan->ic_flags & band_flags)) {
        err = iwx_phy_ctxt_cmd(sc, phyctxt, chains_static,
                               chains_dynamic, IWX_FW_CTXT_ACTION_REMOVE, apply_time);
        if (err) {
            printf("%s: could not remove PHY context "
                   "(error %d)\n", DEVNAME(sc), err);
            return err;
        }
        phyctxt->channel = chan;
        err = iwx_phy_ctxt_cmd(sc, phyctxt, chains_static,
                               chains_dynamic, IWX_FW_CTXT_ACTION_ADD, apply_time);
        if (err) {
            printf("%s: could not add PHY context "
                   "(error %d)\n", DEVNAME(sc), err);
            return err;
        }
    } else {
        phyctxt->channel = chan;
        err = iwx_phy_ctxt_cmd(sc, phyctxt, chains_static,
                               chains_dynamic, IWX_FW_CTXT_ACTION_MODIFY, apply_time);
        if (err) {
            printf("%s: could not update PHY context (error %d)\n",
                   DEVNAME(sc), err);
            return err;
        }
    }
    
    return 0;
}

// RX monitor retunes may visit passive channels. This does not grant transmit
// eligibility: the sender separately checks passive/DFS/no-adhoc restrictions.
int ItlIwx::iwx_awdl_monitor_channel(struct iwx_softc *sc, unsigned number)
{
    struct ieee80211com *ic = &sc->sc_ic;
    if (!awdlRx || !getMainWorkLoop() || !getMainWorkLoop()->inGate() ||
        ic->ic_opmode != IEEE80211_M_MONITOR || !ic->ic_bss ||
        awdlMonitorPending || number > IEEE80211_CHAN_MAX)
        return EBUSY;
    auto *channel = &ic->ic_channels[number];
    if (!channel->ic_freq || !isset(ic->ic_chan_active, number))
        return EINVAL;
    const auto *current = sc->sc_phyctxt[0].channel;
    const unsigned bands = IEEE80211_CHAN_2GHZ | IEEE80211_CHAN_5GHZ;
    // The generic updater removes/re-adds PHY contexts on CDB band changes.
    // Removing one while its monitor station/MAC binding is live asserts FW.
    // Full station/queue/binding teardown is not implemented by this helper.
    if ((sc->sc_flags & IWX_FLAG_BINDING_ACTIVE) && current &&
        (current->ic_flags & bands) != (channel->ic_flags & bands))
        return EOPNOTSUPP;
    const auto mode = ieee80211_chan2mode(ic, channel);
    const auto &rates = ic->ic_sup_rates[mode];
    if (!rates.rs_nrates)
        return EINVAL;
    const int error = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0], channel, 1, 1, 0);
    if (error) {
        // Firmware state is uncertain after a failed command; forbid TX even
        // if the PHY helper has already changed its software channel pointer.
        ic->ic_bss->ni_rates.rs_nrates = 0;
        return error;
    }
    ic->ic_ibss_chan = channel;
    ic->ic_bss->ni_chan = channel;
    ic->ic_bss->ni_rates = rates;
    ic->ic_bss->ni_txrate = 0;
    return 0;
}

int ItlIwx::
iwx_auth(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    uint32_t duration;
    int generation = sc->sc_generation, err = 0;
    
    splassert(IPL_NET);
    
    in->in_ni.ni_chw = IEEE80211_CHAN_WIDTH_20_NOHT;
    in->in_ni.ni_flags &= ~(IEEE80211_NODE_HT |
                            IEEE80211_NODE_QOS |
                            IEEE80211_NODE_HT_SGI20 |
                            IEEE80211_NODE_HT_SGI40 |
                            IEEE80211_NODE_VHT |
                            IEEE80211_NODE_VHT_SGI80 |
                            IEEE80211_NODE_VHT_SGI160 |
                            IEEE80211_NODE_HE);
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        err = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0],
                                  ic->ic_ibss_chan, 1, 1, 0);
        if (err)
            return err;
    } else {
        err = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0],
                                  in->in_ni.ni_chan, 1, 1, 0);
        if (err)
            return err;
    }
    in->in_phyctxt = &sc->sc_phyctxt[0];
    IEEE80211_ADDR_COPY(in->in_macaddr, in->in_ni.ni_macaddr);
    
    err = iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_ADD, 0);
    if (err) {
        XYLog("%s: could not add MAC context (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    sc->sc_flags |= IWX_FLAG_MAC_ACTIVE;
    
    err = iwx_binding_cmd(sc, in, IWX_FW_CTXT_ACTION_ADD);
    if (err) {
        XYLog("%s: could not add binding (error %d)\n",
              DEVNAME(sc), err);
        goto rm_mac_ctxt;
    }
    sc->sc_flags |= IWX_FLAG_BINDING_ACTIVE;
    
    err = iwx_add_sta_cmd(sc, in, 0);
    if (err) {
        XYLog("%s: could not add sta (error %d)\n",
              DEVNAME(sc), err);
        goto rm_binding;
    }
    
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        // This firmware assigns its own queue number, which iwx_enable_txq
        // treats as fatal, restarting the driver. The receive test sends nothing.
        if (awdlRx) {
            if (awdlQueueProbe && ItlAWDL::monitorQueueShouldAllocate(awdlQueueProbeAttempted,
                    awdlMonitorQueue, awdlMonitorGeneration, sc->sc_generation)) {
                // A failed setup can trigger firmware reinitialization, so a failure
                // is never retried. A success is repeated once per firmware start,
                // because a restart (such as a Wi-Fi toggle) invalidates the queue.
                awdlQueueProbeAttempted = true;
                awdlMonitorProbeStarted = false;
                awdlMonitorTxAttempted = false;
                awdlMonitorReadinessPolls = 0;
                awdlDataInFlight = 0;
                awdlBurst.reset();
                awdlMulticastRepeats.reset();
                awdlBackgroundScanActive = false;
                awdlResend = ItlAWDL::ResendState{};
                if (awdlDeferredMulticast) {
                    mbuf_freem(awdlDeferredMulticast);
                    awdlDeferredMulticast = nullptr;
                }
                awdlAckPending = ItlAWDL::AckProbe::None;
                awdlMacTried = false;
                // Allocate through the existing firmware-selected queue path.
                // Do not set first_data_qid or submit/doorbell any frame.
                const int queue = iwx_tvqm_enable_txq(sc, IWX_MGMT_TID, 0,
                    IWX_DEFAULT_QUEUE_SIZE, IWX_MONITOR_STA_ID);
                awdlLog("monitor queue allocation result %d station %d tid %d; no TX submitted\n",
                        queue, IWX_MONITOR_STA_ID, IWX_MGMT_TID);
                if (queue < 0) {
                    awdlMonitorQueue = -1;
                    err = -queue;
                    goto rm_sta;
                }
                awdlMonitorQueue = queue;
                awdlMonitorGeneration = sc->sc_generation;
                int txArgument = 0;
                awdlMonitorTxArmed = PE_parse_boot_argn("-itlawdloneshot", &txArgument, sizeof(txArgument));
            }
            return 0;
        }
        err = iwx_enable_txq(sc, IWX_MONITOR_STA_ID,
                             IWX_DQA_INJECT_MONITOR_QUEUE, IWX_MGMT_TID,
                             sc->txq[IWX_DQA_INJECT_MONITOR_QUEUE].ring_count);
        if (err)
            goto rm_sta;
        return 0;
    }
    
    err = iwx_enable_mgmt_queue(sc);
    if (err)
        goto rm_sta;
    
    err = iwx_clear_statistics(sc);
    if (err)
        goto rm_sta;
    
    /*
     * Prevent the FW from wandering off channel during association
     * by "protecting" the session with a time event.
     */
    if (in->in_ni.ni_intval)
        duration = in->in_ni.ni_intval * 2;
    else
        duration = IEEE80211_DUR_TU;
    
    /* Try really hard to protect the session and hear a beacon
     * The new session protection command allows us to protect the
     * session for a much longer time since the firmware will internally
     * create two events: a 300TU one with a very high priority that
     * won't be fragmented which should be enough for 99% of the cases,
     * and another one (which we configure here to be 900TU long) which
     * will have a slightly lower priority, but more importantly, can be
     * fragmented so that it'll allow other activities to run.
     */
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_SESSION_PROT_CMD))
        err = iwx_schedule_protect_session(sc, in, duration);
    else
        iwx_protect_session(sc, in, duration, in->in_ni.ni_intval / 2);
    
    return err;
    
rm_sta:
    if (generation == sc->sc_generation)
        iwx_rm_sta_cmd(sc, in);
rm_binding:
    if (generation == sc->sc_generation) {
        iwx_binding_cmd(sc, in, IWX_FW_CTXT_ACTION_REMOVE);
        sc->sc_flags &= ~IWX_FLAG_BINDING_ACTIVE;
    }
rm_mac_ctxt:
    if (generation == sc->sc_generation) {
        iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_REMOVE, 0);
        sc->sc_flags &= ~IWX_FLAG_MAC_ACTIVE;
    }
    return err;
}

int ItlIwx::
iwx_deauth(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int err, generation = sc->sc_generation;
    
    splassert(IPL_NET);
    
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_SESSION_PROT_CMD))
        iwx_unprotect_session(sc, in);
    else {
        err = iwx_cancel_session_protection(sc, in);
        if (err)
            return err;
    }
    if (generation != sc->sc_generation)
        return ENXIO;
    
    if (sc->sc_flags & IWX_FLAG_STA_ACTIVE) {
        err = iwx_rm_sta(sc, in);
        if (err)
            return err;
    }
    
    if (sc->sc_flags & IWX_FLAG_BINDING_ACTIVE) {
        err = iwx_binding_cmd(sc, in, IWX_FW_CTXT_ACTION_REMOVE);
        if (err) {
            XYLog("%s: could not remove binding (error %d)\n",
                  DEVNAME(sc), err);
            return err;
        }
        sc->sc_flags &= ~IWX_FLAG_BINDING_ACTIVE;
    }
    
    if (sc->sc_flags & IWX_FLAG_MAC_ACTIVE) {
        err = iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_REMOVE, 0);
        if (err) {
            XYLog("%s: could not remove MAC context (error %d)\n",
                  DEVNAME(sc), err);
            return err;
        }
        sc->sc_flags &= ~IWX_FLAG_MAC_ACTIVE;
    }
    
    in->in_ni.ni_chw = IEEE80211_CHAN_WIDTH_20_NOHT;
    in->in_ni.ni_flags &= ~(IEEE80211_NODE_HT |
                            IEEE80211_NODE_QOS |
                            IEEE80211_NODE_HT_SGI20 |
                            IEEE80211_NODE_HT_SGI40 |
                            IEEE80211_NODE_VHT |
                            IEEE80211_NODE_VHT_SGI80 |
                            IEEE80211_NODE_VHT_SGI160 |
                            IEEE80211_NODE_HE);
    /* Move unused PHY context to a default channel. */
    err = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0],
                              &ic->ic_channels[1], 1, 1, 0);
    if (err)
        return err;
    
    return 0;
}

int ItlIwx::
iwx_run(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int err;
    int chains = iwx_mimo_enabled(sc) ? 2 : 1;
    
    splassert(IPL_NET);
    
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        /* Add a MAC context and a sniffing STA. */
        err = iwx_auth(sc);
        if (err)
            return err;
    }
    
    if (in->in_ni.ni_chw == IEEE80211_CHAN_WIDTH_80P80) {
        /* Fallback to 20mhz VHT */
        in->in_ni.ni_chw = IEEE80211_CHAN_WIDTH_20;
    }
    
    /* Configure Rx chains for MIMO. */
    if ((ic->ic_opmode == IEEE80211_M_MONITOR ||
         (in->in_ni.ni_flags & IEEE80211_NODE_HT) ||
         (in->in_ni.ni_flags & IEEE80211_NODE_VHT) ||
         (in->in_ni.ni_flags & IEEE80211_NODE_HE))) {
        err = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0],
                                  in->in_ni.ni_chan, chains, chains, 0);
        if (err) {
            XYLog("%s: failed to update PHY\n",
                  DEVNAME(sc));
            return err;
        }
    }
    
    /* We have now been assigned an associd by the AP. */
    err = iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_MODIFY, 1);
    if (err) {
        XYLog("%s: failed to update MAC\n", DEVNAME(sc));
        return err;
    }
    
    err = iwx_sf_config(sc, IWX_SF_FULL_ON);
    if (err) {
        XYLog("%s: could not set sf full on (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    
    err = iwx_allow_mcast(sc);
    if (err) {
        XYLog("%s: could not allow mcast (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    
    err = iwx_power_update_device(sc);
    if (err) {
        XYLog("%s: could not send power command (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
#ifdef notyet
    /*
     * Disabled for now. Default beacon filter settings
     * prevent net80211 from getting ERP and HT protection
     * updates from beacons.
     */
    err = iwx_enable_beacon_filter(sc, in);
    if (err) {
        XYLog("%s: could not enable beacon filter\n",
              DEVNAME(sc));
        return err;
    }
#endif
    err = iwx_power_mac_update_mode(sc, in);
    if (err) {
        XYLog("%s: could not update MAC power (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DYNAMIC_QUOTA)) {
        err = iwx_update_quotas(sc, in, 1);
        if (err) {
            XYLog("%s: could not update quotas (error %d)\n",
                  DEVNAME(sc), err);
            return err;
        }
    }
    
    if (ic->ic_opmode == IEEE80211_M_MONITOR)
        return 0;
    
    /* Start at lowest available bit-rate. Firmware will raise. */
    in->in_ni.ni_txrate = 0;
    in->in_ni.ni_txmcs = 0;

    err = iwx_add_sta_cmd(sc, in, 1);
    if (err) {
        XYLog("%s: could not update sta (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    
    err = iwx_config_he_sta(sc, &in->in_ni);
    if (err)
        return err;
    err = iwx_rs_init(sc, in, true);
    if (err) {
        XYLog("%s: could not update rate scaling (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    // Listener restoration follows the RUN commit in iwx_newstate_task: until
    // then the station transition still excludes the periodic coex cycle task.
    return 0;
}

// Sends the listener's MAC context command: add, modify or remove. Its address is our AWDL address
// once macOS's first frame shows it, before that a locally administered one, never the station's.
int ItlIwx::
awdlCoexMacSend(struct iwx_softc *sc, uint32_t action)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    struct iwx_mac_ctx_cmd mac;
    memset(&mac, 0, sizeof(mac));
    mac.id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0));
    mac.action = htole32(action);
    bool promiscWanted = false;
    const bool sameChannelProbe = action != IWX_FW_CTXT_ACTION_REMOVE &&
        awdlCoexSameChannelProbeWanted(sc, awdlUptimeUS());
    if (sameChannelProbe)
        awdlCoexSameChannelProbe.restorePending = true; // Even an uncertain open needs a later close.
    if (action != IWX_FW_CTXT_ACTION_REMOVE) {
        mac.mac_type = htole32(IWX_FW_MAC_TYPE_LISTENER);
        mac.tsf_id = htole32(IWX_TSF_ID_B);
        if (awdlCoexAddrKnown) {
            IEEE80211_ADDR_COPY(mac.node_addr, awdlCoexAddr);
        } else {
            IEEE80211_ADDR_COPY(mac.node_addr, ic->ic_myaddr);
            mac.node_addr[0] |= 0x02;
            mac.node_addr[5] ^= 0x5a;
        }
        static const uint8_t awdlBssid[6] = {0x00, 0x25, 0x00, 0xff, 0x94, 0x73};
        IEEE80211_ADDR_COPY(mac.bssid_addr, (awdlCoexFilter == 1 || awdlCoexFilter == 3) ? awdlBssid : etherbroadcastaddr);
        int cck = 0, ofdm = 0;
        if (awdlCoexOwnChan) {
            // Its own channel's band, not the BSS's: the mandatory OFDM rates (6, 12, 24 Mbit/s) on both
            // bands, CCK only on 2.4 GHz.
            cck = IEEE80211_IS_CHAN_2GHZ(awdlCoexOwnChan) ? 0x0f : 0;
            ofdm = 0x15;
        } else {
            iwx_ack_rates(sc, in, &cck, &ofdm);
        }
        mac.cck_rates = htole32(cck);
        mac.ofdm_rates = htole32(ofdm);
        // Filter 3 (the default with -itlawdlcoexdata): AWDL's BSSID and group frames, plus promiscuous
        // receive while the listener is on its own channel, different from the station's. A LISTENER
        // context without it passes AWDL's broadcast action frames but no data (iface130: AwdlData 0 on
        // both channels), and dedicated mode, where data arrives, is always promiscuous. On the station's
        // own channel it would take the station's frames from it (iface108), so not there.
        struct ieee80211_channel *stationChan = in && in->in_phyctxt ? in->in_phyctxt->channel : nullptr;
        promiscWanted = awdlCoexFilter == 3 && !awdlCoexBaFilterOff && awdlCoexOwnChan && stationChan &&
            (ieee80211_chan2ieee(ic, awdlCoexOwnChan) != ieee80211_chan2ieee(ic, stationChan) ||
             sameChannelProbe);
        mac.filter_flags = htole32(awdlCoexFilter == 0 ?
            IWX_MAC_FILTER_IN_PROMISC | IWX_MAC_FILTER_IN_CONTROL_AND_MGMT | IWX_MAC_FILTER_ACCEPT_GRP |
            IWX_MAC_FILTER_IN_BEACON | IWX_MAC_FILTER_IN_PROBE_REQUEST :
            promiscWanted ? IWX_MAC_FILTER_IN_PROMISC | IWX_MAC_FILTER_IN_CONTROL_AND_MGMT |
                IWX_MAC_FILTER_ACCEPT_GRP :
            IWX_MAC_FILTER_ACCEPT_GRP);
    }
    // The state is recorded only once the firmware has taken the command. A failure leaves it unknown, and
    // the RX isolation then treats the listener as promiscuous until a later command succeeds.
    // An answer that comes back after the listener changed belongs to no one: isolation stays on
    // (uncertain) until a current command settles it. A firmware restart clears everything anyway.
    const uint32_t macTok = awdlCoexToken;
    const int macGen = sc->sc_generation;
    const int result = iwx_send_cmd_pdu(sc, IWX_MAC_CONTEXT_CMD, 0, sizeof(mac), &mac);
    if (macGen != sc->sc_generation)
        return result;
    if (!result && macTok == awdlCoexToken) {
        if (!sameChannelProbe)
            awdlCoexSameChannelProbe.restorePending = false;
        awdlCoexSameChannelProbe.noteApplied(promiscWanted && sameChannelProbe, awdlUptimeUS());
        awdlCoexPromiscLive = promiscWanted;
        awdlCoexPromiscUncertain = false;
    } else {
        if (awdlCoexSameChannelProbe.applied && !sameChannelProbe)
            ++awdlCoexSameChannelProbe.restoreFailures;
        awdlCoexPromiscUncertain = true;
    }
    return result;
}

// The listener's own channel. Apple's AWDL uses 149 or 44 on 5 GHz, and each phone picks one by its own rules
// (Japan: 44; Germany and Russia: 44 although 149 is allowed). The listener follows the phone (PR #21, the min
// rule): while a phone was heard in the last 10 minutes and its AWDL slots name 44, the listener takes 44 (at
// 80 MHz over 36-48, else 20 MHz), and 149 only if the phone names 149 too. Otherwise (no phone heard, or it
// names 149) 149 at 80 MHz as before. Either needs the firmware's current channel map to allow starting there
// (no passive, no radar, ad hoc allowed; at 80 MHz on the whole block). Then 6 at 20 MHz. The station's own
// 80 MHz block with another primary makes it 20 MHz; a 160 MHz station channel over it skips it (#26). 80 MHz is
// not tried again in a generation where its PHY command failed.
// Whether the firmware's channel map lets the listener use ch at all (any width).
static bool
awdlCoexChannelUsable(struct ieee80211com *ic, unsigned ch)
{
    const auto &c = ic->ic_channels[ch];
    return c.ic_freq && isset(ic->ic_chan_active, ch) && !awdlCoexNoIr(ic, ch) &&
        !(c.ic_flags & (IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC));
}

static int
awdlCoexPickOwn(struct iwx_softc *sc, uint8_t *width)
{
    struct ieee80211com *ic = &sc->sc_ic;
    auto usable = [ic](unsigned ch) { return awdlCoexChannelUsable(ic, ch); };
    uint32_t hints = isset(ic->ic_beacon_hint, 6) ? 16U : 0U;
    for (unsigned ch = 149, bit = 1; ch <= 161; ch += 4, bit <<= 1)
        if (isset(ic->ic_beacon_hint, ch))
            hints |= bit;
    for (unsigned ch = 36, bit = 256; ch <= 48; ch += 4, bit <<= 1)
        if (isset(ic->ic_beacon_hint, ch))
            hints |= bit;
    if (hints != awdlCoexBeaconHints) {
        awdlCoexBeaconHints = hints;
        awdlCoexPublish();
    }
    if (awdlCoexSameBand && ic->ic_bss && ic->ic_bss->ni_chan && IEEE80211_IS_CHAN_2GHZ(ic->ic_bss->ni_chan) &&
        usable(6)) {
        *width = IWX_PHY_VHT_CHANNEL_MODE20;
        return 6;
    }
    // How the station's channel overlaps a 5 GHz candidate (149 or 44): 1 when the station is at 80 MHz in the
    // candidate's block with another primary (#26: a listener at 80 MHz on 149 beside a router on 157/80 was never
    // seen by the iPhone), 2 when a 160 MHz (or 80+80) station channel covers the candidate's 160 MHz group (a
    // listener inside it got the station disconnected during transfers, AX201, PR #21). With the station on the
    // candidate itself (at 80 MHz or less) the listener shares its channel as before.
    auto group160 = [](unsigned ch) -> unsigned {
        return ch >= 36 && ch <= 64 ? 1U : ch >= 100 && ch <= 128 ? 2U : ch >= 149 && ch <= 177 ? 3U : 0U;
    };
    const bool stationKnown = !awdlCoexOverlap80 && ic->ic_state == IEEE80211_S_RUN && ic->ic_bss &&
        ic->ic_bss->ni_chan;
    const unsigned stationPrimary = stationKnown ? ieee80211_chan2ieee(ic, ic->ic_bss->ni_chan) : 0U;
    const uint8_t stationChw = stationKnown ? ic->ic_bss->ni_chw : 0;
    auto overlapFor = [&](unsigned c) -> uint8_t {
        if (!stationKnown)
            return 0;
        if ((stationChw == IEEE80211_CHAN_WIDTH_160 || stationChw == IEEE80211_CHAN_WIDTH_80P80) &&
            group160(stationPrimary) == group160(c))
            return 2;
        if (stationChw == IEEE80211_CHAN_WIDTH_80 && stationPrimary != c &&
            awdlCoex80BlockFirst(stationPrimary) == awdlCoex80BlockFirst(c))
            return 1;
        return 0;
    };
    uint8_t overlap = 0;
    // A 5 GHz candidate: 80 MHz over its whole block when allowed; 20 MHz when the station's block overlaps,
    // or (allow20) when the phone is known to use this channel.
    auto tryChannel = [&](unsigned c, bool allow20, uint8_t *w) -> bool {
        overlap = overlapFor(c);
        if (overlap == 2)
            return false;
        const unsigned f = awdlCoex80BlockFirst(c);
        if (!overlap && f && awdlCoexWide80FailedGen != sc->sc_generation &&
            (ic->ic_channels[c].ic_flags & IEEE80211_CHAN_VHT80)) {
            bool all = true;
            for (unsigned ch = f; ch <= f + 12; ch += 4)
                all = all && usable(ch);
            if (all) {
                *w = IWX_PHY_VHT_CHANNEL_MODE80;
                return true;
            }
        }
        if ((overlap == 1 || allow20) && usable(c)) {
            *w = IWX_PHY_VHT_CHANNEL_MODE20;
            return true;
        }
        return false;
    };
    // The min rule (PR #21): what the phone's AWDL slots name, while it was heard in the last 10 minutes.
    const bool peerFresh = awdlCoexPeer5G && awdlUptimeUS() - awdlCoexPeer5GUS < kAwdlCoexPeer5GLifeUS;
    const unsigned peerCh = peerFresh ? awdlCoexPeerChannel(awdlCoexPeerSeq) : 0U;
    // On merge: only while the peer itself is seen on 44, in any slot (its Wi-Fi slots count here), so the
    // flag never keeps the listener on 44 for a peer that never comes there.
    const bool stationOn44 = awdlCoexStation44 && peerFresh && awdlCoexPeerVisits(awdlCoexPeerSeq, 44) &&
        ic->ic_state == IEEE80211_S_RUN && ic->ic_bss && ic->ic_bss->ni_chan &&
        ieee80211_chan2ieee(ic, ic->ic_bss->ni_chan) == 44;
    const bool names44 = peerCh == 44 || stationOn44;
    const bool names149 = peerFresh && awdlCoexPeerNames(awdlCoexPeerSeq, 149);
    int pick = 0;
    uint8_t w = IWX_PHY_VHT_CHANNEL_MODE20;
    if (names44 && tryChannel(44, true, &w))
        pick = 44;
    // 149 as before, unless the phone uses only 44: then it never comes to 149 (#35), and 6 is better.
    else if ((names149 || !names44) && tryChannel(149, names149, &w))
        pick = 149;
    else if (usable(6)) {
        w = IWX_PHY_VHT_CHANNEL_MODE20;
        pick = 6;
    }
    if (overlap != awdlCoexOverlapState) {
        awdlCoexOverlapState = overlap;
        awdlCoexPublish();
    }
    if (pick)
        *width = w;
    return pick;
}

// Station mode: the firmware's country notice answered with its own country and source, and its channel map
// applied, as dedicated mode and Linux do. Nothing is invented: the firmware's reply is the map.
void ItlIwx::
awdlCoexCountryAnswer(struct iwx_softc *sc)
{
    awdlCoexCountryPending = false;
    const uint16_t mcc = awdlCoexCountryNotice;
    const uint8_t source = awdlCoexCountrySource;
    const int gen = sc->sc_generation;
    ItlAWDL::MccSample reply{};
    const int err = iwx_mcc_request(sc, mcc, source, &reply, true);
    if (gen != sc->sc_generation)
        return;
    awdlCoexCountryLastStatus = err ? 0x80000000U | uint32_t(err) : reply.status;
    if (err) {
        // Not answered: the pair isn't recorded, and the latest notice is tried again in 5 s, unless a newer
        // one replaced it meanwhile (the handler keeps only the latest).
        ++awdlCoexCountryFailures;
        awdlCoexCountryRetryUS = awdlUptimeUS() + 5000000ULL;
        if (awdlCoexCountryNotice == mcc && awdlCoexCountrySource == source)
            awdlCoexCountryPending = true;
        awdlCoexPublish();
        return;
    }
    // Beacon hints belong to the old country's rules. A detour through the firmware's world code isn't a
    // change of country: the hints stay until a different usable country is answered. Then only the hints
    // for channels the new country's map (applied above) still has, and not as radar channels, are kept
    // (#21: JP and CN both have 36-48, so a hint on 44 survives a JP-CN switch); the rest are dropped. A
    // kept hint only lifts the passive flag, as it does today; the firmware's flags still apply on every use.
    const bool usableCountry = ItlAWDL::countryNoticeUsable(mcc, source);
    if (!usableCountry)
        ++awdlCoexCountryUnusableAnswers;
    else if (mcc != awdlCoexHintCountry) {
        if (awdlCoexHintCountry)
            ++awdlCoexHintClears;
        struct ieee80211com *hic = &sc->sc_ic;
        uint32_t kept = 0;
        // The hint bitmap holds IEEE80211_CHAN_MAX bits (ieee80211_var.h).
        for (unsigned ch = 0; ch < IEEE80211_CHAN_MAX; ++ch) {
            if (!isset(hic->ic_beacon_hint, ch))
                continue;
            const struct ieee80211_channel &c = hic->ic_channels[ch];
            if (c.ic_freq && !(c.ic_flags & IEEE80211_CHAN_DFS))
                ++kept;
            else
                clrbit(hic->ic_beacon_hint, ch);
        }
        awdlCoexHintsKept = kept;
        awdlCoexHintCountry = mcc;
    }
    awdlCoexCountryAnswered = mcc;
    awdlCoexCountrySourceAnswered = source;
    awdlCoexCountryAnswerSeconds = mccUptimeSeconds();
    awdlCoexCountryRetryUS = 0;
    ++awdlCoexCountryAnswers;
    awdlCoexCountryLearned = ItlAWDL::countryNoticeUsable(mcc, source);
    // A newer notice that arrived while this one waited on the firmware is still pending, and goes next.
    if (awdlCoexCountryNotice == mcc && awdlCoexCountrySource == source)
        awdlCoexCountryPending = false;
    awdlCoexPublish();
}

// Moves the listener's own context when the firmware's channel map changes: up to 149 at 80 MHz when it is
// allowed (at most every 10 s), back down to 6 at once when it is withdrawn. The binding stays; only the PHY
// context moves, then the listener's MAC context takes the new band's rates.
void ItlIwx::
awdlCoexRetarget(struct iwx_softc *sc)
{
    const int gen = sc->sc_generation;
    if (!awdlCoexMultiActive || !awdlCoexAdded || awdlCoexGeneration != gen || awdlCoexAddingGen == gen ||
        awdlCoexRemovingGen == gen || awdlCoexPhyUncertainGen == gen || awdlCoexBrokenGeneration == gen ||
        awdlStopping) {
        awdlCoexMovePending = false;
        return;
    }
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_phy_ctxt *own = &sc->sc_phyctxt[kAwdlCoexPhyId];
    uint8_t width = IWX_PHY_VHT_CHANNEL_MODE20;
    const int want = awdlCoexPickOwn(sc, &width);
    const int have = own->channel ? ieee80211_chan2ieee(ic, own->channel) : 0;
    const int haveWidth = awdlCoexOwnWidth;
    // Same channel and the same width: nothing to do. 20 MHz and 80 MHz on one channel are different choices.
    const uint64_t now = awdlUptimeUS();
    if (!want || (want == have && (width == IWX_PHY_VHT_CHANNEL_MODE80) == (haveWidth == 80))) {
        if (awdlCoexSettleWant) {
            ++awdlCoexMovesSettleDropped;
            awdlCoexSettleWant = 0;
        }
        awdlCoexMovePending = false;
        return;
    }
    // From one usable 5 GHz channel to another (44 and 149), only on a choice that held for
    // kAwdlCoexMoveSettleUS and not within kAwdlCoexMoveQuietUS of AWDL data (#68). The choice follows the
    // last channel sequence heard from any nearby device, which can alternate every few seconds, and each
    // move also drops the block-ack peer, so a transfer was cut off by the next one. A channel the map
    // withdrew, and moves to or from 6, aren't held.
    // Not held when the peer never comes to the channel the listener is on (no slot names it, its Wi-Fi slots
    // included) and does come to the new one: staying helps nobody (a 44-only phone heard while on 149, #35).
    const bool peerSeqFresh = awdlCoexPeer5G && now - awdlCoexPeer5GUS < kAwdlCoexPeer5GLifeUS;
    const bool haveUnvisited = peerSeqFresh && have > 0 && have <= 255 &&
        !awdlCoexPeerVisits(awdlCoexPeerSeq, unsigned(have)) && awdlCoexPeerVisits(awdlCoexPeerSeq, unsigned(want));
    if (haveUnvisited && awdlCoexSettleWant)
        awdlCoexSettleWant = 0;
    if (!haveUnvisited && !awdlCoexMovePending && want != 6 && have && have != 6 &&
        awdlCoexChannelUsable(ic, unsigned(have))) {
        // A choice from an earlier listener (another generation) starts over.
        if (want != awdlCoexSettleWant || width != awdlCoexSettleWidth || awdlCoexSettleGen != gen) {
            if (awdlCoexSettleWant)
                ++awdlCoexMovesSettleDropped;
            awdlCoexSettleWant = want;
            awdlCoexSettleWidth = width;
            awdlCoexSettleSinceUS = now;
            awdlCoexSettleGen = gen;
        }
        const bool dataRecent = awdlCoexLastDataUS && now - awdlCoexLastDataUS < kAwdlCoexMoveQuietUS;
        if (dataRecent || now - awdlCoexSettleSinceUS < kAwdlCoexMoveSettleUS)
            return;
    }
    awdlCoexSettleWant = 0;
    // Up to 5 GHz (149 or 44) at most every 10 s; back to 6 at once.
    if (want != 6 && awdlCoexLastMoveUS && now - awdlCoexLastMoveUS < 10000000ULL) {
        awdlCoexMovePending = false;
        return;
    }
    // Nothing new is submitted from here (the eligibility guard refuses while a move is pending), and the
    // move waits until every sync and data descriptor has completed. After 2 s it goes anyway, but nothing
    // more is sent this generation: what is left may still go out on the old channel.
    if (!awdlCoexMovePending) {
        awdlCoexMovePending = true;
        awdlCoexMovePendingUS = now;
    }
    const bool drained = !awdlCoexInFlight && awdlCoexQueue >= 0 && awdlCoexQueue < int(nitems(sc->txq)) &&
        sc->txq[awdlCoexQueue].queued == 0;
    if (!drained) {
        if (now - awdlCoexMovePendingUS < 2000000ULL)
            return;
        ++awdlCoexMoveDrainTimeouts;
        awdlCoexMultiState = "move-drain-timeout";
        // A software halt doesn't stop what the firmware already holds: flush and remove the listener's
        // station and queue first. If that fails, the firmware may still send on the old channel, so the
        // listener is quarantined and not moved; a firmware restart clears it. Either way listener TX stays
        // off for this generation: teardown clears the halt, so it is set again after, and setup isn't
        // retried.
        const uint32_t drainTok = awdlCoexToken;
        const struct ieee80211_node *drainBss = ic->ic_bss;
        const int flushErr = awdlCoexTxTeardown(sc);
        if (gen != sc->sc_generation)
            return;
        awdlCoexTxHalted = true;
        awdlCoexTxSetupTried = kAwdlCoexTxSetupTries;
        if (drainTok != awdlCoexToken || ic->ic_bss != drainBss || !awdlCoexAdded || !awdlCoexMultiActive) {
            // The listener changed while flushing: this move's decision is stale.
            awdlCoexMovePending = false;
            awdlCoexPublish();
            return;
        }
        if (flushErr) {
            awdlCoexBrokenGeneration = gen;
            awdlCoexMovePending = false;
            awdlCoexMultiState = "move-flush-failed";
            awdlCoexPublish();
            return;
        }
    }
    // The peer station was set up for the old channel's width: the phone asks again after the move. If it
    // can't be removed, its ownership is unknown, so the move waits (BA is quarantined) and TX stays guarded.
    const uint32_t removeTok = awdlCoexToken;
    const int peerErr = awdlCoexBaRemovePeer(sc);
    if (gen != sc->sc_generation)
        return;
    if (peerErr || removeTok != awdlCoexToken || !awdlCoexAdded) {
        awdlCoexMovePending = false;
        if (peerErr)
            awdlCoexMultiState = "move-peer-remove-failed";
        awdlCoexPublish();
        return;
    }
    const uint32_t tok = awdlCoexToken;
    // Re-decide after any wait above: the map may have changed again.
    {
        uint8_t again = IWX_PHY_VHT_CHANNEL_MODE20;
        if (awdlCoexPickOwn(sc, &again) != want || again != width) {
            awdlCoexMovePending = false;
            return;
        }
    }
    struct ieee80211_channel *before = own->channel;
    own->channel = &ic->ic_channels[want];
    awdlCoexPhyWidth = width;
    const int err = iwx_phy_ctxt_cmd(sc, own, 1, 1, IWX_FW_CTXT_ACTION_MODIFY, 0);
    awdlCoexPhyWidth = -1;
    awdlCoexLastMoveUS = now;
    if (gen != sc->sc_generation)
        return;
    if (err || tok != awdlCoexToken) {
        // No answer to read, or the listener changed while waiting: the context may be on either channel.
        // Nothing more is sent this generation.
        awdlCoexMovePending = false;
        ++awdlCoexMoveFailures;
        own->channel = before;
        awdlCoexPhyUncertainGen = gen;
        if (width == IWX_PHY_VHT_CHANNEL_MODE80)
            awdlCoexWide80FailedGen = gen;
        awdlCoexTxHalted = true;
        awdlCoexMultiState = "move-uncertain";
        awdlCoexPublish();
        return;
    }
    ++awdlCoexMoves;
    awdlCoexRateStep = 0;
    awdlCoexRateWindowOK = awdlCoexRateWindowFailed = 0;
    awdlCoexOwnChan = own->channel;
    awdlCoexOwnWidth = width == IWX_PHY_VHT_CHANNEL_MODE80 ? 80 : 20;
    awdlCoexPeerSchedule.reset();
    awdlCoexChannel = want;
    if (awdlCoexTx)
        awdlFixedChannel = want;
    // PHY and MAC are one transition: sending resumes only once the MAC context has the new band's rates.
    const int macErr = awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_MODIFY);
    if (gen != sc->sc_generation)
        return;
    awdlCoexMovePending = false;
    if (macErr || tok != awdlCoexToken || !awdlCoexAdded) {
        ++awdlCoexMoveFailures;
        awdlCoexTxHalted = true;
        awdlCoexMultiState = "move-mac-failed";
    }
    awdlCoexPublish();
}

// Adds or removes the probe's listener. The binding always keeps the station first, so removing the
// listener leaves exactly what the station had.
int ItlIwx::
awdlCoexListener(struct iwx_softc *sc, bool add)
{
    const int gen = sc->sc_generation;
    if (add) {
        if (awdlCoexStationTransitionGen == gen)
            return EBUSY;
        if (awdlCoexBrokenGeneration == gen)
            return EIO;
        if (awdlCoexStationReadyGen != gen || sc->sc_ic.ic_state != IEEE80211_S_RUN || awdlStopping ||
            (sc->sc_flags & IWX_FLAG_SHUTDOWN))
            return ECANCELED;
    }
    if (!add) {
        // Cancellation is not completion: listener/TX setup sleeping in a firmware
        // command must finish rollback before any listener or station context goes.
        if (awdlCoexAddingGen == gen || awdlCoexTxSettingUpGen == gen) {
            awdlCoexRemoveRequested = true;
            ++awdlCoexToken;
        }
        AbsoluteTime deadline;
        clock_interval_to_deadline(5, kSecondScale, reinterpret_cast<uint64_t *>(&deadline));
        while (awdlCoexAddingGen == gen || awdlCoexRemovingGen == gen || awdlCoexTxSettingUpGen == gen) {
            const int result = getMainCommandGate()->commandSleep(&awdlCoexAddingGen, deadline, THREAD_UNINT);
            if (gen != sc->sc_generation || (sc->sc_flags & IWX_FLAG_SHUTDOWN))
                return ECANCELED;
            if (result != THREAD_AWAKENED) {
                awdlCoexBrokenGeneration = gen;
                return ETIMEDOUT;
            }
        }
        if (awdlCoexBrokenGeneration == gen)
            return EIO;
        // A TX station can outlive the listener's published state. It still
        // owns a firmware queue, but there is no MAC/binding to remove here.
        if (!awdlCoexAdded && awdlCoexTxStaAdded && awdlCoexGeneration == gen) {
            ++awdlCoexToken;
            awdlCoexRemovingGen = gen;
            const int err = awdlCoexTxTeardown(sc);
            if (gen != sc->sc_generation)
                return ECANCELED;
            awdlCoexRemovingGen = -1;
            getMainCommandGate()->commandWakeup(&awdlCoexAddingGen);
            if (err) {
                ++awdlCoexTeardownErrors;
                awdlCoexBrokenGeneration = gen;
            }
            return err;
        }
    }
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    if (!in || !in->in_phyctxt)
        return EINVAL;
    if (awdlCoexGeneration != sc->sc_generation) {
        // A firmware restart dropped every context, ours included, and its station and queue.
        if (awdlCoexAdded)
            awdlCoexLostToRestart = true;
        awdlCoexAdded = false;
        awdlCoexTxStaAdded = false;
        awdlCoexInFlight = false;
        awdlCoexPendingSlot = -1;
        awdlCoexAddrApplied = false;
        if (awdlCoexMulti)
            awdlCoexMultiState = "not-added";
        awdlCoexMultiActive = false;
        awdlCoexOwnChan = nullptr;
        awdlCoexMovePending = false;
        awdlCoexSameChannelProbe.noteApplied(false, awdlUptimeUS());
        awdlCoexSameChannelProbe.restorePending = false;
        awdlCoexPromiscLive = false;
        awdlCoexPromiscUncertain = false;
        awdlCoexBaPeerAdded = false;
        awdlCoexBaPeerAccepted = false;
        awdlCoexBaGen = sc->sc_generation;
        awdlCoexBaRequestsPending.clear();
        awdlCoexBaTids = 0;
        awdlCoexBaFilterOff = false;
        awdlCoexBaFilter = ItlAWDL::BaFilterState{};
        awdlCoexBaAnswerLength = 0;
        awdlCoexBaTxState = kCoexBaTxOff;
        awdlCoexBaTxQueue = -1;
        awdlCoexBaTidTeardown = 0;
        awdlCoexBaRxIdleTids = 0;
        awdlCoexQueue = -1;
        awdlCoexTxSetupTried = 0;
        awdlCoexGeneration = sc->sc_generation;
        ++awdlCoexToken;
    }
    if (add == awdlCoexAdded)
        return 0;
    if (awdlCoexRemovingGen == gen || (add && awdlCoexAddingGen == gen))
        return EBUSY;
    // Anything that was waiting on the firmware for the old state sees this and stops.
    const uint32_t tok = ++awdlCoexToken;
    // While adding: no second add, and a removal request makes this add roll back. Cleared on every return.
    struct AddingScope {
        bool on;
        uint32_t owner;
        ItlIwx *driver;
        explicit AddingScope(bool a, int g, ItlIwx *d) : on(a), owner(0), driver(d) {
            if (on) {
                owner = ++awdlCoexAddingNext;
                awdlCoexAddingOwner = owner;
                awdlCoexAddingGen = g;
                awdlCoexRemoveRequested = false;
            }
        }
        // Clears only its own record: an old add waking after a restart leaves a newer add's guard alone.
        ~AddingScope() {
            if (on && awdlCoexAddingOwner == owner) {
                awdlCoexAddingGen = -1;
                awdlCoexAddingOwner = 0;
                driver->getMainCommandGate()->commandWakeup(&awdlCoexAddingGen);
            }
        }
    } addingScope(add, gen, this);
    // Each firmware command can sleep in the gate. After each, the add goes on only for the same listener
    // operation, firmware and association, with no removal or detach meanwhile; the BSS node is fetched again.
    // The association this add is for: its node, the station's PHY context, and the station's MAC id.
    const struct ieee80211_node *addBss = ic->ic_bss;
    const struct iwx_phy_ctxt *addStationPhy = in->in_phyctxt;
    const uint32_t addStationMac = IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color);
    auto stillWanted = [&]() {
        if (ic->ic_bss != addBss)
            return false;
        in = (struct iwx_node *)ic->ic_bss;
        if (!in || in->in_phyctxt != addStationPhy || IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color) != addStationMac)
            return false;
        // A station transition withdraws eligibility before sleeping; removal
        // also changes the token so this add rolls back before the station goes.
        return tok == awdlCoexToken && gen == sc->sc_generation && awdlCoexStationReadyGen == gen &&
            awdlCoexStationTransitionGen != gen && !awdlStopping && !awdlCoexRemoveRequested &&
            in && in->in_phyctxt;
    };
    // Its own context on channel 6 when asked for and allowed (the firmware marks 6 active, no radar, and
    // schedules bindings itself); otherwise the station's. Removal uses whichever add chose.
    bool multi = add ? false : awdlCoexMultiActive;
    if (add)
        awdlCoexOwnChan = nullptr;
        awdlCoexMovePending = false;
    if (add && awdlCoexMulti) {
        uint8_t ownWidth = IWX_PHY_VHT_CHANNEL_MODE20;
        const int ownNumber = awdlCoexPickOwn(sc, &ownWidth);
        if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DYNAMIC_QUOTA)) {
            awdlCoexMultiState = "no-dynamic-quota";
        } else if (awdlCoexPhyUncertainGen == gen) {
            awdlCoexMultiState = "phy-uncertain";
        } else if (ownNumber) {
            struct ieee80211_channel *target = &ic->ic_channels[ownNumber];
            struct iwx_phy_ctxt *own = &sc->sc_phyctxt[kAwdlCoexPhyId];
            struct ieee80211_channel *before = own->channel;
            own->channel = target;
            awdlCoexPhyWidth = ownWidth;
            const int phyErr = iwx_phy_ctxt_cmd(sc, own, 1, 1, IWX_FW_CTXT_ACTION_MODIFY, 0);
            awdlCoexPhyWidth = -1;
            awdlCoexPhyResult = phyErr ? 0x80000000U | uint32_t(phyErr) : 1;
            if (gen != sc->sc_generation)
                return ECANCELED;
            if (phyErr) {
                // No answer to read: the firmware's context may or may not have moved. Keep it reserved.
                own->channel = before;
                awdlCoexPhyUncertainGen = gen;
                if (ownWidth == IWX_PHY_VHT_CHANNEL_MODE80)
                    awdlCoexWide80FailedGen = gen;
                awdlCoexMultiState = "phy-uncertain";
            } else {
                multi = true;
                awdlCoexOwnChan = target;
                awdlCoexOwnWidth = ownWidth == IWX_PHY_VHT_CHANNEL_MODE80 ? 80 : 20;
                awdlCoexLastMoveUS = awdlUptimeUS();
            }
            if (!stillWanted()) {
                awdlCoexOwnChan = nullptr;
                awdlCoexMovePending = false;
                awdlCoexMultiState = "add-cancelled";
                awdlCoexPublish();
                return ECANCELED;
            }
        } else {
            awdlCoexMultiState = "fallback-same";
        }
    }
    struct iwx_phy_ctxt *phy = multi ? &sc->sc_phyctxt[kAwdlCoexPhyId] : in->in_phyctxt;
    struct iwx_binding_cmd bind;
    memset(&bind, 0, sizeof(bind));
    bind.id_and_color = htole32(IWX_FW_CMD_ID_AND_COLOR(phy->id, phy->color));
    bind.action = htole32(IWX_FW_CTXT_ACTION_MODIFY);
    bind.phy = htole32(IWX_FW_CMD_ID_AND_COLOR(phy->id, phy->color));
    bind.macs[0] = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
    for (int i = 1; i < IWX_MAX_MACS_IN_BINDING; i++)
        bind.macs[i] = htole32(IWX_FW_CTXT_INVALID);
    bind.lmac_id = htole32(IEEE80211_IS_CHAN_2GHZ(phy->channel) ||
                           !isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CDB_SUPPORT) ?
                           IWX_LMAC_24G_INDEX : IWX_LMAC_5G_INDEX);
    if (multi) {
        // Its own binding: the listener alone on its own PHY context. The station's binding is untouched.
        bind.action = htole32(add ? IWX_FW_CTXT_ACTION_ADD : IWX_FW_CTXT_ACTION_REMOVE);
        bind.macs[0] = htole32(IWX_FW_CTXT_INVALID);
    }
    int err = 0;
    uint32_t status = 0;
    if (add) {
        err = awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_ADD);
        awdlCoexMacResult = err ? 0x80000000U | uint32_t(err) : 1;
        if (gen != sc->sc_generation)
            return err ? err : ECANCELED;
        if (!err && !stillWanted()) {
            // Made for a listener that is no longer wanted: take it away again.
            if (awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_REMOVE) && gen == sc->sc_generation) {
                ++awdlCoexTeardownErrors;
                awdlCoexBrokenGeneration = gen;
            }
            if (gen == sc->sc_generation) {
                if (multi)
                    awdlCoexMultiState = "add-cancelled";
                awdlCoexPublish();
            }
            return ECANCELED;
        }
        if (err) {
            // This command has no response to read, so a failure doesn't say whether the firmware made
            // the context. Don't add it again until the firmware restarts.
            ++awdlCoexTeardownErrors;
            awdlCoexBrokenGeneration = gen;
            awdlCoexPublish();
            return err;
        }
        bind.macs[multi ? 0 : 1] = htole32(IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0));
        err = iwx_send_cmd_pdu_status(sc, IWX_BINDING_CONTEXT_CMD, sizeof(bind), &bind, &status);
        // A transport failure, unlike a refusal in the answer, doesn't say whether the binding exists.
        const bool bindAmbiguous = err != 0;
        awdlCoexBindStatus = status;
        if (multi)
            awdlCoexMultiBindResult = err ? 0x80000000U | uint32_t(err) : (status ? 0x40000000U | status : 1);
        if (!err && status)
            err = EIO;
        awdlCoexBindResult = err ? 0x80000000U | uint32_t(err) : 1;
        if (err) {
            // Leave no context the binding doesn't know about. If that fails too, the firmware may still
            // have it, so nothing is added again until the firmware restarts.
            if (gen == sc->sc_generation &&
                (awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_REMOVE) || bindAmbiguous) && gen == sc->sc_generation) {
                ++awdlCoexTeardownErrors;
                awdlCoexBrokenGeneration = gen;
                if (multi)
                    awdlCoexPhyUncertainGen = gen;
            }
            awdlCoexPublish();
            return err;
        }
        // -itlawdlcoexlowlat: before the last ownership check, so a removal or reassociation during this
        // firmware wait is caught by the rollback below and the listener is never published for it.
        if (awdlCoexLowLatency && multi && gen == sc->sc_generation) {
            // An unlisted command counts as version 1, the only layout there is, when the firmware has the
            // capability iwlmvm sends it on. Without the capability nothing is sent.
            uint8_t llVer = iwx_lookup_cmd_ver(sc, IWX_MAC_CONF_GROUP, kIwxLowLatencyCmd);
            const bool llCapable = isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DYNAMIC_QUOTA);
            if (llVer == IWX_FW_CMD_VER_UNKNOWN && llCapable)
                llVer = 1;
            if (!llCapable) {
                awdlCoexLowLatencyResult = 0x10000000U; // No dynamic quota: iwlmvm wouldn't send it either.
            } else if (llVer == IWX_FW_CMD_VER_UNKNOWN) {
                awdlCoexLowLatencyResult = 0x40000000U; // The firmware doesn't list the command.
            } else if (llVer != 1) {
                awdlCoexLowLatencyResult = 0x20000000U | llVer; // Only the known 8-byte v1 layout is sent.
            } else {
                struct iwx_mac_low_latency_cmd ll = {};
                ll.mac_id = htole32(kAwdlCoexMacId);
                ll.low_latency_rx = 1;
                ll.low_latency_tx = 1;
                const int llErr = iwx_send_cmd_pdu(sc, iwx_cmd_id(kIwxLowLatencyCmd, IWX_MAC_CONF_GROUP, 0), 0,
                                                   sizeof(ll), &ll);
                // The command was taken; whether the firmware changed airtime isn't observable here.
                awdlCoexLowLatencyResult = llErr ? 0x80000000U | uint32_t(llErr) : (0x100U | llVer);
            }
        }
        if (gen != sc->sc_generation)
            return ECANCELED;
        if (!stillWanted()) {
            // Bound for a listener that is no longer wanted: unbind, then remove it.
            struct iwx_binding_cmd undo = bind;
            if (multi) {
                undo.action = htole32(IWX_FW_CTXT_ACTION_REMOVE);
                undo.macs[0] = htole32(IWX_FW_CTXT_INVALID);
            } else {
                undo.macs[1] = htole32(IWX_FW_CTXT_INVALID);
            }
            uint32_t undoStatus = 0;
            int undoErr = iwx_send_cmd_pdu_status(sc, IWX_BINDING_CONTEXT_CMD, sizeof(undo), &undo, &undoStatus);
            if (!undoErr && undoStatus)
                undoErr = EIO;
            if (gen == sc->sc_generation && !undoErr)
                undoErr = awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_REMOVE);
            if (undoErr && gen == sc->sc_generation) {
                ++awdlCoexTeardownErrors;
                awdlCoexBrokenGeneration = gen;
            }
            if (gen == sc->sc_generation) {
                if (multi)
                    awdlCoexMultiState = "add-cancelled";
                awdlCoexPublish();
            }
            return ECANCELED;
        }
        awdlCoexAdded = true;
        awdlCoexMultiActive = multi;
        if (multi)
            awdlCoexMultiState = "own-channel";

        if (awdlCoexAdds) {
            if (awdlCoexLostToRestart)
                ++awdlCoexAddsAfterRestart;
            else
                ++awdlCoexAddsAfterRemove;
        }
        awdlCoexLostToRestart = false;
        ++awdlCoexAdds;
        awdlCoexAddrApplied = awdlCoexAddrKnown;
        memcpy(awdlCoexAddrInFirmware, awdlCoexAddr, sizeof(awdlCoexAddrInFirmware));
        awdlCoexChannel = ieee80211_chan2ieee(ic, phy->channel);
        if (awdlCoexTx) {
            // Our frames name the channel we're on: the station's.
            awdlFixedChannel = awdlCoexChannel;
            awdlCoexTxSetupTried = 0;
        }
    } else {
        // Its station (and with it its queue) first, then the station's binding again, then the listener.
        // The listener is unavailable from here on: no new TX or setup starts while these commands wait.
        // A command can sleep in the gate. If the firmware restarted meanwhile, everything is gone already,
        // and the new generation's state, which may already be set up again, is left alone.
        awdlCoexAdded = false;
        awdlCoexAddrApplied = false;
        awdlCoexOwnChan = nullptr;
        awdlCoexMovePending = false;
        if (awdlCoexMultiActive)
            awdlCoexMultiState = "removed";
        awdlCoexMultiActive = false;
        awdlCoexRemovingGen = gen;
        awdlCoexBaRemovePeer(sc);
        if (gen != sc->sc_generation)
            return 0;
        const int txErr = awdlCoexTxTeardown(sc);
        if (gen != sc->sc_generation)
            return 0;
        err = iwx_send_cmd_pdu_status(sc, IWX_BINDING_CONTEXT_CMD, sizeof(bind), &bind, &status);
        if (!err && status)
            err = EIO;
        if (gen != sc->sc_generation)
            return 0;
        const int macErr = awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_REMOVE);
        if (gen != sc->sc_generation)
            return 0;
        // The host can't take the context back by itself, so it forgets it either way; but after any
        // failure nothing is added again until the firmware restarts.
        awdlCoexRemovingGen = -1;
        getMainCommandGate()->commandWakeup(&awdlCoexAddingGen);
        ++awdlCoexRemoves;
        if (!err)
            err = macErr;
        if (!err)
            err = txErr;
        if (err) {
            ++awdlCoexTeardownErrors;
            awdlCoexBrokenGeneration = gen;
        }
    }
    awdlCoexPublish();
    return err;
}

// The listener's station and queue. The station has no peer address: like the monitor's, it sends
// to anyone, at fixed rates. With this firmware the queue goes when the station is removed.
int ItlIwx::
awdlCoexTxSetup(struct iwx_softc *sc)
{
    const int gen = sc->sc_generation;
    if (awdlCoexStationTransitionGen == gen || awdlCoexTxSettingUpGen == gen || awdlCoexRemovingGen == gen)
        return EBUSY;
    if (awdlCoexStationReadyGen != gen || sc->sc_ic.ic_state != IEEE80211_S_RUN ||
        !awdlCoexAdded || awdlCoexGeneration != gen || awdlCoexRemoveRequested || awdlStopping ||
        (sc->sc_flags & IWX_FLAG_SHUTDOWN) || awdlCoexBrokenGeneration == gen)
        return ECANCELED;
    // Removal waits for this entire operation, including the unpublished station's
    // rollback. Neither setup nor its queue allocator calls listener removal.
    struct SetupScope {
        ItlIwx *driver;
        uint32_t owner;
        explicit SetupScope(ItlIwx *d, int g) : driver(d), owner(++awdlCoexTxSettingUpNext) {
            awdlCoexTxSettingUpOwner = owner;
            awdlCoexTxSettingUpGen = g;
        }
        ~SetupScope() {
            // A stale setup must not clear a newer generation's operation.
            if (awdlCoexTxSettingUpOwner == owner) {
                awdlCoexTxSettingUpGen = -1;
                awdlCoexTxSettingUpOwner = 0;
                driver->getMainCommandGate()->commandWakeup(&awdlCoexAddingGen);
            }
        }
    } setupScope(this, gen);
    struct iwx_add_sta_cmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.sta_id = IWX_MONITOR_STA_ID;
    cmd.station_type = IWX_STA_GENERAL_PURPOSE;
    cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(kAwdlCoexMacId, 0));
    IEEE80211_ADDR_COPY(&cmd.addr, etheranyaddr);
    cmd.tid_disable_tx = htole16(0xffff);
    cmd.station_flags = htole32(IWX_STA_FLG_FAT_EN_20MHZ | IWX_STA_FLG_MIMO_EN_SISO);
    cmd.station_flags_msk = htole32(IWX_STA_FLG_FAT_EN_MSK | IWX_STA_FLG_MIMO_EN_MSK);
    // Who this setup is for. Each firmware command can sleep in the gate, and on return the listener
    // may be gone, the association changed, the firmware restarted or the driver detaching.
    const uint32_t token = awdlCoexToken;
    auto stillOurs = [&]() {
        return token == awdlCoexToken && gen == sc->sc_generation && awdlCoexStationReadyGen == gen &&
            awdlCoexStationTransitionGen != gen && awdlCoexAdded && !awdlStopping;
    };
    struct iwx_rm_sta_cmd rm;
    memset(&rm, 0, sizeof(rm));
    rm.sta_id = IWX_MONITOR_STA_ID;
    // Each attempt's diagnostics start fresh, all together.
    ++awdlCoexSetupAttempts;
    awdlCoexQueueStage = "not-tried";
    awdlCoexQueueAssigned = -1;
    awdlCoexQueueWritePointer = 0xffffffffU;
    awdlCoexStaResult = 0;
    awdlCoexQueueResult = 0;
    uint32_t status = IWX_ADD_STA_SUCCESS;
    const int transportErr = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
    int err = transportErr;
    if (!err && (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS)
        err = EIO;
    awdlCoexStaResult = err ? 0x80000000U | uint32_t(err) | (status << 8) | (transportErr ? 0x40000000U : 0U) : 1;
    if (err) {
        // A refusal in the response leaves nothing behind. A transport failure doesn't say, so in the same
        // firmware nothing is tried again until it restarts.
        if (transportErr && gen == sc->sc_generation) {
            ++awdlCoexTeardownErrors;
            awdlCoexBrokenGeneration = gen;
        }
        awdlCoexPublish();
        return err;
    }
    if (!stillOurs()) {
        // The station was added for a listener that is gone. Within the same firmware, remove it.
        ++awdlCoexSetupAborts;
        awdlCoexQueueStage = "aborted";
        if (gen == sc->sc_generation && iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm), &rm) &&
            gen == sc->sc_generation) {
            ++awdlCoexTeardownErrors;
            awdlCoexBrokenGeneration = gen;
        }
        awdlCoexPublish();
        return ECANCELED;
    }
    awdlCoexQueueStage = "pending";
    awdlCoexSetupToken = token;
    awdlCoexSetupGen = gen;
    const int queue = iwx_tvqm_enable_txq(sc, IWX_MGMT_TID, 0, IWX_DEFAULT_QUEUE_SIZE, IWX_MONITOR_STA_ID);
    awdlCoexQueueResult = queue < 0 ? 0x80000000U | uint32_t(-queue) : uint32_t(queue);
    if (queue < 0) {
        // A failure before the firmware was asked leaves the stage at "pending".
        if (!strcmp(awdlCoexQueueStage, "pending"))
            awdlCoexQueueStage = "preflight";
        // The station, and any queue the firmware made for it, has to go. If removing it fails, the
        // firmware may still own both, so setup stops until the firmware restarts. After a restart
        // there is nothing to remove.
        if (gen == sc->sc_generation && iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm), &rm) &&
            gen == sc->sc_generation) {
            ++awdlCoexTeardownErrors;
            awdlCoexBrokenGeneration = gen;
        }
        awdlCoexPublish();
        return -queue;
    }
    if (!stillOurs()) {
        // The queue exists, but its listener is gone. Remove the station (and with it the queue); free
        // the ring only if that worked, otherwise keep it as an orphan for the next reset.
        ++awdlCoexSetupAborts;
        awdlCoexQueueStage = "aborted";
        if (gen == sc->sc_generation) {
            if (iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm), &rm)) {
                if (gen == sc->sc_generation) {
                    ++awdlCoexTeardownErrors;
                    awdlCoexBrokenGeneration = gen;
                    awdlCoexOrphanQueue = queue;
                }
            } else if (gen == sc->sc_generation) {
                iwx_reset_tx_ring(sc, &sc->txq[queue]);
            }
        }
        awdlCoexPublish();
        return ECANCELED;
    }
    awdlCoexQueue = queue;
    awdlCoexInFlight = false;
    awdlCoexTxHalted = false;
    // A new queue: no stall history or pause from an earlier one.
    awdlCoexLastCompletionUS = 0;
    awdlCoexTxPauseUntilUS = 0;
    awdlCoexStuckStreak = 0;
    awdlCoexTxStaAdded = true;
    awdlCoexPublish();
    return 0;
}

int ItlIwx::
awdlCoexTxTeardown(struct iwx_softc *sc)
{
    if (!awdlCoexTxStaAdded)
        return 0;
    const int gen = sc->sc_generation;
    const int flushErr = iwx_flush_sta_tids(sc, IWX_MONITOR_STA_ID, 0xffff);
    struct iwx_rm_sta_cmd rm;
    memset(&rm, 0, sizeof(rm));
    rm.sta_id = IWX_MONITOR_STA_ID;
    // After a firmware restart the station is gone, and the restart resets the ring.
    const int rmErr = gen == sc->sc_generation ? iwx_send_cmd_pdu(sc, IWX_REMOVE_STA, 0, sizeof(rm), &rm) : 0;
    // A firmware restart while waiting: the restart resets the ring, and the new generation's state is
    // left alone.
    if (gen != sc->sc_generation)
        return 0;
    // Only when the firmware has let go of the queue is the ring freed here, with its node references.
    // Otherwise it is kept as an orphan: a late completion or a later reset still knows it is ours.
    if (awdlCoexQueue >= 0 && awdlCoexQueue < int(nitems(sc->txq))) {
        if (!flushErr && !rmErr)
            iwx_reset_tx_ring(sc, &sc->txq[awdlCoexQueue]);
        else
            awdlCoexOrphanQueue = awdlCoexQueue;
    }
    awdlCoexTxStaAdded = false;
    awdlCoexInFlight = false;
    awdlCoexTxHalted = false;
    awdlCoexPendingSlot = -1;
    awdlCoexQueue = -1;
    awdlCoexPublish();
    return flushErr ? flushErr : rmErr;
}

void ItlIwx::
awdlCoexTxSend(struct iwx_softc *sc)
{
#if defined(ITL_AWDL_NATIVE)
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    if (!in || !in->in_phyctxt || !in->in_phyctxt->channel)
        return;
    const uint32_t token = awdlCoexToken;
    const int gen = sc->sc_generation;
    {
        // A channel our frames can't describe, or one the firmware won't let us start on, is refused
        // before anything is built or the firmware's address is changed. Checked again before sending.
        if (!awdlCoexChannelEligible(ic, awdlCoexMultiActive ? sc->sc_phyctxt[kAwdlCoexPhyId].channel :
                                     in->in_phyctxt->channel, "before-build", gen))
            return;
    }
    mbuf_t packet = nullptr;
    const IOReturn built = itlAWDLBuildSyncProbe(getController(), &packet, awdlUptimeUS());
    if (built != kIOReturnSuccess || !packet || mbuf_len(packet) < 24) {
        awdlCoexLastBuildResult = uint32_t(built);
        if (built == kIOReturnNotReady)
            ++awdlCoexTxNotReady;
        else
            ++awdlCoexTxBuildRejected;
        if (packet)
            mbuf_freem(packet);
        return;
    }
    ++awdlCoexTxBuilt;
    // The last result describes the latest attempt: a success clears the not-ready result from before
    // macOS sent its template, which otherwise read as a failure while frames were going out (#7).
    awdlCoexLastBuildResult = kIOReturnSuccess;
    const uint8_t *frame = static_cast<const uint8_t *>(mbuf_data(packet));
    // The firmware ACKs only its context's address, so that has to be the one macOS sends from. The wanted
    // address and the one the firmware has are kept apart; nothing goes out until they match.
    memcpy(awdlCoexAddr, frame + 10, sizeof(awdlCoexAddr));
    awdlCoexAddrKnown = true;
    memcpy(awdlOwnAddress, awdlCoexAddr, sizeof(awdlOwnAddress));
    if (!awdlCoexAddrApplied || memcmp(awdlCoexAddrInFirmware, awdlCoexAddr, sizeof(awdlCoexAddr))) {
        // The address placed in the command, in case the wanted one changes while it waits.
        uint8_t sent[6];
        memcpy(sent, awdlCoexAddr, sizeof(sent));
        const int modifyErr = awdlCoexMacSend(sc, IWX_FW_CTXT_ACTION_MODIFY);
        // Commit nothing for a listener that went away while the command waited.
        if (token != awdlCoexToken || gen != sc->sc_generation || awdlStopping || !awdlCoexAdded) {
            mbuf_freem(packet);
            return;
        }
        if (modifyErr) {
            ++awdlCoexAddrFailures;
            awdlCoexAddrApplied = false;
            mbuf_freem(packet);
            return;
        }
        ++awdlCoexAddrChanges;
        memcpy(awdlCoexAddrInFirmware, sent, sizeof(awdlCoexAddrInFirmware));
        awdlCoexAddrApplied = !memcmp(sent, awdlCoexAddr, sizeof(sent));
        // MODIFY waited on the firmware: check everything again, and fetch the node afresh.
        in = (struct iwx_node *)ic->ic_bss;
        if (!awdlCoexAddrApplied || token != awdlCoexToken || gen != sc->sc_generation || awdlStopping || !awdlCoexAdded ||
            !awdlCoexTxStaAdded || ic->ic_state != IEEE80211_S_RUN || !in || !in->in_phyctxt ||
            !in->in_phyctxt->channel) {
            mbuf_freem(packet);
            return;
        }
    }
    // The firmware's regulatory decision stands: nothing is started on a channel it marks passive.
    if (!awdlCoexChannelEligible(ic, awdlCoexMultiActive ? sc->sc_phyctxt[kAwdlCoexPhyId].channel :
                                 in->in_phyctxt->channel, "before-send", gen)) {
        mbuf_freem(packet);
        return;
    }
    auto *node = ieee80211_ref_node(ic->ic_bss);
    awdlCoexSending = true;
    const int err = iwx_tx(sc, packet, node, EDCA_AC_BE, awdlCoexQueue);
    awdlCoexSending = false;
    if (err) {
        ieee80211_release_node(ic, node);
        ++awdlCoexTxSubmitErrors;
        return;
    }
    ++awdlCoexTxSubmitted;
    awdlCoexInFlight = true;
    awdlCoexInFlightUS = awdlUptimeUS();
#endif
}

int ItlIwx::
iwx_run_stop(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int err, i;
    
    splassert(IPL_NET);
    
    err = iwx_flush_sta(sc, in);
    if (err) {
        XYLog("%s: could not flush Tx path (error %d)\n",
              __FUNCTION__, err);
        return err;
    }
    
    /*
     * Stop Rx BA sessions now. We cannot rely on the BA task
     * for this when moving out of RUN state since it runs in a
     * separate thread.
     * Note that in->in_ni (struct ieee80211_node) already represents
     * our new access point in case we are roaming between APs.
     * This means we cannot rely on struct ieee802111_node to tell
     * us which BA sessions exist.
     */
    for (i = 0; i < nitems(sc->sc_rxba_data); i++) {
        struct iwx_rxba_data *rxba = &sc->sc_rxba_data[i];
        if (rxba->baid == IWX_RX_REORDER_DATA_INVALID_BAID)
            continue;
        err = iwx_sta_rx_agg(sc, ic->ic_bss, rxba->tid, 0, 0, 0, 0);
        if (err)
            return err;
    }
    
    err = iwx_sf_config(sc, IWX_SF_INIT_OFF);
    if (err)
        return err;
    
    err = iwx_disable_beacon_filter(sc);
    if (err) {
        XYLog("%s: could not disable beacon filter (error %d)\n",
              DEVNAME(sc), err);
        return err;
    }
    
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DYNAMIC_QUOTA)) {
        err = iwx_update_quotas(sc, in, 0);
        if (err) {
            XYLog("%s: could not update quotas (error %d)\n",
                  DEVNAME(sc), err);
            return err;
        }
    }
    
    err = iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_MODIFY, 0);
    if (err) {
        XYLog("%s: failed to update MAC\n", DEVNAME(sc));
        return err;
    }
    
    /* Reset Tx chains in case MIMO was enabled. */
    if ((in->in_ni.ni_flags & IEEE80211_NODE_HT) &&
        iwx_mimo_enabled(sc)) {
        err = iwx_phy_ctxt_update(sc, &sc->sc_phyctxt[0],
                                  in->in_ni.ni_chan, 1, 1, 0);
        if (err) {
            XYLog("%s: failed to update PHY\n", DEVNAME(sc));
            return err;
        }
    }
    
    return 0;
}

struct ieee80211_node *ItlIwx::
iwx_node_alloc(struct ieee80211com *ic)
{
    return (struct ieee80211_node *)malloc(sizeof (struct iwx_node), 0, M_NOWAIT | M_ZERO);
}

int ItlIwx::
iwx_set_key(struct ieee80211com *ic, struct ieee80211_node *ni,
            struct ieee80211_key *k)
{
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    struct iwx_add_sta_key_cmd cmd;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (k->k_cipher != IEEE80211_CIPHER_CCMP) {
        /* Fallback to software crypto for other ciphers. */
        return (ieee80211_set_key(ic, ni, k));
    }
    
    memset(&cmd, 0, sizeof(cmd));
    
    cmd.common.key_flags = htole16(IWX_STA_KEY_FLG_CCM |
                                   IWX_STA_KEY_FLG_WEP_KEY_MAP |
                                   ((k->k_id << IWX_STA_KEY_FLG_KEYID_POS) &
                                    IWX_STA_KEY_FLG_KEYID_MSK));
    if (k->k_flags & IEEE80211_KEY_GROUP) {
        cmd.common.key_offset = 1;
        cmd.common.key_flags |= htole16(IWX_STA_KEY_MULTICAST);
    } else
        cmd.common.key_offset = 0;
    
    memcpy(cmd.common.key, k->k_key, MIN(sizeof(cmd.common.key), k->k_len));
    cmd.common.sta_id = IWX_STATION_ID;
    
    cmd.transmit_seq_cnt = htole64(k->k_tsc);
    
    return that->iwx_send_cmd_pdu(sc, IWX_ADD_STA_KEY, IWX_CMD_ASYNC,
                            sizeof(cmd), &cmd);
}

void ItlIwx::
iwx_delete_key(struct ieee80211com *ic, struct ieee80211_node *ni,
               struct ieee80211_key *k)
{
    struct iwx_softc *sc = (struct iwx_softc *)ic->ic_softc;
    struct iwx_add_sta_key_cmd cmd;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    if (k->k_cipher != IEEE80211_CIPHER_CCMP) {
        /* Fallback to software crypto for other ciphers. */
        ieee80211_delete_key(ic, ni, k);
        return;
    }
    
    memset(&cmd, 0, sizeof(cmd));
    
    cmd.common.key_flags = htole16(IWX_STA_KEY_NOT_VALID |
                                   IWX_STA_KEY_FLG_NO_ENC | IWX_STA_KEY_FLG_WEP_KEY_MAP |
                                   ((k->k_id << IWX_STA_KEY_FLG_KEYID_POS) &
                                    IWX_STA_KEY_FLG_KEYID_MSK));
    memcpy(cmd.common.key, k->k_key, MIN(sizeof(cmd.common.key), k->k_len));
    if (k->k_flags & IEEE80211_KEY_GROUP)
        cmd.common.key_offset = 1;
    else
        cmd.common.key_offset = 0;
    cmd.common.sta_id = IWX_STATION_ID;
    
    that->iwx_send_cmd_pdu(sc, IWX_ADD_STA_KEY, IWX_CMD_ASYNC, sizeof(cmd), &cmd);
}

int ItlIwx::
iwx_media_change(struct _ifnet *ifp)
{
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    struct ieee80211com *ic = &sc->sc_ic;
    uint8_t rate, ridx;
    int err;
    
    err = ieee80211_media_change(ifp);
    if (err != ENETRESET)
        return err;
    
    if (ic->ic_fixed_mcs != -1)
        sc->sc_fixed_ridx = iwx_mcs2ridx[ic->ic_fixed_mcs];
    else if (ic->ic_fixed_rate != -1) {
        rate = ic->ic_sup_rates[ic->ic_curmode].
        rs_rates[ic->ic_fixed_rate] & IEEE80211_RATE_VAL;
        /* Map 802.11 rate to HW rate index. */
        for (ridx = 0; ridx <= IWX_RIDX_MAX; ridx++)
            if (iwx_rates[ridx].rate == rate)
                break;
        sc->sc_fixed_ridx = ridx;
    }
    
    if ((ifp->if_flags & (IFF_UP | IFF_RUNNING)) ==
        (IFF_UP | IFF_RUNNING)) {
        iwx_stop(ifp);
        err = iwx_init(ifp);
    }
    return err;
}

void ItlIwx::
iwx_newstate_task(void *psc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)psc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                iwx_newstate_task(arg0);
                return kIOReturnSuccess;
            }, psc);
        return;
    }
    struct ieee80211com *ic = &sc->sc_ic;
    enum ieee80211_state nstate = sc->ns_nstate;
    enum ieee80211_state ostate = ic->ic_state;
    int generation = sc->sc_generation;
    int arg = sc->ns_arg;
    int err = 0, s = splnet();
    
    XYLog("%s sc->sc_flags & IWX_FLAG_SHUTDOWN %s\n", __FUNCTION__, sc->sc_flags & IWX_FLAG_SHUTDOWN ? "true" : "false");
    if (sc->sc_flags & IWX_FLAG_SHUTDOWN) {
        /* iwx_stop() is waiting for us. */
        //        refcnt_rele_wake(&sc->task_refs);
        splx(s);
        return;
    }
    // Own the complete station transition, not just listener teardown. Firmware
    // waits below leave ic_state at RUN until the final net80211 commit, so the
    // cycle task must not use that old state to recreate a listener meanwhile.
    // newstate tasks are serialized on systq; never drop a requested transition.
    struct StationTransitionScope {
        uint32_t owner;
        explicit StationTransitionScope(int gen) : owner(++awdlCoexStationTransitionNext) {
            awdlCoexStationTransitionOwner = owner;
            awdlCoexStationTransitionGen = gen;
            awdlCoexStationReadyGen = -1;
        }
        void finish() {
            if (awdlCoexStationTransitionOwner == owner) {
                awdlCoexStationTransitionGen = -1;
                awdlCoexStationTransitionOwner = 0;
            }
        }
        ~StationTransitionScope() { finish(); }
    } stationTransition(generation);

    if (ostate == IEEE80211_S_SCAN) {
        if (nstate == ostate) {
            if (sc->sc_flags & IWX_FLAG_SCANNING) {
                //                refcnt_rele_wake(&sc->task_refs);
                splx(s);
                return;
            }
            /* Firmware is no longer scanning. Do another scan. */
            goto next_scan;
        }
    }
    
    if (nstate <= ostate) {
        switch (ostate) {
            case IEEE80211_S_RUN:
                // Reassociation must not inherit a listener that is still owned by the
                // previous station context.  Use the actual listener state rather than
                // only the boot-time probe flag: an in-flight add or queue can survive
                // the flag's intended lifetime and block the next association.
                if (awdlCoexAdded || awdlCoexAddingGen == sc->sc_generation || awdlCoexTxStaAdded ||
                    awdlCoexRemovingGen == sc->sc_generation || awdlCoexTxSettingUpGen == sc->sc_generation) {
                    err = that->awdlCoexListener(sc, false);
                    // Listener commands and completion waits drop the gate. Never
                    // stop the new firmware generation's station on their return.
                    if (generation != sc->sc_generation || (sc->sc_flags & IWX_FLAG_SHUTDOWN))
                        goto out;
                    if (err) {
                        // AWDL is optional: quarantine it for this firmware generation,
                        // but do not turn a station reassociation into a firmware reset.
                        awdlCoexBrokenGeneration = generation;
                        awdlCoexPublish();
                        err = 0;
                    }
                }
                err = that->iwx_run_stop(sc);
                if (generation != sc->sc_generation || (sc->sc_flags & IWX_FLAG_SHUTDOWN))
                    goto out;
                if (err)
                    goto out;
                /* FALLTHROUGH */
            case IEEE80211_S_ASSOC:
            case IEEE80211_S_AUTH:
                if (nstate <= IEEE80211_S_AUTH) {
                    err = that->iwx_deauth(sc);
                    if (err)
                        goto out;
                }
                /* FALLTHROUGH */
            case IEEE80211_S_SCAN:
            case IEEE80211_S_INIT:
                break;
        }
        
        /* Die now if iwx_stop() was called while we were sleeping. */
        if (generation != sc->sc_generation || (sc->sc_flags & IWX_FLAG_SHUTDOWN)) {
            //            refcnt_rele_wake(&sc->task_refs);
            splx(s);
            return;
        }
    }
    
    switch (nstate) {
        case IEEE80211_S_INIT:
            break;
            
        case IEEE80211_S_SCAN:
        next_scan:
            err = that->iwx_scan(sc);
            if (err)
                break;
            //        refcnt_rele_wake(&sc->task_refs);
            splx(s);
            return;
            
        case IEEE80211_S_AUTH:
            err = that->iwx_auth(sc);
            break;
            
        case IEEE80211_S_ASSOC:
            err = that->iwx_rs_init(sc, (iwx_node *)ic->ic_bss, false);
            if (err) {
                XYLog("%s: could not init rate scaling (error %d)\n",
                      DEVNAME(sc), err);
                goto out;
            }
            break;
            
        case IEEE80211_S_RUN:
            err = that->iwx_run(sc);
            break;
    }
    
out:
    if (generation == sc->sc_generation && (sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0) {
        if (err)
            task_add(systq, &sc->init_task);
        else {
            sc->sc_newstate(ic, nstate, arg);
            if (nstate == IEEE80211_S_RUN && ic->ic_state == IEEE80211_S_RUN &&
                generation == sc->sc_generation && !(sc->sc_flags & IWX_FLAG_SHUTDOWN) &&
                awdlCoexStationTransitionOwner == stationTransition.owner) {
                awdlCoexStationReadyGen = generation;
                stationTransition.finish();
                // Probe failure never fails Wi-Fi. A concurrent exit cancels and
                // waits for this add just like any other listener operation.
                if (awdlCoexProbe && awdlCoexWant)
                    (void)that->awdlCoexListener(sc, true);
            }
        }
    }
    //    refcnt_rele_wake(&sc->task_refs);
    splx(s);
}

int ItlIwx::
iwx_newstate(struct ieee80211com *ic, enum ieee80211_state nstate, int arg)
{
    struct _ifnet *ifp = IC2IFP(ic);
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    struct ieee80211_node *ni = ic->ic_bss;
    
    // The AWDL receive test stays on its channels whatever macOS asks for.
    if (awdlRx && ic->ic_state == IEEE80211_S_RUN &&
        (nstate == IEEE80211_S_SCAN || nstate == IEEE80211_S_AUTH || nstate == IEEE80211_S_ASSOC))
        return 0;
    
    /*
     * Prevent attemps to transition towards the same state, unless
     * we are scanning in which case a SCAN -> SCAN transition
     * triggers another scan iteration. And AUTH -> AUTH is needed
     * to support band-steering.
     */
    if (sc->ns_nstate == nstate && nstate != IEEE80211_S_SCAN &&
        nstate != IEEE80211_S_AUTH)
        return 0;
    
    if (ic->ic_state == IEEE80211_S_RUN) {
        if (nstate == IEEE80211_S_SCAN) {
            /*
             * During RUN->SCAN we don't call sc_newstate() so
             * we must stop A-MPDU Tx ourselves in this case.
             */
            ieee80211_stop_ampdu_tx(ic, ni, -1);
            ieee80211_ba_del(ni);
        }
        that->iwx_del_task(sc, systq, &sc->ba_task);
        that->iwx_del_task(sc, systq, &sc->mac_ctxt_task);
        that->iwx_del_task(sc, systq, &sc->chan_ctxt_task);
    }
    
    sc->ns_nstate = nstate;
    sc->ns_arg = arg;
    
    that->iwx_add_task(sc, sc->sc_nswq, &sc->newstate_task);
    
    return 0;
}

void ItlIwx::
iwx_endscan(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    
    struct ieee80211_node *ni, *nextbs;
    
//    ni = RB_MIN(ieee80211_tree, &ic->ic_tree);
//    for (; ni != NULL; ni = nextbs) {
//        nextbs = RB_NEXT(ieee80211_tree, &ic->ic_tree, ni);
//        XYLog("%s scan_result ssid=%s, bssid=%s, ni_rsnciphers=%d, ni_rsncipher=%d, ni_rsngroupmgmtcipher=%d, ni_rsngroupcipher=%d, ni_rssi=%d,  ni_capinfo=%d, ni_intval=%d, ni_rsnakms=%d, ni_supported_rsnakms=%d, ni_rsnprotos=%d, ni_supported_rsnprotos=%d, ni_rstamp=%d\n", __FUNCTION__, ni->ni_essid, ether_sprintf(ni->ni_bssid), ni->ni_rsnciphers, ni->ni_rsncipher, ni->ni_rsngroupmgmtcipher, ni->ni_rsngroupcipher, ni->ni_rssi, ni->ni_capinfo, ni->ni_intval, ni->ni_rsnakms, ni->ni_supported_rsnakms, ni->ni_rsnprotos, ni->ni_supported_rsnprotos, ni->ni_rstamp);
//    }
    
    if ((sc->sc_flags & (IWX_FLAG_SCANNING | IWX_FLAG_BGSCAN)) == 0)
        return;
    
    sc->sc_flags &= ~(IWX_FLAG_SCANNING | IWX_FLAG_BGSCAN);
    ieee80211_end_scan(&ic->ic_if);
}

/*
 * Aging and idle timeouts for the different possible scenarios
 * in default configuration
 */
static const uint32_t
iwx_sf_full_timeout_def[IWX_SF_NUM_SCENARIO][IWX_SF_NUM_TIMEOUT_TYPES] = {
    {
        htole32(IWX_SF_SINGLE_UNICAST_AGING_TIMER_DEF),
        htole32(IWX_SF_SINGLE_UNICAST_IDLE_TIMER_DEF)
    },
    {
        htole32(IWX_SF_AGG_UNICAST_AGING_TIMER_DEF),
        htole32(IWX_SF_AGG_UNICAST_IDLE_TIMER_DEF)
    },
    {
        htole32(IWX_SF_MCAST_AGING_TIMER_DEF),
        htole32(IWX_SF_MCAST_IDLE_TIMER_DEF)
    },
    {
        htole32(IWX_SF_BA_AGING_TIMER_DEF),
        htole32(IWX_SF_BA_IDLE_TIMER_DEF)
    },
    {
        htole32(IWX_SF_TX_RE_AGING_TIMER_DEF),
        htole32(IWX_SF_TX_RE_IDLE_TIMER_DEF)
    },
};

/*
 * Aging and idle timeouts for the different possible scenarios
 * in single BSS MAC configuration.
 */
static const uint32_t
iwx_sf_full_timeout[IWX_SF_NUM_SCENARIO][IWX_SF_NUM_TIMEOUT_TYPES] = {
    {
        htole32(IWX_SF_SINGLE_UNICAST_AGING_TIMER),
        htole32(IWX_SF_SINGLE_UNICAST_IDLE_TIMER)
    },
    {
        htole32(IWX_SF_AGG_UNICAST_AGING_TIMER),
        htole32(IWX_SF_AGG_UNICAST_IDLE_TIMER)
    },
    {
        htole32(IWX_SF_MCAST_AGING_TIMER),
        htole32(IWX_SF_MCAST_IDLE_TIMER)
    },
    {
        htole32(IWX_SF_BA_AGING_TIMER),
        htole32(IWX_SF_BA_IDLE_TIMER)
    },
    {
        htole32(IWX_SF_TX_RE_AGING_TIMER),
        htole32(IWX_SF_TX_RE_IDLE_TIMER)
    },
};

void ItlIwx::
iwx_fill_sf_command(struct iwx_softc *sc, struct iwx_sf_cfg_cmd *sf_cmd,
                    struct ieee80211_node *ni)
{
    int i, j, watermark;
    
    sf_cmd->watermark[IWX_SF_LONG_DELAY_ON] = htole32(IWX_SF_W_MARK_SCAN);
    
    /*
     * If we are in association flow - check antenna configuration
     * capabilities of the AP station, and choose the watermark accordingly.
     */
    if (ni) {
        if (ni->ni_flags & IEEE80211_NODE_HT || ni->ni_flags & IEEE80211_NODE_VHT || ni->ni_flags & IEEE80211_NODE_HE) {
            if (ni->ni_rxmcs[1] != 0)
                watermark = IWX_SF_W_MARK_MIMO2;
            else
                watermark = IWX_SF_W_MARK_SISO;
        } else {
            watermark = IWX_SF_W_MARK_LEGACY;
        }
        /* default watermark value for unassociated mode. */
    } else {
        watermark = IWX_SF_W_MARK_MIMO2;
    }
    sf_cmd->watermark[IWX_SF_FULL_ON] = htole32(watermark);
    
    for (i = 0; i < IWX_SF_NUM_SCENARIO; i++) {
        for (j = 0; j < IWX_SF_NUM_TIMEOUT_TYPES; j++) {
            sf_cmd->long_delay_timeouts[i][j] =
            htole32(IWX_SF_LONG_DELAY_AGING_TIMER);
        }
    }
    
    if (ni) {
        memcpy(sf_cmd->full_on_timeouts, iwx_sf_full_timeout,
               sizeof(iwx_sf_full_timeout));
    } else {
        memcpy(sf_cmd->full_on_timeouts, iwx_sf_full_timeout_def,
               sizeof(iwx_sf_full_timeout_def));
    }
    
}

int ItlIwx::
iwx_sf_config(struct iwx_softc *sc, int new_state)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_sf_cfg_cmd sf_cmd = {
        .state = htole32(new_state),
    };
    int err = 0;
    
    switch (new_state) {
        case IWX_SF_UNINIT:
        case IWX_SF_INIT_OFF:
            iwx_fill_sf_command(sc, &sf_cmd, NULL);
            break;
        case IWX_SF_FULL_ON:
            iwx_fill_sf_command(sc, &sf_cmd, ic->ic_bss);
            break;
        default:
            return EINVAL;
    }
    
    err = iwx_send_cmd_pdu(sc, IWX_REPLY_SF_CFG_CMD, IWX_CMD_ASYNC,
                           sizeof(sf_cmd), &sf_cmd);
    return err;
}

int ItlIwx::
iwx_send_bt_init_conf(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_bt_coex_cmd bt_cmd;
    
    // Monitor mode keeps Wi-Fi busy on 2.4 GHz, so an AWDL test boot may need a different
    // balance with Bluetooth, which shares the radio. Default behaviour is unchanged.
    bt_cmd.mode = htole32(ItlAWDL::btCoexModeFor(awdlBtCoexRequest, IWX_BT_COEX_WIFI));
    bt_cmd.enabled_modules = 0;
    
    return iwx_send_cmd_pdu(sc, IWX_BT_CONFIG, 0, sizeof(bt_cmd),
                            &bt_cmd);
}

int ItlIwx::
iwx_send_soc_conf(struct iwx_softc *sc)
{
   struct iwx_soc_configuration_cmd cmd;
   int err;
   uint32_t cmd_id, flags = 0;

   memset(&cmd, 0, sizeof(cmd));

   /*
    * In VER_1 of this command, the discrete value is considered
    * an integer; In VER_2, it's a bitmask.  Since we have only 2
    * values in VER_1, this is backwards-compatible with VER_2,
    * as long as we don't set any other flag bits.
    */
   if (!sc->sc_integrated) { /* VER_1 */
       flags = IWX_SOC_CONFIG_CMD_FLAGS_DISCRETE;
   } else { /* VER_2 */
       uint8_t scan_cmd_ver;
       if (sc->sc_ltr_delay != IWX_SOC_FLAGS_LTR_APPLY_DELAY_NONE)
           flags |= (sc->sc_ltr_delay &
               IWX_SOC_FLAGS_LTR_APPLY_DELAY_MASK);
       scan_cmd_ver = iwx_lookup_cmd_ver(sc, IWX_LONG_GROUP,
           IWX_SCAN_REQ_UMAC);
       if (scan_cmd_ver != IWX_FW_CMD_VER_UNKNOWN &&
           scan_cmd_ver >= 2 && sc->sc_low_latency_xtal)
           flags |= IWX_SOC_CONFIG_CMD_FLAGS_LOW_LATENCY;
   }
   cmd.flags = htole32(flags);

   cmd.latency = htole32(sc->sc_xtal_latency);

   cmd_id = iwx_cmd_id(IWX_SOC_CONFIGURATION_CMD, IWX_SYSTEM_GROUP, 0);
   err = iwx_send_cmd_pdu(sc, cmd_id, 0, sizeof(cmd), &cmd);
   if (err)
       XYLog("%s: failed to set soc latency: %d\n", DEVNAME(sc), err);
   return err;
}

int ItlIwx::
iwx_mcc_request(struct iwx_softc *sc, uint16_t country, uint8_t source, ItlAWDL::MccSample *sample, bool apply)
{
    // The reply is recorded. The channel map changes only with apply, and then as the firmware says.
    struct iwx_mcc_update_cmd mcc_cmd;
    struct iwx_host_cmd hcmd = {
        .id = IWX_MCC_UPDATE_CMD,
        .flags = IWX_CMD_WANT_RESP,
        .data = { &mcc_cmd },
    };
    memset(&mcc_cmd, 0, sizeof(mcc_cmd));
    mcc_cmd.mcc = htole16(country);
    mcc_cmd.source_id = source;
    hcmd.len[0] = sizeof(struct iwx_mcc_update_cmd);
    hcmd.resp_pkt_len = IWX_CMD_RESP_MAX;
    int err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    struct iwx_rx_packet *pkt = hcmd.resp_pkt;
    size_t resp_len = 0;
    struct iwx_mcc_update_resp *resp = nullptr;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        err = EIO;
        goto out;
    }
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (resp_len < sizeof(*resp)) {
        err = EIO;
        goto out;
    }
    resp = (struct iwx_mcc_update_resp *)pkt->data;
    if (resp_len != sizeof(*resp) + resp->n_channels * sizeof(resp->channels[0])) {
        err = EIO;
        goto out;
    }
    {
        sample->mcc = le16toh(resp->mcc);
        sample->source = resp->source_id;
        sample->status = uint8_t(le32toh(resp->status));
        const uint8_t *table = sc->sc_uhb_supported ? iwx_nvm_channels_uhb : iwx_nvm_channels_8000;
        const size_t tableCount = sc->sc_uhb_supported ? nitems(iwx_nvm_channels_uhb) : nitems(iwx_nvm_channels_8000);
        ItlAWDL::regulatoryChannelFlags(table, tableCount, 149, resp->channels, resp->n_channels, &sample->channel149);
        ItlAWDL::regulatoryChannelFlags(table, tableCount, 36, resp->channels, resp->n_channels, &sample->channel36);
        ItlAWDL::regulatoryChannelFlags(table, tableCount, 6, resp->channels, resp->n_channels, &sample->channel6);
        if (apply)
            iwx_init_channel_map(sc, NULL, resp->channels, resp->n_channels);
    }
out:
    iwx_free_resp(sc, &hcmd);
    return err;
}

// Answers the firmware's notice with its own country and source, and applies its reply.
bool ItlIwx::
awdlCountryAnswer(struct iwx_softc *sc)
{
    ItlAWDL::MccSample reply{};
    awdlCountryLastAnswered = awdlCountryNotice;
    awdlCountryAnswerSeconds = mccUptimeSeconds();
    ++awdlCountryAnswers;
    const int err = iwx_mcc_request(sc, awdlCountryNotice, awdlCountryNoticeSource, &reply, true);
    awdlCountryLastStatus = err ? 0xffffffffU : reply.status;
    awdlLog("country notice %c%c source %u answered: err %d status %u\n", awdlCountryNotice >> 8,
            awdlCountryNotice & 255, awdlCountryNoticeSource, err, reply.status);
    return !err;
}

// Before monitor RUN, scan for a few seconds. With no notice, nothing changes and the
// channel stays 6. A scan needs no association, and no scan flag is set here, so the
// normal end of scan handling in net80211 doesn't run.
void ItlIwx::
awdlBaHandle(struct iwx_softc *sc)
{
    if (awdlBaFailed)
        return;
    if (awdlFixedChannel != 149) {
        ++awdlBaOffChannel;
        return;
    }
    if (awdlBaGeneration != sc->sc_generation) {
        // A new start of the firmware, so the station and sessions from before are gone.
        if (awdlBaAttempts >= kAwdlBaAttemptsMax) {
            ++awdlBaStale;
            return;
        }
        ++awdlBaAttempts;
        awdlBaGeneration = sc->sc_generation;
        awdlBaStationAdded = false;
        awdlBaPeerKnown = false;
        awdlBaTids = 0;
        awdlBaResponseLength = 0;
        awdlBaPeerAccepted = false;
        awdlBaFilterOff = false;
        awdlBaFilter = ItlAWDL::BaFilterState{};
        awdlBaTxState = kBaTxOff;
        awdlBaTxQueue = -1;
        awdlBaTxLastAskUS = 0;
        awdlBaTxAsks = 0;
        awdlBaTxRestUntilUS = 0;
        ++awdlBaTxToken;
    }
    const ItlAWDL::AddbaRequest request = awdlBaRequest;
    if (!request.immediate || !sc->sc_ic.ic_bss)
        return;
    auto *in = reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss);
    struct iwx_add_sta_cmd cmd;
    uint32_t status;
    int err;
    if (!awdlBaStationAdded) {
        awdlBaPeerKnown = true;
        memcpy(awdlBaPeer, request.peer, sizeof(awdlBaPeer));
        awdlBaStep = 1;
        memset(&cmd, 0, sizeof(cmd));
        cmd.sta_id = kAwdlBaStationId;
        cmd.station_type = IWX_STA_LINK;
        cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
        IEEE80211_ADDR_COPY(&cmd.addr, request.peer);
        cmd.tid_disable_tx = htole16(0xffff);
        awdlBaTx80Active = false;
        if (awdlBaTx && awdlBaTx80) {
            awdlBaTx80Active = awdlWide80Live && !awdlWide80Refused && awdlFixedChannel == 149;
            awdlBaTx80State = awdlBaTx80Active ? 1 : 2;
        }
        cmd.station_flags = htole32((awdlBaTx80Active ? IWX_STA_FLG_FAT_EN_80MHZ : IWX_STA_FLG_FAT_EN_20MHZ) |
                                    IWX_STA_FLG_MIMO_EN_MIMO2 |
                                    (awdlBaTx ? (awdlBaTx80Active ? awdlBaTxAgg : min(awdlBaTxAgg, 3U))
                                                    << IWX_STA_FLG_MAX_AGG_SIZE_SHIFT : 0U));
        cmd.station_flags_msk = htole32(IWX_STA_FLG_FAT_EN_MSK | IWX_STA_FLG_MIMO_EN_MSK |
                                        (awdlBaTx ? IWX_STA_FLG_MAX_AGG_SIZE_MSK | IWX_STA_FLG_AGG_MPDU_DENS_MSK : 0U));
        status = IWX_ADD_STA_SUCCESS;
        err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
        awdlBaStationStatus = err ? 0x80000000U | uint32_t(err) : status;
        if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
            awdlBaFailed = true;
            return;
        }
        awdlBaStationAdded = true;
        // Filters stay promiscuous, so frames for other BSSIDs and groups still arrive.
        if (ItlAWDL::knownAddress(request.bssid)) {
            awdlBaStep = 4;
            memcpy(awdlBaBssid, request.bssid, sizeof(awdlBaBssid));
            err = iwx_mac_ctxt_cmd(sc, in, IWX_FW_CTXT_ACTION_MODIFY, 0);
            awdlBaBssidResult = err ? 0x80000000U | uint32_t(err) : 1;
            if (err) {
                memset(awdlBaBssid, 0, sizeof(awdlBaBssid));
                awdlBaFailed = true;
                return;
            }
        }
    }
    // A new token means a new session, with its own start. The firmware's would still have the old one.
    if ((awdlBaTids & (1U << request.tid)) && awdlBaTidToken[request.tid] != request.token) {
        memset(&cmd, 0, sizeof(cmd));
        cmd.sta_id = kAwdlBaStationId;
        cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
        cmd.add_modify = IWX_STA_MODE_MODIFY;
        cmd.remove_immediate_ba_tid = request.tid;
        cmd.modify_mask = IWX_STA_MODIFY_REMOVE_BA_TID;
        status = IWX_ADD_STA_SUCCESS;
        err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
        if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS) {
            awdlBaSessionStatus = err ? 0x80000000U | uint32_t(err) : status;
            awdlBaFailed = true;
            return;
        }
        awdlBaTids &= ~(1U << request.tid);
        ++awdlBaSessionRestarts;
        awdlSessLog("rx session restart tid %u token %u -> %u\n", unsigned(request.tid),
                    unsigned(awdlBaTidToken[request.tid]), unsigned(request.token));
    }
    if (!(awdlBaTids & (1U << request.tid))) {
        awdlBaTidToken[request.tid] = request.token;
        awdlBaStep = 2;
        memset(&cmd, 0, sizeof(cmd));
        cmd.sta_id = kAwdlBaStationId;
        cmd.mac_id_n_color = htole32(IWX_FW_CMD_ID_AND_COLOR(in->in_id, in->in_color));
        cmd.add_modify = IWX_STA_MODE_MODIFY;
        cmd.add_immediate_ba_tid = request.tid;
        cmd.add_immediate_ba_ssn = htole16(request.ssn);
        cmd.rx_ba_window = htole16(request.window);
        cmd.modify_mask = IWX_STA_MODIFY_ADD_BA_TID;
        status = IWX_ADD_STA_SUCCESS;
        err = iwx_send_cmd_pdu_status(sc, IWX_ADD_STA, sizeof(cmd), &cmd, &status);
        awdlBaSessionStatus = err ? 0x80000000U | uint32_t(err) : status;
        if (err || (status & IWX_ADD_STA_STATUS_MASK) != IWX_ADD_STA_SUCCESS || !(status & IWX_ADD_STA_BAID_VALID_MASK)) {
            awdlBaFailed = true;
            return;
        }
        awdlBaTids |= 1U << request.tid;
    }
    // The peer repeats its request until it hears an answer, so each one gets its own.
    awdlBaStep = 3;
    awdlBaResponseLength = ItlAWDL::buildAddbaResponse(awdlBaResponse, sizeof(awdlBaResponse), request, awdlOwnAddress, ++awdlBaSequence);
}

void ItlIwx::
awdlBaTxStep(struct iwx_softc *sc)
{
    if (!awdlBaStationAdded || !awdlBaPeerAccepted || awdlBaTxState == kBaTxAgreed || awdlBaTxState == kBaTxFailed)
        return;
    if (awdlBaTxState == kBaTxOff) {
        const int queue = iwx_tvqm_enable_txq(sc, kAwdlBaTxTid, 0, IWX_DEFAULT_QUEUE_SIZE, kAwdlBaStationId);
        awdlBaTxQueueResult = queue < 0 ? 0x80000000U | uint32_t(-queue) : uint32_t(queue);
        if (queue < 0) {
            awdlBaTxState = kBaTxFailed;
            return;
        }
        awdlBaTxQueue = queue;
        awdlBaTxSequence = uint16_t(sc->txq[queue].cur);
        // Rate control for the peer's station, which needs no node of its own here.
        awdlBaTlc = true;
        const int err = iwx_rs_init(sc, reinterpret_cast<struct iwx_node *>(sc->sc_ic.ic_bss), true);
        awdlBaTlc = false;
        if (err) {
            awdlBaTxQueueResult = 0x40000000U | uint32_t(err);
            awdlBaTxState = kBaTxFailed;
            return;
        }
        awdlBaTxState = kBaTxAsking;
    }
    const uint64_t now = awdlUptimeUS();
    if (awdlBaTxRestUntilUS && now < awdlBaTxRestUntilUS)
        return;
    awdlBaTxRestUntilUS = 0;
    if (awdlBaResponseLength || (awdlBaTxLastAskUS && now - awdlBaTxLastAskUS < 200000))
        return;
    // An ask while the phone's schedule has it away can't be answered, so it isn't spent.
    if (awdlPeerSchedule.shouldPause(now)) {
        ++awdlBaTxAsksSkippedAway;
        return;
    }
    if (awdlBaTxAsks >= kAwdlBaTxAsksMax) {
        awdlBaTxAsks = 0;
        ++awdlBaTxToken;
        ++awdlBaTxAskRounds;
        awdlBaTxRestUntilUS = now + kAwdlBaTxRestUS;
        awdlSessLog("mac tx session: no answer to %u asks, asking again in %u s\n", unsigned(kAwdlBaTxAsksMax),
                    unsigned(kAwdlBaTxRestUS / 1000000));
        return;
    }
    awdlBaTxLastAskUS = now;
    ++awdlBaTxAsks;
    if (!awdlBaTxToken)
        awdlBaTxToken = 0x5a;
    awdlBaResponseLength = ItlAWDL::buildAddbaRequest(awdlBaResponse, sizeof(awdlBaResponse), awdlBaPeer, awdlOwnAddress,
        kAwdlBssid, awdlBaTxToken, kAwdlBaTxTid, ItlAWDL::kBaWindowMax, awdlBaTxSequence, ++awdlBaSequence);
}

bool ItlIwx::
awdlBaTxQueueFull(struct iwx_softc *sc)
{
    return awdlBaTxQueue >= 0 && uint32_t(sc->txq[awdlBaTxQueue].queued) >= awdlBaTxQueuedMax;
}

// Takes the packet on true. On false, the caller sends it the usual way.
bool ItlIwx::
awdlBaTxSend(struct iwx_softc *sc, mbuf_t packet)
{
    if (!awdlBaTx || awdlBaTxState != kBaTxAgreed || awdlBaTxQueue < 0 || mbuf_next(packet) ||
        mbuf_len(packet) < 24 || !ItlAWDL::sameAddress(static_cast<const uint8_t *>(mbuf_data(packet)) + 4, awdlBaPeer))
        return false;
    if (!awdlBaTxBulk.bulk) {
        ++awdlBaTxBulkSkipped;
        return false;
    }
    mbuf_t qos = nullptr;
    if (mbuf_getpacket(MBUF_DONTWAIT, &qos) || !qos)
        return false;
    const size_t length = ItlAWDL::buildQosData(static_cast<const uint8_t *>(mbuf_data(packet)), mbuf_len(packet), kAwdlBaTxTid,
        awdlBaTxSequence, static_cast<uint8_t *>(mbuf_data(qos)), mbuf_maxlen(qos));
    if (!length) {
        mbuf_freem(qos);
        return false;
    }
    mbuf_setlen(qos, length);
    mbuf_pkthdr_setlen(qos, length);
    auto *node = ieee80211_ref_node(sc->sc_ic.ic_bss);
    awdlBurstSending = true;
    awdlDataInFlight = 3; // Selects the firmware's rate control in iwx_tx_fill_cmd.
    const int result = iwx_tx(sc, qos, node, EDCA_AC_BE, awdlBaTxQueue);
    awdlDataInFlight = 0;
    awdlBurstSending = false;
    if (result) {
        ieee80211_release_node(&sc->sc_ic, node);
        ++awdlBaTxRefused;
        return false;
    }
    awdlBaTxSequence = (awdlBaTxSequence + 1) & 0xfff;
    ++awdlBaTxFrames;
    ++awdlMonitorSubmitted;
    sc->sc_tx_timer = 15;
    IC2IFP(&sc->sc_ic)->if_timer = 1;
    mbuf_freem(packet);
    return true;
}

void ItlIwx::
awdlCountryScan(struct iwx_softc *sc)
{
    const int generation = sc->sc_generation;
    // Coming back down, there's nothing to look for yet.
    if (awdlChannelMove.skipStartupScan) {
        awdlChannelMove.skipStartupScan = false;
        return;
    }
    // The map was refreshed from the firmware's reply earlier in this start.
    const auto &channel149 = sc->sc_ic.ic_channels[149];
    if (!ItlAWDL::startupScanNeeded(awdlFixedChannel, channel149.ic_freq &&
            !(channel149.ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC))))
        return;
    AbsoluteTime deadline;
    clock_interval_to_deadline(10, kSecondScale, reinterpret_cast<uint64_t *>(&deadline));
    awdlCountryDiscovery = true;
    awdlCountryNoticeSeen = false;
    bool timedOut = false;
    while (!awdlCountryNoticeSeen && !timedOut) {
        awdlCountryScanDone = false;
        const int err = iwx_umac_scan(sc, 0);
        ++awdlCountryScans;
        if (err) {
            awdlLog("country scan failed: %d\n", err);
            awdlCountryScanDone = true;
            break;
        }
        while (!awdlCountryScanDone && !awdlCountryNoticeSeen) {
            const int result = getMainCommandGate()->commandSleep(&awdlCountryDiscovery, deadline, THREAD_UNINT);
            if (generation != sc->sc_generation) {
                awdlCountryDiscovery = false;
                return;
            }
            if (result != THREAD_AWAKENED) {
                timedOut = true;
                break;
            }
        }
    }
    if (!awdlCountryScanDone) {
        (void)iwx_umac_scan_abort(sc);
        AbsoluteTime stopDeadline;
        clock_interval_to_deadline(1, kSecondScale, reinterpret_cast<uint64_t *>(&stopDeadline));
        while (!awdlCountryScanDone && generation == sc->sc_generation) {
            if (getMainCommandGate()->commandSleep(&awdlCountryDiscovery, stopDeadline, THREAD_UNINT) != THREAD_AWAKENED)
                break;
        }
    }
    awdlCountryDiscovery = false;
    if (generation == sc->sc_generation && awdlCountryNoticeSeen)
        (void)awdlCountryAnswer(sc);
}

void ItlIwx::
mccProbeTimeout(void *arg)
{
    auto *sc = static_cast<struct iwx_softc *>(arg);
    ItlIwx *that = container_of(sc, ItlIwx, com);
    auto *ic = &sc->sc_ic;
    const bool notice = mccProbeNoticePending;
    mccProbeNoticePending = false;
    if ((IC2IFP(ic)->if_flags & IFF_RUNNING) &&
        !(sc->sc_flags & (IWX_FLAG_HW_ERR | IWX_FLAG_SHUTDOWN | IWX_FLAG_RFKILL))) {
        auto record = [&](uint16_t country, uint8_t source, uint8_t trigger) {
            ItlAWDL::MccSample sample{};
            sample.uptimeSeconds = mccUptimeSeconds();
            sample.state = uint8_t(ic->ic_state);
            sample.trigger = trigger;
            if (ic->ic_state == IEEE80211_S_RUN && ic->ic_bss && ic->ic_bss->ni_chan)
                sample.bssChannel = uint8_t(ieee80211_chan2ieee(ic, ic->ic_bss->ni_chan));
            if (that->iwx_mcc_request(sc, country, source, &sample, false) == 0)
                ItlAWDL::regulatoryAppend(mccSamples, nitems(mccSamples), mccSampleCount, sample);
        };
        const uint16_t current = 'Z' << 8 | 'Z';
        // Once, the way Linux offers it at startup: the laptop maker's value.
        if (mccBiosCountry && !mccBiosSent) {
            mccBiosSent = true;
            record(mccBiosCountry, IWX_MCC_SOURCE_BIOS, ItlAWDL::kMccBiosReply);
            record(current, IWX_MCC_SOURCE_GET_CURRENT, ItlAWDL::kMccRead);
        }
        // The firmware's own country and source, as it reported them.
        if (notice) {
            mccEchoAnswered = true;
            mccEchoLastSeconds = mccUptimeSeconds();
            record(mccEchoCountry, mccEchoSource, ItlAWDL::kMccEchoReply);
        }
        record(current, IWX_MCC_SOURCE_GET_CURRENT, notice ? ItlAWDL::kMccReadAfterNotice : ItlAWDL::kMccRead);
        mccProbePublish();
    }
    if (mccSampleCount < nitems(mccSamples))
        timeout_add_sec(&mccProbeTimer, 15);
}

int ItlIwx::
iwx_send_update_mcc_cmd(struct iwx_softc *sc, const char *alpha2)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_mcc_update_cmd mcc_cmd;
    struct iwx_host_cmd hcmd = {
        .id = IWX_MCC_UPDATE_CMD,
        .flags = IWX_CMD_WANT_RESP,
        .data = { &mcc_cmd },
    };
    struct iwx_rx_packet *pkt;
    struct iwx_mcc_update_resp *resp;
    size_t resp_len;
    int err;
    
    memset(&mcc_cmd, 0, sizeof(mcc_cmd));
    mcc_cmd.mcc = htole16(alpha2[0] << 8 | alpha2[1]);
    if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_WIFI_MCC_UPDATE) ||
        isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_LAR_MULTI_MCC))
        // ZZ reads the firmware's current domain. A real country is a request the
        // firmware may still refuse, and its reply is what fills the channel map.
        mcc_cmd.source_id = alpha2[0] == 'Z' && alpha2[1] == 'Z' ? IWX_MCC_SOURCE_GET_CURRENT : IWX_MCC_SOURCE_ME;
    else
        mcc_cmd.source_id = IWX_MCC_SOURCE_OLD_FW;
    
    hcmd.len[0] = sizeof(struct iwx_mcc_update_cmd);
    hcmd.resp_pkt_len = IWX_CMD_RESP_MAX;
    
    err = iwx_send_cmd(sc, &hcmd);
    if (err)
        return err;
    
    pkt = hcmd.resp_pkt;
    if (!pkt || (pkt->hdr.group_id & IWX_CMD_FAILED_MSK)) {
        err = EIO;
        goto out;
    }
    
    resp_len = iwx_rx_packet_payload_len(pkt);
    if (resp_len < sizeof(*resp)) {
        err = EIO;
        goto out;
    }
    
    resp = (struct iwx_mcc_update_resp *)pkt->data;
    if (resp_len != sizeof(*resp) +
        resp->n_channels * sizeof(resp->channels[0])) {
        err = EIO;
        goto out;
    }

    DPRINTF(("MCC status=0x%x mcc=0x%x cap=0x%x time=0x%x geo_info=0x%x source_id=0x%d n_channels=%u\n",
             resp->status, resp->mcc, resp->cap, resp->time, resp->geo_info, resp->source_id, resp->n_channels));

    /* Update channel map for net80211 and our scan configuration. */
    iwx_init_channel_map(sc, NULL, resp->channels, resp->n_channels);
    
out:
    iwx_free_resp(sc, &hcmd);
    
    return err;
}

int ItlIwx::
iwx_send_temp_report_ths_cmd(struct iwx_softc *sc)
{
    struct iwx_temp_report_ths_cmd cmd;
    int err;
    
    /*
     * In order to give responsibility for critical-temperature-kill
     * and TX backoff to FW we need to send an empty temperature
     * reporting command at init time.
     */
    memset(&cmd, 0, sizeof(cmd));
    
    err = iwx_send_cmd_pdu(sc,
                           IWX_WIDE_ID(IWX_PHY_OPS_GROUP, IWX_TEMP_REPORTING_THRESHOLDS_CMD),
                           0, sizeof(cmd), &cmd);
    if (err)
        XYLog("%s: TEMP_REPORT_THS_CMD command failed (error %d)\n",
               DEVNAME(sc), err);
    
    return err;
}

#define TX_FIFO_MAX_NUM            15
#define RX_FIFO_MAX_NUM            2
#define TX_FIFO_INTERNAL_MAX_NUM    6

int ItlIwx::
iwx_init_hw(struct iwx_softc *sc)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    int err, i, generation = sc->sc_generation;
    
    err = iwx_preinit(sc);
    if (err)
        return err;
    
    err = iwx_start_hw(sc);
    if (err) {
        XYLog("%s: could not initialize hardware\n", DEVNAME(sc));
        return err;
    }
    
    err = iwx_run_init_mvm_ucode(sc, 0);
    if (err)
        return err;
    
    if (!iwx_nic_lock(sc))
        return EBUSY;
    
    err = iwx_send_tx_ant_cfg(sc, iwx_fw_valid_tx_ant(sc));
    if (err) {
        XYLog("%s: could not init tx ant config (error %d)\n",
               DEVNAME(sc), err);
        goto err;
    }
    
    iwx_toggle_tx_ant(sc, &sc->sc_mgmt_last_antenna_idx);
    
    if (sc->sc_tx_with_siso_diversity) {
        err = iwx_send_phy_cfg_cmd(sc);
        if (err) {
            XYLog("%s: could not send phy config (error %d)\n",
                   DEVNAME(sc), err);
            goto err;
        }
    }
    
    err = iwx_send_bt_init_conf(sc);
    if (err) {
        XYLog("%s: could not init bt coex (error %d)\n",
               DEVNAME(sc), err);
        goto err;
    }
    
    err = iwx_send_soc_conf(sc);
    if (err)
        goto err;
    
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_DQA_SUPPORT)){
        err = iwx_send_dqa_cmd(sc);
        if (err)
            goto err;
    }
    
    /* Add auxiliary station for scanning */
    err = iwx_add_aux_sta(sc);
    if (err) {
        XYLog("%s: could not add aux station (error %d)\n",
              DEVNAME(sc), err);
        goto err;
    }
    
    for (i = 0; i < IWX_NUM_PHY_CTX; i++) {
        /*
         * The channel used here isn't relevant as it's
         * going to be overwritten in the other flows.
         * For now use the first channel we have.
         */
        sc->sc_phyctxt[i].id = i;
        sc->sc_phyctxt[i].channel = &ic->ic_channels[1];
        err = iwx_phy_ctxt_cmd(sc, &sc->sc_phyctxt[i], 1, 1,
                               IWX_FW_CTXT_ACTION_ADD, 0);
        if (err) {
            XYLog("%s: could not add phy context %d (error %d)\n",
                   DEVNAME(sc), i, err);
            goto err;
        }
    }
    
    if (!isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_SET_LTR_GEN2)) {
        err = iwx_config_ltr(sc);
        if (err) {
            XYLog("%s: PCIe LTR configuration failed (error %d)\n",
                  DEVNAME(sc), err);
            goto err;
        }
    }
    
    if (isset(sc->sc_enabled_capa, IWX_UCODE_TLV_CAPA_CT_KILL_BY_FW)) {
        err = iwx_send_temp_report_ths_cmd(sc);
        if (err)
            goto err;
    }
    
    err = iwx_power_update_device(sc);
    if (err) {
        XYLog("%s: could not send power command (error %d)\n",
               DEVNAME(sc), err);
        goto err;
    }
    
    if (sc->sc_nvm.lar_enabled) {
        err = iwx_send_update_mcc_cmd(sc, awdlRx ? awdlCountry : "ZZ");
        // A refused country must not take Wi-Fi down: fall back to the world domain.
        if (err && awdlRx && strcmp(awdlCountry, "ZZ")) {
            awdlLog("country %s refused: %d\n", awdlCountry, err);
            memcpy(awdlCountry, "ZZ", sizeof(awdlCountry));
            err = iwx_send_update_mcc_cmd(sc, "ZZ");
        }
        if (err) {
            XYLog("%s: could not init LAR (error %d)\n",
                   DEVNAME(sc), err);
            goto err;
        }
        if (mccProbe && !timeout_pending(&mccProbeTimer))
            timeout_add_sec(&mccProbeTimer, 5);
    }
    
    err = iwx_config_umac_scan(sc);
    if (err) {
        XYLog("%s: could not configure scan (error %d)\n",
               DEVNAME(sc), err);
        goto err;
    }
    
    err = iwx_disable_beacon_filter(sc);
    if (err) {
        XYLog("%s: could not disable beacon filter (error %d)\n",
               DEVNAME(sc), err);
        goto err;
    }
    
err:
    if (generation == sc->sc_generation)
        iwx_nic_unlock(sc);
    return err;
}

/* Allow multicast from our BSSID. */
int ItlIwx::
iwx_allow_mcast(struct iwx_softc *sc)
{
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    struct iwx_mcast_filter_cmd *cmd;
    size_t size;
    int err;
    
    size = roundup(sizeof(*cmd), 4);
    cmd = (struct iwx_mcast_filter_cmd *)malloc(size, 0, M_NOWAIT | M_ZERO);
    if (cmd == NULL)
        return ENOMEM;
    cmd->filter_own = 1;
    cmd->port_id = 0;
    cmd->count = 0;
    cmd->pass_all = 1;
    IEEE80211_ADDR_COPY(cmd->bssid, in->in_macaddr);
    
    err = iwx_send_cmd_pdu(sc, IWX_MCAST_FILTER_CMD,
                           0, size, cmd);
    ::free(cmd);
    return err;
}

int ItlIwx::
iwx_init(struct _ifnet *ifp)
{
    if (!getMainWorkLoop()->inGate()) {
        return getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
                ItlIwx *that = (ItlIwx *)arg0;
                return that->iwx_init((struct _ifnet *)arg1);
            }, this, ifp);
    }

    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    struct ieee80211com *ic = &sc->sc_ic;
    int err, generation;
    int i;

    memset(sc->sc_tid_data, 0, sizeof(sc->sc_tid_data));
    for (i = 0; i < ARRAY_SIZE(sc->sc_tid_data); i++) {
        sc->sc_tid_data[i].qid = IWX_INVALID_QUEUE;
    }
    
    //    rw_assert_wrlock(&sc->ioctl_rwl);
    
    generation = ++sc->sc_generation;
    
    //    KASSERT(sc->task_refs.refs == 0);
    //    refcnt_init(&sc->task_refs);
    
#ifdef AIRPORT_WCL
    if (ic->ic_event_handler)
        ic->ic_event_handler(ic, IEEE80211_EVT_DRIVER_RESET_BEGIN, NULL);
#endif
    for (int attempt = 0; ; attempt++) {
        err = iwx_init_hw(sc);
        if (generation != sc->sc_generation)
            return ENXIO;
        if (!err)
            break;
        generation = ++sc->sc_generation;
        iwx_stop_device(sc);
        if (attempt != 0 || err == ENXIO || !(ifp->if_flags & IFF_UP) ||
            (sc->sc_flags & (IWX_FLAG_RFKILL | IWX_FLAG_HW_ERR)))
            return err;
        XYLog("%s: retrying firmware initialization after error %d\n", DEVNAME(sc), err);
    }
    
    if (sc->sc_nvm.sku_cap_11n_enable)
        iwx_setup_ht_rates(sc);
    
    if (sc->sc_nvm.sku_cap_11ac_enable)
        iwx_setup_vht_rates(sc);
    
    if (sc->sc_nvm.sku_cap_11ax_enable)
        iwx_setup_he_rates(sc);
    
    ifq_clr_oactive(&ifp->if_snd);
    ifq_flush(&ifp->if_snd);
    ifp->if_flags |= IFF_RUNNING;
    
    if (ic->ic_opmode == IEEE80211_M_MONITOR) {
        // Before the channel map is refreshed below, so the reply reaches the active set.
        if (awdlRx && awdlRxChannel6 && awdlWant149)
            awdlCountryScan(sc);
        if (awdlRx) {
            // Initial attachment precedes firmware channel discovery. Unlike
            // scanning, monitor RUN never refreshes the active set or fills
            // the BSS legacy rate table. Use the normal net80211 routines.
            err = ieee80211_setmode(ic, IEEE80211_MODE_AUTO);
            if (err) {
                awdlLog("monitor channel initialization failed: %d\n", err);
                return err;
            }
        }
        if (awdlRx) {
            if (awdlRxChannel6) {
                const auto &candidate = ic->ic_channels[149];
                awdlFixedChannel = ItlAWDL::fixedChannelFor(awdlWant149,
                    candidate.ic_freq && isset(ic->ic_chan_active, 149),
                    candidate.ic_flags & (IEEE80211_CHAN_PASSIVE | IEEE80211_CHAN_DFS | IEEE80211_CHAN_NOADHOC));
            }
            const unsigned first = awdlRxChannel6 ? awdlFixedChannel : awdlRxChannels[0];
            if (!ic->ic_channels[first].ic_freq || !isset(ic->ic_chan_active, first)) {
                awdlLog("monitor initial channel %u unavailable\n", first);
                return EINVAL;
            }
            awdlLog("entering monitor RUN, ch%u flags %x\n", first, ic->ic_channels[first].ic_flags);
            ic->ic_ibss_chan = &ic->ic_channels[first];
        }
        ic->ic_bss->ni_chan = ic->ic_ibss_chan;
        if (awdlRx) {
            ic->ic_bss->ni_rates = ic->ic_sup_rates[ieee80211_chan2mode(ic, ic->ic_ibss_chan)];
            ic->ic_bss->ni_txrate = 0;
        }
        ieee80211_new_state(ic, IEEE80211_S_RUN, -1);
        if (awdlRx && !awdlStopping && !timeout_pending(&awdlRxTimer))
            timeout_add_sec(&awdlRxTimer, 6);
        return 0;
    }
    
    ieee80211_begin_scan(ifp);
    
    /*
     * ieee80211_begin_scan() ends up scheduling iwx_newstate_task().
     * Wait until the transition to SCAN state has completed.
     */
    AbsoluteTime deadline;
    clock_interval_to_deadline(1, kSecondScale,
        reinterpret_cast<uint64_t *>(&deadline));
    while (ic->ic_state != IEEE80211_S_SCAN) {
        int result = getMainCommandGate()->commandSleep(&ic->ic_state, deadline, THREAD_UNINT);
        if (generation != sc->sc_generation)
            return ENXIO;
        if (result != THREAD_AWAKENED && ic->ic_state != IEEE80211_S_SCAN) {
            iwx_stop(ifp);
            return (result == THREAD_TIMED_OUT) ? EWOULDBLOCK : EINTR;
        }
    }
    if (generation != sc->sc_generation)
        return ENXIO;

#ifdef AIRPORT_WCL
    if (ic->ic_event_handler)
        ic->ic_event_handler(ic, IEEE80211_EVT_DRIVER_READY, NULL);
#endif
    return 0;
}

IOReturn ItlIwx::
_iwx_start_task(OSObject *target, void *arg0, void *arg1, void *arg2, void *arg3)
{
    struct _ifnet *ifp = (struct _ifnet *)arg0;
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    struct ieee80211com *ic = &sc->sc_ic;
    struct ieee80211_node *ni;
    struct ether_header *eh;
    mbuf_t m;
    int ac = EDCA_AC_BE; /* XXX */
    
    if (!(ifp->if_flags & IFF_RUNNING) || ifq_is_oactive(&ifp->if_snd) ||
        (sc->sc_flags & (IWX_FLAG_SHUTDOWN | IWX_FLAG_TXFLUSH)) ||
        (ic->ic_state == IEEE80211_S_RUN && sc->ns_nstate != IEEE80211_S_RUN)) {
        return kIOReturnError;
    }
    
    for (;;) {
        /* why isn't this done per-queue? */
        if (!sc->qfullmsk.empty()) {
            ifq_set_oactive(&ifp->if_snd);
            break;
        }

        /* Don't queue additional frames while flushing Tx queues. */
        if (sc->sc_flags & IWX_FLAG_TXFLUSH)
            break;
        
        /* need to send management frames even if we're not RUNning */
        m = mq_dequeue(&ic->ic_mgtq);
        if (m) {
            //            ni = m->m_pkthdr.ph_cookie;
            ni = (struct ieee80211_node *)mbuf_pkthdr_rcvif(m);
            goto sendit;
        }
        
        if (
#ifndef AIRPORT
            ic->ic_state != IEEE80211_S_RUN ||
#endif
            (ic->ic_xflags & IEEE80211_F_TX_MGMT_ONLY))
            break;
        
        m = ifq_dequeue(&ifp->if_snd);
        if (!m)
            break;
        if (mbuf_len(m) < sizeof (*eh) &&
            mbuf_pullup(&m, sizeof (*eh)) != 0) {
            ifp->netStat->outputErrors++;
            continue;
        }
#if NBPFILTER > 0
        if (ifp->if_bpf != NULL)
            bpf_mtap(ifp->if_bpf, m, BPF_DIRECTION_OUT);
#endif
        if ((m = ieee80211_encap(ifp, m, &ni)) == NULL) {
            ifp->netStat->outputErrors++;
            continue;
        }
        
    sendit:
#if NBPFILTER > 0
        if (ic->ic_rawbpf != NULL)
            bpf_mtap(ic->ic_rawbpf, m, BPF_DIRECTION_OUT);
#endif
        if (that->iwx_tx(sc, m, ni, ac) != 0) {
            ieee80211_release_node(ic, ni);
            ifp->netStat->outputErrors++;
            continue;
        }
        ifp->netStat->outputPackets++;
        
        if (ifp->if_flags & IFF_UP) {
            sc->sc_tx_timer = 15;
            ifp->if_timer = 1;
        }
    }
    
    return kIOReturnSuccess;
}

void ItlIwx::
iwx_start(struct _ifnet *ifp)
{
    struct iwx_softc *sc = (struct iwx_softc*)ifp->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);

    IOReturn ret = that->getMainCommandGate()->runAction(
        _iwx_start_task,
        &that->com.sc_ic.ic_ac.ac_if
    );

    if (ret != kIOReturnSuccess)
        XYLog("%s: iwx_start runAction ret=0x%x\n", DEVNAME(sc), ret);
}

void ItlIwx::
iwx_stop(struct _ifnet *ifp)
{
    if (!getMainWorkLoop()->inGate()) {
        getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
                ItlIwx *that = (ItlIwx *)arg0;
                that->iwx_stop((struct _ifnet *)arg1);
                return kIOReturnSuccess;
            }, this, ifp);
        return;
    }

    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwx_node *in = (struct iwx_node *)ic->ic_bss;
    int i, s = splnet();
    
    //    rw_assert_wrlock(&sc->ioctl_rwl);
    
    sc->sc_flags |= IWX_FLAG_SHUTDOWN; /* Disallow new tasks. */
    sc->sc_generation++;
    getMainCommandGate()->commandWakeup(&awdlCoexAddingGen);
    getMainCommandGate()->commandWakeup(&sc->sc_uc.uc_intr);
    getMainCommandGate()->commandWakeup(&sc->sc_init_complete);
    getMainCommandGate()->commandWakeup(&ic->ic_state);
    
    /* Cancel scheduled tasks and let any stale tasks finish up. */
    task_del(systq, &sc->init_task);
    iwx_del_task(sc, sc->sc_nswq, &sc->newstate_task);
    iwx_del_task(sc, systq, &sc->ba_task);
    iwx_del_task(sc, systq, &sc->mac_ctxt_task);
    iwx_del_task(sc, systq, &sc->chan_ctxt_task);
    KASSERT(sc->task_refs.refs >= 1, "sc->task_refs.refs >= 1");
    //    refcnt_finalize(&sc->task_refs, "iwxstop");
    
    iwx_stop_device(sc);
    
    /* Reset soft state. */
    
    ifp->if_flags &= ~IFF_RUNNING;
#ifdef AIRPORT_WCL
    // A stopped firmware scan cannot deliver its completion event.
    ic->ic_flags &= ~(IEEE80211_F_BGSCAN | IEEE80211_F_ASCAN);
    ic->ic_wcl_scan_requested = false;
    ic->ic_wcl_scan_active = false;
    ic->ic_wcl_scan_ssid_length = 0;
    if (ic->ic_event_handler)
        ic->ic_event_handler(ic, IEEE80211_EVT_DRIVER_STOPPED, NULL);
#endif

    ifq_clr_oactive(&ifp->if_snd);
    ifq_flush(&ifp->if_snd);
    
    if (in != NULL) {
        in->in_phyctxt = NULL;
        in->in_ni.ni_chw = IEEE80211_CHAN_WIDTH_20_NOHT;
        IEEE80211_ADDR_COPY(in->in_macaddr, etheranyaddr);
    }
    
    sc->sc_flags &= ~(IWX_FLAG_SCANNING | IWX_FLAG_BGSCAN);
    sc->sc_flags &= ~IWX_FLAG_MAC_ACTIVE;
    sc->sc_flags &= ~IWX_FLAG_BINDING_ACTIVE;
    sc->sc_flags &= ~IWX_FLAG_STA_ACTIVE;
    sc->sc_flags &= ~IWX_FLAG_TE_ACTIVE;
    sc->sc_flags &= ~IWX_FLAG_HW_ERR;
    sc->sc_flags &= ~IWX_FLAG_TXFLUSH;

    sc->sc_rx_ba_sessions = 0;
    sc->ba_rx.start_tidmask = 0;
    sc->ba_rx.stop_tidmask = 0;
    sc->ba_tx.start_tidmask = 0;
    sc->ba_tx.stop_tidmask = 0;
    
    sc->sc_newstate(ic, IEEE80211_S_INIT, -1);
    sc->ns_nstate = IEEE80211_S_INIT;
    
    for (i = 0; i < nitems(sc->sc_rxba_data); i++) {
        struct iwx_rxba_data *rxba = &sc->sc_rxba_data[i];
        iwx_clear_reorder_buffer(sc, rxba);
    }
    
    ifp->if_timer = sc->sc_tx_timer = 0;
    sc->sc_flags &= ~IWX_FLAG_SHUTDOWN;
    
    splx(s);
}

void ItlIwx::
iwx_watchdog(struct _ifnet *ifp)
{
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    ifp->if_timer = 0;
    if (sc->sc_tx_timer > 0) {
        if (--sc->sc_tx_timer == 0) {
            XYLog("%s: device timeout\n", DEVNAME(sc));
#ifdef IWX_DEBUG
            int i;

            /* Dump driver status (TX and RX rings) while we're here. */
            XYLog("driver status:\n");
            for (i = 0; i < IWX_MAX_QUEUES; i++) {
                struct iwx_tx_ring *ring = &sc->txq[i];
                XYLog("  tx ring %2d: qid=%-2d cur=%-3d "
                      "queued=%-3d\n",
                      i, ring->qid, ring->cur, ring->queued);
            }
            XYLog("  rx ring: cur=%d\n", sc->rxq.cur);
            XYLog("  802.11 state %s\n",
                  ieee80211_state_name[sc->sc_ic.ic_state]);

            that->iwx_nic_error(sc);
#endif
            if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0)
                task_add(systq, &sc->init_task);
            ifp->netStat->outputErrors++;
            return;
        }
        ifp->if_timer = 1;
    }

    ieee80211_watchdog(ifp);
}

int ItlIwx::
iwx_ioctl(struct _ifnet *ifp, u_long cmd, caddr_t data)
{
    struct iwx_softc *sc = (struct iwx_softc *)ifp->if_softc;
    int s, err = 0, generation = sc->sc_generation;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    
    /*
     * Prevent processes from entering this function while another
     * process is tsleep'ing in it.
     */
    //    err = rw_enter(&sc->ioctl_rwl, RW_WRITE | RW_INTR);
    if (err == 0 && generation != sc->sc_generation) {
        //        rw_exit(&sc->ioctl_rwl);
        return ENXIO;
    }
    if (err)
        return err;
    s = splnet();
    
    switch (cmd) {
        case SIOCSIFADDR:
            ifp->if_flags |= IFF_UP;
            /* FALLTHROUGH */
        case SIOCSIFFLAGS:
            if (ifp->if_flags & IFF_UP) {
                if (!(ifp->if_flags & IFF_RUNNING)) {
                    err = that->iwx_init(ifp);
                }
            } else {
                if (ifp->if_flags & IFF_RUNNING)
                    that->iwx_stop(ifp);
            }
            break;
            
        default:
            err = ieee80211_ioctl(ifp, cmd, data);
    }
    
    if (err == ENETRESET) {
        err = 0;
        if ((ifp->if_flags & (IFF_UP | IFF_RUNNING)) ==
            (IFF_UP | IFF_RUNNING)) {
            that->iwx_stop(ifp);
            err = that->iwx_init(ifp);
        }
    }
    
    splx(s);
    //    rw_exit(&sc->ioctl_rwl);
    
    return err;
}

#if 1 /* usually #ifdef IWX_DEBUG but always enabled for now */
/*
 * Note: This structure is read from the device with IO accesses,
 * and the reading already does the endian conversion. As it is
 * read with uint32_t-sized accesses, any members with a different size
 * need to be ordered correctly though!
 */
struct iwx_error_event_table {
    uint32_t valid;        /* (nonzero) valid, (0) log is empty */
    uint32_t error_id;        /* type of error */
    uint32_t trm_hw_status0;    /* TRM HW status */
    uint32_t trm_hw_status1;    /* TRM HW status */
    uint32_t blink2;        /* branch link */
    uint32_t ilink1;        /* interrupt link */
    uint32_t ilink2;        /* interrupt link */
    uint32_t data1;        /* error-specific data */
    uint32_t data2;        /* error-specific data */
    uint32_t data3;        /* error-specific data */
    uint32_t bcon_time;        /* beacon timer */
    uint32_t tsf_low;        /* network timestamp function timer */
    uint32_t tsf_hi;        /* network timestamp function timer */
    uint32_t gp1;        /* GP1 timer register */
    uint32_t gp2;        /* GP2 timer register */
    uint32_t fw_rev_type;    /* firmware revision type */
    uint32_t major;        /* uCode version major */
    uint32_t minor;        /* uCode version minor */
    uint32_t hw_ver;        /* HW Silicon version */
    uint32_t brd_ver;        /* HW board version */
    uint32_t log_pc;        /* log program counter */
    uint32_t frame_ptr;        /* frame pointer */
    uint32_t stack_ptr;        /* stack pointer */
    uint32_t hcmd;        /* last host command header */
    uint32_t isr0;        /* isr status register LMPM_NIC_ISR0:
                         * rxtx_flag */
    uint32_t isr1;        /* isr status register LMPM_NIC_ISR1:
                         * host_flag */
    uint32_t isr2;        /* isr status register LMPM_NIC_ISR2:
                         * enc_flag */
    uint32_t isr3;        /* isr status register LMPM_NIC_ISR3:
                         * time_flag */
    uint32_t isr4;        /* isr status register LMPM_NIC_ISR4:
                         * wico interrupt */
    uint32_t last_cmd_id;    /* last HCMD id handled by the firmware */
    uint32_t wait_event;        /* wait event() caller address */
    uint32_t l2p_control;    /* L2pControlField */
    uint32_t l2p_duration;    /* L2pDurationField */
    uint32_t l2p_mhvalid;    /* L2pMhValidBits */
    uint32_t l2p_addr_match;    /* L2pAddrMatchStat */
    uint32_t lmpm_pmg_sel;    /* indicate which clocks are turned on
                             * (LMPM_PMG_SEL) */
    uint32_t u_timestamp;    /* indicate when the date and time of the
                             * compilation */
    uint32_t flow_handler;    /* FH read/write pointers, RX credit */
} __packed /* LOG_ERROR_TABLE_API_S_VER_3 */;

/*
 * UMAC error struct - relevant starting from family 8000 chip.
 * Note: This structure is read from the device with IO accesses,
 * and the reading already does the endian conversion. As it is
 * read with u32-sized accesses, any members with a different size
 * need to be ordered correctly though!
 */
struct iwx_umac_error_event_table {
    uint32_t valid;        /* (nonzero) valid, (0) log is empty */
    uint32_t error_id;    /* type of error */
    uint32_t blink1;    /* branch link */
    uint32_t blink2;    /* branch link */
    uint32_t ilink1;    /* interrupt link */
    uint32_t ilink2;    /* interrupt link */
    uint32_t data1;        /* error-specific data */
    uint32_t data2;        /* error-specific data */
    uint32_t data3;        /* error-specific data */
    uint32_t umac_major;
    uint32_t umac_minor;
    uint32_t frame_pointer;    /* core register 27*/
    uint32_t stack_pointer;    /* core register 28 */
    uint32_t cmd_header;    /* latest host cmd sent to UMAC */
    uint32_t nic_isr_pref;    /* ISR status register */
} __packed;

#define ERROR_START_OFFSET  (1 * sizeof(uint32_t))
#define ERROR_ELEM_SIZE     (7 * sizeof(uint32_t))

void ItlIwx::
iwx_nic_umac_error(struct iwx_softc *sc)
{
    struct iwx_umac_error_event_table table;
    uint32_t base;
    
    base = sc->sc_uc.uc_umac_error_event_table;
    
    if (base < 0x400000) {
        XYLog("%s: Invalid error log pointer 0x%08x\n",
              DEVNAME(sc), base);
        return;
    }
    
    if (iwx_read_mem(sc, base, &table, sizeof(table)/sizeof(uint32_t))) {
        XYLog("%s: reading errlog failed\n", DEVNAME(sc));
        return;
    }
    
    if (ERROR_START_OFFSET <= table.valid * ERROR_ELEM_SIZE) {
        XYLog("%s: Start UMAC Error Log Dump:\n", DEVNAME(sc));
        XYLog("%s: Status: 0x%x, count: %d\n", DEVNAME(sc),
              sc->sc_flags, table.valid);
    }
    
    XYLog("%s: 0x%08X | %s\n", DEVNAME(sc), table.error_id,
          iwx_desc_lookup(table.error_id));
    XYLog("%s: 0x%08X | umac branchlink1\n", DEVNAME(sc), table.blink1);
    XYLog("%s: 0x%08X | umac branchlink2\n", DEVNAME(sc), table.blink2);
    XYLog("%s: 0x%08X | umac interruptlink1\n", DEVNAME(sc), table.ilink1);
    XYLog("%s: 0x%08X | umac interruptlink2\n", DEVNAME(sc), table.ilink2);
    XYLog("%s: 0x%08X | umac data1\n", DEVNAME(sc), table.data1);
    XYLog("%s: 0x%08X | umac data2\n", DEVNAME(sc), table.data2);
    XYLog("%s: 0x%08X | umac data3\n", DEVNAME(sc), table.data3);
    XYLog("%s: 0x%08X | umac major\n", DEVNAME(sc), table.umac_major);
    XYLog("%s: 0x%08X | umac minor\n", DEVNAME(sc), table.umac_minor);
    XYLog("%s: 0x%08X | frame pointer\n", DEVNAME(sc),
          table.frame_pointer);
    XYLog("%s: 0x%08X | stack pointer\n", DEVNAME(sc),
          table.stack_pointer);
    XYLog("%s: 0x%08X | last host cmd\n", DEVNAME(sc), table.cmd_header);
    XYLog("%s: 0x%08X | isr status reg\n", DEVNAME(sc),
          table.nic_isr_pref);
}

#define IWX_FW_SYSASSERT_CPU_MASK 0xf0000000
static struct {
    const char *name;
    uint8_t num;
} advanced_lookup[] = {
    { "NMI_INTERRUPT_WDG", 0x34 },
    { "SYSASSERT", 0x35 },
    { "UCODE_VERSION_MISMATCH", 0x37 },
    { "BAD_COMMAND", 0x38 },
    { "BAD_COMMAND", 0x39 },
    { "NMI_INTERRUPT_DATA_ACTION_PT", 0x3C },
    { "FATAL_ERROR", 0x3D },
    { "NMI_TRM_HW_ERR", 0x46 },
    { "NMI_INTERRUPT_TRM", 0x4C },
    { "NMI_INTERRUPT_BREAK_POINT", 0x54 },
    { "NMI_INTERRUPT_WDG_RXF_FULL", 0x5C },
    { "NMI_INTERRUPT_WDG_NO_RBD_RXF_FULL", 0x64 },
    { "NMI_INTERRUPT_HOST", 0x66 },
    { "NMI_INTERRUPT_LMAC_FATAL", 0x70 },
    { "NMI_INTERRUPT_UMAC_FATAL", 0x71 },
    { "NMI_INTERRUPT_OTHER_LMAC_FATAL", 0x73 },
    { "NMI_INTERRUPT_ACTION_PT", 0x7C },
    { "NMI_INTERRUPT_UNKNOWN", 0x84 },
    { "NMI_INTERRUPT_INST_ACTION_PT", 0x86 },
    { "ADVANCED_SYSASSERT", 0 },
};

const char *ItlIwx::
iwx_desc_lookup(uint32_t num)
{
    int i;
    
    for (i = 0; i < nitems(advanced_lookup) - 1; i++)
        if (advanced_lookup[i].num ==
            (num & ~IWX_FW_SYSASSERT_CPU_MASK))
            return advanced_lookup[i].name;
    
    /* No entry matches 'num', so it is the last: ADVANCED_SYSASSERT */
    return advanced_lookup[i].name;
}

/*
 * Support for dumping the error log seemed like a good idea ...
 * but it's mostly hex junk and the only sensible thing is the
 * hw/ucode revision (which we know anyway).  Since it's here,
 * I'll just leave it in, just in case e.g. the Intel guys want to
 * help us decipher some "ADVANCED_SYSASSERT" later.
 */
void ItlIwx::
iwx_nic_error(struct iwx_softc *sc)
{
    struct iwx_error_event_table table;
    uint32_t base;
    
    XYLog("%s: dumping device error log\n", DEVNAME(sc));
    base = sc->sc_uc.uc_lmac_error_event_table[0];
    if (base < 0x400000) {
        XYLog("%s: Invalid error log pointer 0x%08x\n",
              DEVNAME(sc), base);
        return;
    }
    
    if (iwx_read_mem(sc, base, &table, sizeof(table)/sizeof(uint32_t))) {
        XYLog("%s: reading errlog failed\n", DEVNAME(sc));
        return;
    }
    
    if (!table.valid) {
        XYLog("%s: errlog not found, skipping\n", DEVNAME(sc));
        return;
    }
    
    if (ERROR_START_OFFSET <= table.valid * ERROR_ELEM_SIZE) {
        XYLog("%s: Start Error Log Dump:\n", DEVNAME(sc));
        XYLog("%s: Status: 0x%x, count: %d\n", DEVNAME(sc),
              sc->sc_flags, table.valid);
    }
    
    XYLog("%s: 0x%08X | %-28s\n", DEVNAME(sc), table.error_id,
          iwx_desc_lookup(table.error_id));
    XYLog("%s: %08X | trm_hw_status0\n", DEVNAME(sc),
          table.trm_hw_status0);
    XYLog("%s: %08X | trm_hw_status1\n", DEVNAME(sc),
          table.trm_hw_status1);
    XYLog("%s: %08X | branchlink2\n", DEVNAME(sc), table.blink2);
    XYLog("%s: %08X | interruptlink1\n", DEVNAME(sc), table.ilink1);
    XYLog("%s: %08X | interruptlink2\n", DEVNAME(sc), table.ilink2);
    XYLog("%s: %08X | data1\n", DEVNAME(sc), table.data1);
    XYLog("%s: %08X | data2\n", DEVNAME(sc), table.data2);
    XYLog("%s: %08X | data3\n", DEVNAME(sc), table.data3);
    XYLog("%s: %08X | beacon time\n", DEVNAME(sc), table.bcon_time);
    XYLog("%s: %08X | tsf low\n", DEVNAME(sc), table.tsf_low);
    XYLog("%s: %08X | tsf hi\n", DEVNAME(sc), table.tsf_hi);
    XYLog("%s: %08X | time gp1\n", DEVNAME(sc), table.gp1);
    XYLog("%s: %08X | time gp2\n", DEVNAME(sc), table.gp2);
    XYLog("%s: %08X | uCode revision type\n", DEVNAME(sc),
          table.fw_rev_type);
    XYLog("%s: %08X | uCode version major\n", DEVNAME(sc),
          table.major);
    XYLog("%s: %08X | uCode version minor\n", DEVNAME(sc),
          table.minor);
    XYLog("%s: %08X | hw version\n", DEVNAME(sc), table.hw_ver);
    XYLog("%s: %08X | board version\n", DEVNAME(sc), table.brd_ver);
    XYLog("%s: %08X | hcmd\n", DEVNAME(sc), table.hcmd);
    XYLog("%s: %08X | isr0\n", DEVNAME(sc), table.isr0);
    XYLog("%s: %08X | isr1\n", DEVNAME(sc), table.isr1);
    XYLog("%s: %08X | isr2\n", DEVNAME(sc), table.isr2);
    XYLog("%s: %08X | isr3\n", DEVNAME(sc), table.isr3);
    XYLog("%s: %08X | isr4\n", DEVNAME(sc), table.isr4);
    XYLog("%s: %08X | last cmd Id\n", DEVNAME(sc), table.last_cmd_id);
    XYLog("%s: %08X | wait_event\n", DEVNAME(sc), table.wait_event);
    XYLog("%s: %08X | l2p_control\n", DEVNAME(sc), table.l2p_control);
    XYLog("%s: %08X | l2p_duration\n", DEVNAME(sc), table.l2p_duration);
    XYLog("%s: %08X | l2p_mhvalid\n", DEVNAME(sc), table.l2p_mhvalid);
    XYLog("%s: %08X | l2p_addr_match\n", DEVNAME(sc), table.l2p_addr_match);
    XYLog("%s: %08X | lmpm_pmg_sel\n", DEVNAME(sc), table.lmpm_pmg_sel);
    XYLog("%s: %08X | timestamp\n", DEVNAME(sc), table.u_timestamp);
    XYLog("%s: %08X | flow_handler\n", DEVNAME(sc), table.flow_handler);
    
    if (sc->sc_uc.uc_umac_error_event_table)
        iwx_nic_umac_error(sc);
}
#endif

//#define SYNC_RESP_STRUCT(_var_, _pkt_)                    \
//do {                                    \
//    bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*(_pkt_)),    \
//        sizeof(*(_var_)), BUS_DMASYNC_POSTREAD);            \
//    _var_ = (void *)((_pkt_)+1);                    \
//} while (/*CONSTCOND*/0)
//
//#define SYNC_RESP_PTR(_ptr_, _len_, _pkt_)                \
//do {                                    \
//    bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*(_pkt_)),    \
//        sizeof(len), BUS_DMASYNC_POSTREAD);                \
//    _ptr_ = (void *)((_pkt_)+1);                    \
//} while (/*CONSTCOND*/0)

#define SYNC_RESP_STRUCT(_var_, _pkt_, t)                    \
do {                                    \
bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*(_pkt_)),    \
sizeof(*(_var_)), BUS_DMASYNC_POSTREAD);            \
_var_ = (t)((_pkt_)+1);                    \
} while (/*CONSTCOND*/0)

int ItlIwx::
iwx_rx_pkt_valid(struct iwx_rx_packet *pkt)
{
    int qid, idx, code;
    
    qid = pkt->hdr.qid & ~0x80;
    idx = pkt->hdr.idx;
    code = IWX_WIDE_ID(pkt->hdr.group_id, pkt->hdr.cmd);
    
    return (!(qid == 0 && idx == 0 && code == 0) &&
            pkt->len_n_flags != htole32(IWX_FH_RSCSR_FRAME_INVALID));
}

/**
 * struct iwl_pnvm_init_complete_ntfy - PNVM initialization complete
 * @status: PNVM image loading status
 */
struct iwl_pnvm_init_complete_ntfy {
    uint32_t status;
} __packed; /* PNVM_INIT_COMPLETE_NTFY_S_VER_1 */

/*
 * Number of bytes of an RX buffer that iwx_rx_pkt() will consume. Must
 * stop exactly where the packet loop in iwx_rx_pkt() stops; the bytes
 * after this point are zeroed instead of copied from the bounce buffer.
 */
size_t ItlIwx::
iwx_rx_buf_used(struct iwx_softc *sc, const uint8_t *buf)
{
    struct iwx_rx_packet *pkt;
    const size_t minsz = sizeof(pkt->len_n_flags) + sizeof(pkt->hdr);
    uint32_t offset = 0, len;
    
    while (offset + minsz < IWX_RBUF_SIZE) {
        pkt = (struct iwx_rx_packet *)(buf + offset);
        if (!iwx_rx_pkt_valid(pkt))
            break;
        len = sizeof(pkt->len_n_flags) + iwx_rx_packet_len(pkt);
        if (len < minsz || len > (IWX_RBUF_SIZE - offset))
            break;
        offset += roundup(len, IWX_FH_RSCSR_FRAME_ALIGN);
        if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
            break;
    }
    return MIN(offset, IWX_RBUF_SIZE);
}

void ItlIwx::
iwx_rx_pkt(struct iwx_softc *sc, struct iwx_rx_data *data, struct mbuf_list *ml)
{
    struct _ifnet *ifp = IC2IFP(&sc->sc_ic);
    struct iwx_rx_packet *pkt, *nextpkt;
    uint32_t offset = 0, nextoff = 0, nmpdu = 0, len;
    mbuf_t m0, m;
    const size_t minsz = sizeof(pkt->len_n_flags) + sizeof(pkt->hdr);
    int qid, idx, code, handled;
    
    //    bus_dmamap_sync(sc->sc_dmat, data->map, 0, IWX_RBUF_SIZE,
    //        BUS_DMASYNC_POSTREAD);
    
    const uint8_t *rxbuf = (const uint8_t *)bus_dmamap_rx_data(data->map, IWX_RBUF_SIZE);
    if (rxbuf) {
        /* Copy only the packets the firmware wrote, zero the rest. */
        if (!bus_dmamap_read_used(data->map, data->m,
            iwx_rx_buf_used(sc, rxbuf), IWX_RBUF_SIZE)) {
            ifp->netStat->inputErrors++;
            return;
        }
    } else if (!bus_dmamap_read(data->map, data->m, IWX_RBUF_SIZE)) {
        ifp->netStat->inputErrors++;
        return;
    }
    m0 = data->m;
    while (m0 && offset + minsz < IWX_RBUF_SIZE) {
        handled = 1;
        pkt = (struct iwx_rx_packet *)((uint8_t*)mbuf_data(m0) + offset);
        qid = pkt->hdr.qid;
        idx = pkt->hdr.idx;
        
        code = IWX_WIDE_ID(pkt->hdr.group_id, pkt->hdr.cmd);
        
        DPRINTFN(3, ("%s gid=%d cmd=%d code=0x%02x qid=%d idx=%d packet_len=%d payload_len=%d\n", __FUNCTION__, pkt->hdr.group_id, pkt->hdr.cmd, code, qid, idx, iwx_rx_packet_len(pkt), iwx_rx_packet_payload_len(pkt)));
        
        if (!iwx_rx_pkt_valid(pkt))
            break;
        
        /*
         * XXX Intel inside (tm)
         * Any commands in the LONG_GROUP could actually be in the
         * LEGACY group. Firmware API versions >= 50 reject commands
         * in group 0, forcing us to use this hack.
         */
        if (iwx_cmd_groupid(code) == IWX_LONG_GROUP &&
            qid == IWX_DQA_CMD_QUEUE && idx < sc->txq[qid].ring_count) {
            struct iwx_tx_ring *ring = &sc->txq[qid];
            struct iwx_tx_data *txdata = &ring->data[idx];
            if (txdata->flags & IWX_TXDATA_FLAG_CMD_IS_NARROW)
                code = iwx_cmd_opcode(code);
        }
        
        len = sizeof(pkt->len_n_flags) + iwx_rx_packet_len(pkt);
        if (len < minsz || len > (IWX_RBUF_SIZE - offset))
            break;
        
        if (code == IWX_REPLY_RX_MPDU_CMD && ++nmpdu == 1) {
            /* Take mbuf m0 off the RX ring. */
            if (iwx_rx_addbuf(sc, IWX_RBUF_SIZE, sc->rxq.cur)) {
                ifp->netStat->inputErrors++;
                break;
            }
            KASSERT(data->m != m0, "data->m != m0");
        }
        
        if (code == IWX_STATISTICS_NOTIFICATION || code == IWX_STATISTICS_CMD) {
            const size_t length = iwx_rx_packet_payload_len(pkt);
            const bool observe = awdlRadioProbe && (sc->sc_flags & IWX_FLAG_MAC_ACTIVE) &&
                sc->sc_ic.ic_opmode == IEEE80211_M_MONITOR && sc->sc_ic.ic_state == IEEE80211_S_RUN &&
                !awdlBackgroundScanActive && !awdlCountryDiscovery;
            if (observe) {
                if (code == IWX_STATISTICS_CMD)
                    awdlRadioLastCommandLength = uint32_t(length);
                else
                    awdlRadioLastNotificationLength = uint32_t(length);
                if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_NEW_RX_STATS) &&
                    length == sizeof(iwx_notif_statistics)) {
                    const struct iwx_notif_statistics *stats;
                    SYNC_RESP_STRUCT(stats, pkt, const struct iwx_notif_statistics *);
                    awdlNoteRadioStatistics(stats->general.common);
                    awdlRadioReportUS = awdlUptimeUS();
                } else if (!isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_NEW_RX_STATS) &&
                           length == sizeof(iwx_notif_statistics_v11)) {
                    const struct iwx_notif_statistics_v11 *stats;
                    SYNC_RESP_STRUCT(stats, pkt, const struct iwx_notif_statistics_v11 *);
                    awdlNoteRadioStatistics(stats->general.common);
                    awdlRadioReportUS = awdlUptimeUS();
                } else if (code == IWX_STATISTICS_NOTIFICATION || length > sizeof(uint32_t)) {
                    ++awdlRadioUnexpectedLengths;
                }
            }
        }
        switch (code) {
            case IWX_REPLY_RX_PHY_CMD:
                iwx_rx_rx_phy_cmd(sc, pkt, data);
                break;
                
            case IWX_REPLY_RX_MPDU_CMD: {
                // This notification's own payload length (checked above against the buffer), not the
                // space left in the buffer: a firmware record can't then reach into the next one.
                size_t maxlen = iwx_rx_packet_payload_len(pkt);
                nextoff = offset +
                roundup(len, IWX_FH_RSCSR_FRAME_ALIGN);
                nextpkt = (struct iwx_rx_packet *)
                ((uint8_t*)mbuf_data(m0) + nextoff);
                if (nextoff + minsz >= IWX_RBUF_SIZE ||
                    !iwx_rx_pkt_valid(nextpkt)) {
                    /* No need to copy last frame in buffer. */
                    if (offset > 0)
                        mbuf_adj(m0, offset);
                    iwx_rx_mpdu_mq(sc, m0, pkt->data, maxlen, ml);
                    m0 = NULL; /* stack owns m0 now; abort loop */
                } else {
                    /*
                     * Create an mbuf which points to the current
                     * packet. Always copy from offset zero to
                     * preserve m_pkthdr.
                     */
                    mbuf_copym(m0, 0, MBUF_COPYALL, MBUF_DONTWAIT, &m);
                    if (m == NULL) {
                        ifp->netStat->inputErrors++;
                        mbuf_freem(m0);
                        m0 = NULL;
                        break;
                    }
                    mbuf_adj(m, offset);
                    iwx_rx_mpdu_mq(sc, m, pkt->data, maxlen, ml);
                }
                break;
            }
            case IWX_BA_NOTIF:
                iwx_rx_tx_ba_notif(sc, pkt, data);
                break;
                
            case IWX_TX_CMD:
                iwx_rx_tx_cmd(sc, pkt, data);
                break;
                
            case IWX_MISSED_BEACONS_NOTIFICATION:
                iwx_rx_bmiss(sc, pkt, data);
                break;
                
            case IWX_MFUART_LOAD_NOTIFICATION:
                break;
                
            case IWX_ALIVE: {
                struct iwx_alive_resp_v4 *resp4;
                struct iwx_alive_resp_v5 *resp5;
                
                DPRINTF(("%s: firmware alive, size=%d\n", __FUNCTION__, iwx_rx_packet_payload_len(pkt)));
                if (iwx_rx_packet_payload_len(pkt) == sizeof(*resp4)) {
                    SYNC_RESP_STRUCT(resp4, pkt, struct iwx_alive_resp_v4 *);
                    sc->sc_uc.uc_lmac_error_event_table[0] = le32toh(
                                                                     resp4->lmac_data[0].dbg_ptrs.error_event_table_ptr);
                    sc->sc_uc.uc_lmac_error_event_table[1] = le32toh(
                                                                     resp4->lmac_data[1].dbg_ptrs.error_event_table_ptr);
                    sc->sc_uc.uc_log_event_table = le32toh(
                                                           resp4->lmac_data[0].dbg_ptrs.log_event_table_ptr);
                    sc->sc_uc.uc_umac_error_event_table = le32toh(
                                                                  resp4->umac_data.dbg_ptrs.error_info_addr);
                    if (resp4->status == IWX_ALIVE_STATUS_OK)
                        sc->sc_uc.uc_ok = 1;
                    else
                        sc->sc_uc.uc_ok = 0;
                } else if (IWX_NOTIF_FITS(pkt, struct iwx_alive_resp_v5)) {
                    SYNC_RESP_STRUCT(resp5, pkt, struct iwx_alive_resp_v5 *);
                    sc->sc_uc.uc_lmac_error_event_table[0] = le32toh(
                                                                     resp5->lmac_data[0].dbg_ptrs.error_event_table_ptr);
                    sc->sc_uc.uc_lmac_error_event_table[1] = le32toh(
                                                                     resp5->lmac_data[1].dbg_ptrs.error_event_table_ptr);
                    sc->sc_uc.uc_log_event_table = le32toh(
                                                           resp5->lmac_data[0].dbg_ptrs.log_event_table_ptr);
                    sc->sc_uc.uc_umac_error_event_table = le32toh(
                                                                  resp5->umac_data.dbg_ptrs.error_info_addr);
                    if (resp5->status == IWX_ALIVE_STATUS_OK)
                        sc->sc_uc.uc_ok = 1;
                    else
                        sc->sc_uc.uc_ok = 0;
                    
                    sc->sku_id[0] = le32toh(resp5->sku_id.data[0]);
                    sc->sku_id[1] = le32toh(resp5->sku_id.data[1]);
                    sc->sku_id[2] = le32toh(resp5->sku_id.data[2]);
                    
                    XYLog("Got sku_id: 0x0%x 0x0%x 0x0%x\n",
                                 sc->sku_id[0],
                                 sc->sku_id[1],
                                 sc->sku_id[2]);
                } else {
                    // Neither known size: report a failed start instead of reading past the record.
                    sc->sc_uc.uc_ok = 0;
                }
                
                sc->sc_uc.uc_intr = 1;
                getMainCommandGate()->commandWakeup(&sc->sc_uc.uc_intr);
                break;
            }
                
            case IWX_STATISTICS_NOTIFICATION: {
                struct iwx_notif_statistics *stats;
                struct iwx_notif_statistics_v11 *stats_v11;
                if (isset(sc->sc_ucode_api, IWX_UCODE_TLV_API_NEW_RX_STATS)) {
                    if (iwx_rx_packet_payload_len(pkt) < sizeof(*stats))
                        break;
                    SYNC_RESP_STRUCT(stats, pkt, struct iwx_notif_statistics *);
                    sc->sc_noise = iwx_get_noise((uint8_t *)&stats->rx.general.beacon_silence_rssi_a);
                } else {
                    if (iwx_rx_packet_payload_len(pkt) < sizeof(*stats_v11))
                        break;
                    SYNC_RESP_STRUCT(stats_v11, pkt, struct iwx_notif_statistics_v11 *);
                    sc->sc_noise = iwx_get_noise((uint8_t *)&stats_v11->rx.general.beacon_silence_rssi_a);
                }
                break;
            }
                
            case IWX_DTS_MEASUREMENT_NOTIFICATION:
            case IWX_WIDE_ID(IWX_PHY_OPS_GROUP,
                             IWX_DTS_MEASUREMENT_NOTIF_WIDE):
            case IWX_WIDE_ID(IWX_PHY_OPS_GROUP,
                             IWX_TEMP_REPORTING_THRESHOLDS_CMD):
                break;
                
            case IWX_WIDE_ID(IWX_PHY_OPS_GROUP,
                             IWX_CT_KILL_NOTIFICATION): {
                struct iwx_ct_kill_notif *notif;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_ct_kill_notif *);
                XYLog("%s: device at critical temperature (%u degC), "
                       "stopping device\n",
                       DEVNAME(sc), IWX_NOTIF_FITS(pkt, struct iwx_ct_kill_notif) ? le16toh(notif->temperature) : 0);
                sc->sc_flags |= IWX_FLAG_HW_ERR;
                task_add(systq, &sc->init_task);
                break;
            }
                
            case IWX_WIDE_ID(IWX_REGULATORY_AND_NVM_GROUP,
                IWX_NVM_GET_INFO):
            case IWX_ADD_STA_KEY:
            case IWX_PHY_CONFIGURATION_CMD:
            case IWX_TX_ANT_CONFIGURATION_CMD:
            case IWX_ADD_STA:
            case IWX_MAC_CONTEXT_CMD:
            case IWX_REPLY_SF_CFG_CMD:
            case IWX_POWER_TABLE_CMD:
            case IWX_LTR_CONFIG:
            case IWX_PHY_CONTEXT_CMD:
            case IWX_BINDING_CONTEXT_CMD:
            case IWX_WIDE_ID(IWX_LONG_GROUP, IWX_SCAN_CFG_CMD):
            case IWX_WIDE_ID(IWX_LONG_GROUP, IWX_SCAN_REQ_UMAC):
            case IWX_WIDE_ID(IWX_LONG_GROUP, IWX_SCAN_ABORT_UMAC):
            case IWX_WIDE_ID(IWX_MAC_CONF_GROUP, IWX_SESSION_PROTECTION_CMD):
            case IWX_REPLY_BEACON_FILTERING_CMD:
            case IWX_MAC_PM_POWER_TABLE:
            case IWX_TIME_QUOTA_CMD:
            case IWX_REMOVE_STA:
            case IWX_TXPATH_FLUSH:
            case IWX_BT_CONFIG:
            case IWX_MCC_UPDATE_CMD:
            case IWX_TIME_EVENT_CMD:
            case IWX_STATISTICS_CMD:
            case IWX_SCD_QUEUE_CFG: {
                size_t pkt_len;
                
                if (qid != IWX_DQA_CMD_QUEUE ||
                    idx >= sc->txq[IWX_DQA_CMD_QUEUE].ring_count ||
                    !(sc->txq[IWX_DQA_CMD_QUEUE].data[idx].flags & IWX_TXDATA_FLAG_CMD_PENDING) ||
                    sc->sc_cmd_resp_pkt[idx] == NULL)
                    break;
                
                //            bus_dmamap_sync(sc->sc_dmat, data->map, 0,
                //                sizeof(*pkt), BUS_DMASYNC_POSTREAD);
                
                pkt_len = sizeof(pkt->len_n_flags) +
                iwx_rx_packet_len(pkt);
                
                if ((pkt->hdr.group_id & IWX_CMD_FAILED_MSK) ||
                    pkt_len < sizeof(*pkt) ||
                    pkt_len > sc->sc_cmd_resp_len[idx]) {
                    ::free(sc->sc_cmd_resp_pkt[idx]);
                    sc->sc_cmd_resp_pkt[idx] = NULL;
                    break;
                }
                
                //            bus_dmamap_sync(sc->sc_dmat, data->map, sizeof(*pkt),
                //                pkt_len - sizeof(*pkt), BUS_DMASYNC_POSTREAD);
                memcpy(sc->sc_cmd_resp_pkt[idx], pkt, pkt_len);
                break;
            }
                
            case IWX_WIDE_ID(IWX_REGULATORY_AND_NVM_GROUP, IWX_PNVM_INIT_COMPLETE_NTFY):
                sc->sc_init_complete |= IWX_PNVM_COMPLETE;
                getMainCommandGate()->commandWakeup(&sc->sc_init_complete);
                struct iwl_pnvm_init_complete_ntfy *pnvm_ntf;
                SYNC_RESP_STRUCT(pnvm_ntf, pkt, struct iwl_pnvm_init_complete_ntfy *);
                if (IWX_NOTIF_FITS(pkt, struct iwl_pnvm_init_complete_ntfy))
                    XYLog("PNVM complete notification received with status 0x%0x\n", le32toh(pnvm_ntf->status));
                break;
                
            case IWX_INIT_COMPLETE_NOTIF:
                sc->sc_init_complete |= IWX_INIT_COMPLETE;
                getMainCommandGate()->commandWakeup(&sc->sc_init_complete);
                break;
                
            case IWX_SCAN_COMPLETE_UMAC: {
                struct iwx_umac_scan_complete *notif;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_umac_scan_complete *);
                awdlBackgroundScanActive = false;
                if (awdlCountryDiscovery) {
                    awdlCountryScanDone = true;
                    getMainCommandGate()->commandWakeup(&awdlCountryDiscovery);
                }
                iwx_endscan(sc);
                break;
            }
                
            case IWX_SCAN_ITERATION_COMPLETE_UMAC: {
                struct iwx_umac_scan_iter_complete_notif *notif;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_umac_scan_iter_complete_notif *);
                awdlBackgroundScanActive = false;
                if (awdlCountryDiscovery) {
                    awdlCountryScanDone = true;
                    getMainCommandGate()->commandWakeup(&awdlCountryDiscovery);
                }
                iwx_endscan(sc);
                break;
            }
                
            case IWX_MCC_CHUB_UPDATE_CMD: {
                struct iwx_mcc_chub_notif *notif;
                if (!IWX_NOTIF_FITS(pkt, struct iwx_mcc_chub_notif))
                    break;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_mcc_chub_notif *);
                iwx_mcc_update(sc, notif);
                break;
            }
                
            case IWX_REPLY_ERROR: {
                struct iwx_error_resp *resp;
                if (!IWX_NOTIF_FITS(pkt, struct iwx_error_resp))
                    break;
                SYNC_RESP_STRUCT(resp, pkt, struct iwx_error_resp *);
                XYLog("%s: firmware error 0x%x, cmd 0x%x\n",
                      DEVNAME(sc), le32toh(resp->error_type),
                      resp->cmd_id);
                break;
            }
                
            case IWX_TIME_EVENT_NOTIFICATION: {
                struct iwx_time_event_notif *notif;
                uint32_t action;
                if (!IWX_NOTIF_FITS(pkt, struct iwx_time_event_notif))
                    break;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_time_event_notif *);
                
                if (sc->sc_time_event_uid != le32toh(notif->unique_id))
                    break;
                action = le32toh(notif->action);
                if (action & IWX_TE_V2_NOTIF_HOST_EVENT_END)
                    sc->sc_flags &= ~IWX_FLAG_TE_ACTIVE;
                break;
            }
                
            case IWX_WIDE_ID(IWX_SYSTEM_GROUP,
                             IWX_FSEQ_VER_MISMATCH_NOTIFICATION):
                break;
                
                /*
                 * Firmware versions 21 and 22 generate some DEBUG_LOG_MSG
                 * messages. Just ignore them for now.
                 */
            case IWX_DEBUG_LOG_MSG:
                break;
                
            case IWX_MCAST_FILTER_CMD:
                break;
                
            case IWX_WIDE_ID(IWX_DATA_PATH_GROUP, IWX_DQA_ENABLE_CMD):
                break;
                
            case IWX_WIDE_ID(IWX_SYSTEM_GROUP, IWX_SOC_CONFIGURATION_CMD):
                break;
                
            case IWX_WIDE_ID(IWX_SYSTEM_GROUP, IWX_INIT_EXTENDED_CFG_CMD):
                break;
                
            case IWX_WIDE_ID(IWX_SYSTEM_GROUP, IWX_SHARED_MEM_CFG_CMD):
                break;
                
            case IWX_WIDE_ID(IWX_REGULATORY_AND_NVM_GROUP,
                             IWX_NVM_ACCESS_COMPLETE):
                break;
                
            case IWX_WIDE_ID(IWX_DATA_PATH_GROUP, IWX_RX_NO_DATA_NOTIF):
                break; /* happens in monitor mode; ignore for now */
            case IWX_WIDE_ID(IWX_DATA_PATH_GROUP, IWX_TLC_MNG_CONFIG_CMD):
                break;
            case IWX_WIDE_ID(IWX_DATA_PATH_GROUP, IWX_STA_HE_CTXT_CMD):
                /* Empty command ACK; complete the synchronous HE setup below. */
                break;
                
            case IWX_WIDE_ID(IWX_DATA_PATH_GROUP,
                             IWX_TLC_MNG_UPDATE_NOTIF): {
                struct iwx_tlc_update_notif *notif;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_tlc_update_notif *);
                if (iwx_rx_packet_payload_len(pkt) == sizeof(*notif))
                    iwx_rs_update(sc, notif);
                break;
            }
                
            case IWX_WIDE_ID(IWX_MAC_CONF_GROUP, IWX_SESSION_PROTECTION_NOTIF): {
                struct iwx_session_prot_notif *notif;
                if (!IWX_NOTIF_FITS(pkt, struct iwx_session_prot_notif))
                    break;
                SYNC_RESP_STRUCT(notif, pkt, struct iwx_session_prot_notif *);
                if (!notif->status) {
                    XYLog("Session protection failure\n");
                    sc->sc_flags &= ~IWX_FLAG_TE_ACTIVE;
                    break;
                }
                if (!notif->start) {
                    /*
                     * By now, we should have finished association
                     * and know the dtim period.
                     */
                    sc->sc_flags &= ~IWX_FLAG_TE_ACTIVE;
                    XYLog("%s finish association\n", __FUNCTION__);
                }
                break;
            }
            
            case IWX_WIDE_ID(IWX_LEGACY_GROUP, IWX_BAR_FRAME_RELEASE): {
                struct iwx_bar_frame_release *release;
                if (!IWX_NOTIF_FITS(pkt, struct iwx_bar_frame_release))     // before any field is read
                    break;
                SYNC_RESP_STRUCT(release, pkt, struct iwx_bar_frame_release *);
                unsigned int baid = le32_get_bits(release->ba_info,
                                  IWX_BAR_FRAME_RELEASE_BAID_MASK);
                unsigned int nssn = le32_get_bits(release->ba_info,
                                  IWX_BAR_FRAME_RELEASE_NSSN_MASK);
                unsigned int sta_id = le32_get_bits(release->sta_tid,
                                    IWX_BAR_FRAME_RELEASE_STA_MASK);
                unsigned int tid = le32_get_bits(release->sta_tid,
                                 IWX_BAR_FRAME_RELEASE_TID_MASK);
                struct iwx_rxba_data *baid_data;
                
                if (iwx_rx_packet_payload_len(pkt) < sizeof(*release))
                    break;
                
                if (baid == IWX_RX_REORDER_DATA_INVALID_BAID || baid >= IWX_MAX_BAID)
                    break;
                
                baid_data = &sc->sc_rxba_data[baid];
                
                if (!baid_data) {
                    DPRINTFN(1, ("Got valid BAID %d but not allocated, invalid BAR release!\n",
                     baid));
                    break;
                }
                
                if (sta_id == kAwdlBaStationId)
                    ++awdlBaBarReleases;
                if (tid != baid_data->tid || sta_id != baid_data->sta_id) {
                    DPRINTFN(1, ("baid 0x%x is mapped to sta:%d tid:%d, but BAR release received for sta:%d tid:%d\n",
                                 baid, baid_data->sta_id, baid_data->tid, sta_id,
                                 tid));
                    break;
                }
                
                iwx_release_frames(sc, sc->sc_ic.ic_bss, baid_data, &baid_data->reorder_buf, nssn, ml);
                
                break;
            }
                
            default:
                handled = 0;
                XYLog("%s: unhandled firmware response 0x%x/0x%x "
                      "rx ring %d[%d]\n",
                      DEVNAME(sc), code, pkt->len_n_flags,
                      (qid & ~0x80), idx);
                break;
        }
        
        /*
         * uCode sets bit 0x80 when it originates the notification,
         * i.e. when the notification is not a direct response to a
         * command sent by the driver.
         * For example, uCode issues IWX_REPLY_RX when it sends a
         * received frame to the driver.
         */
        if (handled && !(qid & (1 << 7))) {
            iwx_cmd_done(sc, qid, idx, code);
        }
        
        offset += roundup(len, IWX_FH_RSCSR_FRAME_ALIGN);
        
        if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
            break;
    }
    
    if (m0 && m0 != data->m && mbuf_type(m0) != MBUF_TYPE_FREE)
        mbuf_freem(m0);
}

void ItlIwx::
iwx_notif_intr(struct iwx_softc *sc)
{
    struct mbuf_list ml = MBUF_LIST_INITIALIZER();
    uint16_t hw;
    
    //    bus_dmamap_sync(sc->sc_dmat, sc->rxq.stat_dma.map,
    //        0, sc->rxq.stat_dma.size, BUS_DMASYNC_POSTREAD);
    
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        hw = le16toh(*(uint16_t *)(sc->rxq.stat)) & 0xfff;
    else
        hw = le16toh(((struct iwx_rb_status *)sc->rxq.stat)->closed_rb_num) & 0xfff;
    hw &= (IWX_RX_MQ_RING_COUNT - 1);
    DPRINTFN(3, ("%s hw=%d\n", __FUNCTION__, hw));
    while (sc->rxq.cur != hw) {
        struct iwx_rx_data *data = &sc->rxq.data[sc->rxq.cur];
        iwx_rx_pkt(sc, data, &ml);
        sc->rxq.cur = (sc->rxq.cur + 1) % IWX_RX_MQ_RING_COUNT;
    }
    if_input(&sc->sc_ic.ic_if, &ml);
    
    /*
     * Tell the firmware what we have processed.
     * Seems like the hardware gets upset unless we align the write by 8??
     */
    hw = (hw == 0) ? IWX_RX_MQ_RING_COUNT - 1 : hw - 1;
    IWX_WRITE(sc, IWX_RFH_Q0_FRBDCB_WIDX_TRG, hw & ~7);
}

int ItlIwx::
iwx_intr(OSObject *object, IOInterruptEventSource* sender, int count)
{
//    XYLog("Interrupt!!!\n");
    ItlIwx *that = (ItlIwx*)object;
    struct iwx_softc *sc = &that->com;
    int handled = 0;
    int r1, r2, rv = 0;
    
//    IWX_WRITE(&that->com, IWX_CSR_INT_MASK, 0);
    
    if (sc->sc_flags & IWX_FLAG_USE_ICT) {
        uint32_t *ict = (uint32_t *)sc->ict_dma.vaddr;
        int tmp;
        
        tmp = htole32(ict[sc->ict_cur]);
        if (!tmp)
            goto out_ena;
        
        /*
         * ok, there was something.  keep plowing until we have all.
         */
        r1 = r2 = 0;
        while (tmp) {
            r1 |= tmp;
            ict[sc->ict_cur] = 0;
            sc->ict_cur = (sc->ict_cur+1) % IWX_ICT_COUNT;
            tmp = htole32(ict[sc->ict_cur]);
        }
        
        /* this is where the fun begins.  don't ask */
        if (r1 == 0xffffffff)
            r1 = 0;
        
        /* i am not expected to understand this */
        if (r1 & 0xc0000)
            r1 |= 0x8000;
        r1 = (0xff & r1) | ((0xff00 & r1) << 16);
    } else {
        r1 = IWX_READ(sc, IWX_CSR_INT);
        if (r1 == 0xffffffff || (r1 & 0xfffffff0) == 0xa5a5a5a0)
            goto out;
        r2 = IWX_READ(sc, IWX_CSR_FH_INT_STATUS);
    }
    if (r1 == 0 && r2 == 0) {
        goto out_ena;
    }
    
    IWX_WRITE(sc, IWX_CSR_INT, r1 | ~sc->sc_intmask);
    
    if (r1 & IWX_CSR_INT_BIT_ALIVE) {
        int i;
        
        /* Firmware has now configured the RFH. */
        for (i = 0; i < IWX_RX_MQ_RING_COUNT; i++)
            that->iwx_update_rx_desc(sc, &sc->rxq, i);
        IWX_WRITE(sc, IWX_RFH_Q0_FRBDCB_WIDX_TRG, 8);
    }
    
    handled |= (r1 & (IWX_CSR_INT_BIT_ALIVE /*| IWX_CSR_INT_BIT_SCD*/));
    
    if (r1 & IWX_CSR_INT_BIT_RF_KILL) {
        handled |= IWX_CSR_INT_BIT_RF_KILL;
        XYLog("%s RF_KILL has been toggled\n", __FUNCTION__);
        that->iwx_check_rfkill(sc);
        task_add(systq, &sc->init_task);
        rv = 1;
        goto out_ena;
    }
    
    if (r1 & IWX_CSR_INT_BIT_SW_ERR) {
#if 1 /* usually #ifdef IWX_DEBUG but always enabled for now */
        int i;
        
        that->iwx_nic_error(sc);
        
        /* Dump driver status (TX and RX rings) while we're here. */
        XYLog("driver status:\n");
        for (i = 0; i < IWX_MAX_QUEUES; i++) {
            struct iwx_tx_ring *ring = &sc->txq[i];
            XYLog("  tx ring %2d: qid=%-2d cur=%-3d "
                  "queued=%-3d\n",
                  i, ring->qid, ring->cur, ring->queued);
        }
        XYLog("  rx ring: cur=%d\n", sc->rxq.cur);
        XYLog("  802.11 state %s\n",
              ieee80211_state_name[sc->sc_ic.ic_state]);
#endif
        
        XYLog("%s: fatal firmware error\n", DEVNAME(sc));
        if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0)
            task_add(systq, &sc->init_task);
        rv = 1;
        goto out;
        
    }
    
    if (r1 & IWX_CSR_INT_BIT_HW_ERR) {
        handled |= IWX_CSR_INT_BIT_HW_ERR;
        XYLog("%s: hardware error, stopping device \n", DEVNAME(sc));
        if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0) {
            sc->sc_flags |= IWX_FLAG_HW_ERR;
            task_add(systq, &sc->init_task);
        }
        rv = 1;
        goto out;
    }
    
    /* firmware chunk loaded */
    if (r1 & IWX_CSR_INT_BIT_FH_TX) {
        IWX_WRITE(sc, IWX_CSR_FH_INT_STATUS, IWX_CSR_FH_INT_TX_MASK);
        handled |= IWX_CSR_INT_BIT_FH_TX;
        
        sc->sc_fw_chunk_done = 1;
        that->wakeupOn(&sc->sc_fw);
    }
    
    if (r1 & (IWX_CSR_INT_BIT_FH_RX | IWX_CSR_INT_BIT_SW_RX |
              IWX_CSR_INT_BIT_RX_PERIODIC)) {
        if (r1 & (IWX_CSR_INT_BIT_FH_RX | IWX_CSR_INT_BIT_SW_RX)) {
            handled |= (IWX_CSR_INT_BIT_FH_RX | IWX_CSR_INT_BIT_SW_RX);
            IWX_WRITE(sc, IWX_CSR_FH_INT_STATUS, IWX_CSR_FH_INT_RX_MASK);
        }
        if (r1 & IWX_CSR_INT_BIT_RX_PERIODIC) {
            handled |= IWX_CSR_INT_BIT_RX_PERIODIC;
            IWX_WRITE(sc, IWX_CSR_INT, IWX_CSR_INT_BIT_RX_PERIODIC);
        }
        
        /* Disable periodic interrupt; we use it as just a one-shot. */
        IWX_WRITE_1(sc, IWX_CSR_INT_PERIODIC_REG, IWX_CSR_INT_PERIODIC_DIS);
        
        /*
         * Enable periodic interrupt in 8 msec only if we received
         * real RX interrupt (instead of just periodic int), to catch
         * any dangling Rx interrupt.  If it was just the periodic
         * interrupt, there was no dangling Rx activity, and no need
         * to extend the periodic interrupt; one-shot is enough.
         */
        if (r1 & (IWX_CSR_INT_BIT_FH_RX | IWX_CSR_INT_BIT_SW_RX))
            IWX_WRITE_1(sc, IWX_CSR_INT_PERIODIC_REG,
                        IWX_CSR_INT_PERIODIC_ENA);
        
        that->iwx_notif_intr(sc);
    }
    
    rv = 1;
    
out_ena:
    that->iwx_restore_interrupts(sc);
out:
    return rv;
}

int ItlIwx::
iwx_intr_msix(OSObject *object, IOInterruptEventSource* sender, int count)
{
//    XYLog("Interrupt!!!\n");
    ItlIwx *that = (ItlIwx*)object;
    struct iwx_softc *sc = &that->com;
    uint32_t inta_fh, inta_hw;
    int vector = 0;
    
    inta_fh = IWX_READ(sc, IWX_CSR_MSIX_FH_INT_CAUSES_AD);
    inta_hw = IWX_READ(sc, IWX_CSR_MSIX_HW_INT_CAUSES_AD);
    IWX_WRITE(sc, IWX_CSR_MSIX_FH_INT_CAUSES_AD, inta_fh);
    IWX_WRITE(sc, IWX_CSR_MSIX_HW_INT_CAUSES_AD, inta_hw);
    inta_fh &= sc->sc_fh_mask;
    inta_hw &= sc->sc_hw_mask;
    
    if (inta_fh & IWX_MSIX_FH_INT_CAUSES_Q0 ||
        inta_fh & IWX_MSIX_FH_INT_CAUSES_Q1) {
        that->iwx_notif_intr(sc);
    }
    
    /* firmware chunk loaded */
    if (inta_fh & IWX_MSIX_FH_INT_CAUSES_D2S_CH0_NUM) {
        sc->sc_fw_chunk_done = 1;
        that->wakeupOn(&sc->sc_fw);
    }
    
    if ((inta_fh & IWX_MSIX_FH_INT_CAUSES_FH_ERR) ||
        (inta_hw & IWX_MSIX_HW_INT_CAUSES_REG_SW_ERR) ||
        (inta_hw & IWX_MSIX_HW_INT_CAUSES_REG_SW_ERR_V2)) {
#if 1 /* usually #ifdef IWX_DEBUG but always enabled for now */
        int i;
        
        that->iwx_nic_error(sc);
        
        /* Dump driver status (TX and RX rings) while we're here. */
        XYLog("driver status:\n");
        for (i = 0; i < IWX_MAX_QUEUES; i++) {
            struct iwx_tx_ring *ring = &sc->txq[i];
            XYLog("  tx ring %2d: qid=%-2d cur=%-3d "
                  "queued=%-3d\n",
                  i, ring->qid, ring->cur, ring->queued);
        }
        XYLog("  rx ring: cur=%d\n", sc->rxq.cur);
        XYLog("  802.11 state %s\n",
              ieee80211_state_name[sc->sc_ic.ic_state]);
#endif
        
        XYLog("%s: fatal firmware error\n", DEVNAME(sc));
        if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0)
            task_add(systq, &sc->init_task);
        return 1;
    }
    
    if (inta_hw & IWX_MSIX_HW_INT_CAUSES_REG_RF_KILL) {
        that->iwx_check_rfkill(sc);
        task_add(systq, &sc->init_task);
    }
    
    if (inta_hw & IWX_MSIX_HW_INT_CAUSES_REG_HW_ERR) {
        XYLog("%s: hardware error, stopping device \n", DEVNAME(sc));
        if ((sc->sc_flags & IWX_FLAG_SHUTDOWN) == 0) {
            sc->sc_flags |= IWX_FLAG_HW_ERR;
            task_add(systq, &sc->init_task);
        }
        return 1;
    }
    
    if (inta_hw & IWX_MSIX_HW_INT_CAUSES_REG_ALIVE) {
        int i;
        
        /* Firmware has now configured the RFH. */
        for (i = 0; i < IWX_RX_MQ_RING_COUNT; i++)
            that->iwx_update_rx_desc(sc, &sc->rxq, i);
        IWX_WRITE(sc, IWX_RFH_Q0_FRBDCB_WIDX_TRG, 8);
    }
    
    /*
     * Before sending the interrupt the HW disables it to prevent
     * a nested interrupt. This is done by writing 1 to the corresponding
     * bit in the mask register. After handling the interrupt, it should be
     * re-enabled by clearing this bit. This register is defined as
     * write 1 clear (W1C) register, meaning that it's being clear
     * by writing 1 to the bit.
     */
    IWX_WRITE(sc, IWX_CSR_MSIX_AUTOMASK_ST_AD, 1 << vector);
    return 1;
}

#define PCI_VENDOR_INTEL 0x8086

#define IWL_PCI_DEVICE(dev, subdev, cfg) \
.pm_vid = PCI_VENDOR_INTEL,  .pm_pid = (dev), \
.pm_sub_vid = PCI_ANY_ID, .pm_sub_dev = (subdev), \
.drv_data = (void *)&(cfg)

/*
 * If the device doesn't support HE, no need to have that many buffers.
 * 22000 devices can split multiple frames into a single RB, so fewer are
 * needed; AX210 cannot (but use smaller RBs by default) - these sizes
 * were picked according to 8 MSDUs inside 256 A-MSDUs in an A-MPDU, with
 * additional overhead to account for processing time.
 */
#define IWL_NUM_RBDS_NON_HE        512
#define IWL_NUM_RBDS_22000_HE        2048
#define IWL_NUM_RBDS_AX210_HE        4096

/*
 * A-MPDU buffer sizes
 * According to HT size varies from 8 to 64 frames
 * HE adds the ability to have up to 256 frames.
 */
#define IEEE80211_MIN_AMPDU_BUF        0x8
#define IEEE80211_MAX_AMPDU_BUF_HT    0x40
#define IEEE80211_MAX_AMPDU_BUF        0x100

const struct iwl_cfg_trans_params iwl_qu_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_22000,
    .integrated = 1,
    .xtal_latency = 5000,
    .ltr_delay = IWX_SOC_FLAGS_LTR_APPLY_DELAY_200,
};

const struct iwl_cfg_trans_params iwl_qu_medium_latency_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_22000,
    .integrated = 1,
    .xtal_latency = 1820,
    .ltr_delay = IWX_SOC_FLAGS_LTR_APPLY_DELAY_1820,
};

const struct iwl_cfg_trans_params iwl_qu_long_latency_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_22000,
    .integrated = 1,
    .xtal_latency = 12000,
    .low_latency_xtal = true,
    .ltr_delay = IWX_SOC_FLAGS_LTR_APPLY_DELAY_2500,
};

const struct iwl_cfg_trans_params iwl_qnj_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_22000,
};

const struct iwl_cfg_trans_params iwl_snj_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_AX210,
};

const struct iwl_cfg_trans_params iwl_so_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .integrated = 1,
    .xtal_latency = 500,
    .ltr_delay = IWX_SOC_FLAGS_LTR_APPLY_DELAY_200,
};

const struct iwl_cfg_trans_params iwl_so_long_latency_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .integrated = 1,
    .xtal_latency = 12000,
    .ltr_delay = IWX_SOC_FLAGS_LTR_APPLY_DELAY_2500,
};

const struct iwl_cfg_trans_params iwl_ma_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .integrated = 1,
};

const struct iwl_cfg_trans_params iwl_ax200_trans_cfg = {
    .device_family = IWX_DEVICE_FAMILY_22000,
    .bisr_workaround = 1,
};

const struct iwl_cfg iwlax210_2ax_cfg_so_jf_a0 = {
    .name = "Intel(R) Wireless-AC 9560 160MHz",
    .fwname = "iwlwifi-so-a0-jf-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwlax210_2ax_cfg_so_hr_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX210 160MHz",
    .fwname = "iwlwifi-so-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax211_2ax_cfg_so_gf_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX211 160MHz",
    .fwname = "iwlwifi-so-a0-gf-a0-68.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax211_2ax_cfg_so_gf_a0_long = {
    .name = "Intel(R) Wi-Fi 6 AX211 160MHz",
    .fwname = "iwlwifi-so-a0-gf-a0-68.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .trans.xtal_latency = 12000,
    .trans.low_latency_xtal = 1,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax210_2ax_cfg_ty_gf_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX210 160MHz",
    .fwname = "iwlwifi-ty-a0-gf-a0-68.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax411_2ax_cfg_so_gf4_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX411 160MHz",
    .fwname = "iwlwifi-so-a0-gf4-a0-68.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax411_2ax_cfg_so_gf4_a0_long = {
    .name = "Intel(R) Wi-Fi 6 AX411 160MHz",
    .fwname = "iwlwifi-so-a0-gf4-a0-68.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .trans.xtal_latency = 12000,
    .trans.low_latency_xtal = 1,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax411_2ax_cfg_sosnj_gf4_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX411 160MHz",
    .fwname = "iwlwifi-SoSnj-a0-gf4-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwlax211_cfg_snj_gf_a0 = {
    .name = "Intel(R) Wi-Fi 6 AX211 160MHz",
    .fwname = "iwlwifi-SoSnj-a0-gf-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_snj_hr_b0 = {
    .fwname = "iwlwifi-SoSnj-a0-hr-b0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_snj_a0_jf_b0 = {
    .fwname = "iwlwifi-SoSnj-a0-jf-b0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_ma_a0_hr_b0 = {
    .fwname = "iwlwifi-ma-a0-hr-b0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_ma_a0_gf_a0 = {
    .fwname = "iwlwifi-ma-a0-gf-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_ma_a0_gf4_a0 = {
    .fwname = "iwlwifi-ma-a0-gf4-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_ma_a0_mr_a0 = {
    .fwname = "iwlwifi-ma-a0-mr-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_ma_a0_fm_a0 = {
    .fwname = "iwlwifi-ma-a0-fm-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_snj_a0_mr_a0 = {
    .fwname = "iwlwifi-SoSnj-a0-mr-a0-63.ucode",
    .uhb_supported = 1,
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_so_a0_hr_a0 = {
    .fwname = "iwlwifi-so-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_AX210_HE,
};

const struct iwl_cfg iwl_cfg_quz_a0_hr_b0 = {
    .fwname = "iwlwifi-QuZ-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

static const struct pci_matchid iwx_devices[] = {
    /* Qu devices */
    {IWL_PCI_DEVICE(0x02F0, PCI_ANY_ID, iwl_qu_trans_cfg)},
    {IWL_PCI_DEVICE(0x06F0, PCI_ANY_ID, iwl_qu_trans_cfg)},

    {IWL_PCI_DEVICE(0x34F0, PCI_ANY_ID, iwl_qu_medium_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x3DF0, PCI_ANY_ID, iwl_qu_medium_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x4DF0, PCI_ANY_ID, iwl_qu_medium_latency_trans_cfg)},

    {IWL_PCI_DEVICE(0x43F0, PCI_ANY_ID, iwl_qu_long_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0xA0F0, PCI_ANY_ID, iwl_qu_long_latency_trans_cfg)},

    {IWL_PCI_DEVICE(0x2720, PCI_ANY_ID, iwl_qnj_trans_cfg)},

    {IWL_PCI_DEVICE(0x2723, PCI_ANY_ID, iwl_ax200_trans_cfg)},
    
    /* So devices */
    {IWL_PCI_DEVICE(0x2725, PCI_ANY_ID, iwl_so_trans_cfg)},
    {IWL_PCI_DEVICE(0x2726, PCI_ANY_ID, iwl_snj_trans_cfg)},
    {IWL_PCI_DEVICE(0x7A70, PCI_ANY_ID, iwl_so_long_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x7AF0, PCI_ANY_ID, iwl_so_trans_cfg)},
    {IWL_PCI_DEVICE(0x51F0, PCI_ANY_ID, iwl_so_long_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x51F1, PCI_ANY_ID, iwl_so_long_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x54F0, PCI_ANY_ID, iwl_so_long_latency_trans_cfg)},
    {IWL_PCI_DEVICE(0x7F70, PCI_ANY_ID, iwl_so_trans_cfg)},
    
    /* Ma devices */
    {IWL_PCI_DEVICE(0x2729, PCI_ANY_ID, iwl_ma_trans_cfg)},
    {IWL_PCI_DEVICE(0x7E40, PCI_ANY_ID, iwl_ma_trans_cfg)},
};

struct iwl_dev_info {
    uint16_t device;
    uint16_t subdevice;
    uint16_t mac_type;
    uint16_t rf_type;
    uint8_t mac_step;
    uint8_t rf_id;
    uint8_t no_160;
    uint8_t cores;
    uint8_t cdb;
    const struct iwl_cfg *cfg;
    const char *name;
};

#define _IWL_DEV_INFO(_device, _subdevice, _mac_type, _mac_step, _rf_type, \
              _rf_id, _no_160, _cores, _cdb, _cfg, _name)           \
    { .device = (uint16_t)(_device), .subdevice = (uint16_t)(_subdevice), .cfg = &(_cfg),  \
      .name = _name, .mac_type = (uint16_t)_mac_type, .rf_type = (uint16_t)_rf_type,       \
      .no_160 = (uint8_t)_no_160, .cores = (uint8_t)_cores, .rf_id = (uint8_t)_rf_id,           \
      .mac_step = (uint8_t)_mac_step, .cdb = (uint8_t)_cdb }

#define IWL_DEV_INFO(_device, _subdevice, _cfg, _name) \
    _IWL_DEV_INFO(_device, _subdevice, IWL_CFG_ANY, IWL_CFG_ANY,       \
              IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_ANY,  \
              IWL_CFG_NO_CDB, _cfg, _name)

const char iwl9162_name[] = "Intel(R) Wireless-AC 9162";
const char iwl9260_name[] = "Intel(R) Wireless-AC 9260";
const char iwl9260_1_name[] = "Intel(R) Wireless-AC 9260-1";
const char iwl9270_name[] = "Intel(R) Wireless-AC 9270";
const char iwl9461_name[] = "Intel(R) Wireless-AC 9461";
const char iwl9462_name[] = "Intel(R) Wireless-AC 9462";
const char iwl9560_name[] = "Intel(R) Wireless-AC 9560";
const char iwl9162_160_name[] = "Intel(R) Wireless-AC 9162 160MHz";
const char iwl9260_160_name[] = "Intel(R) Wireless-AC 9260 160MHz";
const char iwl9270_160_name[] = "Intel(R) Wireless-AC 9270 160MHz";
const char iwl9461_160_name[] = "Intel(R) Wireless-AC 9461 160MHz";
const char iwl9462_160_name[] = "Intel(R) Wireless-AC 9462 160MHz";
const char iwl9560_160_name[] = "Intel(R) Wireless-AC 9560 160MHz";

const char iwl9260_killer_1550_name[] =
    "Killer (R) Wireless-AC 1550 Wireless Network Adapter (9260NGW) 160MHz";
const char iwl9560_killer_1550i_name[] =
    "Killer (R) Wireless-AC 1550i Wireless Network Adapter (9560NGW)";
const char iwl9560_killer_1550i_160_name[] =
    "Killer(R) Wireless-AC 1550i Wireless Network Adapter (9560NGW) 160MHz";
const char iwl9560_killer_1550s_name[] =
    "Killer (R) Wireless-AC 1550s Wireless Network Adapter (9560NGW)";
const char iwl9560_killer_1550s_160_name[] =
    "Killer(R) Wireless-AC 1550s Wireless Network Adapter (9560D2W) 160MHz";

const char iwl_ax101_name[] = "Intel(R) Wi-Fi 6 AX101";
const char iwl_ax200_name[] = "Intel(R) Wi-Fi 6 AX200 160MHz";
const char iwl_ax201_name[] = "Intel(R) Wi-Fi 6 AX201 160MHz";
const char iwl_ax203_name[] = "Intel(R) Wi-Fi 6 AX203";
const char iwl_ax211_name[] = "Intel(R) Wi-Fi 6E AX211 160MHz";
const char iwl_ax221_name[] = "Intel(R) Wi-Fi 6E AX221 160MHz";
const char iwl_ax231_name[] = "Intel(R) Wi-Fi 6E AX231 160MHz";
const char iwl_ax411_name[] = "Intel(R) Wi-Fi 6E AX411 160MHz";
const char iwl_bz_name[] = "Intel(R) TBD Bz device";

const char iwl_ax200_killer_1650w_name[] =
    "Killer(R) Wi-Fi 6 AX1650w 160MHz Wireless Network Adapter (200D2W)";
const char iwl_ax200_killer_1650x_name[] =
    "Killer(R) Wi-Fi 6 AX1650x 160MHz Wireless Network Adapter (200NGW)";
const char iwl_ax201_killer_1650s_name[] =
    "Killer(R) Wi-Fi 6 AX1650s 160MHz Wireless Network Adapter (201D2W)";
const char iwl_ax201_killer_1650i_name[] =
    "Killer(R) Wi-Fi 6 AX1650i 160MHz Wireless Network Adapter (201NGW)";
const char iwl_ax210_killer_1675w_name[] =
    "Killer(R) Wi-Fi 6E AX1675w 160MHz Wireless Network Adapter (210D2W)";
const char iwl_ax210_killer_1675x_name[] =
    "Killer(R) Wi-Fi 6E AX1675x 160MHz Wireless Network Adapter (210NGW)";
const char iwl_ax211_killer_1675s_name[] =
    "Killer(R) Wi-Fi 6E AX1675s 160MHz Wireless Network Adapter (211NGW)";
const char iwl_ax211_killer_1675i_name[] =
    "Killer(R) Wi-Fi 6E AX1675i 160MHz Wireless Network Adapter (211NGW)";
const char iwl_ax411_killer_1690s_name[] =
    "Killer(R) Wi-Fi 6E AX1690s 160MHz Wireless Network Adapter (411D2W)";
const char iwl_ax411_killer_1690i_name[] =
    "Killer(R) Wi-Fi 6E AX1690i 160MHz Wireless Network Adapter (411NGW)";

const struct iwl_cfg iwl_ax200_cfg_cc = {
    .fwname = "iwlwifi-cc-a0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_qnj_b0_hr_b0_cfg = {
    .fwname = "iwlwifi-QuQnj-b0-hr-b0-48.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwlax210_2ax_cfg_so_jf_b0 = {
    .name = "Intel(R) Wireless-AC 9560 160MHz",
    .fwname = "iwlwifi-so-a0-jf-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_AX210,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwl_ax201_cfg_qu_hr = {
    .name = "Intel(R) Wi-Fi 6 AX201 160MHz",
    .fwname = "iwlwifi-Qu-b0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg killer1650s_2ax_cfg_qu_b0_hr_b0 = {
    .name = "Killer(R) Wi-Fi 6 AX1650s 160MHz Wireless Network Adapter (201NGW)",
    .fwname = "iwlwifi-Qu-b0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg killer1650i_2ax_cfg_qu_b0_hr_b0 = {
    .name = "Killer(R) Wi-Fi 6 AX1650i 160MHz Wireless Network Adapter (201D2W)",
    .fwname = "iwlwifi-Qu-b0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg killer1650s_2ax_cfg_qu_c0_hr_b0 = {
    .name = "Killer(R) Wi-Fi 6 AX1650s 160MHz Wireless Network Adapter (201NGW)",
    .fwname = "iwlwifi-Qu-c0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg killer1650i_2ax_cfg_qu_c0_hr_b0 = {
    .name = "Killer(R) Wi-Fi 6 AX1650i 160MHz Wireless Network Adapter (201D2W)",
    .fwname = "iwlwifi-Qu-c0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_ax201_cfg_quz_hr = {
    .name = "Intel(R) Wi-Fi 6 AX201 160MHz",
    .fwname = "iwlwifi-QuZ-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
         * This device doesn't support receiving BlockAck with a large bitmap
         * so we need to restrict the size of transmitted aggregation to the
         * HT size; mac80211 would otherwise pick the HE max (256) by default.
         */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_ax1650s_cfg_quz_hr = {
    .name = "Killer(R) Wi-Fi 6 AX1650s 160MHz Wireless Network Adapter (201D2W)",
    .fwname = "iwlwifi-QuZ-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
         * This device doesn't support receiving BlockAck with a large bitmap
         * so we need to restrict the size of transmitted aggregation to the
         * HT size; mac80211 would otherwise pick the HE max (256) by default.
         */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_ax1650i_cfg_quz_hr = {
    .name = "Killer(R) Wi-Fi 6 AX1650i 160MHz Wireless Network Adapter (201NGW)",
    .fwname = "iwlwifi-QuZ-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    /*
         * This device doesn't support receiving BlockAck with a large bitmap
         * so we need to restrict the size of transmitted aggregation to the
         * HT size; mac80211 would otherwise pick the HE max (256) by default.
         */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

/*
* All JF radio modules are part of the 9000 series, but the MAC part
* looks more like 22000.  That's why this device is here, but called
* 9560 nevertheless.
*/
const struct iwl_cfg iwl9560_qu_b0_jf_b0_cfg = {
    .fwname = "iwlwifi-Qu-b0-jf-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwl9560_qu_c0_jf_b0_cfg = {
    .fwname = "iwlwifi-Qu-c0-jf-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwl9560_quz_a0_jf_b0_cfg = {
    .fwname = "iwlwifi-QuZ-a0-jf-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwl9560_qnj_b0_jf_b0_cfg = {
    .fwname = "iwlwifi-QuQnj-b0-jf-b0-48.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_NON_HE,
};

const struct iwl_cfg iwl_qu_b0_hr1_b0 = {
    .fwname = "iwlwifi-Qu-b0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 1,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_qu_b0_hr_b0 = {
    .fwname = "iwlwifi-Qu-b0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_qu_c0_hr_b0 = {
    .fwname = "iwlwifi-Qu-c0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_qu_c0_hr1_b0 = {
    .fwname = "iwlwifi-Qu-c0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 1,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_quz_a0_hr1_b0 = {
    .fwname = "iwlwifi-QuZ-a0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 1,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

const struct iwl_cfg iwl_ax201_cfg_qu_c0_hr_b0 = {
    .name = "Intel(R) Wi-Fi 6 AX201 160MHz",
    .fwname = "iwlwifi-Qu-c0-hr-b0-68.ucode",
    .device_family = IWX_DEVICE_FAMILY_22000,
    .tx_with_siso_diversity = 0,
    .uhb_supported = 0,
    /*
     * This device doesn't support receiving BlockAck with a large bitmap
     * so we need to restrict the size of transmitted aggregation to the
     * HT size; mac80211 would otherwise pick the HE max (256) by default.
     */
    .max_tx_agg_size = IEEE80211_MAX_AMPDU_BUF_HT,
    .num_rbds = IWL_NUM_RBDS_22000_HE,
};

static const struct iwl_dev_info iwl_dev_info_table[] = {
    /* AX200 */
    IWL_DEV_INFO(0x2723, IWL_CFG_ANY, iwl_ax200_cfg_cc, iwl_ax200_name),
    IWL_DEV_INFO(0x2723, 0x1653, iwl_ax200_cfg_cc, iwl_ax200_killer_1650w_name),
    IWL_DEV_INFO(0x2723, 0x1654, iwl_ax200_cfg_cc, iwl_ax200_killer_1650x_name),
    IWL_DEV_INFO(0x51F0, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x51F0, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x51F1, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x54F0, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x54F0, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x7A70, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x7A70, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x7AF0, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x7AF0, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    
    /* Qu with Hr */
    IWL_DEV_INFO(0x43F0, 0x0070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x43F0, 0x0074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x43F0, 0x0078, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x43F0, 0x007C, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x43F0, 0x1651, killer1650s_2ax_cfg_qu_b0_hr_b0, iwl_ax201_killer_1650s_name),
    IWL_DEV_INFO(0x43F0, 0x1652, killer1650i_2ax_cfg_qu_b0_hr_b0, iwl_ax201_killer_1650i_name),
    IWL_DEV_INFO(0x43F0, 0x2074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x43F0, 0x4070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x0070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x0074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x0078, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x007C, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x0A10, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x1651, killer1650s_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0xA0F0, 0x1652, killer1650i_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0xA0F0, 0x2074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x4070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0xA0F0, 0x6074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x0070, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x0074, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x6074, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x0078, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x007C, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x0310, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x1651, iwl_ax1650s_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x1652, iwl_ax1650i_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x2074, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x02F0, 0x4070, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x0070, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x0074, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x0078, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x007C, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x0310, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x1651, iwl_ax1650s_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x1652, iwl_ax1650i_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x2074, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x06F0, 0x4070, iwl_ax201_cfg_quz_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x0070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x0074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x0078, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x007C, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x0310, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x1651, killer1650s_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x34F0, 0x1652, killer1650i_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x34F0, 0x2074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x34F0, 0x4070, iwl_ax201_cfg_qu_hr, NULL),
    
    IWL_DEV_INFO(0x3DF0, 0x0070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x0074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x0078, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x007C, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x0310, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x1651, killer1650s_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x3DF0, 0x1652, killer1650i_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x3DF0, 0x2074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x3DF0, 0x4070, iwl_ax201_cfg_qu_hr, NULL),
    
    IWL_DEV_INFO(0x4DF0, 0x0070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x0074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x0078, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x007C, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x0310, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x1651, killer1650s_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x4DF0, 0x1652, killer1650i_2ax_cfg_qu_b0_hr_b0, NULL),
    IWL_DEV_INFO(0x4DF0, 0x2074, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x4070, iwl_ax201_cfg_qu_hr, NULL),
    IWL_DEV_INFO(0x4DF0, 0x6074, iwl_ax201_cfg_qu_hr, NULL),
    
    /* Qu with JF */
    IWL_DEV_INFO(0x06f0, 0x1551, iwl9560_quz_a0_jf_b0_cfg, iwl9560_killer_1550s_160_name),
    IWL_DEV_INFO(0x06f0, 0x1552, iwl9560_quz_a0_jf_b0_cfg, iwl9560_killer_1550i_160_name),

    /* So with HR */
    IWL_DEV_INFO(0x2725, 0x0090, iwlax211_2ax_cfg_so_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x0020, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x2020, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x0024, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x0310, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x0510, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x0A10, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0xE020, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0xE024, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x4020, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x6020, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x6024, iwlax210_2ax_cfg_ty_gf_a0, NULL),
    IWL_DEV_INFO(0x2725, 0x1673, iwlax210_2ax_cfg_ty_gf_a0, iwl_ax210_killer_1675w_name),
    IWL_DEV_INFO(0x2725, 0x1674, iwlax210_2ax_cfg_ty_gf_a0, iwl_ax210_killer_1675x_name),
    IWL_DEV_INFO(0x7A70, 0x0090, iwlax211_2ax_cfg_so_gf_a0_long, NULL),
    IWL_DEV_INFO(0x7A70, 0x0098, iwlax211_2ax_cfg_so_gf_a0_long, NULL),
    IWL_DEV_INFO(0x7A70, 0x00B0, iwlax411_2ax_cfg_so_gf4_a0_long, NULL),
    IWL_DEV_INFO(0x7A70, 0x0310, iwlax211_2ax_cfg_so_gf_a0_long, NULL),
    IWL_DEV_INFO(0x7A70, 0x0510, iwlax211_2ax_cfg_so_gf_a0_long, NULL),
    IWL_DEV_INFO(0x7A70, 0x0A10, iwlax211_2ax_cfg_so_gf_a0_long, NULL),
    IWL_DEV_INFO(0x7AF0, 0x0090, iwlax211_2ax_cfg_so_gf_a0, NULL),
    IWL_DEV_INFO(0x7AF0, 0x0098, iwlax211_2ax_cfg_so_gf_a0, NULL),
    IWL_DEV_INFO(0x7AF0, 0x00B0, iwlax411_2ax_cfg_so_gf4_a0, NULL),
    IWL_DEV_INFO(0x7AF0, 0x0310, iwlax211_2ax_cfg_so_gf_a0, NULL),
    IWL_DEV_INFO(0x7AF0, 0x0510, iwlax211_2ax_cfg_so_gf_a0, NULL),
    IWL_DEV_INFO(0x7AF0, 0x0A10, iwlax211_2ax_cfg_so_gf_a0, NULL),
    
    /* SnJ with HR */
    IWL_DEV_INFO(0x2725, 0x00B0, iwlax411_2ax_cfg_sosnj_gf4_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x0090, iwlax211_cfg_snj_gf_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x0098, iwlax211_cfg_snj_gf_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x00B0, iwlax411_2ax_cfg_sosnj_gf4_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x00B4, iwlax411_2ax_cfg_sosnj_gf4_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x0510, iwlax211_cfg_snj_gf_a0, NULL),
    IWL_DEV_INFO(0x2726, 0x1651, iwl_cfg_snj_hr_b0, iwl_ax201_killer_1650s_name),
    IWL_DEV_INFO(0x2726, 0x1652, iwl_cfg_snj_hr_b0, iwl_ax201_killer_1650i_name),
    IWL_DEV_INFO(0x2726, 0x1691, iwlax411_2ax_cfg_sosnj_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x2726, 0x1692, iwlax411_2ax_cfg_sosnj_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x7F70, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x7F70, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    IWL_DEV_INFO(0x7AF0, 0x1691, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690s_name),
    IWL_DEV_INFO(0x7AF0, 0x1692, iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_killer_1690i_name),
    /* SO with GF2 */
    IWL_DEV_INFO(0x2726, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x2726, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),
    IWL_DEV_INFO(0x51F0, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x51F0, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),
    IWL_DEV_INFO(0x54F0, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x54F0, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),
    IWL_DEV_INFO(0x7A70, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x7A70, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),
    IWL_DEV_INFO(0x7AF0, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x7AF0, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),
    IWL_DEV_INFO(0x7F70, 0x1671, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x7F70, 0x1672, iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_killer_1675i_name),

    /* MA with GF2 */
    IWL_DEV_INFO(0x7E40, 0x1671, iwl_cfg_ma_a0_gf_a0, iwl_ax211_killer_1675s_name),
    IWL_DEV_INFO(0x7E40, 0x1672, iwl_cfg_ma_a0_gf_a0, iwl_ax211_killer_1675i_name),

    /* Qu with Jf */
    /* Qu B step */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9462_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9560_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1551,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9560_killer_1550s_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1552,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_b0_jf_b0_cfg, iwl9560_killer_1550i_name),
    
    /* Qu C step */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9462_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9560_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1551,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9560_killer_1550s_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1552,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qu_c0_jf_b0_cfg, iwl9560_killer_1550i_name),
    
    /* QuZ */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9462_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9560_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1551,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9560_killer_1550s_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1552,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_quz_a0_jf_b0_cfg, iwl9560_killer_1550i_name),
    
    /* QnJ */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9462_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9560_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1551,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9560_killer_1550s_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, 0x1552,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl9560_qnj_b0_jf_b0_cfg, iwl9560_killer_1550i_name),
    
    /* Qu with Hr */
    /* Qu B step */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_qu_b0_hr1_b0, iwl_ax101_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_qu_b0_hr_b0, iwl_ax203_name),
    
    /* Qu C step */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_qu_c0_hr1_b0, iwl_ax101_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QU, IWX_SILICON_C_STEP,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_qu_c0_hr_b0, iwl_ax203_name),
    
    /* QuZ */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_quz_a0_hr1_b0, iwl_ax101_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QUZ, IWX_SILICON_B_STEP,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_quz_a0_hr_b0, iwl_ax203_name),
    
    /* QnJ with Hr */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_QNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_qnj_b0_hr_b0_cfg, iwl_ax201_name),
    
    /* SnJ with Jf */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9462_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_jf_b0, iwl9560_name),
    
    /* SnJ with Hr */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_hr_b0, iwl_ax101_name),
    
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_hr_b0, iwl_ax201_name),
    
    /* Ma */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_MA, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_ma_a0_hr_b0, iwl_ax201_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_MA, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_ma_a0_gf_a0, iwl_ax211_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_MA, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_CDB,
                  iwl_cfg_ma_a0_gf4_a0, iwl_ax211_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_MA, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_MR, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_ma_a0_mr_a0, iwl_ax221_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_MA, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_FM, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_ma_a0_fm_a0, iwl_ax231_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SNJ, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_MR, IWL_CFG_ANY,
                  IWL_CFG_ANY, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_snj_a0_mr_a0, iwl_ax221_name),
    
    /* So with Hr */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax203_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax101_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax201_name),
    
    /* So-F with Hr */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax203_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR1, IWL_CFG_ANY,
                  IWL_CFG_NO_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax101_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_HR2, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwl_cfg_so_a0_hr_a0, iwl_ax201_name),
    
    /* So-F with Gf */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_CDB,
                  iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_name),
    
    /* SoF with JF2 */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9560_name),
    
    /* SoF with JF */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SOF, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9462_name),
    
    /* So with GF */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_NO_CDB,
                  iwlax211_2ax_cfg_so_gf_a0, iwl_ax211_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_GF, IWL_CFG_ANY,
                  IWL_CFG_160, IWL_CFG_ANY, IWL_CFG_CDB,
                  iwlax411_2ax_cfg_so_gf4_a0, iwl_ax411_name),
    
    /* So with JF2 */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9560_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF2, IWL_CFG_RF_ID_JF,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9560_name),
    
    /* So with JF */
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9461_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9462_160_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9461_name),
    _IWL_DEV_INFO(IWL_CFG_ANY, IWL_CFG_ANY,
                  IWL_CFG_MAC_TYPE_SO, IWL_CFG_ANY,
                  IWL_CFG_RF_TYPE_JF1, IWL_CFG_RF_ID_JF1_DIV,
                  IWL_CFG_NO_160, IWL_CFG_CORES_BT, IWL_CFG_NO_CDB,
                  iwlax210_2ax_cfg_so_jf_b0, iwl9462_name)
};

int ItlIwx::
iwx_match(IOPCIDevice *device)
{
    int devId = device->configRead16(kIOPCIConfigDeviceID);
    return pci_matchbyid(PCI_VENDOR_INTEL, devId, iwx_devices,
                         nitems(iwx_devices));
}

int ItlIwx::
iwx_preinit(struct iwx_softc *sc)
{
    if (!getMainWorkLoop()->inGate()) {
        return getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *arg1, void *, void *) -> IOReturn {
                ItlIwx *that = (ItlIwx *)arg0;
                return that->iwx_preinit((struct iwx_softc *)arg1);
            }, this, sc);
    }

    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = IC2IFP(ic);
    int err, generation = sc->sc_generation;
    static int attached;
    
    err = iwx_prepare_card_hw(sc);
    if (err) {
        XYLog("%s: could not initialize hardware\n", DEVNAME(sc));
        return err;
    }
    
    if (attached) {
        /* Update MAC in case the upper layers changed it. */
        IEEE80211_ADDR_COPY(sc->sc_ic.ic_myaddr,
                            ((struct arpcom *)ifp)->ac_enaddr);
        return 0;
    }
    
    err = iwx_start_hw(sc);
    if (err) {
        XYLog("%s: could not initialize hardware\n", DEVNAME(sc));
        return err;
    }
    
    err = iwx_run_init_mvm_ucode(sc, 1);
    if (generation != sc->sc_generation)
        return ENXIO;
    iwx_stop_device(sc);
    if (err)
        return err;
    
    /* Print version info and MAC address on first successful fw load. */
    attached = 1;
    XYLog("%s: hw rev 0x%x, fw ver %s, address %s\n",
          DEVNAME(sc), sc->sc_hw_rev & IWX_CSR_HW_REV_TYPE_MSK,
          sc->sc_fwver, ether_sprintf(sc->sc_nvm.hw_addr));
    
    if (sc->sc_nvm.sku_cap_11n_enable)
        iwx_setup_ht_rates(sc);
    
    if (sc->sc_nvm.sku_cap_11ac_enable)
        iwx_setup_vht_rates(sc);
    
    if (sc->sc_nvm.sku_cap_11ax_enable)
        iwx_setup_he_rates(sc);
    
    /* not all hardware can do 5GHz band */
    if (!sc->sc_nvm.sku_cap_band_52GHz_enable)
        memset(&ic->ic_sup_rates[IEEE80211_MODE_11A], 0,
               sizeof(ic->ic_sup_rates[IEEE80211_MODE_11A]));
    
    /* Configure channel information obtained from firmware. */
    ieee80211_channel_init(ifp);
    
    /* Configure MAC address. */
    err = if_setlladdr(ifp, ic->ic_myaddr);
    if (err)
        XYLog("%s: could not set MAC address (error %d)\n",
                DEVNAME(sc), err);
    
    ieee80211_media_init(ifp);
    
    return 0;
}

void ItlIwx::
iwx_attach_hook(struct device *self)
{
    struct iwx_softc *sc = (struct iwx_softc *)self;
    
    iwx_preinit(sc);
}

bool ItlIwx::
intrFilter(OSObject *object, IOFilterInterruptEventSource *src)
{
    ItlIwx *that = (ItlIwx*)object;
    IWX_WRITE(&that->com, IWX_CSR_INT_MASK, 0);
    return true;
}

bool ItlIwx::
iwx_attach(struct iwx_softc *sc, struct pci_attach_args *pa)
{
    pcireg_t reg, memtype;
    struct ieee80211com *ic = &sc->sc_ic;
    struct _ifnet *ifp = &ic->ic_if;
    int err;
    int txq_i, i, j;
    
    sc->sc_pct = pa->pa_pc;
    sc->sc_pcitag = pa->pa_tag;
    sc->sc_dmat = pa->pa_dmat;
    
    //    rw_init(&sc->ioctl_rwl, "iwxioctl");
    
    err = pci_get_capability(sc->sc_pct, sc->sc_pcitag,
                             PCI_CAP_PCIEXPRESS, &sc->sc_cap_off, NULL);
    if (err == 0) {
        XYLog("%s: PCIe capability structure not found!\n",
              DEVNAME(sc));
        return false;
    }
    
    /* Clear device-specific "PCI retry timeout" register (41h). */
    reg = pci_conf_read(sc->sc_pct, sc->sc_pcitag, 0x40);
    pci_conf_write(sc->sc_pct, sc->sc_pcitag, 0x40, reg & ~0xff00);

    /* Enable bus-mastering and hardware bug workaround. */
    reg = pci_conf_read(sc->sc_pct, sc->sc_pcitag, PCI_COMMAND_STATUS_REG);
    reg |= PCI_COMMAND_MASTER_ENABLE;
    /* if !MSI */
    if (reg & PCI_COMMAND_INTERRUPT_DISABLE) {
        reg &= ~PCI_COMMAND_INTERRUPT_DISABLE;
    }
    pci_conf_write(sc->sc_pct, sc->sc_pcitag, PCI_COMMAND_STATUS_REG, reg);
    
    memtype = pci_mapreg_type(pa->pa_pc, pa->pa_tag, PCI_MAPREG_START);
    err = pci_mapreg_map(pa, PCI_MAPREG_START, memtype, 0,
                         &sc->sc_st, &sc->sc_sh, NULL, &sc->sc_sz, 0);
    if (err) {
        XYLog("%s: can't map mem space\n", DEVNAME(sc));
        return false;
    }
    if (0) {
        sc->sc_msix = 1;
        XYLog("msix intr mode\n");
    } else if (pci_intr_map_msi(pa, &sc->ih)) {
        XYLog("%s: can't map interrupt\n", DEVNAME(sc));
        return false;
    }
    
    if (!sc->sc_msix) {
        /* Hardware bug workaround. */
        reg = pci_conf_read(sc->sc_pct, sc->sc_pcitag,
            PCI_COMMAND_STATUS_REG);
        if (reg & PCI_COMMAND_INTERRUPT_DISABLE)
            reg &= ~PCI_COMMAND_INTERRUPT_DISABLE;
        pci_conf_write(sc->sc_pct, sc->sc_pcitag,
            PCI_COMMAND_STATUS_REG, reg);
    }
    
    int msiIntrIndex = -1;
    for (int index = 0; ; index++)
    {
        int interruptType;
        int ret = pa->pa_tag->getInterruptType(index, &interruptType);
        if (ret != kIOReturnSuccess)
            break;
        if (interruptType & kIOInterruptTypePCIMessaged)
        {
            msiIntrIndex = index;
            break;
        }
    }
    if (msiIntrIndex == -1) {
        XYLog("%s: can't find MSI interrupt controller\n", DEVNAME(sc));
        return false;
    }

    if (sc->sc_msix)
        sc->sc_ih =
        IOFilterInterruptEventSource::filterInterruptEventSource(this,
                                                                 (IOInterruptEventSource::Action)&ItlIwx::iwx_intr_msix,
                                                                 &ItlIwx::intrFilter
                                                                 ,pa->pa_tag, msiIntrIndex);
    else
        sc->sc_ih = IOFilterInterruptEventSource::filterInterruptEventSource(this,
                                                                             (IOInterruptEventSource::Action)&ItlIwx::iwx_intr, &ItlIwx::intrFilter
                                                                             ,pa->pa_tag, msiIntrIndex);
    if (sc->sc_ih == NULL || pa->workloop->addEventSource(sc->sc_ih) != kIOReturnSuccess) {
        XYLog("%s: can't establish interrupt\n", DEVNAME(sc));
        return false;
    }
    sc->sc_ih->enable();
    
    /* Clear pending interrupts. */
    IWX_WRITE(sc, IWX_CSR_INT_MASK, 0);
    IWX_WRITE(sc, IWX_CSR_INT, ~0);
    IWX_WRITE(sc, IWX_CSR_FH_INT_STATUS, ~0);
    
    sc->sc_hw_rev = IWX_READ(sc, IWX_CSR_HW_REV);
    /*
     * In the 8000 HW family the format of the 4 bytes of CSR_HW_REV have
     * changed, and now the revision step also includes bit 0-1 (no more
     * "dash" value). To keep hw_rev backwards compatible - we'll store it
     * in the old format.
     */
    sc->sc_hw_rev = (sc->sc_hw_rev & 0xfff0) |
    (IWX_CSR_HW_REV_STEP(sc->sc_hw_rev << 2) << 2);
    sc->sc_hw_rf_id = IWX_READ(sc, IWX_CSR_HW_RF_ID);
    uint16_t device = sc->sc_pcitag->configRead16(kIOPCIConfigDeviceID);
    uint16_t subsystem_device = sc->sc_pcitag->configRead16(kIOPCIConfigSubSystemID);
    uint16_t subsystem_vendor = sc->sc_pcitag->configRead16(kIOPCIConfigSubSystemVendorID);
    sc->sc_hw_id = (device << 16) + subsystem_device;
    pci_match(PCI_VENDOR_INTEL, device, subsystem_vendor, subsystem_device, iwx_devices,
              nitems(iwx_devices), (void **)&com.sc_cfg_params);
    if (!com.sc_cfg_params) {
        XYLog("%s: Why??? unknown adapter type\n", DEVNAME(sc));
        return false;
    }
    for (i = 0; i < ARRAY_SIZE(iwl_dev_info_table); i++) {
        const struct iwl_dev_info *dev_info = &iwl_dev_info_table[i];
        if ((dev_info->device == (u16)IWL_CFG_ANY ||
             dev_info->device == device) &&
            (dev_info->subdevice == (u16)IWL_CFG_ANY ||
             dev_info->subdevice == subsystem_device) &&
            (dev_info->mac_type == (u16)IWL_CFG_ANY ||
             dev_info->mac_type ==
             CSR_HW_REV_TYPE(sc->sc_hw_rev)) &&
            (dev_info->mac_step == (u8)IWL_CFG_ANY ||
             dev_info->mac_step ==
             IWX_CSR_HW_REV_STEP(sc->sc_hw_rev)) &&
            (dev_info->rf_type == (u16)IWL_CFG_ANY ||
             dev_info->rf_type ==
             CSR_HW_RFID_TYPE(sc->sc_hw_rf_id)) &&
            (dev_info->cdb == IWL_CFG_NO_CDB ||
             CSR_HW_RFID_IS_CDB(sc->sc_hw_rf_id)) &&
            (dev_info->rf_id == (u8)IWL_CFG_ANY ||
             dev_info->rf_id ==
             IWL_SUBDEVICE_RF_ID(subsystem_device)) &&
            (dev_info->no_160 == (u8)IWL_CFG_ANY ||
             dev_info->no_160 ==
             IWL_SUBDEVICE_NO_160(subsystem_device)) &&
            (dev_info->cores == (u8)IWL_CFG_ANY ||
             dev_info->cores ==
             IWL_SUBDEVICE_CORES(subsystem_device))) {
            sc->sc_cfg = dev_info->cfg;
            if (dev_info->name)
                XYLog("Found device: %s fw: %s index: %d:%zu\n", dev_info->name, dev_info->cfg->fwname, i, ARRAY_SIZE(iwl_dev_info_table));
            else if (dev_info->cfg->name)
                XYLog("Found device cfg: %s fw: %s index: %d:%zu\n", dev_info->cfg->name, dev_info->cfg->fwname, i, ARRAY_SIZE(iwl_dev_info_table));
            else
                XYLog("Found device: No Name fw: %s index: %d:%zu\n", dev_info->cfg->fwname, i, ARRAY_SIZE(iwl_dev_info_table));
        }
    }
    /*
     * Workaround for problematic SnJ device: sometimes when
     * certain RF modules are connected to SnJ, the device ID
     * changes to QnJ's ID.  So we are using QnJ's trans_cfg until
     * here.  But if we detect that the MAC type is actually SnJ,
     * we should switch to it here to avoid problems later.
     */
    if (CSR_HW_REV_TYPE(sc->sc_hw_rev) == IWL_CFG_MAC_TYPE_SNJ)
        sc->sc_cfg_params = &iwl_so_trans_cfg;
    
    /*
     * This is a hack to switch from Qu B0 to Qu C0.  We need to
     * do this for all cfgs that use Qu B0, except for those using
     * Jf, which have already been moved to the new table.  The
     * rest must be removed once we convert Qu with Hr as well.
     */
    if (sc->sc_hw_rev == CSR_HW_REV_TYPE_QU_C0) {
        if (sc->sc_cfg == &iwl_ax201_cfg_qu_hr)
            sc->sc_cfg = &iwl_ax201_cfg_qu_c0_hr_b0;
        else if (sc->sc_cfg == &killer1650s_2ax_cfg_qu_b0_hr_b0)
            sc->sc_cfg = &killer1650s_2ax_cfg_qu_c0_hr_b0;
        else if (sc->sc_cfg == &killer1650i_2ax_cfg_qu_b0_hr_b0)
            sc->sc_cfg = &killer1650i_2ax_cfg_qu_c0_hr_b0;
    }

    /* same thing for QuZ... */
    if (sc->sc_hw_rev == CSR_HW_REV_TYPE_QUZ) {
        if (sc->sc_cfg == &iwl_ax201_cfg_qu_hr)
            sc->sc_cfg = &iwl_ax201_cfg_quz_hr;
        else if (sc->sc_cfg == &killer1650s_2ax_cfg_qu_b0_hr_b0)
            sc->sc_cfg = &iwl_ax1650s_cfg_quz_hr;
        else if (sc->sc_cfg == &killer1650i_2ax_cfg_qu_b0_hr_b0)
            sc->sc_cfg = &iwl_ax1650i_cfg_quz_hr;
    }
    if (sc->sc_cfg == NULL) {
        XYLog("No config found for PCI dev %04x/%04x, rev=0x%x, rfid=0x%x\n",
              device, subsystem_device,
              sc->sc_hw_rev, sc->sc_hw_rf_id);
        return false;
    }
    XYLog("Found PCI dev %04x/%04x, rev=0x%x, rfid=0x%x fw: %s\n",
          device, subsystem_device,
          sc->sc_hw_rev, sc->sc_hw_rf_id, sc->sc_cfg->fwname);
    sc->sc_fwname = sc->sc_cfg->fwname;
    sc->sc_device_family = sc->sc_cfg->device_family;
    sc->sc_integrated = sc->sc_cfg_params->integrated;
    sc->sc_ltr_delay = sc->sc_cfg_params->ltr_delay;
    sc->sc_low_latency_xtal = sc->sc_cfg_params->low_latency_xtal;
    sc->sc_xtal_latency = sc->sc_cfg_params->xtal_latency;
    sc->sc_tx_with_siso_diversity = sc->sc_cfg->tx_with_siso_diversity;
    sc->sc_uhb_supported = sc->sc_cfg->uhb_supported;
    
    /* Allocate DMA memory for loading firmware. */
    if (sc->sc_device_family >= IWX_DEVICE_FAMILY_AX210)
        err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->ctxt_info_dma,
                                   sizeof(struct iwx_context_info_gen3), 0);
    else
        err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->ctxt_info_dma,
                                   sizeof(struct iwx_context_info), 0);
    if (err) {
        XYLog("%s: could not allocate memory for loading firmware\n",
              DEVNAME(sc));
        return false;
    }
    
    /* Allocate interrupt cause table (ICT).*/
    err = iwx_dma_contig_alloc(sc->sc_dmat, &sc->ict_dma,
                               IWX_ICT_SIZE, 1<<IWX_ICT_PADDR_SHIFT);
    if (err) {
        XYLog("%s: could not allocate ICT table\n", DEVNAME(sc));
        goto fail0;
    }
    
    for (txq_i = 0; txq_i < nitems(sc->txq); txq_i++) {
        err = iwx_alloc_tx_ring(sc, &sc->txq[txq_i], txq_i);
        if (err) {
            XYLog("%s: could not allocate TX ring %d\n",
                  DEVNAME(sc), txq_i);
            goto fail4;
        }
    }
    
    err = iwx_alloc_rx_ring(sc, &sc->rxq);
    if (err) {
        XYLog("%s: could not allocate RX ring\n", DEVNAME(sc));
        goto fail4;
    }
    
    taskq_init();
    sc->sc_nswq = taskq_create("iwxns", 1, IPL_NET, 0);
    if (sc->sc_nswq == NULL)
        goto fail4;
    
    ic->ic_phytype = IEEE80211_T_OFDM;    /* not only, but not used */
    ic->ic_opmode = IEEE80211_M_STA;    /* default to BSS mode */
    {
        int dummy;
        mccProbe = PE_parse_boot_argn("-itlmccprobe", &dummy, sizeof(dummy));
        if (mccProbe)
            timeout_set(&mccProbeTimer, mccProbeTimeout, sc);
        awdlCoexIrConcurrentOff = PE_parse_boot_argn("-itlawdlnoirconcurrent", &dummy, sizeof(dummy));
        // -itllog (#38): keep the driver's own log ring (the last 512 lines of XYLog, which otherwise only
        // reaches kprintf) on in normal use, and publish it as ITLAWDLLog, so a failed wake or firmware restart
        // can be read back afterwards with ioreg. Works with or without the AirDrop flags.
        if (PE_parse_boot_argn("-itllog", &dummy, sizeof(dummy)) && !itlLogOn) {
            itlLogOn = true;
            if (OSSerializer *live = OSSerializer::forTarget(nullptr, itlLogSerialize)) {
                IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLLog", live);
                live->release();
            }
        }
        awdlCoexProbe = itlAWDLBuildAllowed() && PE_parse_boot_argn("-itlawdlcoexprobe", &dummy, sizeof(dummy)) &&
            !PE_parse_boot_argn("-itlawdlrx", &dummy, sizeof(dummy));
        // A new attach in the same loaded image starts with its timers allowed again.
        awdlStopping = false;
        awdlRawSamples = PE_parse_boot_argn("-itlawdlsamples", &dummy, sizeof(dummy));
        awdlCoexRx = awdlCoexProbe && PE_parse_boot_argn("-itlawdlcoexrx", &dummy, sizeof(dummy));
        awdlCoexTx = awdlCoexRx && PE_parse_boot_argn("-itlawdlcoextx", &dummy, sizeof(dummy));
        awdlCoexMulti = awdlCoexTx && PE_parse_boot_argn("-itlawdlcoexmulti", &dummy, sizeof(dummy));
        awdlCoexData = awdlCoexTx && PE_parse_boot_argn("-itlawdlcoexdata", &dummy, sizeof(dummy));
        awdlCoexBaTxEnabled = awdlCoexData && PE_parse_boot_argn("-itlawdlcoexbatx", &dummy, sizeof(dummy));
        // On by default since 0.6.0 (PR #47; A/B on 149/149 and 44/44 by three testers). The old opt-in
        // flag -itlawdlcoexsamechprobe is still accepted and changes nothing; -itlawdlnosamechprobe turns it off.
        awdlCoexSameChannelProbe.enabled = awdlCoexBaTxEnabled &&
            !PE_parse_boot_argn("-itlawdlnosamechprobe", &dummy, sizeof(dummy));
        awdlCoexBaPeerPauseEnabled = awdlCoexBaTxEnabled &&
            PE_parse_boot_argn("-itlawdlcoexpeerpause", &dummy, sizeof(dummy));
        awdlCoexBaTraceEnabled = awdlCoexBaTxEnabled &&
            PE_parse_boot_argn("-itlawdlcoexbatrace", &dummy, sizeof(dummy));
        awdlCoexBaRefillEnabled = awdlCoexBaTxEnabled &&
            PE_parse_boot_argn("-itlawdlcoexbarefill", &dummy, sizeof(dummy));
        awdlCoexBaFilterHysteresis = awdlCoexData &&
            PE_parse_boot_argn("-itlawdlcoexbafilterhyst", &dummy, sizeof(dummy));
        awdlCoexBaFilterBySession = PE_parse_boot_argn("-itlawdlfilterbysession", &dummy, sizeof(dummy));
        awdlCoexAwHold = awdlCoexData && PE_parse_boot_argn("-itlawdlcoexawhold", &dummy, sizeof(dummy));
        // -itlawdlcoexlowlat is disabled: on the AX211 the firmware rejected LOW_LATENCY_CMD (error 35)
        // and each listener setup then took normal Wi-Fi down with it. The flag is ignored.
        awdlCoexLowLatency = false;
        awdlCoexOrder = !PE_parse_boot_argn("-itlawdlcoexnoorder", &dummy, sizeof(dummy));
        awdlCoexAwSyncAssume = awdlCoexData && PE_parse_boot_argn("-itlawdlcoexawsync0", &dummy, sizeof(dummy));
        awdlCoexGate = !PE_parse_boot_argn("-itlawdlcoexnogate", &dummy, sizeof(dummy));
        awdlCoexAssumeZero = !PE_parse_boot_argn("-itlawdlcoexcalwait", &dummy, sizeof(dummy));
        awdlCoexPeerSchedule.assumeZero = awdlCoexAssumeZero;
        if (awdlCoexData) {
            // What made dedicated mode fast and quick to connect, for the listener beside Wi-Fi too:
            // the service-record merge (iface81), AW-timed idle sync frames (iface106), and shorter
            // interrupt coalescing (iface92). These were parsed only inside the -itlawdlrx block.
            awdlServiceMerge = PE_parse_boot_argn("-itlawdlsvcmerge", &dummy, sizeof(dummy));
            awdlAwSync = PE_parse_boot_argn("-itlawdlawsync", &dummy, sizeof(dummy));
            int coexCoalescing = -1;
            if (PE_parse_boot_argn("itlawdlintcoal", &coexCoalescing, sizeof(coexCoalescing)) &&
                coexCoalescing >= IWX_HOST_INT_TIMEOUT_MIN && coexCoalescing <= IWX_HOST_INT_TIMEOUT_MAX)
                awdlIntCoalescing = uint8_t(coexCoalescing);
        }
        // Bluetooth coexistence mode, for both AWDL modes (#19): it used to be read only inside the
        // -itlawdlrx block below, so itlawdlbtcoex=1 did nothing beside normal Wi-Fi.
        int requestedCoexBt = -1;
        if (PE_parse_boot_argn("itlawdlbtcoex", &requestedCoexBt, sizeof(requestedCoexBt)))
            awdlBtCoexRequest = requestedCoexBt;
        awdlCoexSameBand = PE_parse_boot_argn("-itlawdlsameband", &dummy, sizeof(dummy));
        awdlCoexOverlap80 = PE_parse_boot_argn("-itlawdloverlap80", &dummy, sizeof(dummy));
        awdlCoexStation44 = PE_parse_boot_argn("-itlawdlsta44", &dummy, sizeof(dummy));
        awdlCoexNoSharedBa = PE_parse_boot_argn("-itlawdlnosharedba", &dummy, sizeof(dummy));
        awdlCoexMultiState = awdlCoexMulti ? "not-added" : "off";
        if (awdlCoexTx) {
            task_set(&awdlCoexTxTaskEntry, awdlCoexTxTask, sc, "awdlCoexTxTask");
            timeout_set(&awdlCoexTxTimer, awdlCoexTxTimeout, sc);
            timeout_add_msec(&awdlCoexTxTimer, kAwdlCoexTxPeriodMS);
        }
        uint32_t requestedCoexCycle = 0;
        if (awdlCoexProbe && PE_parse_boot_argn("itlawdlcoexcycle", &requestedCoexCycle, sizeof(requestedCoexCycle)) &&
            requestedCoexCycle >= 10 && requestedCoexCycle <= 3600) {
            awdlCoexCycleSecs = requestedCoexCycle;
            task_set(&awdlCoexTaskEntry, awdlCoexCycleTask, sc, "awdlCoexCycleTask");
            timeout_set(&awdlCoexTimer, awdlCoexCycleTimeout, sc);
            timeout_add_sec(&awdlCoexTimer, awdlCoexCycleSecs);
        }
        uint32_t requestedCoexFilter = 0;
        if (PE_parse_boot_argn("itlawdlcoexfilter", &requestedCoexFilter, sizeof(requestedCoexFilter)) &&
            requestedCoexFilter <= 3)
            awdlCoexFilter = requestedCoexFilter;
        else if (awdlCoexData)
            awdlCoexFilter = 3; // Data needs it; see awdlCoexMacSend.
        if (itlAWDLBuildAllowed() && PE_parse_boot_argn("-itlawdlrx", &dummy, sizeof(dummy))) {
            awdlRx = true;
            awdlQueueProbe = PE_parse_boot_argn("-itlawdlqueue", &dummy, sizeof(dummy));
            awdlRxChannel6 = PE_parse_boot_argn("-itlawdl6", &dummy, sizeof(dummy));
            awdlWant149 = awdlRxChannel6 && PE_parse_boot_argn("-itlawdlch149", &dummy, sizeof(dummy));
            awdlPeerCountryTest = PE_parse_boot_argn("-itlawdlpeercctest", &dummy, sizeof(dummy));
            awdlBackgroundScan = awdlWant149 && PE_parse_boot_argn("-itlawdlbgscan", &dummy, sizeof(dummy));
            awdlBaProbe = PE_parse_boot_argn("-itlawdlba", &dummy, sizeof(dummy));
            if (awdlBaProbe) {
                awdlBaNoPromisc = PE_parse_boot_argn("-itlawdlbanopromisc", &dummy, sizeof(dummy));
                awdlBaFilterKeepOff = awdlBaNoPromisc && PE_parse_boot_argn("-itlawdlbafilterkeepoff", &dummy, sizeof(dummy));
                awdlBaTx = PE_parse_boot_argn("-itlawdlbatx", &dummy, sizeof(dummy));
                awdlBaTx80 = awdlBaTx && PE_parse_boot_argn("-itlawdlbatx80", &dummy, sizeof(dummy));
                int requestedFixedMcs = -1;
                if (awdlBaTx80 && PE_parse_boot_argn("itlawdlbatxrate", &requestedFixedMcs, sizeof(requestedFixedMcs)) &&
                    requestedFixedMcs >= 0 && requestedFixedMcs <= 9)
                    awdlBaTxFixedMcs = requestedFixedMcs;
                uint32_t requestedMinMcs = 0;
                if (awdlBaTx80 && PE_parse_boot_argn("itlawdlbatxminmcs", &requestedMinMcs, sizeof(requestedMinMcs)) &&
                    requestedMinMcs <= 9)
                    awdlBaTxMinMcs = requestedMinMcs;
                uint32_t requestedAgg = 0, requestedQueue = 0;
                if (PE_parse_boot_argn("itlawdlbatxagg", &requestedAgg, sizeof(requestedAgg)) && requestedAgg <= 7)
                    awdlBaTxAgg = requestedAgg;
                if (PE_parse_boot_argn("itlawdlbatxq", &requestedQueue, sizeof(requestedQueue)) &&
                    requestedQueue >= 4 && requestedQueue <= 128)
                    awdlBaTxQueuedMax = requestedQueue;
                uint32_t requestedMac = 0;
                if (PE_parse_boot_argn("itlawdlbamac", &requestedMac, sizeof(requestedMac)) &&
                    (requestedMac == IWX_FW_MAC_TYPE_IBSS || requestedMac == IWX_FW_MAC_TYPE_BSS_STA ||
                     requestedMac == IWX_FW_MAC_TYPE_P2P_STA))
                    awdlBaMacType = requestedMac;
            }
            if (PE_parse_boot_argn("-itlawdlht", &dummy, sizeof(dummy)))
                awdlDataRate.top = ItlAWDL::kDataRateSteps - 1;
            int requestedMoveTest = 0;
            if (PE_parse_boot_argn("itlawdlmovetest", &requestedMoveTest, sizeof(requestedMoveTest)) && requestedMoveTest > 0)
                awdlMoveTestSeconds = unsigned(requestedMoveTest);
            int requestedRepeats = 1;
            awdlMcastUnicast = PE_parse_boot_argn("-itlawdlmcastuc", &dummy, sizeof(dummy));
            awdlNoPeerPsf = PE_parse_boot_argn("-itlawdlnopsf", &dummy, sizeof(dummy));
            awdlServiceMerge = PE_parse_boot_argn("-itlawdlsvcmerge", &dummy, sizeof(dummy));
            awdlRadioProbe = PE_parse_boot_argn("-itlawdlradioprobe", &dummy, sizeof(dummy));
            awdlWide80 = PE_parse_boot_argn("-itlawdlwide80", &dummy, sizeof(dummy));
            awdlAdvertise80 = awdlWide80 && PE_parse_boot_argn("-itlawdladv80", &dummy, sizeof(dummy));
            awdlTx80 = awdlAdvertise80 && PE_parse_boot_argn("-itlawdltx80", &dummy, sizeof(dummy));
            awdlPeerPause = PE_parse_boot_argn("-itlawdlpeerpause", &dummy, sizeof(dummy));
            awdlAwSync = PE_parse_boot_argn("-itlawdlawsync", &dummy, sizeof(dummy));
            int requestedCoalescing = -1;
            if (PE_parse_boot_argn("itlawdlintcoal", &requestedCoalescing, sizeof(requestedCoalescing)) &&
                requestedCoalescing >= IWX_HOST_INT_TIMEOUT_MIN && requestedCoalescing <= IWX_HOST_INT_TIMEOUT_MAX)
                awdlIntCoalescing = uint8_t(requestedCoalescing);
            if (PE_parse_boot_argn("itlawdlmcastrepeat", &requestedRepeats, sizeof(requestedRepeats)))
                awdlMulticastCopies = ItlAWDL::multicastRepeatsFor(requestedRepeats);
            int requestedWindow = 1;
            if (PE_parse_boot_argn("itlawdlwindow", &requestedWindow, sizeof(requestedWindow)))
                awdlWindow = ItlAWDL::txWindowFor(requestedWindow);
            int requestedBtCoex = -1;
            if (PE_parse_boot_argn("itlawdlbtcoex", &requestedBtCoex, sizeof(requestedBtCoex)))
                awdlBtCoexRequest = requestedBtCoex;
            char requestedCountry[4] = {};
            if (PE_parse_boot_argn("itlawdlcc", requestedCountry, sizeof(requestedCountry)) &&
                ItlAWDL::validCountry(requestedCountry))
                memcpy(awdlCountry, requestedCountry, sizeof(awdlCountry));
            awdlSyncProbe = PE_parse_boot_argn("-itlawdlsyncprobe", &dummy, sizeof(dummy));
            awdlSyncTrain = awdlSyncProbe && PE_parse_boot_argn("-itlawdlsynctrain", &dummy, sizeof(dummy));
            awdlFastProbe = awdlSyncTrain && PE_parse_boot_argn("-itlawdlfastprobe", &dummy, sizeof(dummy));
            awdlPeerTrain = awdlFastProbe && PE_parse_boot_argn("-itlawdlpeertrain", &dummy, sizeof(dummy));
            awdlAckProbe = awdlPeerTrain && PE_parse_boot_argn("-itlawdlackprobe", &dummy, sizeof(dummy));
            awdlMacProbe = awdlPeerTrain && PE_parse_boot_argn("-itlawdlmacaddr", &dummy, sizeof(dummy));
            awdlElicit = awdlMacProbe && PE_parse_boot_argn("-itlawdlelicit", &dummy, sizeof(dummy));
            awdlForeignControl = awdlElicit && PE_parse_boot_argn("-itlawdlackcontrol", &dummy, sizeof(dummy));
            awdlDataTx = awdlMacProbe && PE_parse_boot_argn("-itlawdldatatx", &dummy, sizeof(dummy));
            itlLogOn = true;
            if (OSSerializer *live = OSSerializer::forTarget(nullptr, itlLogSerialize)) {
                IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLLog", live);
                live->release();
            }
            if (OSSerializer *live = OSSerializer::forTarget(awdlEventLines, itlLogSerialize)) {
                IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLEvents", live);
                live->release();
            }
            if (OSSerializer *live = OSSerializer::forTarget(nullptr, awdlSessLogSerialize)) {
                IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLSessionEvents", live);
                live->release();
            }
            if (OSSerializer *live = OSSerializer::forTarget(nullptr, awdlTxLogSerialize)) {
                IORegistryEntry::getRegistryRoot()->setProperty("ITLAWDLTXEvents", live);
                live->release();
            }
            ic->ic_opmode = IEEE80211_M_MONITOR;
            task_set(&awdlRxTaskEntry, awdlRxTask, sc, "awdlRxTask");
            timeout_set(&awdlRxTimer, awdlRxTimeout, sc);
            if (awdlRxChannel6)
                awdlLog("receive test on, monitor mode, fixed channel 6; hopping disabled\n");
            else
                awdlLog("receive test on, monitor mode, channels %u and %u\n", awdlRxChannels[0], awdlRxChannels[1]);
        }
    }
    ic->ic_state = IEEE80211_S_INIT;
    
    /* Set device capabilities. */
    ic->ic_caps =
    IEEE80211_C_WEP |        /* WEP */
    IEEE80211_C_RSN |        /* WPA/RSN */
    IEEE80211_C_SCANALL |    /* device scans all channels at once */
    IEEE80211_C_SCANALLBAND |    /* device scans all bands at once */
    IEEE80211_C_MONITOR |    /* monitor mode supported */
    IEEE80211_C_SHSLOT |    /* short slot time supported */
    IEEE80211_C_SHPREAMBLE;    /* short preamble supported */
    
    ic->ic_htcaps = IEEE80211_HTCAP_SGI20;
    ic->ic_htcaps |=
    (IEEE80211_HTCAP_SMPS_DIS << IEEE80211_HTCAP_SMPS_SHIFT);
    ic->ic_htcaps |= (IEEE80211_HTCAP_CBW20_40 | IEEE80211_HTCAP_SGI40);
    ic->ic_htcaps |= IEEE80211_HTCAP_LDPC;  /* all of the gen2/gen3 cards support LDPC */
    ic->ic_htxcaps = 0;
    ic->ic_txbfcaps = 0;
    ic->ic_aselcaps = 0;
    ic->ic_ampdu_params = (IEEE80211_AMPDU_PARAM_SS_4 | 0x3 /* 64k */);
    ic->ic_caps |= (IEEE80211_C_QOS | IEEE80211_C_TX_AMPDU_SETUP_IN_HW | IEEE80211_C_TX_AMPDU | IEEE80211_C_AMSDU_IN_AMPDU);
    ic->ic_caps |= IEEE80211_C_SUPPORTS_VHT_EXT_NSS_BW;
    
    ic->ic_sup_rates[IEEE80211_MODE_11A] = ieee80211_std_rateset_11a;
    ic->ic_sup_rates[IEEE80211_MODE_11B] = ieee80211_std_rateset_11b;
    ic->ic_sup_rates[IEEE80211_MODE_11G] = ieee80211_std_rateset_11g;
    
    for (i = 0; i < nitems(sc->sc_phyctxt); i++) {
        sc->sc_phyctxt[i].id = i;
    }
    
    /* IBSS channel undefined for now. */
    ic->ic_ibss_chan = &ic->ic_channels[1];
    
    ic->ic_max_rssi = IWX_MAX_DBM - IWX_MIN_DBM;
    
    ifp->if_softc = sc;
    ifp->if_flags = IFF_BROADCAST | IFF_SIMPLEX | IFF_MULTICAST | IFF_DEBUG;
    ifp->if_ioctl = iwx_ioctl;
    ifp->if_start = iwx_start;
    ifp->if_watchdog = iwx_watchdog;
    memcpy(ifp->if_xname, DEVNAME(sc), IFNAMSIZ);
    
    if_attach(ifp);
    ieee80211_ifattach(ifp, getController());
    ieee80211_media_init(ifp);
    
#if NBPFILTER > 0
    iwx_radiotap_attach(sc);
#endif
    for (i = 0; i < nitems(sc->sc_rxba_data); i++) {
        struct iwx_rxba_data *rxba = &sc->sc_rxba_data[i];
        rxba->baid = IWX_RX_REORDER_DATA_INVALID_BAID;
        rxba->sc = sc;
        timeout_set(&rxba->session_timer, iwx_rx_ba_session_expired,
                    rxba);
        timeout_set(&rxba->reorder_buf.reorder_timer,
                    iwx_reorder_timer_expired, &rxba->reorder_buf);
        for (j = 0; j < nitems(rxba->entries); j++)
        ml_init(&rxba->entries[j].frames);
    }
    task_set(&sc->init_task, iwx_init_task, sc, "iwx_init_task");
    task_set(&sc->newstate_task, iwx_newstate_task, sc, "iwx_newstate_task");
    task_set(&sc->ba_task, iwx_ba_task, sc, "iwx_ba_task");
    task_set(&sc->mac_ctxt_task, iwx_mac_ctxt_task, sc, "iwx_mac_ctxt_task");
    task_set(&sc->chan_ctxt_task, iwx_chan_ctxt_task, sc, "iwx_chan_ctxt_task");
    
    ic->ic_node_alloc = iwx_node_alloc;
    ic->ic_bgscan_start = iwx_bgscan;
    ic->ic_set_key = iwx_set_key;
    ic->ic_delete_key = iwx_delete_key;
    
    /* Override 802.11 state transition machine. */
    sc->sc_newstate = ic->ic_newstate;
    ic->ic_newstate = iwx_newstate;
    ic->ic_updateprot = iwx_updateprot;
    ic->ic_updateslot = iwx_updateslot;
    ic->ic_updateedca = iwx_updateedca;
    ic->ic_updatedtim = iwx_updatedtim;
    ic->ic_ampdu_rx_start = iwx_ampdu_rx_start;
    ic->ic_ampdu_rx_stop = iwx_ampdu_rx_stop;
    ic->ic_ampdu_tx_start = iwx_ampdu_tx_start;
    ic->ic_ampdu_tx_stop = iwx_ampdu_tx_stop;
    ic->ic_update_chw = iwx_update_chw;
    /*
     * We cannot read the MAC address without loading the
     * firmware from disk. Postpone until mountroot is done.
     */
    //    config_mountroot(self, iwx_attach_hook);
    if (iwx_preinit(sc)) {
        goto fail5;
    }
    
    return true;
    
fail5:
    for (i = 0; i < nitems(sc->sc_rxba_data); i++) {
        struct iwx_rxba_data *rxba = &sc->sc_rxba_data[i];
        iwx_clear_reorder_buffer(sc, rxba);
    }
fail4:    while (--txq_i >= 0)
    iwx_free_tx_ring(sc, &sc->txq[txq_i]);
    iwx_free_rx_ring(sc, &sc->rxq);
fail3:    if (sc->ict_dma.vaddr != NULL)
    iwx_dma_contig_free(&sc->ict_dma);

fail0:    iwx_dma_contig_free(&sc->ctxt_info_dma);
    return false;
}

#if NBPFILTER > 0
void ItlIwx::
iwx_radiotap_attach(struct iwx_softc *sc)
{
    bpfattach(&sc->sc_drvbpf, &sc->sc_ic.ic_if, DLT_IEEE802_11_RADIO,
              sizeof (struct ieee80211_frame) + IEEE80211_RADIOTAP_HDRLEN);
    
    sc->sc_rxtap_len = sizeof sc->sc_rxtapu;
    sc->sc_rxtap.wr_ihdr.it_len = htole16(sc->sc_rxtap_len);
    sc->sc_rxtap.wr_ihdr.it_present = htole32(IWX_RX_RADIOTAP_PRESENT);
    
    sc->sc_txtap_len = sizeof sc->sc_txtapu;
    sc->sc_txtap.wt_ihdr.it_len = htole16(sc->sc_txtap_len);
    sc->sc_txtap.wt_ihdr.it_present = htole32(IWX_TX_RADIOTAP_PRESENT);
}
#endif

void ItlIwx::
iwx_init_task(void *arg1)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwx_softc *sc = (struct iwx_softc *)arg1;
    ItlIwx *that = container_of(sc, ItlIwx, com);
    if (!that->getMainWorkLoop()->inGate()) {
        that->getMainCommandGate()->runAction(
            [](OSObject *, void *arg0, void *, void *, void *) -> IOReturn {
                iwx_init_task(arg0);
                return kIOReturnSuccess;
            }, arg1);
        return;
    }
    struct _ifnet *ifp = &sc->sc_ic.ic_if;

    int s = splnet();
    int generation = sc->sc_generation;
    int fatal = (sc->sc_flags & (IWX_FLAG_HW_ERR | IWX_FLAG_RFKILL));
    
    //    rw_enter_write(&sc->ioctl_rwl);
    if (generation != sc->sc_generation) {
        //        rw_exit(&sc->ioctl_rwl);
        splx(s);
        return;
    }
    
    if (ifp->if_flags & IFF_RUNNING)
        that->iwx_stop(ifp);
    else
        sc->sc_flags &= ~IWX_FLAG_HW_ERR;
    
    if (!fatal && (ifp->if_flags & (IFF_UP | IFF_RUNNING)) == IFF_UP)
#ifdef AIRPORT_WCL
    {
        int error = that->iwx_init(ifp);
        if (error && error != ENXIO && !(ifp->if_flags & IFF_RUNNING)) {
            sc->sc_ic.ic_wcl_mac_reconfig = false;
            ifp->if_flags &= ~IFF_UP;
            if (sc->sc_ic.ic_event_handler)
                sc->sc_ic.ic_event_handler(&sc->sc_ic, IEEE80211_EVT_DRIVER_STOPPED, NULL);
        }
    }
#else
        that->iwx_init(ifp);
#endif
    
    //    rw_exit(&sc->ioctl_rwl);
    splx(s);
}

int ItlIwx::
iwx_resume(struct iwx_softc *sc)
{
    pcireg_t reg;
    
    /* Clear device-specific "PCI retry timeout" register (41h). */
    reg = pci_conf_read(sc->sc_pct, sc->sc_pcitag, 0x40);
    pci_conf_write(sc->sc_pct, sc->sc_pcitag, 0x40, reg & ~0xff00);
    
    if (!sc->sc_msix) {
        /* Hardware bug workaround. */
        reg = pci_conf_read(sc->sc_pct, sc->sc_pcitag,
                            PCI_COMMAND_STATUS_REG);
        if (reg & PCI_COMMAND_INTERRUPT_DISABLE)
            reg &= ~PCI_COMMAND_INTERRUPT_DISABLE;
        pci_conf_write(sc->sc_pct, sc->sc_pcitag,
                       PCI_COMMAND_STATUS_REG, reg);
    }

    iwx_enable_rfkill_int(sc);
    iwx_check_rfkill(sc);

    return iwx_prepare_card_hw(sc);
}

int ItlIwx::
iwx_activate(struct iwx_softc *sc, int act)
{
    struct _ifnet *ifp = &sc->sc_ic.ic_if;
    int err = 0;
    
    switch (act) {
        case DVACT_QUIESCE:
            /* Also cancel a firmware load that has not reached IFF_RUNNING. */
            iwx_stop(ifp);
            break;
        case DVACT_RESUME:
            err = iwx_resume(sc);
            if (err)
                XYLog("%s: could not initialize hardware\n",
                      DEVNAME(sc));
            break;
        case DVACT_WAKEUP:
            /* Hardware should be up at this point. */
            if (iwx_set_hw_ready(sc))
                task_add(systq, &sc->init_task);
            break;
    }
    
    return 0;
}
